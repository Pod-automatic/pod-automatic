"""
Modelos de Datos y Almacenamiento en Memoria para la Fase 2 (Extracción de Datos POD).

Define el esquema estandarizado de registros POD, estados de procesamiento,
métricas de calidad y la clase de almacenamiento en memoria PODMemoryStorage.
"""

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import List, Optional, Dict, Any
from datetime import datetime


class VerdictEnum(str, Enum):
    """Veredictos de auditoría de un POD."""
    VALIDO = "VÁLIDO"
    SOSPECHOSO = "SOSPECHOSO"
    REQUIERE_REVISION = "REQUIERE_REVISIÓN"


class ValidationClassification(str, Enum):
    """Categorías de clasificación inicial del motor de reglas para triaje humano (Fase 4)."""
    VALID = "VALID"
    LIKELY_VALID = "LIKELY VALID"
    REVIEW_REQUIRED = "REVIEW REQUIRED"
    POSSIBLE_ISSUE = "POSSIBLE ISSUE"
    ERROR = "ERROR"


class ProcessingStatusEnum(str, Enum):
    """Estado del ciclo de vida del procesamiento de un registro POD."""
    PENDING = "PENDING"
    PROCESSING = "PROCESSING"
    PROCESSED = "PROCESSED"
    FAILED = "FAILED"
    SKIPPED = "SKIPPED"


class DuplicateStatusEnum(str, Enum):
    """Clasificación formal de duplicidad de fotografías para la Fase 6."""
    EXACT_DUPLICATE = "Exact Duplicate"
    POSSIBLE_VISUAL_DUPLICATE = "Possible Visual Duplicate"
    UNIQUE = "Unique"


class AnomalyCode(str, Enum):
    """Códigos de anomalía detectados por Computer Vision y reglas de negocio."""
    FOTO_FALTANTE = "FOTO_FALTANTE"
    FOTO_BORROSA = "FOTO_BORROSA"
    FOTO_MUY_OSCURA = "FOTO_MUY_OSCURA"
    FOTO_SOBREEXPUESTA = "FOTO_SOBREEXPUESTA"
    FOTO_UNIFORME_TAPADA = "FOTO_UNIFORME_TAPADA"
    FOTO_DUPLICADA = "FOTO_DUPLICADA"
    INCUMPLIMIENTO_PLATAFORMA = "INCUMPLIMIENTO_PLATAFORMA"
    HORARIO_ATIPICO = "HORARIO_ATIPICO"
    FIRMA_FALTANTE = "FIRMA_FALTANTE"
    DIRECCION_INCOMPLETA = "DIRECCION_INCOMPLETA"


class PhotoRole(str, Enum):
    """Rol de cada una de las 4 fotos de un albarán de GOFO."""
    DOOR_UNIT = "door_unit"        # Puerta con número de unidad
    DOOR_GENERAL = "door_general"  # Puerta general
    BUILDING = "building"          # Edificio
    LABEL = "label"                # Etiqueta con barcode
    UNKNOWN = "unknown"            # Rol aún no identificado


# TODO(inspect): los roles reales se asignan cuando mapeemos el modal del portal con
# `python main.py inspect`. Hasta entonces el scraper deja las fotos como UNKNOWN y los
# chequeos (p. ej. OCR de dirección) se ejecutan sobre todas las fotos.


class PriorityEnum(str, Enum):
    """Prioridad de revisión humana derivada del score de riesgo total."""
    ALTA = "Alta"
    MEDIA = "Media"
    BAJA = "Baja"
    LOCKERS = "Lockers"


@dataclass
class ImageQualityMetrics:
    """Métricas cuantitativas de Computer Vision para una fotografía de entrega."""
    file_path: str
    width: int = 0
    height: int = 0
    file_size_bytes: int = 0
    file_size_kb: float = 0.0
    aspect_ratio: float = 0.0
    megapixels: float = 0.0
    blur_score: float = 0.0          # Varianza del operador Laplaciano
    mean_brightness: float = 0.0     # Luminancia media (0-255)
    std_contrast: float = 0.0        # Desviación estándar de luminancia
    perceptual_hash: str = ""        # Difference Hash (dHash) de 64 bits
    phash: str = ""                  # Perceptual DCT Hash
    ahash: str = ""                  # Average Hash
    sha256: str = ""                 # Hash criptográfico SHA-256
    is_blurry: bool = False
    is_dark: bool = False
    is_overexposed: bool = False
    is_blank_or_covered: bool = False
    is_low_resolution: bool = False
    is_corrupted: bool = False
    error_detail: str = ""


def _to_enum(enum_cls, value):
    """Convierte 'PROCESSED' / 'ProcessingStatusEnum.PROCESSED' al Enum; deja el valor si no coincide."""
    if isinstance(value, enum_cls) or value is None:
        return value
    text = str(value).split(".")[-1]
    for member in enum_cls:
        if text in (member.value, member.name):
            return member
    return value


class PODRecord:
    """
    Modelo de Dominio POD para la Fase 2.
    
    Estandariza los atributos corporativos requeridos con constructor flexible
    que soporta tanto el nuevo esquema como llamadas legacy por kwargs.
    """

    def __init__(
        self,
        tracking_number: Optional[str] = None,
        stop_number: Optional[str] = None,
        driver_name: str = "Desconocido",
        station: str = "",
        address: str = "",
        delivery_status: str = "Entregado",
        delivery_datetime: str = "",
        signature_datetime: Optional[str] = None,
        delivery_type: str = "Estándar",
        reviewer: str = "Automated POD Verifier",
        pod_review_date: Optional[str] = None,
        abnormal_status: bool = False,
        non_compliance_reason: Optional[str] = None,
        number_of_photos: int = 0,
        photo_paths: Optional[List[str]] = None,
        photo_urls: Optional[List[str]] = None,
        signature_path: Optional[str] = None,
        signature_url: Optional[str] = None,
        has_signature: bool = False,
        processing_status: ProcessingStatusEnum = ProcessingStatusEnum.PENDING,
        error_message: Optional[str] = None,
        verdict: VerdictEnum = VerdictEnum.REQUIERE_REVISION,
        quality_score: float = 100.0,
        anomalies: Optional[List[str]] = None,
        image_metrics: Optional[List[ImageQualityMetrics]] = None,
        audit_notes: str = "",
        signed_by: Optional[str] = None,
        billing_type: Optional[str] = None,
        receipt_address: Optional[str] = None,
        photo_roles: Optional[Dict[str, str]] = None,
        risk_score: Optional[float] = None,
        priority: Optional[str] = None,
        check_results: Optional[List[Dict[str, Any]]] = None,
        portal_meta: Optional[Dict[str, Any]] = None,
        **kwargs,
    ):
        # 1. Identificadores y Datos de Ruta
        self.tracking_number = tracking_number or kwargs.get("albaran", "UNKNOWN")
        self.stop_number = stop_number or kwargs.get("stop")
        self.driver_name = kwargs.get("driver") if "driver" in kwargs else driver_name
        self.station = station or kwargs.get("estacion", "")
        self.address = kwargs.get("direccion") if "direccion" in kwargs else address
        self.delivery_status = kwargs.get("estado_entrega") if "estado_entrega" in kwargs else delivery_status
        self.delivery_datetime = kwargs.get("fecha_hora") if "fecha_hora" in kwargs else delivery_datetime
        self.signature_datetime = signature_datetime or kwargs.get("hora_firma")
        self.delivery_type = kwargs.get("tipo_entrega") if "tipo_entrega" in kwargs else delivery_type

        # 2. Auditoría y Revisión
        self.reviewer = reviewer or kwargs.get("revisor", "Automated POD Verifier")
        self.pod_review_date = (
            pod_review_date
            or kwargs.get("fecha_auditoria")
            or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        )
        self.non_compliance_reason = (
            kwargs.get("razon_incumplimiento")
            if "razon_incumplimiento" in kwargs
            else non_compliance_reason
        )
        self.abnormal_status = (
            abnormal_status
            or bool(self.non_compliance_reason)
            or kwargs.get("estado_anormal", False)
        )

        # 3. Evidencias Multimedia
        self.photo_paths = list(photo_paths or kwargs.get("fotos_locales") or [])
        self.photo_urls = list(photo_urls or kwargs.get("fotos_urls") or [])
        self.number_of_photos = number_of_photos or max(len(self.photo_paths), len(self.photo_urls))
        self.signature_path = signature_path or kwargs.get("firma_local")
        self.signature_url = signature_url or kwargs.get("firma_url")
        self.has_signature = (
            has_signature
            or bool(self.signature_path or self.signature_url)
            or kwargs.get("tiene_firma", False)
        )

        # 4. Estado de Ejecución
        self.processing_status = (
            kwargs.get("estado_proceso")
            if "estado_proceso" in kwargs
            else processing_status
        )
        self.error_message = error_message or kwargs.get("mensaje_error")

        # 5. Resultados de Auditoría y Computer Vision (Fase 4)
        self.verdict = kwargs.get("veredicto") if "veredicto" in kwargs else verdict
        self.classification = (
            kwargs.get("clasificacion")
            or kwargs.get("classification")
            or (
                ValidationClassification.VALID
                if self.verdict == VerdictEnum.VALIDO
                else (
                    ValidationClassification.REVIEW_REQUIRED
                    if self.verdict == VerdictEnum.REQUIERE_REVISION
                    else ValidationClassification.POSSIBLE_ISSUE
                )
            )
        )
        self.flags = list(kwargs.get("flags") or [])
        self.quality_score = (
            kwargs.get("puntaje_calidad")
            if "puntaje_calidad" in kwargs
            else quality_score
        )
        self.anomalies = list(anomalies or kwargs.get("anomalias") or [])
        self.image_metrics = [
            m if isinstance(m, ImageQualityMetrics) else ImageQualityMetrics(**m)
            for m in (image_metrics or kwargs.get("metricas_imagenes") or [])
        ]
        self.audit_notes = audit_notes or kwargs.get("detalles_auditoria", "")

        # 5b. Campos de negocio del albarán de GOFO
        self.signed_by = signed_by                # Quién firmó / recibió
        self.billing_type = billing_type          # Tipo de facturación
        self.receipt_address = receipt_address    # Dirección de recibo (esperada)
        # Rol (PhotoRole.value) -> ruta local de la foto
        self.photo_roles: Dict[str, str] = dict(photo_roles or {})

        # 5c. Triaje por score de riesgo (0 = sin riesgo, 100 = riesgo alto)
        self.risk_score = risk_score
        self.priority = priority.value if isinstance(priority, Enum) else priority
        self.check_results: List[Dict[str, Any]] = list(check_results or [])
        from models.priorities import category_for_payload
        self.priority = category_for_payload({'priority': self.priority, 'check_results': self.check_results})

        # 5d. Datos crudos útiles del portal (GPS del POD, signDistance, podCompliance, signId...)
        self.portal_meta: Dict[str, Any] = dict(portal_meta or {})

        # Al reconstruir desde JSON/SQLite los estados llegan como texto: volver a Enum
        self.processing_status = _to_enum(ProcessingStatusEnum, self.processing_status)
        self.verdict = _to_enum(VerdictEnum, self.verdict)
        self.classification = _to_enum(ValidationClassification, self.classification)

        # 6. Trazabilidad de Duplicados (Fase 6)
        self.duplicate_status = (
            kwargs.get("duplicate_status")
            or DuplicateStatusEnum.UNIQUE.value
        )
        self.duplicate_matched_tracking = kwargs.get("duplicate_matched_tracking")
        self.duplicate_matched_photo = kwargs.get("duplicate_matched_photo")
        self.duplicate_comparisons = list(kwargs.get("duplicate_comparisons") or [])

    def to_dict(self) -> Dict[str, Any]:
        """Serializa el registro POD a diccionario para persistencia en SQLite o JSON."""
        return {
            "tracking_number": self.tracking_number,
            "stop_number": self.stop_number,
            "driver_name": self.driver_name,
            "station": self.station,
            "address": self.address,
            "delivery_status": self.delivery_status,
            "delivery_datetime": self.delivery_datetime,
            "signature_datetime": self.signature_datetime,
            "delivery_type": self.delivery_type,
            "reviewer": self.reviewer,
            "pod_review_date": self.pod_review_date,
            "abnormal_status": self.abnormal_status,
            "non_compliance_reason": self.non_compliance_reason,
            "number_of_photos": self.number_of_photos,
            "photo_paths": self.photo_paths,
            "photo_urls": self.photo_urls,
            "signature_path": self.signature_path,
            "signature_url": self.signature_url,
            "has_signature": self.has_signature,
            "processing_status": self.processing_status.value if isinstance(self.processing_status, Enum) else self.processing_status,
            "error_message": self.error_message,
            "verdict": self.verdict.value if isinstance(self.verdict, Enum) else self.verdict,
            "classification": self.classification.value if isinstance(self.classification, Enum) else self.classification,
            "flags": self.flags,
            "quality_score": self.quality_score,
            "anomalies": self.anomalies,
            "audit_notes": self.audit_notes,
            "duplicate_status": self.duplicate_status if isinstance(self.duplicate_status, str) else self.duplicate_status.value,
            "duplicate_matched_tracking": self.duplicate_matched_tracking,
            "duplicate_matched_photo": self.duplicate_matched_photo,
            "duplicate_comparisons": self.duplicate_comparisons,
            "image_metrics": [asdict(m) for m in self.image_metrics],
            "signed_by": self.signed_by,
            "billing_type": self.billing_type,
            "receipt_address": self.receipt_address,
            "photo_roles": dict(self.photo_roles),
            "risk_score": self.risk_score,
            "priority": self.priority,
            "check_results": list(self.check_results),
            "portal_meta": dict(self.portal_meta),
        }

    @property
    def expected_address(self) -> str:
        """Dirección contra la que se verifica el POD: la de recibo si existe, si no la de entrega."""
        return (self.receipt_address or self.address or "").strip()

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PODRecord":
        """Reconstruye un objeto PODRecord a partir de un diccionario."""
        return cls(**data)

    def add_flag(self, flag: str):
        """Agrega una etiqueta o tag descriptivo (ej: POSSIBLE DUPLICATE, LOW IMAGE QUALITY)."""
        if flag not in self.flags:
            self.flags.append(flag)

    def add_anomaly(self, code: AnomalyCode, description: str, penalty: float = 25.0):
        """Registra una anomalía detectada, reduce el puntaje y marca abnormal_status."""
        text = f"[{code.value}] {description}"
        if text not in self.anomalies:
            self.anomalies.append(text)
            self.quality_score = max(0.0, self.quality_score - penalty)
            self.abnormal_status = True

    def sync_photo_count(self):
        """Asegura que number_of_photos coincida con las fotos registradas."""
        self.number_of_photos = max(len(self.photo_paths), len(self.photo_urls))

    # --- Aliases para Retrocompatibilidad Total ---
    @property
    def albaran(self) -> str:
        return self.tracking_number

    @albaran.setter
    def albaran(self, value: str):
        self.tracking_number = value

    @property
    def driver(self) -> str:
        return self.driver_name

    @driver.setter
    def driver(self, value: str):
        self.driver_name = value

    @property
    def direccion(self) -> str:
        return self.address

    @direccion.setter
    def direccion(self, value: str):
        self.address = value

    @property
    def estado_entrega(self) -> str:
        return self.delivery_status

    @estado_entrega.setter
    def estado_entrega(self, value: str):
        self.delivery_status = value

    @property
    def fecha_hora(self) -> str:
        return self.delivery_datetime

    @fecha_hora.setter
    def fecha_hora(self, value: str):
        self.delivery_datetime = value

    @property
    def tipo_entrega(self) -> str:
        return self.delivery_type

    @tipo_entrega.setter
    def tipo_entrega(self, value: str):
        self.delivery_type = value

    @property
    def fotos_locales(self) -> List[str]:
        return self.photo_paths

    @fotos_locales.setter
    def fotos_locales(self, value: List[str]):
        self.photo_paths = value
        self.sync_photo_count()

    @property
    def fotos_urls(self) -> List[str]:
        return self.photo_urls

    @fotos_urls.setter
    def fotos_urls(self, value: List[str]):
        self.photo_urls = value
        self.sync_photo_count()

    @property
    def razon_incumplimiento(self) -> Optional[str]:
        return self.non_compliance_reason

    @razon_incumplimiento.setter
    def razon_incumplimiento(self, value: Optional[str]):
        self.non_compliance_reason = value
        if value and value.strip():
            self.abnormal_status = True

    @property
    def veredicto(self) -> VerdictEnum:
        return self.verdict

    @veredicto.setter
    def veredicto(self, value: VerdictEnum):
        self.verdict = value

    @property
    def puntaje_calidad(self) -> float:
        return self.quality_score

    @puntaje_calidad.setter
    def puntaje_calidad(self, value: float):
        self.quality_score = value

    @property
    def anomalias(self) -> List[str]:
        return self.anomalies

    @anomalias.setter
    def anomalias(self, value: List[str]):
        self.anomalies = value

    @property
    def metricas_imagenes(self) -> List[ImageQualityMetrics]:
        return self.image_metrics

    @metricas_imagenes.setter
    def metricas_imagenes(self, value: List[ImageQualityMetrics]):
        self.image_metrics = value

    @property
    def tiene_firma(self) -> bool:
        return self.has_signature

    @tiene_firma.setter
    def tiene_firma(self, value: bool):
        self.has_signature = value

    @property
    def firma_url(self) -> Optional[str]:
        return self.signature_url

    @firma_url.setter
    def firma_url(self, value: Optional[str]):
        self.signature_url = value
        if value:
            self.has_signature = True

    @property
    def firma_local(self) -> Optional[str]:
        return self.signature_path

    @firma_local.setter
    def firma_local(self, value: Optional[str]):
        self.signature_path = value
        if value:
            self.has_signature = True

    @property
    def detalles_auditoria(self) -> str:
        return self.audit_notes

    @detalles_auditoria.setter
    def detalles_auditoria(self, value: str):
        self.audit_notes = value

    @property
    def fecha_auditoria(self) -> str:
        return self.pod_review_date

    @fecha_auditoria.setter
    def fecha_auditoria(self, value: str):
        self.pod_review_date = value


class PODMemoryStorage:
    """
    Almacenamiento en memoria para acumular, indexar y gestionar los registros POD
    durante la ejecución antes de su exportación definitiva.
    """

    def __init__(self):
        self._records: Dict[str, PODRecord] = {}

    def add(self, record: PODRecord) -> None:
        """Guarda o actualiza un registro en memoria indexado por su tracking number."""
        record.sync_photo_count()
        self._records[record.tracking_number] = record

    def get(self, tracking_number: str) -> Optional[PODRecord]:
        """Obtiene un registro por número de tracking."""
        return self._records.get(tracking_number)

    def get_all(self) -> List[PODRecord]:
        """Retorna todos los registros acumulados en orden de inserción."""
        return list(self._records.values())

    def get_successful(self) -> List[PODRecord]:
        """Retorna aquellos registros procesados sin fallo de ejecución."""
        return [r for r in self._records.values() if r.processing_status != ProcessingStatusEnum.FAILED]

    def get_failed(self) -> List[PODRecord]:
        """Retorna registros que presentaron fallas técnicas."""
        return [r for r in self._records.values() if r.processing_status == ProcessingStatusEnum.FAILED]

    def count(self) -> int:
        """Cantidad total de registros en memoria."""
        return len(self._records)

    def clear(self) -> None:
        """Limpia el almacenamiento en memoria."""
        self._records.clear()

    def to_dict_list(self) -> List[Dict[str, Any]]:
        """Serializa todos los registros a una lista de diccionarios planos."""
        serialized = []
        for r in self._records.values():
            serialized.append({
                "tracking_number": r.tracking_number,
                "stop_number": r.stop_number,
                "driver_name": r.driver_name,
                "station": r.station,
                "address": r.address,
                "delivery_status": r.delivery_status,
                "delivery_datetime": r.delivery_datetime,
                "signature_datetime": r.signature_datetime,
                "delivery_type": r.delivery_type,
                "reviewer": r.reviewer,
                "pod_review_date": r.pod_review_date,
                "abnormal_status": r.abnormal_status,
                "non_compliance_reason": r.non_compliance_reason,
                "number_of_photos": r.number_of_photos,
                "photo_paths": "; ".join(r.photo_paths),
                "processing_status": r.processing_status.value,
                "error_message": r.error_message,
                "verdict": r.verdict.value,
                "quality_score": r.quality_score,
            })
        return serialized
