"""Categorías de revisión; Lockers de Amazon no pertenece a Alta/Media/Baja."""
REVIEW_CATEGORIES = ('Alta', 'Media', 'Lockers')
ALL_CATEGORIES = ('Alta', 'Media', 'Baja', 'Lockers')


def category_for_payload(payload):
    priority = payload.get('priority')
    if priority is None:
        return None
    hub = payload.get('hub') or payload.get('detection') == 'amazon_hub' or any(
        r.get('check') == 'amazon_hub' and r.get('applicable', True)
        for r in payload.get('check_results') or [] if isinstance(r, dict))
    return 'Lockers' if hub else priority
