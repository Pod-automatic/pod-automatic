"""
Sincronización con el portal web (trackingint.com/portal), 05/10/2026.

- Envía los albaranes Alta / Media con su tarjeta (la misma imagen de la página local, en JPG) y retira de la web
  los que el script vuelve a calificar como Baja (si nadie los revisó todavía).
- Envía las marcas hechas en la página local (reportado / descartado), mientras se usen las dos.
- Baja las marcas hechas en la web y las guarda en report_status.db: siguen siendo casos guía para
  `main.py limpiar` y tools/evaluar_dia.py.

Todo pasa por una bandeja de salida en SQLite (storage/portal_outbox.db): si no hay internet o el portal falla, la
corrida sigue sin esperar y se reintenta después (cada vez más espaciado). Un hilo en segundo plano hace los envíos.
"""

import base64
import io
import json
import logging
import socket
import sqlite3
import threading
import time
import hashlib
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Callable, Dict, List, Optional

import config
from models.priorities import REVIEW_CATEGORIES, category_for_payload

logger = logging.getLogger("PODAutomation.Portal")

SEND_PRIORITIES = REVIEW_CATEGORIES
MAX_CARDS = 6              # Una tarjeta por foto (la foto grande cambia), como "Foto grande: 1 2 3" en la página local
MAX_PHOTOS = 12            # Fotos originales por albarán (19/10: TODAS las del POD, para la vista del cliente; antes eran 6)
MAX_ATTEMPTS = 8           # Un albarán que el portal rechaza por sus datos se descarta tras estos intentos
WARN_EVERY_S = 600         # Aviso de "portal caído" como mucho cada 10 min (no llenar el log)
COVERAGE_EVERY_S = 600     # 29/10: repartidores de todas las ciudades para la cobertura del portal, cada 10 min


class PortalError(Exception):
    pass


class PortalClient:
    """Llamadas HTTP a la API del portal (cabecera X-Api-Key)."""

    def __init__(self, base_url: str, api_key: str, timeout: float = 60):
        self.base = base_url.rstrip("/") + "/api/"
        self.key = api_key
        self.timeout = timeout

    def call(self, path: str, body: Optional[Dict] = None, query: Optional[Dict] = None) -> Dict:
        url = self.base + path + ("?" + urllib.parse.urlencode(query) if query else "")
        data = json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else None
        req = urllib.request.Request(url, data, {"X-Api-Key": self.key, "Content-Type": "application/json",
                                                 "User-Agent": "pod_automation"})
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                return json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            try:
                detail = json.loads(e.read().decode("utf-8"))
            except Exception:
                detail = {}
            if e.code == 422 and "errors" in detail:
                return detail          # Todos los albaranes del envío rechazados: cada uno trae su motivo
            raise PortalError(f"HTTP {e.code}: {detail.get('error') or e.reason}") from None
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            raise PortalError(f"sin conexión con el portal ({e})") from None
        except ValueError as e:
            # 29/10: respondió algo que no es JSON (p. ej. una página de bloqueo del hosting): hay conexión, no es un corte
            raise PortalError(f"respuesta inválida del portal ({e})") from None


    def download_wa_card(self, job_id: int, tracking: str) -> bytes:
        """Descarga autenticada y acotada a un albarán de la cola, sin aceptar URLs externas."""
        url = self.base + 'wa_evidence.php?' + urllib.parse.urlencode({'job': job_id, 'tracking': tracking})
        req = urllib.request.Request(url, headers={'X-Api-Key': self.key, 'User-Agent': 'pod_automation'})
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                if response.headers.get_content_type() not in ('image/jpeg', 'image/png'):
                    raise PortalError(f'Evidencia inválida para {tracking}')
                data = response.read(16 * 1024 * 1024 + 1)
                if not data or len(data) > 16 * 1024 * 1024:
                    raise PortalError(f'Evidencia vacía o demasiado grande para {tracking}')
                return data
        except urllib.error.HTTPError as e:
            raise PortalError(f'No se pudo descargar la evidencia reservada de {tracking} (HTTP {e.code})') from None
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            raise PortalError(f'No se pudo descargar la evidencia reservada de {tracking}: {e}') from None


class Outbox:
    """Bandeja de salida persistente: lo que falta enviar sobrevive a cortes y reinicios."""

    def __init__(self, path: Path = None):
        self.path = Path(path or config.PORTAL_OUTBOX_PATH)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._conn() as c:
            c.executescript("""
                CREATE TABLE IF NOT EXISTS outbox (
                    kind TEXT NOT NULL, tracking TEXT NOT NULL, day TEXT NOT NULL, body TEXT NOT NULL,
                    attempts INTEGER NOT NULL DEFAULT 0, next_try REAL NOT NULL DEFAULT 0, last_error TEXT,
                    created_at TEXT NOT NULL, PRIMARY KEY (kind, tracking, day));
                CREATE TABLE IF NOT EXISTS sent (tracking TEXT NOT NULL, day TEXT NOT NULL, PRIMARY KEY (tracking, day));
                CREATE TABLE IF NOT EXISTS state (name TEXT PRIMARY KEY, value TEXT);
                CREATE TABLE IF NOT EXISTS analysis_history (
                    worker TEXT NOT NULL, model TEXT NOT NULL, tracking TEXT NOT NULL, day TEXT NOT NULL,
                    body TEXT NOT NULL, PRIMARY KEY (worker, model, tracking, day));
            """)

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.path), timeout=30)
        conn.execute("PRAGMA journal_mode = WAL;")
        return conn

    def put(self, kind: str, tracking: str, day: str, body: Dict) -> None:
        """Agrega o reemplaza (la versión más nueva de un albarán pisa a la que esperaba envío)."""
        with self._conn() as c:
            c.execute("INSERT OR REPLACE INTO outbox (kind, tracking, day, body, created_at) VALUES (?, ?, ?, ?, ?)",
                      (kind, tracking, day, json.dumps(body, ensure_ascii=False), datetime.now().isoformat(timespec="seconds")))

    def due(self, kind: str, limit: int) -> List[Dict]:
        with self._conn() as c:
            rows = c.execute("SELECT tracking, day, body, attempts FROM outbox WHERE kind = ? AND next_try <= ? "
                             "ORDER BY created_at LIMIT ?", (kind, time.time(), limit)).fetchall()
        return [{"tracking": t, "day": d, "body": json.loads(b), "attempts": a} for t, d, b, a in rows]

    def done(self, kind: str, tracking: str, day: str, body: Dict) -> None:
        """Quita el envío solo si no llegó una versión más nueva mientras se mandaba."""
        with self._conn() as c:
            c.execute("DELETE FROM outbox WHERE kind = ? AND tracking = ? AND day = ? AND body = ?",
                      (kind, tracking, day, json.dumps(body, ensure_ascii=False)))

    def failed(self, kind: str, tracking: str, day: str, error: str, permanent: bool = False) -> None:
        with self._conn() as c:
            row = c.execute("SELECT attempts FROM outbox WHERE kind = ? AND tracking = ? AND day = ?",
                            (kind, tracking, day)).fetchone()
            if not row:
                return
            attempts = row[0] + 1
            if permanent and attempts >= MAX_ATTEMPTS:
                logger.warning(f"Portal: se descarta {tracking} ({day}) tras {attempts} rechazos: {error}")
                c.execute("DELETE FROM outbox WHERE kind = ? AND tracking = ? AND day = ?", (kind, tracking, day))
                return
            wait = min(30 * 2 ** (attempts - 1), 1800)   # 30 s, 1 min, 2 min... hasta 30 min
            c.execute("UPDATE outbox SET attempts = ?, next_try = ?, last_error = ? WHERE kind = ? AND tracking = ? AND day = ?",
                      (attempts, time.time() + wait, error[:300], kind, tracking, day))

    def mark_sent(self, tracking: str, day: str, sent: bool) -> None:
        with self._conn() as c:
            if sent:
                c.execute("INSERT OR IGNORE INTO sent VALUES (?, ?)", (tracking, day))
            else:
                c.execute("DELETE FROM sent WHERE tracking = ? AND day = ?", (tracking, day))

    def was_sent(self, tracking: str, day: str) -> bool:
        with self._conn() as c:
            return c.execute("SELECT 1 FROM sent WHERE tracking = ? AND day = ? UNION "
                             "SELECT 1 FROM outbox WHERE kind = 'pod' AND tracking = ? AND day = ?",
                             (tracking, day, tracking, day)).fetchone() is not None

    def get_state(self, name: str, default: str = "") -> str:
        with self._conn() as c:
            row = c.execute("SELECT value FROM state WHERE name = ?", (name,)).fetchone()
        return row[0] if row else default

    def set_state(self, name: str, value: str) -> None:
        with self._conn() as c:
            c.execute("INSERT OR REPLACE INTO state VALUES (?, ?)", (name, value))

    def counts(self) -> Dict[str, int]:
        with self._conn() as c:
            out = dict(c.execute("SELECT kind, COUNT(*) FROM outbox GROUP BY kind").fetchall())
            out["enviados"] = c.execute("SELECT COUNT(*) FROM sent").fetchone()[0]
        return out

    def record_analysis(self, item: Dict) -> None:
        """Historial sin fotos y envío atómico. Un reintento no duplica albaranes."""
        key = hashlib.sha256((item['worker'] + '\n' + item['model'] + '\n' + item['tracking']).encode()).hexdigest()
        body = json.dumps(item, ensure_ascii=False)
        with self._conn() as c:
            old = c.execute('SELECT body FROM analysis_history WHERE worker=? AND model=? AND tracking=? AND day=?',
                            (item['worker'], item['model'], item['tracking'], item['date'])).fetchone()
            if old and (json.loads(old[0]).get('processed_at') or 0) > (item.get('processed_at') or 0):
                return
            c.execute('INSERT OR REPLACE INTO analysis_history VALUES (?, ?, ?, ?, ?)',
                      (item['worker'], item['model'], item['tracking'], item['date'], body))
            c.execute("INSERT OR REPLACE INTO outbox (kind,tracking,day,body,created_at) VALUES ('analysis',?,?,?,?)",
                      (key, item['date'], body, datetime.now().isoformat(timespec='seconds')))

    def analysis_snapshots(self) -> List[Dict]:
        with self._conn() as c:
            # Agrupar en SQLite evita cargar todos los motivos del historial en cada aviso.
            rows = c.execute("""SELECT worker,model,json_extract(body,'$.instance'),day,COUNT(*)
                FROM analysis_history WHERE day >= date('now','-30 days')
                GROUP BY worker,model,json_extract(body,'$.instance'),day ORDER BY day DESC LIMIT 100""").fetchall()
            pending = c.execute("SELECT kind,day,body FROM outbox WHERE kind IN ('analysis','pod')").fetchall()
        groups = {tuple(r[:4]): dict(worker=r[0], model=r[1], instance=r[2], date=r[3],
                                    analyzed=r[4], pending=0, pending_errors=0) for r in rows}
        for kind, day, body in pending:
            item = json.loads(body)
            if kind == 'analysis':
                key = (item['worker'], item['model'], item['instance'], day)
                if key in groups:
                    groups[key]['pending'] += 1
            else:
                # Compatibilidad con envíos de fotos encolados antes de registrar el origen.
                worker = item.get('worker') or ('gpu' if config.PORTAL_GPU else 'pc')
                model = item.get('model') or config.VISION_MODEL
                for key, g in groups.items():
                    if key[0] == worker and key[1] == model and key[3] == day:
                        g['pending_errors'] += 1
        return list(groups.values())


def analysis_instance() -> str:
    """'equipo:corrida' (ej. 'abc123:gpu_luis'). 29/10: las dos corridas de Kaggle comparten máquina; sin la corrida el
    portal no podía separarlas en Comparar GPU y sus avisos de estado se pisaban."""
    suffix = ':' + (config.CLAIM_WORKER or 'pc')[:20]
    return socket.gethostname()[:80 - len(suffix)] + suffix


def analysis_item(payload: Dict, day: str, processed_at=None) -> Dict:
    """Origen congelado al analizar; nunca se deduce de que exista un caso en Revisión."""
    item = gpu_item(payload, day)
    item.update(worker='gpu' if config.PORTAL_GPU else 'pc',
                instance=analysis_instance(), processed_at=processed_at)
    for key, length in [('driver', 120), ('address', 255), ('detection', 40)]:
        item[key] = str(item.get(key) or '')[:length]
    item['reasons'] = [str(r)[:240] for r in item.get('reasons', [])[:6]]
    return item


DETAIL_MAX = 262144   # Igual que ANALYSIS_DETAIL_MAX del portal (inc/analysis.php)


def detail_blob(pod) -> str:
    """30/10: lo que leyó esta corrida en cada foto (OCR y modelo) y los datos del albarán, comprimido, para repuntuar el
    caso en la PC con tools/detalle_portal.py (los casos de Kaggle no quedaban en ningún lado). "" si no hay lecturas."""
    import zlib
    from dataclasses import asdict
    photos = getattr(pod, "_photo_readings", None)
    if not photos:
        return ""
    readings = []
    for p in photos:
        d = asdict(p)
        d.pop("text_regions", None)   # Cajas del texto: lo más pesado y no cambian el puntaje
        readings.append(d)
    raw = json.dumps({"v": 1, "pod": pod.to_dict(), "photos": readings}, ensure_ascii=False, default=str)
    blob = base64.b64encode(zlib.compress(raw.encode("utf-8"), 9)).decode("ascii")
    return blob if len(blob) <= DETAIL_MAX else ""


def with_detail(item: Dict, pod) -> Dict:
    if item.get("priority") in REVIEW_CATEGORIES:
        try:
            blob = detail_blob(pod)
            if blob:
                item["detail"] = blob
        except Exception as e:   # El detalle nunca frena el envío del resultado
            logger.debug("Portal: sin detalle de %s: %s", getattr(pod, "tracking_number", "?"), e)
    return item


# ---------- Qué se envía de cada albarán ----------

def main_detection(check_results: List[Dict]) -> Optional[str]:
    """La detección que más pesó (mismo orden que scoring.top_reasons): el portal la usa para proponer el tipo de error."""
    active = [r for r in check_results or [] if r.get("applicable", True) and r.get("score", 0) > 0]
    active.sort(key=lambda r: (not r.get("force_report"), -(r.get("score", 0) * r.get("weight", 1))))
    return active[0].get("check") if active else None


def _num(value) -> Optional[float]:
    """Número o None (el GPS del portal llega como texto; cualquier cosa rara se manda como 'sin dato')."""
    try:
        f = float(value)
    except (TypeError, ValueError):
        return None
    return f if f == f and abs(f) != float("inf") else None


def pod_item(payload: Dict, day: str) -> Dict:
    """Datos del albarán para el portal (payload = pod.to_dict(), lo mismo que se guarda en el checkpoint)."""
    from processing.scoring import top_reasons
    from models.pod import PODRecord
    item = {"date": day, "tracking": payload.get("tracking_number"), "priority": category_for_payload(payload)}
    if item["priority"] in SEND_PRIORITIES:
        meta = payload.get("portal_meta") or {}
        item.update({
            # 09/10: botones "Ver en mapa" / "Street View" del panel admin (GPS donde se tomó la foto y metros a la dirección)
            "pod_lat": _num(meta.get("pod_lat")), "pod_lng": _num(meta.get("pod_lng")),
            "sign_distance": _num(meta.get("sign_distance")),
            "station": payload.get("station") or "",
            "driver": " ".join((payload.get("driver_name") or "").split()),
            "driver_id": str(meta.get("driver_id") or ""),
            "address": payload.get("receipt_address") or payload.get("address") or "",
            "score": payload.get("risk_score"),
            "reasons": top_reasons(PODRecord.from_dict(payload), 4),
            "detection": main_detection(payload.get("check_results")),
            # 12/10: para que el portal junte en UNA tarjeta los paquetes repetidos (mismo repartidor, mismo lugar y al
            # menos una foto idéntica), igual que la página local
            "place_key": _place_key(payload.get("receipt_address") or payload.get("address") or ""),
            # 19/10: vista del cliente del portal: Lockers de Amazon (se juntan por repartidor), parada y hora de entrega
            "hub": item['priority'] == 'Lockers' or any(r.get("check") == "amazon_hub" and r.get("applicable", True) for r in payload.get("check_results") or []),
            "stop": str(payload.get("stop_number") or ""),
            "signed": str(payload.get("signature_datetime") or payload.get("delivery_datetime") or ""),
            "photo_keys": ",".join(sorted({m["sha256"][:16] for m in payload.get("image_metrics") or []
                                           if isinstance(m, dict) and m.get("sha256")}))[:600],
        })
    return item


def pod_processed_at(payload: Dict, analyzed_now: bool = True):
    """Hora original del análisis; un checkpoint recuperado no se convierte en un análisis nuevo."""
    saved=(payload.get('portal_meta') or {}).get('analysis_processed_at')
    if saved:
        return int(saved)
    if analyzed_now:
        return time.time_ns() // 1000
    try:
        return int(datetime.fromisoformat(payload['pod_review_date']).timestamp()*1000000)
    except (KeyError, TypeError, ValueError):
        return None


def gpu_item(payload: Dict, day: str) -> Dict:
    """Albarán de la corrida en GPU (Kaggle): igual que pod_item pero también con los Baja, y con el modelo de visión usado."""
    real = category_for_payload(payload)
    item = pod_item({**payload, "priority": "Alta"}, day)
    item["priority"] = real
    for k in ("place_key", "photo_keys", "stop", "signed"):
        item.pop(k, None)
    item["model"] = config.VISION_MODEL
    # 24/10: si una regla de la operación lo omitió (entrega en mano / casillero: puntaje forzado a 0), el portal lo muestra
    # para poder comparar contra la corrida local (caso MI17712102026272830: motivos iguales, Media 40 local vs Baja 0 en GPU)
    for r in payload.get("check_results") or []:
        if "score_sin_regla" in (r.get("details") or {}):
            item["omitted"] = {"check": r.get("check"), "why": (r.get("explanation") or "")[:240],
                               "score_without_rule": _num(r["details"].get("score_sin_regla"))}
            break
    return item


CLAIM_MAX_TRACKINGS = 100   # límites de api/claim.php por pedido
CLAIM_MAX_DONE = 200


def claim_granted(client, worker: str, day: str, trackings: List[str], done: List[str], lease_s: int = 600) -> List[str]:
    """Reparto de trabajo (25/10): pide al portal los albaranes que le tocan a esta corrida y le avisa de los ya revisados.
    El portal acepta hasta 100 albaranes y 200 "hechos" por pedido: si se acumularon más "hechos" (portal caído un rato),
    se mandan primero en pedidos aparte y los albaranes nuevos van en el último. Si algo falla, la excepción sube (el
    llamador revisa todo, como siempre) y los "hechos" que no se alcanzaron a avisar los conserva el llamador."""
    done = list(dict.fromkeys(done))
    trackings = list(dict.fromkeys(trackings))
    while len(done) > CLAIM_MAX_DONE:
        chunk, done = done[:CLAIM_MAX_DONE], done[CLAIM_MAX_DONE:]
        client.call("claim.php", {"worker": worker, "date": day, "trackings": [], "done": chunk, "lease_s": lease_s})
    granted: List[str] = []
    for i in range(0, max(1, len(trackings)), CLAIM_MAX_TRACKINGS):
        part = trackings[i:i + CLAIM_MAX_TRACKINGS]
        resp = client.call("claim.php", {"worker": worker, "date": day, "trackings": part, "done": done if i == 0 else [],
                                         "lease_s": lease_s})
        granted.extend(resp.get("granted") or [])
    return granted


def claim_some(client, worker: str, day: str, trackings: List[str], done: List[str], max_n: int,
               lease_s: int = 600):
    """29/10: muchos candidatos (en orden de preferencia) y el portal concede solo los primeros `max_n` libres, en UN pedido.
    Devuelve (concedidos, tomados): tomados = los que ya hizo o tiene otra corrida. Solo con el portal nuevo: el anterior
    ignora "max" y reservaria todos (por eso el llamador lo usa solo si claims_done() respondio)."""
    done = list(dict.fromkeys(done))
    while len(done) > CLAIM_MAX_DONE:
        chunk, done = done[:CLAIM_MAX_DONE], done[CLAIM_MAX_DONE:]
        client.call("claim.php", {"worker": worker, "date": day, "trackings": [], "done": chunk, "lease_s": lease_s})
    resp = client.call("claim.php", {"worker": worker, "date": day, "done": done, "lease_s": lease_s, "max": int(max_n),
                                     "trackings": list(dict.fromkeys(trackings))[:CLAIM_MAX_TRACKINGS]})
    if "taken" not in resp:
        raise PortalError('el portal no admite "max" en claim.php')
    return list(resp.get("granted") or []), list(resp.get("taken") or [])


def claims_done(client, day: str) -> set:
    """29/10: albaranes ya revisados hoy por cualquier corrida (una corrida recien lanzada empieza sin historia)."""
    out, after = set(), ""
    for _ in range(40):
        resp = client.call("claims_done.php", {"date": day, "after": after})
        rows = [str(t) for t in resp.get("trackings") or []]
        out.update(rows)
        if not resp.get("more") or not rows:
            break
        after = rows[-1]
    return out


def route_claim(client, worker: str, day: str, station: str, drivers: List[str], max_n: int = 1, lease_s: int = 900,
                release: List[str] = (), release_all: bool = False):
    """29/10: reparto por repartidor. Devuelve (concedidos, los que tiene otra corrida)."""
    resp = client.call("route_claim.php", {"worker": worker, "date": day, "station": station, "drivers": list(drivers),
                                           "max": int(max_n), "lease_s": int(lease_s), "release": list(release),
                                           "release_all": bool(release_all)})
    if "held" not in resp:
        raise PortalError("respuesta invalida de route_claim.php")
    return list(resp.get("granted") or []), list(resp.get("held") or [])


def _place_key(address: str) -> str:
    from export.report_server import place_key
    return place_key(address)[:160]


def requeue_day(day: str, outbox: Outbox = None, dry_run: bool = True) -> int:
    """
    Vuelve a encolar para el portal los Alta/Media ya calificados de una fecha (por ejemplo, para que los albaranes enviados
    antes del 09/10 reciban su GPS). El portal actualiza los datos sin tocar su estado (pendiente/reportado/descartado) ni
    lo cargado a mano. Sale lo mismo que en un envío normal: la tarjeta y las fotos se vuelven a mandar.
    Con dry_run=True (por defecto) solo cuenta, no encola. Devuelve cuántos son.
    """
    from export.report_server import _latest_rows, _ro
    latest = _latest_rows(day)
    wanted = {r[0]: trk for trk, r in latest.items() if r[3] is not None and r[2] in SEND_PRIORITIES}
    if not wanted:
        return 0
    if dry_run:
        return len(wanted)
    with _ro() as c:
        marks = ",".join("?" * len(wanted))
        rows = c.execute(f"SELECT rowid, payload_json FROM pod_checkpoints WHERE rowid IN ({marks})", list(wanted)).fetchall()
    outbox = outbox or Outbox()
    for rowid, payload in rows:
        outbox.put("pod", wanted[rowid], day, {"payload": json.loads(payload)})
    return len(rows)


def card_jpeg(payload: Dict, main_index: int = 0) -> bytes:
    """La tarjeta de la página local (render_card), achicada a JPG para no llenar el hosting."""
    from PIL import Image
    from export.report_card import render_card
    img = Image.open(io.BytesIO(render_card(payload, main_index))).convert("RGB")
    if img.width > config.PORTAL_CARD_MAX_WIDTH:
        img.thumbnail((config.PORTAL_CARD_MAX_WIDTH, config.PORTAL_CARD_MAX_WIDTH * 4))
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=config.PORTAL_CARD_QUALITY, optimize=True)
    return buf.getvalue()


def photo_jpeg(path: str) -> bytes:
    """Foto original achicada (lado mayor 1600 px) para el zoom del portal: ahí se leen números lejanos."""
    from PIL import Image, ImageOps
    with Image.open(path) as im:
        img = ImageOps.exif_transpose(im).convert("RGB")
    img.thumbnail((config.PORTAL_PHOTO_MAX_SIDE, config.PORTAL_PHOTO_MAX_SIDE))
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=config.PORTAL_PHOTO_QUALITY, optimize=True)
    return buf.getvalue()


def write_local_status(day: str, tracking: str, status: str) -> None:
    """Guarda en report_status.db una marca que vino de la web (sin volver a enviarla al portal)."""
    from export.report_server import set_status
    set_status(day, tracking, status, notify_portal=False)


class PortalSync:
    """Hilo en segundo plano: vacía la bandeja de salida y baja las marcas de la web."""

    def __init__(self, client: PortalClient, outbox: Outbox, status_writer: Callable[[str, str, str], None] = write_local_status,
                 card_maker: Callable[[Dict, int], bytes] = card_jpeg, batch: int = None, pull_interval: float = None,
                 photo_maker: Callable[[str], bytes] = photo_jpeg):
        self.client = client
        self.outbox = outbox
        self.status_writer = status_writer
        self.card_maker = card_maker
        self.photo_maker = photo_maker
        self.batch = batch or config.PORTAL_PUSH_BATCH
        self.pull_interval = config.PORTAL_PULL_INTERVAL_S if pull_interval is None else pull_interval
        self._stop = threading.Event()
        self._wake = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._last_warn = 0.0
        # 07/10: latido para que el portal avise si la corrida se cae o se traba. La corrida asigna esta función
        # (devuelve día, revisados, último revisado y faltantes); sin ella no se envía latido.
        self.heartbeat_info: Optional[Callable[[], Dict]] = None
        self._last_heartbeat = -1e9
        # 29/10: última lectura de la cobertura (la deja la corrida con queue_coverage; la manda este hilo)
        self._coverage: Optional[Dict] = None
        self._coverage_lock = threading.Lock()

    # --- Cobertura (29/10) ---
    def queue_coverage(self, day: str, stations: Dict[str, List[Dict]]) -> None:
        """La corrida deja los repartidores de cada ciudad (tal como los da GOFO); solo se guarda lo más nuevo."""
        with self._coverage_lock:
            self._coverage = coverage_body(day, stations, config.CLAIM_WORKER or "pc")
        self._wake.set()

    def push_coverage(self) -> bool:
        """POST coverage.php con la última lectura pendiente. Nunca frena la corrida: si falla, se reintenta en la próxima vuelta
        (salvo que mientras tanto llegue una lectura más nueva, que la reemplaza)."""
        with self._coverage_lock:
            body, self._coverage = self._coverage, None
        if not body:
            return False
        try:
            self.client.call("coverage.php", body)
            return True
        except Exception as e:
            logger.debug(f"Portal: cobertura no enviada ({e})")
            with self._coverage_lock:
                if self._coverage is None:
                    self._coverage = body
            return False

    # --- Latido ---
    def send_heartbeat(self, state: str = "running") -> bool:
        """
        POST heartbeat.php: {"state": "running"|"stopped", "host", "sent_at", "day", "reviewed_today",
        "last_reviewed_at", "backlog": {...faltantes.json...}}. Nunca frena ni ensucia el registro: si el portal
        todavía no tiene el endpoint (404) o no hay conexión, se ignora.
        """
        if not self.heartbeat_info:
            return False
        try:
            body = dict(self.heartbeat_info(), state=state, host=socket.gethostname(),
                        sent_at=datetime.now().isoformat(timespec="seconds"))
            self.client.call("heartbeat.php", body)
            return True
        except Exception as e:
            logger.debug(f"Portal: latido no enviado ({e})")
            return False

    # --- Panel de rutas (11/10) ---
    def push_panel(self, day: str = None) -> bool:
        """
        POST panel.php con el resumen de los repartidores y las entregas con problema del día (storage/route_panel.db).
        Nunca frena la corrida: si el portal todavía no tiene el endpoint (404) o no hay conexión, se ignora.
        """
        from storage import route_panel
        day = day or datetime.now().strftime("%Y-%m-%d")
        try:
            from export.report_server import panel_data   # 19/10: con "revisados" por el script (vista del administrador)
            data = panel_data(day)
        except Exception as e:
            logger.debug(f"Portal: panel sin los revisados ({e})")
            data = route_panel.load(day)
        if not data["couriers"]:
            return False
        keep_c = ("user_id", "driver", "station", "checkout", "pod", "returned", "failed", "reassigned", "delivering",
                  "revisados", "pod_rate", "updated_at")
        keep_e = ("tracking", "user_id", "driver", "station", "stop", "status", "issue", "remark", "issue_time")
        body = {"date": day, "couriers": [{k: c.get(k) for k in keep_c} for c in data["couriers"]],
                "exceptions": [{k: e.get(k) for k in keep_e} for e in data["exceptions"]]}
        try:
            self.client.call("panel.php", body)
            return True
        except Exception as e:
            logger.debug(f"Portal: panel de rutas no enviado ({e})")
            return False

    # --- Control de paquetes (19/10) ---
    def push_control(self, day: str = None) -> bool:
        """
        POST control.php con lo que calcula `python main.py control` (perdidos, devoluciones y escaneos de salida dudosos) para
        la vista del cliente / administrador del portal. Solo manda cuando hubo un control nuevo (o el contenido cambió), y,
        como el panel, nunca frena la corrida: si el portal no tiene el endpoint (404) o no hay conexión, se ignora.
        Devoluciones: todas menos "a_tiempo" (las "pendiente" van porque el portal las da por vencidas cuando pasa el plazo).
        """
        from storage import package_control
        day = day or datetime.now().strftime("%Y-%m-%d")
        data = package_control.load(day)
        if not (data["lost"] or data["returns"] or data["scans"] or data.get("roster")):
            return False
        body = {
            "date": day,
            "lost": [{"tracking": x.get("tracking"), "label": x.get("label"), "date": x.get("date"), "lost_time": x.get("lost_time"),
                      "last_scan_by": x.get("last_scan_by"), "last_out_by": x.get("last_out_by"), "station": x.get("station")}
                     for x in data["lost"]],
            "returns": [{k: x.get(k) for k in ("tracking", "driver", "station", "kind", "issue", "date", "start_time", "deadline",
                                              "outcome", "resolved_time", "resolved_by")}
                        for x in data["returns"] if x.get("outcome") != "a_tiempo"],
            "scans": [{k: x.get(k) for k in ("tracking", "driver", "station", "date", "out_time", "verdict", "scanned_by", "after_by")}
                      for x in data["scans"] if x.get("verdict") != "ok"],
        }
        signature = json.dumps(body, sort_keys=True, ensure_ascii=False)
        if signature == getattr(self, "_control_signature", None):
            return False
        try:
            self.client.call("control.php", body)
            self._control_signature = signature
            return True
        except Exception as e:
            logger.debug(f"Portal: control de paquetes no enviado ({e})")
            return False

    # --- Lo que llama la corrida ---
    def enqueue_pod(self, pod, day: str, analyzed_now: bool = True) -> None:
        """Llamado al terminar el score de cada albarán. Nunca frena la corrida."""
        try:
            if pod.risk_score is None:
                return
            try:
                if analyzed_now:
                    self.outbox.record_analysis(with_detail(analysis_item(pod.to_dict(), day, int(time.time())), pod))
                    self._wake.set()
            except Exception as e:
                logger.warning('Portal: no se pudo registrar el análisis de %s: %s', pod.tracking_number, e)
            processed_at=pod_processed_at(pod.to_dict(),analyzed_now)
            if config.PORTAL_GPU:
                self.outbox.put("pod", pod.tracking_number, day, {"payload": pod.to_dict(), "worker": "gpu", "model": config.VISION_MODEL, "processed_at": processed_at})
            elif pod.priority in SEND_PRIORITIES:
                self.outbox.put("pod", pod.tracking_number, day, {"payload": pod.to_dict(), "worker": "pc", "model": config.VISION_MODEL, "processed_at": processed_at})
            elif self.outbox.was_sent(pod.tracking_number, day):
                self.outbox.put("pod", pod.tracking_number, day, {"payload": {"tracking_number": pod.tracking_number,
                                                                              "priority": "Baja"}, "worker": "pc", "model": config.VISION_MODEL, "processed_at": processed_at})
            else:
                return
            self._wake.set()
        except Exception as e:
            logger.warning(f"Portal: no se pudo encolar {getattr(pod, 'tracking_number', '?')}: {e}")

    def enqueue_verify(self, pod, day: str) -> None:
        """Resultado de analizar un albarán que marcó la OTRA corrida (verificación cruzada). Nunca frena la corrida."""
        try:
            if pod.risk_score is not None:
                verify_day = (pod.portal_meta or {}).get('verify_day') or day
                try:
                    self.outbox.record_analysis(with_detail(analysis_item(pod.to_dict(), verify_day, int(time.time())), pod))
                except Exception as e:
                    logger.warning('Portal: no se pudo registrar el análisis cruzado: %s', e)
            self.outbox.put("verify", pod.tracking_number, day, {"payload": pod.to_dict()})
            self._wake.set()
        except Exception as e:
            logger.warning(f"Portal: no se pudo encolar la verificación de {getattr(pod, 'tracking_number', '?')}: {e}")

    def fetch_verifications(self, limit: int) -> List[Dict]:
        """Albaranes que marcó la otra corrida y esta debe verificar (el portal decide cuáles)."""
        resp = self.client.call("verify.php", {"action": "next", "worker": config.CLAIM_WORKER, "limit": limit,
                                               "priorities": config.VERIFY_PRIORITIES,
                                               "only_reported": config.VERIFY_ONLY_REPORTED})
        return resp.get("items") or []

    def report_verify_error(self, item: Dict, message: str) -> None:
        """Avisa al portal que ese albarán no se pudo verificar (para que no se pida otra vez)."""
        self.client.call("verify.php", {"action": "result", "worker": config.CLAIM_WORKER,
                                        "items": [{"date": item.get("date"), "tracking": item.get("tracking"),
                                                   "error": str(message)[:200]}]})

    def push_verify(self) -> int:
        rows = self.outbox.due("verify", 10)
        if not rows:
            return 0
        items = []
        for row in rows:
            payload = row["body"]["payload"]
            it = gpu_item(payload, row["day"])
            it["worker"] = config.CLAIM_WORKER
            it["date"] = (payload.get("portal_meta") or {}).get("verify_day") or row["day"]
            it["verify_of"] = (payload.get("portal_meta") or {}).get("verify_of")
            it.pop("cards", None)
            items.append(it)
        resp = self.client.call("verify.php", {"action": "result", "worker": config.CLAIM_WORKER, "items": items})
        rejected = {e.get("index"): e.get("error", "") for e in resp.get("errors") or []}
        ok = 0
        for i, row in enumerate(rows):
            if i in rejected:
                self.outbox.failed("verify", row["tracking"], row["day"], f"el portal lo rechazó: {rejected[i]}", permanent=True)
            else:
                self.outbox.done("verify", row["tracking"], row["day"], row["body"])
                ok += 1
        return ok

    def enqueue_status(self, day: str, tracking: str, status: str) -> None:
        self.outbox.put("status", tracking, day, {"date": day, "tracking": tracking, "status": status})
        self._wake.set()

    # --- Envíos ---
    def push_analyses(self) -> int:
        rows = self.outbox.due('analysis', 200)
        if not rows and time.monotonic() - getattr(self, '_last_analysis_status', 0) < 60:
            return 0
        snapshots = self.outbox.analysis_snapshots()
        if not rows and not snapshots:
            return 0
        # Un pedido por origen: una clave exclusiva de GPU no puede escribir resultados PC.
        worker = rows[0]['body']['worker'] if rows else ('gpu' if config.PORTAL_GPU else 'pc')
        rows = [r for r in rows if r['body']['worker'] == worker]
        try:
            resp = self.client.call('analysis.php', {'worker': worker, 'items': [r['body'] for r in rows],
                                                   'snapshots': [s for s in snapshots if s['worker'] == worker]})
            # Solo se borra lo confirmado explícitamente por el portal.
            accepted = {i for i in (resp.get('accepted') or []) if type(i) is int and 0 <= i < len(rows)}
            rejected = {e.get('index'): e.get('error', '') for e in resp.get('errors') or []}
            for i, row in enumerate(rows):
                if i in accepted:
                    self.outbox.done('analysis', row['tracking'], row['day'], row['body'])
                else:
                    self.outbox.failed('analysis', row['tracking'], row['day'], rejected.get(i) or 'sin confirmación')
            self._last_analysis_status = time.monotonic()
            return len(accepted)
        except PortalError as e:
            for row in rows:
                self.outbox.failed('analysis', row['tracking'], row['day'], str(e))
            if time.monotonic() - getattr(self, '_last_analysis_warning', 0) > WARN_EVERY_S:
                logger.warning('Portal: historial de análisis pendiente (%s). Los errores siguen su envío normal.', e)
                self._last_analysis_warning = time.monotonic()
            return 0

    def push_pods(self) -> int:
        rows = self.outbox.due("pod", self.batch)
        if not rows:
            return 0
        default_worker = 'gpu' if config.PORTAL_GPU else 'pc'
        worker = rows[0]['body'].get('worker', default_worker)
        rows = [r for r in rows if r['body'].get('worker', default_worker) == worker]
        items, sent_rows = [], []
        for row in rows:
            payload = row["body"]["payload"]
            try:
                gpu = worker == 'gpu'
                item = gpu_item(payload, row["day"]) if gpu else pod_item(payload, row["day"])
                item["processed_at"]=row["body"].get("processed_at")
                if gpu:
                    item['model'] = row['body'].get('model', config.VISION_MODEL)
                if item["priority"] in SEND_PRIORITIES:
                    paths = [x for x in payload.get("photo_paths") or [] if Path(x).exists()][:MAX_PHOTOS]
                    item["cards"] = [base64.b64encode(self.card_maker(payload, i)).decode("ascii")
                                     for i in range(max(min(len(paths), MAX_CARDS), 1))]
                    if not gpu or config.GPU_SEND_PHOTOS:   # En la prueba de GPU solo las tarjetas, salvo con el reparto (GPU_SEND_PHOTOS)
                        item["photos"] = [base64.b64encode(self.photo_maker(x)).decode("ascii") for x in paths]
            except Exception as e:
                self.outbox.failed("pod", row["tracking"], row["day"], f"no se pudo armar el envío: {e}", permanent=True)
                continue
            items.append(item)
            sent_rows.append(row)
        if not items:
            return 0
        endpoint = "ingest_gpu.php" if worker == 'gpu' else "ingest.php"
        try:
            resp = self.client.call(endpoint, {"items": items})
        except PortalError as e:
            if "HTTP 413" not in str(e):
                raise
            # El hosting rechaza envíos grandes: de a un albarán, y si uno solo no entra, sin las fotos originales
            if len(items) > 1:
                logger.warning("Portal: envío demasiado grande; desde ahora se manda de a un albarán")
                self.batch = 1
                return 0
            items[0].pop("photos", None)
            logger.warning(f"Portal: {items[0]['tracking']} no entra con sus fotos originales; se manda sin ellas")
            resp = self.client.call(endpoint, {"items": items})
        rejected = {e.get("index"): e.get("error", "") for e in resp.get("errors") or []}
        ok = 0
        for i, (row, item) in enumerate(zip(sent_rows, items)):
            if i in rejected:
                self.outbox.failed("pod", row["tracking"], row["day"], f"el portal lo rechazó: {rejected[i]}", permanent=True)
                continue
            self.outbox.done("pod", row["tracking"], row["day"], row["body"])
            self.outbox.mark_sent(row["tracking"], row["day"], item["priority"] in SEND_PRIORITIES)
            ok += 1
        return ok

    def push_statuses(self) -> int:
        rows = self.outbox.due("status", 200)
        if not rows:
            return 0
        resp = self.client.call("status.php", {"items": [r["body"] for r in rows]})
        missing = set(resp.get("missing") or [])
        for r in rows:
            if r["tracking"] in missing:
                # Aún no llegó al portal (se reintenta) o no está (Baja de la muestra): se descarta a los 8 intentos
                self.outbox.failed("status", r["tracking"], r["day"], "el albarán no está en el portal", permanent=True)
            else:
                self.outbox.done("status", r["tracking"], r["day"], r["body"])
        return len(rows) - len(missing)

    def pull_changes(self) -> int:
        n = 0
        for _ in range(10):
            since = self.outbox.get_state("pull_cursor", "")
            resp = self.client.call("changes.php", query={"since": since} if since else None)
            for it in resp.get("items") or []:
                if it.get("status") in ("pendiente", "reportado", "descartado") and it.get("tracking") and it.get("date"):
                    self.status_writer(it["date"], it["tracking"], it["status"])
                    n += 1
            # Persistir solo después de aplicar toda la página; un fallo permite repetirla.
            cursor=resp.get("cursor")
            if cursor:
                self.outbox.set_state("pull_cursor", cursor)
            if not resp.get("has_more") or not cursor or cursor == since:
                break
        self.outbox.set_state("last_pull", datetime.now().isoformat(timespec="seconds"))
        return n

    def sync_once(self, pull: bool = True) -> Dict[str, int]:
        """Una vuelta completa (también la usa `main.py portal`). Lanza PortalError si no hay conexión."""
        out = {"albaranes": 0, "marcas_enviadas": 0, "marcas_recibidas": 0}
        # Historial ligero e independiente de que se pueda construir/enviar una foto.
        try:
            for _ in range(5):
                if not self.push_analyses():
                    break
        except Exception as e:
            logger.warning('Portal: historial pendiente, se mantiene el envío de errores: %s', e)
        while True:
            n = self.push_pods()
            out["albaranes"] += n
            if not n or self._stop.is_set():
                break
        if config.VERIFY_WORK:
            while self.push_verify() and not self._stop.is_set():
                pass
        self.push_coverage()   # 29/10: también la GPU (los totales de GOFO no dependen de qué corrida siga viva)
        if config.PORTAL_GPU:   # La corrida de GPU solo sube albaranes: nada de marcas
            return out
        out["marcas_enviadas"] = self.push_statuses()
        if pull:
            out["marcas_recibidas"] = self.pull_changes()
        return out

    # --- Hilo ---
    def start(self) -> "PortalSync":
        self._thread = threading.Thread(target=self._loop, name="portal-sync", daemon=True)
        self._thread.start()
        return self

    def stop(self, timeout: float = 30) -> None:
        """Al terminar la corrida: un último intento de envío (lo que quede, sale en la próxima corrida)."""
        self._stop.set()
        self._wake.set()
        if self._thread:
            self._thread.join(timeout)
        if config.PORTAL_GPU:
            return
        self.send_heartbeat("stopped")   # Detenida a propósito: el portal no debe avisar de caída

    def _loop(self) -> None:
        last_pull = 0.0
        while True:
            wait = 5
            pull = time.monotonic() - last_pull >= self.pull_interval
            try:
                self.sync_once(pull=pull)
                if pull:
                    last_pull = time.monotonic()
            except PortalError as e:
                if time.monotonic() - self._last_warn >= WARN_EVERY_S:
                    logger.warning(f"Portal: {e}. Los envíos quedan en espera y se reintentan solos.")
                    self._last_warn = time.monotonic()
                last_pull = time.monotonic()   # No martillar al portal caído
                wait = 60
            except Exception as e:
                logger.exception(f"Portal: error inesperado en la sincronización: {e}")
            if not config.PORTAL_GPU and time.monotonic() - self._last_heartbeat >= config.PORTAL_HEARTBEAT_S:
                self.send_heartbeat()
                self.push_panel()   # 11/10: panel de rutas, con el mismo ritmo que el latido (cada 5 min)
                self.push_control()   # 19/10: control de paquetes (solo si hay un control nuevo)
                self._last_heartbeat = time.monotonic()
            if self._stop.is_set():
                return
            self._wake.wait(wait)
            self._wake.clear()


def coverage_body(day: str, stations: Dict[str, List[Dict]], worker: str) -> Dict:
    """Cuerpo de api/coverage.php: por ciudad, cada repartidor con sus entregas (checkOut / POD / en reparto) del resumen de GOFO.
    Una ciudad sin repartidores también va (el portal guarda que hoy tiene 0)."""
    def num(v):
        try:
            return int(v) if v is not None else None
        except (TypeError, ValueError):
            return None
    out = []
    for station, couriers in stations.items():
        rows = []
        for c in couriers or []:
            uid = str(c.get("userId") or "").strip()
            if not uid:
                continue
            rows.append({"user_id": uid, "driver": " ".join((c.get("driverName") or "").split()),
                         "checkout": num(c.get("checkOutPieces")), "pod": num(c.get("podPieces")),
                         "delivering": num(c.get("deliveringPieces"))})
        out.append({"station": station, "couriers": rows})
    return {"date": day, "worker": worker[:20], "stations": out}


def coverage_tick(api, sync: Optional["PortalSync"], day: str, state: Dict) -> bool:
    """29/10: cada COVERAGE_EVERY_S, desde el hilo de la corrida (Playwright no se comparte entre hilos), lee los repartidores
    de TODAS las ciudades de GOFO (1 llamada por ciudad, sin cambiar la ciudad activa) y los deja para que el hilo del portal
    los mande. Una ciudad que falla se salta; nunca frena la corrida. Devuelve True si leyó."""
    if not sync or time.monotonic() - state.get("last_coverage", -1e9) < COVERAGE_EVERY_S:
        return False
    state["last_coverage"] = time.monotonic()
    stations = {}
    for station_id, name in config.GOFO_STATION_NAMES.items():
        try:
            stations[name] = api.list_couriers(station_id, day)
        except Exception as e:
            logger.debug(f"Cobertura: no se leyó {name} ({e})")
    if stations:
        sync.queue_coverage(day, stations)
    return True


def from_config(start: bool = True) -> Optional[PortalSync]:
    """PortalSync con la configuración del .env, o None si el portal no está configurado."""
    if not config.PORTAL_SYNC_ENABLED:
        return None
    sync = PortalSync(PortalClient(config.PORTAL_URL, config.PORTAL_API_KEY), Outbox())
    return sync.start() if start else sync


def notify_status(day: str, tracking: str, status: str) -> None:
    """Marca hecha en la página local: se encola para el portal (la envía el hilo de la corrida)."""
    if config.PORTAL_SYNC_ENABLED:
        try:
            Outbox().put("status", tracking, day, {"date": day, "tracking": tracking, "status": status})
        except Exception as e:
            logger.warning(f"Portal: no se pudo encolar la marca de {tracking}: {e}")
