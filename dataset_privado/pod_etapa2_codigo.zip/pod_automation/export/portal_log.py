"""
30/10 (pedido del usuario): el registro de cada corrida (PC, Kaggle Luis, Kaggle Tracking) se ve en el portal, en
Auditoría > Registro, para ir ajustando sin tener que bajar el registro de Kaggle.

Copia lo que la corrida escribe en pantalla (stdout: avisos de la consola) y los mensajes "PODAutomation.*" (INFO o más) a
una cola en memoria; un hilo los manda a api/run_log.php cada PORTAL_LOG_EVERY_S. Nunca frena ni rompe la corrida: si el
portal no responde, las líneas esperan en la cola (con tope; lo más viejo se descarta y se avisa cuántas). Las líneas con
claves, tokens o cookies se tachan antes de salir de la máquina.
"""
import atexit
import logging
import re
import sys
import threading
import time
from collections import deque
from typing import Optional

import config

logger = logging.getLogger("PODAutomation.PortalLog")

_ANSI = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]")
# Lo que nunca debe salir de la máquina: valores de claves, tokens, cookies y contraseñas
_SECRET = re.compile(r"(?i)((?:api[_-]?key|x-api-key|token|admin-token|authorization|cookie|password|passwd|secret)"
                     r"[\"']?\s*[:=]\s*[\"']?)([^\s\"',;]+)")
_BEARER = re.compile(r"(?i)\b(bearer\s+)\S+")
MAX_LINE = 2000
BATCH = 400


def scrub(text: str) -> str:
    text = _ANSI.sub("", text).replace("\r", "")
    text = _BEARER.sub(lambda m: m.group(1) + "***", text)
    return _SECRET.sub(lambda m: m.group(1) + "***", text)[:MAX_LINE]


class PortalLog:
    def __init__(self, client, worker: str, instance: str, every_s: float = None, max_per_min: int = None,
                 max_queue: int = 20000, clock=time.time):
        self.client = client
        self.worker = worker
        self.instance = instance
        self.every_s = config.PORTAL_LOG_EVERY_S if every_s is None else every_s
        self.max_per_min = config.PORTAL_LOG_MAX_PER_MIN if max_per_min is None else max_per_min
        self.clock = clock
        self.queue = deque(maxlen=max_queue)
        self.lock = threading.Lock()
        self.seq = 0
        self.dropped = 0          # Por tope de la cola o de líneas por minuto (se avisa en el próximo envío)
        self.minute = (0, 0)      # (minuto, líneas aceptadas en ese minuto)
        self.paused_until = 0.0   # Portal sin el endpoint (404): no insistir por un rato
        self.stop_event = threading.Event()
        self.thread: Optional[threading.Thread] = None

    def add(self, level: str, text: str) -> None:
        """Una o varias líneas; nunca lanza (se llama desde print y desde logging)."""
        try:
            now = self.clock()
            with self.lock:
                for line in str(text).split("\n"):
                    line = line.rstrip()
                    if not line.strip():
                        continue
                    minute = int(now // 60)
                    if self.minute[0] != minute:
                        self.minute = (minute, 0)
                    if self.minute[1] >= self.max_per_min and level not in ("WARNING", "ERROR", "CRITICAL"):
                        self.dropped += 1
                        continue
                    self.minute = (minute, self.minute[1] + 1)
                    if len(self.queue) == self.queue.maxlen:
                        self.dropped += 1
                    self.seq += 1
                    self.queue.append({"t": round(now, 3), "s": self.seq, "lvl": level, "msg": scrub(line)})
        except Exception:
            pass

    def flush(self) -> int:
        """Manda lo que haya (de a BATCH). Devuelve las líneas enviadas; si el portal falla, vuelven a la cola."""
        sent = 0
        if self.clock() < self.paused_until:
            return 0
        while True:
            with self.lock:
                lines = [self.queue.popleft() for _ in range(min(BATCH, len(self.queue)))]
                dropped, self.dropped = self.dropped, 0
                if dropped:
                    self.seq += 1
                    lines.append({"t": round(self.clock(), 3), "s": self.seq, "lvl": "WARNING",
                                  "msg": f"(registro) {dropped} líneas no se enviaron al portal: demasiadas por minuto o cola llena"})
            if not lines:
                return sent
            try:
                self.client.call("run_log.php", {"worker": self.worker, "instance": self.instance, "lines": lines})
            except Exception as e:
                with self.lock:
                    self.queue.extendleft(reversed([l for l in lines if not l["msg"].startswith("(registro)")]))
                    self.dropped += dropped
                if "HTTP 404" in str(e):
                    self.paused_until = self.clock() + 600   # Portal sin actualizar: probar cada 10 min
                logger.debug(f"Registro no enviado al portal ({e})")
                return sent
            sent += len(lines)
            if len(lines) < BATCH:
                return sent

    def _loop(self) -> None:
        while not self.stop_event.wait(self.every_s):
            self.flush()

    def start(self) -> "PortalLog":
        self.thread = threading.Thread(target=self._loop, name="portal-log", daemon=True)
        self.thread.start()
        return self

    def stop(self) -> None:
        self.stop_event.set()
        self.flush()


class _Tee:
    """Copia lo que se escribe en stdout/stderr al registro del portal, sin cambiar la salida original."""

    def __init__(self, stream, sink: PortalLog, level: str):
        self._stream, self._sink, self._level, self._buf = stream, sink, level, ""

    def write(self, text):
        n = self._stream.write(text)
        try:
            self._buf += text
            if "\n" in self._buf:
                done, self._buf = self._buf.rsplit("\n", 1)
                self._sink.add(self._level, done)
        except Exception:
            pass
        return n

    def flush(self):
        return self._stream.flush()

    def __getattr__(self, name):
        return getattr(self._stream, name)


class _Handler(logging.Handler):
    def __init__(self, sink: PortalLog):
        super().__init__(logging.INFO)
        self.sink = sink
        self.setFormatter(logging.Formatter("[%(name)s] %(message)s"))

    def emit(self, record):
        try:
            self.sink.add(record.levelname, self.format(record))
        except Exception:
            pass


_installed: Optional[PortalLog] = None


def install() -> Optional[PortalLog]:
    """Activa el envío del registro de esta corrida (solo con portal configurado y PORTAL_LOG=1). Idempotente."""
    global _installed
    if _installed is not None or not (config.PORTAL_SYNC_ENABLED and config.PORTAL_LOG):
        return _installed
    from export.portal_sync import PortalClient, analysis_instance
    sink = PortalLog(PortalClient(config.PORTAL_URL, config.PORTAL_API_KEY, timeout=20),
                     (config.CLAIM_WORKER or "pc")[:20], analysis_instance())
    logging.getLogger("PODAutomation").addHandler(_Handler(sink))
    # Los mensajes de logging ya entran por el handler: stderr solo aporta los errores sin logging (tracebacks)
    sys.stdout = _Tee(sys.stdout, sink, "INFO")
    sys.stderr = _Tee(sys.stderr, sink, "ERROR")
    sink.start()
    atexit.register(sink.stop)
    _installed = sink
    sink.add("INFO", f"(registro) Inicio de la corrida {sink.instance}: el registro se envía al portal cada {sink.every_s:.0f} s")
    return sink
