"""
Módulo de Exportación a Excel Profesional para la Fase 3.

Combina pandas y openpyxl para estructurar los datos y aplicar formato condicional:
- Hoja 1: 'POD Results' con las 20 columnas estandarizadas y semáforo de colores.
- Hoja 2: 'Summary' con el panel de control y métricas clave de auditoría.
"""

from pathlib import Path
from typing import List, Union, Dict, Any, Optional
import pandas as pd
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.formatting.rule import CellIsRule
from openpyxl.utils import get_column_letter

from config import OUTPUT_DIR, DEFAULT_EXCEL_FILENAME
from models.pod import PODRecord, VerdictEnum, ProcessingStatusEnum, PODMemoryStorage


class PODExcelExporter:
    """Generador corporativo de reportes Excel utilizando pandas y openpyxl."""

    # Paleta de Colores Corporativa
    COLOR_HEADER_BG = "1F4E79"        # Azul Marino
    COLOR_HEADER_FG = "FFFFFF"        # Blanco

    # Veredictos - Semaforización
    COLOR_VALID_BG = "D4EDDA"         # Verde Suave (#D4EDDA)
    COLOR_VALID_FG = "155724"         # Verde Oscuro (#155724)

    COLOR_REVIEW_BG = "FFF3CD"        # Amarillo / Ámbar Suave (#FFF3CD)
    COLOR_REVIEW_FG = "856404"        # Ámbar Oscuro (#856404)

    COLOR_INVALID_BG = "F8D7DA"       # Rojo Suave (#F8D7DA)
    COLOR_INVALID_FG = "721C24"       # Rojo Oscuro (#721C24)

    COLOR_ZEBRA_LIGHT = "F9FBFD"      # Fondo alternado muy sutil

    def __init__(self, output_dir: Path = OUTPUT_DIR):
        self.output_dir = output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def _map_validation_result(self, pod: PODRecord) -> str:
        """Determina la etiqueta textual de resultado de validación solicitada (Fase 4)."""
        if pod.processing_status == ProcessingStatusEnum.FAILED:
            return "ERROR"
        if hasattr(pod, "classification") and pod.classification:
            return pod.classification.value
        if pod.verdict == VerdictEnum.VALIDO:
            return "VALID"
        elif pod.verdict == VerdictEnum.REQUIERE_REVISION:
            return "REVIEW REQUIRED"
        else:
            return "POSSIBLE ISSUE"

    def _determine_heuristics(self, pod: PODRecord) -> Dict[str, str]:
        """Calcula los indicadores de visibilidad de paquete, puerta, dirección y calidad."""
        has_photos = pod.number_of_photos > 0 or len(pod.photo_paths) > 0 or len(pod.photo_urls) > 0

        # Imagen borrosa o tapada
        has_blur_or_cover = any(
            m.is_blurry or m.is_blank_or_covered or m.is_dark
            for m in pod.image_metrics
        )

        # 1. Package Visible
        if not has_photos:
            pkg_visible = "NO"
        elif has_blur_or_cover and pod.quality_score < 40:
            pkg_visible = "UNCERTAIN"
        else:
            pkg_visible = "YES"

        # 2. Property / Door Visible
        door_types = ("puerta", "door", "front door", "portal", "buzón", "mailbox", "conserje")
        if not has_photos:
            door_visible = "NO"
        elif any(dt in pod.delivery_type.lower() for dt in door_types) and not has_blur_or_cover:
            door_visible = "YES"
        else:
            door_visible = "YES" if has_photos and pod.quality_score >= 60 else "NO"

        # 3. Address Visible
        address_visible = "YES" if has_photos and pod.quality_score >= 75 and len(pod.address) > 8 else "NO"

        # 4. Image Quality
        if not has_photos:
            img_quality = "NO PHOTO"
        elif pod.quality_score >= 80:
            img_quality = "HIGH"
        elif pod.quality_score >= 50:
            img_quality = "MEDIUM"
        else:
            img_quality = "POOR"

        # 5. Duplicate Photo (Fase 6)
        anomaly_str = " ".join(pod.anomalies)
        if pod.duplicate_status == "Exact Duplicate":
            is_dup = "YES (Exact)"
        elif pod.duplicate_status == "Possible Visual Duplicate":
            is_dup = "YES (Visual)"
        elif "FOTO_DUPLICADA" in anomaly_str:
            is_dup = "YES"
        else:
            is_dup = "NO"

        return {
            "pkg_visible": pkg_visible,
            "door_visible": door_visible,
            "address_visible": address_visible,
            "img_quality": img_quality,
            "is_dup": is_dup,
        }

    def _build_dataframe(self, pod_list: List[PODRecord]) -> pd.DataFrame:
        """Construye un DataFrame de pandas con las 20 columnas exactas requeridas para 'POD Results'."""
        rows = []
        for pod in pod_list:
            pod.sync_photo_count()
            heuristics = self._determine_heuristics(pod)
            validation_result = self._map_validation_result(pod)
            requires_review = "YES" if (validation_result == "REVIEW REQUIRED" or pod.abnormal_status) else "NO"

            rows.append({
                "Tracking": pod.tracking_number,
                "Stop": str(pod.stop_number or "N/A"),
                "Driver": pod.driver_name,
                "Station": pod.station or "N/A",
                "Address": pod.address,
                "Delivery Status": pod.delivery_status,
                "Delivery Date": pod.delivery_datetime,
                "Delivery Type": pod.delivery_type,
                "Photos Count": pod.number_of_photos,
                "Package Visible": heuristics["pkg_visible"],
                "Property/Door Visible": heuristics["door_visible"],
                "Address Visible": heuristics["address_visible"],
                "Image Quality": heuristics["img_quality"],
                "Duplicate Photo": heuristics["is_dup"],
                "Validation Result": validation_result,
                "Confidence Score": f"{(pod.quality_score / 100.0):.2f}",
                "Requires Manual Review": requires_review,
                "Non Compliance Reason": pod.non_compliance_reason or "N/A",
                "Processing Status": pod.processing_status.value if hasattr(pod.processing_status, "value") else str(pod.processing_status),
                "Error": pod.error_message or "None",
            })

        df = pd.DataFrame(rows)
        return df

    def _build_summary_dataframe(self, pod_list: List[PODRecord]) -> pd.DataFrame:
        """Calcula el resumen de métricas clave mediante agregación de pandas."""
        total_pods = len(pod_list)
        total_valid = sum(1 for p in pod_list if p.verdict == VerdictEnum.VALIDO and p.processing_status != ProcessingStatusEnum.FAILED)
        total_review = sum(1 for p in pod_list if p.verdict == VerdictEnum.REQUIERE_REVISION or (p.abnormal_status and p.verdict != VerdictEnum.SOSPECHOSO))
        total_errors = sum(1 for p in pod_list if p.verdict == VerdictEnum.SOSPECHOSO or p.processing_status == ProcessingStatusEnum.FAILED)
        total_photos = sum(p.number_of_photos for p in pod_list)
        total_duplicates = sum(
            1 for p in pod_list
            if p.duplicate_status in ("Exact Duplicate", "Possible Visual Duplicate")
            or any("FOTO_DUPLICADA" in a for a in p.anomalies)
        )

        summary_data = [
            {"Métrica": "Total POD procesados", "Valor": total_pods},
            {"Métrica": "Total válidos", "Valor": total_valid},
            {"Métrica": "Total que requieren revisión", "Valor": total_review},
            {"Métrica": "Total con errores", "Valor": total_errors},
            {"Métrica": "Total fotografías analizadas", "Valor": total_photos},
            {"Métrica": "Total posibles duplicados", "Valor": total_duplicates},
            {"Métrica": "Prioridad Alta (revisar primero)", "Valor": sum(1 for p in pod_list if p.priority == "Alta")},
            {"Métrica": "Prioridad Media", "Valor": sum(1 for p in pod_list if p.priority == "Media")},
            {"Métrica": "Lockers de Amazon", "Valor": sum(1 for p in pod_list if p.priority == "Lockers")},
            {"Métrica": "Prioridad Baja", "Valor": sum(1 for p in pod_list if p.priority == "Baja")},
        ]
        return pd.DataFrame(summary_data)

    # ------------------------------------------------------------------ cola de revisión priorizada
    PRIORITY_ORDER = {"Alta": 0, "Media": 1, "Baja": 2, "Lockers": 3}
    PRIORITY_COLORS = {
        "POD FALSO (portal)": ("C00000", "FFFFFF"),
        "Alta": ("F8D7DA", "721C24"),
        "Media": ("FFF3CD", "856404"),
        "Baja": ("D4EDDA", "155724"),
        "Lockers": ("EDE9FE", "6D28D9"),
    }
    CHECK_LABELS = {
        "numero_direccion": "Número vs dirección",
        "fotos_etiqueta": "Fotos de etiqueta",
        "fotos_edificio": "Foto edificio/puerta",
        "fotos_duplicadas": "Fotos duplicadas",
        "distancia_gps": "Distancia GPS",
        "cantidad_fotos": "Cantidad de fotos",
        "calidad_imagen": "Calidad de imagen",
        "incumplimiento_portal": "Incumplimiento portal",
        "cambio_estado": "Cambio de estado",
        "pod_falso_portal": "POD falso (portal)",
    }

    def _build_review_queue_dataframe(self, pod_list: List[PODRecord]) -> pd.DataFrame:
        """Cola de revisión: de mayor a menor riesgo, con prioridad, motivos y desglose por chequeo."""
        from processing.scoring import top_reasons

        from processing.scoring import queue_sort_key, is_portal_flagged_false_pod
        ordered = sorted(pod_list, key=queue_sort_key)
        rows = []
        for i, pod in enumerate(ordered, 1):
            meta = pod.portal_meta or {}
            breakdown = [
                f"{self.CHECK_LABELS.get(c['check'], c['check'])}: "
                f"{'REPORTAR' if c.get('force_report') else int(c['score'])}"
                for c in sorted(pod.check_results, key=lambda c: -c.get("score", 0))
                if c.get("applicable", True) and c.get("score", 0) > 0
            ]
            photos_dir = str(Path(pod.photo_paths[0]).parent) if pod.photo_paths else ""
            rows.append({
                "#": i,
                "Prioridad": ("POD FALSO (portal)" if is_portal_flagged_false_pod(pod) else pod.priority or "Sin score"),
                "Score": round(pod.risk_score, 1) if pod.risk_score is not None else None,
                "Motivo principal": " | ".join(top_reasons(pod, 3)) or "Sin alertas",
                "Tracking": pod.tracking_number,
                "Repartidor": pod.driver_name,
                "Estación": pod.station or "",
                "Parada": pod.stop_number or "",
                "Dirección esperada": pod.expected_address,
                "Tipo de facturación": pod.billing_type or pod.delivery_type,
                "Fecha/hora POD": pod.delivery_datetime,
                "Fotos": pod.number_of_photos,
                "Distancia GPS": meta.get("sign_distance"),
                "Desglose (chequeo: score)": "; ".join(breakdown),
                "Re-revisar (cambió estado)": "SÍ" if meta.get("status_change") else "",
                "Carpeta de fotos": photos_dir,
                "Revisado por": "",
                "Decisión (OK / Error)": "",
                "Comentario": "",
            })
        return pd.DataFrame(rows)

    def _style_review_queue_sheet(self, ws) -> None:
        font_header = Font(name="Segoe UI", size=10, bold=True, color=self.COLOR_HEADER_FG)
        fill_header = PatternFill(start_color=self.COLOR_HEADER_BG, end_color=self.COLOR_HEADER_BG, fill_type="solid")
        thin = Side(style="thin", color="E0E0E0")
        border = Border(left=thin, right=thin, top=thin, bottom=thin)
        headers = [c.value for c in ws[1]]
        col = {h: i + 1 for i, h in enumerate(headers)}
        for cell in ws[1]:
            cell.font, cell.fill = font_header, fill_header
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        ws.row_dimensions[1].height = 30
        widths = {"#": 5, "Prioridad": 10, "Score": 7, "Motivo principal": 60, "Tracking": 21,
                  "Repartidor": 24, "Estación": 11, "Parada": 9, "Dirección esperada": 38,
                  "Tipo de facturación": 20, "Fecha/hora POD": 18, "Fotos": 6, "Distancia GPS": 9,
                  "Desglose (chequeo: score)": 45, "Re-revisar (cambió estado)": 11, "Carpeta de fotos": 16,
                  "Revisado por": 14, "Decisión (OK / Error)": 14, "Comentario": 30}
        for h, w in widths.items():
            if h in col:
                ws.column_dimensions[get_column_letter(col[h])].width = w
        for row in ws.iter_rows(min_row=2):
            for cell in row:
                cell.font = Font(name="Segoe UI", size=9)
                cell.border = border
                cell.alignment = Alignment(vertical="top", wrap_text=True)
            prio = row[col["Prioridad"] - 1]
            bg, fg = self.PRIORITY_COLORS.get(str(prio.value), ("FFFFFF", "000000"))
            prio.fill = PatternFill(start_color=bg, end_color=bg, fill_type="solid")
            prio.font = Font(name="Segoe UI", size=9, bold=True, color=fg)
            prio.alignment = Alignment(horizontal="center", vertical="top")
            folder = row[col["Carpeta de fotos"] - 1]
            if folder.value:
                folder.hyperlink = Path(str(folder.value)).resolve().as_uri()
                folder.value = "Abrir fotos"
                folder.font = Font(name="Segoe UI", size=9, color="0563C1", underline="single")
        # Lista desplegable para la decisión del revisor
        from openpyxl.worksheet.datavalidation import DataValidation
        if ws.max_row >= 2:
            dv = DataValidation(type="list", formula1='"OK,Error,Dudoso"', allow_blank=True)
            letter = get_column_letter(col["Decisión (OK / Error)"])
            dv.add(f"{letter}2:{letter}{ws.max_row}")
            ws.add_data_validation(dv)
        ws.freeze_panes = "E2"
        ws.auto_filter.ref = ws.dimensions

    def _build_route_progress_dataframe(self, route_progress: List[Dict[str, Any]]) -> pd.DataFrame:
        rows = []
        for r in route_progress:
            delivered = r.get("delivered_in_portal") or 0
            reviewed = r.get("reviewed") or 0
            rows.append({
                "Estación": r.get("station_id"),
                "Repartidor": r.get("driver_name"),
                "Nuevo": "SÍ" if r.get("is_new") else "",
                "Revisadas": reviewed,
                "Entregadas con POD": delivered,
                "Asignadas": r.get("assigned_in_portal"),
                "Avance": f"{reviewed} de {delivered}",
                "Re-revisar": r.get("needs_recheck") or 0,
                "Ruta terminada": "SÍ" if delivered and r.get("assigned_in_portal") and delivered >= r["assigned_in_portal"] else "",
                "Actualizado": r.get("updated_at"),
            })
        return pd.DataFrame(rows)

    def export(
        self,
        pods_input: Union[List[PODRecord], PODMemoryStorage],
        filename: str = DEFAULT_EXCEL_FILENAME,
        route_progress: Optional[List[Dict[str, Any]]] = None,
    ) -> Path:
        """
        Exporta el conjunto de datos a Excel combinando pandas (estructuración)
        y openpyxl (estilos profesionales, autoajuste y formato condicional).
        """
        if isinstance(pods_input, PODMemoryStorage):
            pod_list = pods_input.get_all()
        else:
            pod_list = pods_input

        file_path = self.output_dir / filename

        # 1. Crear DataFrames con pandas
        df_results = self._build_dataframe(pod_list)
        df_summary = self._build_summary_dataframe(pod_list)

        df_queue = self._build_review_queue_dataframe(pod_list)

        # 2. Escribir DataFrames con pandas usando el motor openpyxl ("Review Queue" es la primera hoja)
        with pd.ExcelWriter(file_path, engine="openpyxl") as writer:
            df_queue.to_excel(writer, sheet_name="Review Queue", index=False)
            if route_progress:
                self._build_route_progress_dataframe(route_progress).to_excel(
                    writer, sheet_name="Avance por repartidor", index=False)
            df_results.to_excel(writer, sheet_name="POD Results", index=False)
            df_summary.to_excel(writer, sheet_name="Summary", index=False, startrow=2)

        # 3. Abrir con openpyxl para aplicar estilos corporativos avanzados
        wb = openpyxl.load_workbook(file_path)
        ws_results = wb["POD Results"]
        ws_summary = wb["Summary"]

        self._style_review_queue_sheet(wb["Review Queue"])
        if route_progress:
            ws_prog = wb["Avance por repartidor"]
            for cell in ws_prog[1]:
                cell.font = Font(name="Segoe UI", size=10, bold=True, color=self.COLOR_HEADER_FG)
                cell.fill = PatternFill(start_color=self.COLOR_HEADER_BG, end_color=self.COLOR_HEADER_BG, fill_type="solid")
            for column in ws_prog.columns:
                ws_prog.column_dimensions[get_column_letter(column[0].column)].width = 18
            ws_prog.freeze_panes = "A2"
            ws_prog.auto_filter.ref = ws_prog.dimensions
        self._style_results_sheet(ws_results, pod_list)
        self._style_summary_sheet(ws_summary, pod_list)

        # Guardar cambios
        wb.save(file_path)
        return file_path

    def _style_results_sheet(self, ws, pod_list: List[PODRecord]):
        """Aplica estilos corporativos y formato condicional a la hoja 'POD Results'."""
        font_header = Font(name="Segoe UI", size=10, bold=True, color=self.COLOR_HEADER_FG)
        fill_header = PatternFill(start_color=self.COLOR_HEADER_BG, end_color=self.COLOR_HEADER_BG, fill_type="solid")
        align_header = Alignment(horizontal="center", vertical="center", wrap_text=True)

        ws.row_dimensions[1].height = 28

        thin_border = Border(
            left=Side(style="thin", color="E0E0E0"),
            right=Side(style="thin", color="E0E0E0"),
            top=Side(style="thin", color="E0E0E0"),
            bottom=Side(style="thin", color="E0E0E0"),
        )
        font_body = Font(name="Segoe UI", size=9)
        align_left = Alignment(horizontal="left", vertical="center")
        align_center = Alignment(horizontal="center", vertical="center")

        # Formato de encabezados
        num_cols = ws.max_column
        for col_num in range(1, num_cols + 1):
            cell = ws.cell(row=1, column=col_num)
            cell.font = font_header
            cell.fill = fill_header
            cell.alignment = align_header

        # Formato de datos
        validation_col_idx = 15  # Columna 'Validation Result'

        for row_idx in range(2, ws.max_row + 1):
            ws.row_dimensions[row_idx].height = 22
            is_even = (row_idx % 2 == 0)
            default_fill = PatternFill(start_color=self.COLOR_ZEBRA_LIGHT, end_color=self.COLOR_ZEBRA_LIGHT, fill_type="solid") if is_even else None

            for col_idx in range(1, num_cols + 1):
                cell = ws.cell(row=row_idx, column=col_idx)
                cell.font = font_body
                cell.border = thin_border
                # Centrar columnas de identificación, estados, números y banderas
                if col_idx in [1, 2, 4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 19]:
                    cell.alignment = align_center
                else:
                    cell.alignment = align_left

                if default_fill:
                    cell.fill = default_fill

            # Aplicar formato condicional a la celda 'Validation Result' (Columna 15)
            val_cell = ws.cell(row=row_idx, column=validation_col_idx)
            val_text = str(val_cell.value).strip().upper()

            if val_text in ("VALID", "LIKELY VALID", "APPROVED"):
                val_cell.fill = PatternFill(start_color=self.COLOR_VALID_BG, end_color=self.COLOR_VALID_BG, fill_type="solid")
                val_cell.font = Font(name="Segoe UI", size=9, bold=True, color=self.COLOR_VALID_FG)
            elif val_text == "REVIEW REQUIRED":
                val_cell.fill = PatternFill(start_color=self.COLOR_REVIEW_BG, end_color=self.COLOR_REVIEW_BG, fill_type="solid")
                val_cell.font = Font(name="Segoe UI", size=9, bold=True, color=self.COLOR_REVIEW_FG)
            elif val_text in ("POSSIBLE ISSUE", "POSSIBLE INVALID POD", "ERROR"):
                val_cell.fill = PatternFill(start_color=self.COLOR_INVALID_BG, end_color=self.COLOR_INVALID_BG, fill_type="solid")
                val_cell.font = Font(name="Segoe UI", size=9, bold=True, color=self.COLOR_INVALID_FG)

        # Reglas dinámicas de formato condicional nativas de openpyxl en columna O
        val_range = f"O2:O{ws.max_row}"
        rule_green1 = CellIsRule(operator="equal", formula=['"VALID"'], fill=PatternFill(start_color=self.COLOR_VALID_BG, end_color=self.COLOR_VALID_BG, fill_type="solid"), font=Font(color=self.COLOR_VALID_FG, bold=True))
        rule_green2 = CellIsRule(operator="equal", formula=['"LIKELY VALID"'], fill=PatternFill(start_color=self.COLOR_VALID_BG, end_color=self.COLOR_VALID_BG, fill_type="solid"), font=Font(color=self.COLOR_VALID_FG, bold=True))
        rule_yellow = CellIsRule(operator="equal", formula=['"REVIEW REQUIRED"'], fill=PatternFill(start_color=self.COLOR_REVIEW_BG, end_color=self.COLOR_REVIEW_BG, fill_type="solid"), font=Font(color=self.COLOR_REVIEW_FG, bold=True))
        rule_red1 = CellIsRule(operator="equal", formula=['"POSSIBLE ISSUE"'], fill=PatternFill(start_color=self.COLOR_INVALID_BG, end_color=self.COLOR_INVALID_BG, fill_type="solid"), font=Font(color=self.COLOR_INVALID_FG, bold=True))
        rule_red2 = CellIsRule(operator="equal", formula=['"ERROR"'], fill=PatternFill(start_color=self.COLOR_INVALID_BG, end_color=self.COLOR_INVALID_BG, fill_type="solid"), font=Font(color=self.COLOR_INVALID_FG, bold=True))
        rule_red3 = CellIsRule(operator="equal", formula=['"POSSIBLE INVALID POD"'], fill=PatternFill(start_color=self.COLOR_INVALID_BG, end_color=self.COLOR_INVALID_BG, fill_type="solid"), font=Font(color=self.COLOR_INVALID_FG, bold=True))

        ws.conditional_formatting.add(val_range, rule_green1)
        ws.conditional_formatting.add(val_range, rule_green2)
        ws.conditional_formatting.add(val_range, rule_yellow)
        ws.conditional_formatting.add(val_range, rule_red1)
        ws.conditional_formatting.add(val_range, rule_red2)
        ws.conditional_formatting.add(val_range, rule_red3)

        # Autoajustar ancho de columnas
        for col in ws.columns:
            max_len = 0
            col_letter = get_column_letter(col[0].column)
            for cell in col:
                val = str(cell.value or "")
                length = min(len(val), 35)
                if length > max_len:
                    max_len = length
            ws.column_dimensions[col_letter].width = max(max_len + 3, 12)

        # Congelar primera fila y habilitar autofiltro
        ws.auto_filter.ref = ws.dimensions
        ws.freeze_panes = "A2"

    def _style_summary_sheet(self, ws, pod_list: List[PODRecord]):
        """Aplica estilos ejecutivos y formato de tarjeta a la hoja 'Summary'."""
        # Título superior
        ws.merge_cells("A1:C1")
        title_cell = ws["A1"]
        title_cell.value = "SUMMARY — AUDITORÍA DE ENTREGAS Y POD"
        title_cell.font = Font(name="Segoe UI", size=13, bold=True, color="FFFFFF")
        title_cell.fill = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")
        title_cell.alignment = Alignment(horizontal="center", vertical="center")
        ws.row_dimensions[1].height = 32

        # Encabezado de la tabla de resumen (fila 3)
        font_subhead = Font(name="Segoe UI", size=10, bold=True, color="FFFFFF")
        fill_subhead = PatternFill(start_color="2B579A", end_color="2B579A", fill_type="solid")
        border_box = Border(
            left=Side(style="thin", color="D0D0D0"),
            right=Side(style="thin", color="D0D0D0"),
            top=Side(style="thin", color="D0D0D0"),
            bottom=Side(style="thin", color="D0D0D0"),
        )

        ws.cell(row=3, column=1).font = font_subhead
        ws.cell(row=3, column=1).fill = fill_subhead
        ws.cell(row=3, column=2).font = font_subhead
        ws.cell(row=3, column=2).fill = fill_subhead

        # Estilizar filas de métricas
        for row_idx in range(4, 13):  # 9 métricas
            metric_cell = ws.cell(row=row_idx, column=1)
            val_cell = ws.cell(row=row_idx, column=2)

            metric_cell.font = Font(name="Segoe UI", size=10, bold=True)
            metric_cell.border = border_box

            val_cell.font = Font(name="Segoe UI", size=11, bold=True)
            val_cell.alignment = Alignment(horizontal="center", vertical="center")
            val_cell.border = border_box

            # Resaltar colores específicos de KPI
            label = str(metric_cell.value or "")
            if "válidos" in label.lower():
                val_cell.font = Font(name="Segoe UI", size=11, bold=True, color=self.COLOR_VALID_FG)
                val_cell.fill = PatternFill(start_color=self.COLOR_VALID_BG, fill_type="solid")
            elif "revisión" in label.lower():
                val_cell.font = Font(name="Segoe UI", size=11, bold=True, color=self.COLOR_REVIEW_FG)
                val_cell.fill = PatternFill(start_color=self.COLOR_REVIEW_BG, fill_type="solid")
            elif "errores" in label.lower():
                val_cell.font = Font(name="Segoe UI", size=11, bold=True, color=self.COLOR_INVALID_FG)
                val_cell.fill = PatternFill(start_color=self.COLOR_INVALID_BG, fill_type="solid")

        ws.column_dimensions["A"].width = 36
        ws.column_dimensions["B"].width = 18
