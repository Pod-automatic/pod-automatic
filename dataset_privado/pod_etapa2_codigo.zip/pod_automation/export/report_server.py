"""
Página local de reportes (`python main.py report`): lista los POD de prioridad Alta y Media de un día,
con la imagen tipo modal del portal y el texto listo para pegar en el grupo de WhatsApp "GOFO DALLAS".

- Solo lee la base de checkpoints (modo lectura): puede correr mientras el pipeline procesa.
- El estado de cada reporte (pendiente / reportado / descartado) se guarda aparte, en report_status.db.
- Escucha solo en 127.0.0.1: las fotos no salen del equipo.
"""

import json
import re
import sqlite3
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Dict, List, Optional
from urllib.parse import parse_qs, quote, urlparse

import config
from export.report_card import caption, render_card, station_label, city_code, company_code

CHECKPOINT_DB = config.CHECKPOINT_DB_PATH
STATUS_DB = config.STORAGE_DIR / "report_status.db"
PAGE = Path(__file__).with_name("report_page.html")
PRIORITIES = ("Alta", "Media", "Lockers")
STATUSES = ("pendiente", "reportado", "descartado")


def _ro() -> sqlite3.Connection:
    return sqlite3.connect(f"file:{CHECKPOINT_DB.as_posix()}?mode=ro", uri=True, timeout=15)


def _status_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(STATUS_DB), timeout=15)
    conn.execute("""CREATE TABLE IF NOT EXISTS report_status (
        tracking_number TEXT PRIMARY KEY, query_date TEXT, status TEXT NOT NULL, updated_at TEXT NOT NULL)""")
    # Repartidores ya revisados en la página, por día
    conn.execute("""CREATE TABLE IF NOT EXISTS driver_review (
        query_date TEXT NOT NULL, driver TEXT NOT NULL, seen INTEGER NOT NULL, updated_at TEXT NOT NULL,
        PRIMARY KEY (query_date, driver))""")
    return conn


def list_dates() -> List[str]:
    with _ro() as c:
        return [r[0] for r in c.execute("SELECT DISTINCT query_date FROM audit_sessions ORDER BY query_date DESC")]


def _reasons(check_results: List[Dict], n: int = 3) -> List[str]:
    """Igual que scoring.top_reasons, pero sobre los dicts guardados."""
    active = [r for r in check_results or [] if r.get("applicable", True) and r.get("score", 0) > 0]
    active.sort(key=lambda r: (not r.get("force_report"), -(r["score"] * r["weight"])))
    return [("[REPORTAR] " if r.get("force_report") else "") + r["explanation"] for r in active[:n]]


def _latest_rows(date: str) -> Dict[str, tuple]:
    """
    tracking -> (rowid, driver, priority, risk_score, station) de la sesión más reciente del día.
    json_extract evita parsear los payloads completos (pesan por las comparaciones de duplicados):
    pasa de ~3 s a milisegundos con unos cientos de albaranes.
    """
    with _ro() as c:
        rows = c.execute("""
            SELECT p.tracking_number, p.rowid, p.driver_name,
                   CASE WHEN EXISTS (SELECT 1 FROM json_each(p.payload_json,'$.check_results') r
                       WHERE json_extract(r.value,'$.check')='amazon_hub' AND COALESCE(json_extract(r.value,'$.applicable'),1)=1)
                       THEN 'Lockers' ELSE json_extract(p.payload_json, '$.priority') END, json_extract(p.payload_json, '$.risk_score'),
                   json_extract(p.payload_json, '$.station')
            FROM pod_checkpoints p JOIN audit_sessions s ON s.session_id = p.session_id
            WHERE s.query_date = ? ORDER BY s.started_at""", (date,)).fetchall()
    return {trk: rest for trk, *rest in rows}   # La última sesión pisa a las anteriores


def panel_data(date: str) -> Dict:
    """
    11/10: panel de rutas (como el Dashboard(DSP) de GOFO). Resumen de cada repartidor y entregas con problema que
    guarda la corrida (storage/route_panel.py) + lo nuestro: revisados por el script y Alta/Media pendientes.
    """
    from storage import route_panel
    data = route_panel.load(date)
    with _status_db() as s:
        status = dict(s.execute("SELECT tracking_number, status FROM report_status WHERE query_date=?", (date,)))
    mine: Dict[str, Dict[str, int]] = {}
    for trk, (_, driver, prio, score, _st) in _latest_rows(date).items():
        d = mine.setdefault(" ".join((driver or "").split()).lower(), {"revisados": 0, "alta": 0, "media": 0, "lockers": 0,
                                                                       "reportados": 0})
        d["revisados"] += 1
        if prio in PRIORITIES and status.get(trk, "pendiente") == "pendiente":
            d[prio.lower()] += 1
        d["reportados"] += status.get(trk) == "reportado"
    for c in data["couriers"]:
        c.update(mine.get((c["driver"] or "").lower(), {"revisados": 0, "alta": 0, "media": 0, "lockers": 0, "reportados": 0}))
    return data


UNIT_RE = re.compile(r"\s*(?:,|\b(?:apt|apartamento|apartment|unit|ste|suite|bldg|building)\b|#).*$", re.I)


def maps_address(address: str) -> str:
    """'Kennedale Kennedale 3100 Joplin Rd Apt 1102 5203' -> '3100 Joplin Rd, Kennedale, TX' (sin la unidad: la casa/edificio)."""
    m = re.search(r"\b\d", address or "")
    if not m:
        return (address or "").strip()
    city = address[:m.start()].split()
    if len(city) % 2 == 0 and [w.lower() for w in city[:len(city) // 2]] == [w.lower() for w in city[len(city) // 2:]]:
        city = city[:len(city) // 2]   # El portal repite la ciudad delante de la calle
    street = UNIT_RE.sub("", address[m.start():]).strip()
    return ", ".join(x for x in (street, " ".join(city).title(), "TX") if x)


def map_links(address: str, meta: Dict) -> Dict:
    """
    09/10: botón "Ver en mapa" para confirmar un Alta (sobre todo casas): ruta a pie desde donde se tomó la foto
    (GPS del POD) hasta la dirección, y Street View en el punto de la foto. Sin GPS, solo la dirección.
    """
    dest = maps_address(address)
    lat, lng = meta.get("pod_lat"), meta.get("pod_lng")
    try:
        point = f"{float(lat):.6f},{float(lng):.6f}"
    except (TypeError, ValueError):
        point = None
    try:
        dist = round(float(meta.get("sign_distance")))
    except (TypeError, ValueError):
        dist = None
    if point:
        return {"map": f"https://www.google.com/maps/dir/?api=1&origin={point}&destination={quote(dest)}&travelmode=walking",
                "street": f"https://www.google.com/maps/@?api=1&map_action=pano&viewpoint={point}",
                "distance": dist}
    return {"map": f"https://www.google.com/maps/search/?api=1&query={quote(dest)}" if dest else None,
            "street": None, "distance": dist}


# 09/10: filtro "Tipo de error" de la página. Casi todo es numero_direccion: se separa por su resultado.
NUMBER_TYPES = {
    "mismatch": "Número no concuerda", "mismatch_unconfirmed": "Número no concuerda",
    "not_visible": "Número no se ve",
    "near_match": "Número parecido (lectura dudosa)", "partial_read": "Número parecido (lectura dudosa)",
    "neighbor_digit": "Número parecido (lectura dudosa)",
    "far_numbers": "Edificio sin número de unidad", "partial": "Edificio sin número de unidad",
    "two_doors": "Dos puertas distintas", "two_doors_unconfirmed": "Dos puertas distintas",
}
CHECK_TYPES = {
    "pod_falso_portal": "POD falso (portal)", "amazon_hub": "Lockers de Amazon", "fotos_etiqueta": "Fotos de etiqueta",
    "fotos_duplicadas": "Fotos duplicadas", "distancia_gps": "Lejos de la dirección (GPS)",
    "fotos_edificio": "Foto edificio/puerta", "cantidad_fotos": "Cantidad de fotos", "calidad_imagen": "Calidad de imagen",
    "incumplimiento_portal": "Incumplimiento portal", "cambio_estado": "Cambio de estado", "captura_mapa": "Captura de mapa",
}


def error_type(check_results: List[Dict]) -> str:
    """El motivo que más pesó (el mismo que el portal usa para proponer el tipo de error), en palabras."""
    from export.portal_sync import main_detection
    check = main_detection(check_results)
    if not check:
        return "Otro"
    if check == "numero_direccion":
        r = next((x for x in check_results if x.get("check") == check), {})
        return NUMBER_TYPES.get((r.get("details") or {}).get("status"), "Número vs dirección")
    return CHECK_TYPES.get(check, check.replace("_", " ").capitalize())


def load_pods(date: str) -> List[Dict]:
    """POD Alta/Media del día (de todas las sesiones de esa fecha; la más reciente gana)."""
    # Sin score = re-evaluándose; Baja = no va a la página, salvo la muestra al azar del día (regla 01/10)
    latest = _latest_rows(date)
    wanted = {r[0]: trk for trk, r in latest.items() if r[3] is not None and r[2] in PRIORITIES}
    sample = _baja_sample(date, latest)
    wanted.update({latest[t][0]: t for t in sample})
    with _ro() as c:
        marks = ",".join("?" * len(wanted))
        rows = c.execute(f"SELECT rowid, payload_json FROM pod_checkpoints WHERE rowid IN ({marks})",
                         list(wanted)).fetchall() if wanted else []
    with _status_db() as s:
        status = dict(s.execute("SELECT tracking_number, status FROM report_status WHERE query_date=?", (date,)))
    pods: Dict[str, Dict] = {}
    shas: Dict[str, set] = {}
    for rowid, payload in rows:
        p = json.loads(payload)
        trk = wanted[rowid]
        shas[trk] = {m.get("sha256") for m in p.get("image_metrics") or [] if isinstance(m, dict) and m.get("sha256")}
        pods[trk] = {
            "tracking": trk,
            "driver_key": driver_key({'driver':p.get('driver_name'), 'driver_id':(p.get('portal_meta') or {}).get('driver_id'), 'station':p.get('station'), 'tracking':trk}),
            "driver": " ".join((p.get("driver_name") or "Desconocido").split()),
            "station": p.get("station") or "",
            "city": city_code(p.get("station") or ""),
            "company": company_code(p.get("station") or ""),
            "priority": latest[trk][2],
            "score": p["risk_score"],
            "reasons": _reasons(p.get("check_results")),
            "photos": len([x for x in p.get("photo_paths") or [] if Path(x).exists()]),
            "address": p.get("receipt_address") or p.get("address") or "",
            "signed": p.get("signature_datetime") or p.get("delivery_datetime") or "",
            "added": p.get("pod_review_date") or "",   # 10/10: cuándo el script lo analizó y lo subió a la cola
            "stop": p.get("stop_number") or "",
            "status": status.get(trk, "pendiente"),
            "sample": trk in sample,
            "amazon_hub": any(r.get("check") == "amazon_hub" and r.get("applicable", True)
                              for r in p.get("check_results") or []),
            "etype": error_type(p.get("check_results") or []),
            "maps": map_links(p.get("receipt_address") or p.get("address") or "", p.get("portal_meta") or {}),
        }
    repeated_groups(pods, shas)
    order = {"Alta": 0, "Media": 1, "Baja": 2, "Lockers": 3}
    return sorted(pods.values(), key=lambda x: (x["driver"].casefold(), order.get(x["priority"], 3), -(x["score"] or 0)))


def place_key(address: str) -> str:
    """
    12/10: el mismo lugar aunque la dirección venga escrita distinto ("1500 Precision Dr STE 110 PW 1301",
    "1500 Precision Dr.  STE 110 SFW-2002T", "1500 Precision Drive STE 110 PKB6212": 3 reportes sueltos por WhatsApp).
    Número + calle normalizada + unidad; otra unidad del mismo edificio es otro lugar.
    """
    from processing.ocr_address import parse_us_address
    from processing.validator import building_key
    try:
        number, street = building_key(address or "")
        unit = (parse_us_address(address or "").unit or "").lower()
    except Exception:
        number = street = unit = ""
    if number and street:
        return f"{number}|{street}|{unit}"
    return re.sub(r"[^a-z0-9]", "", (address or "").lower())


def driver_key(data: Dict) -> str:
    station=str(data.get('station') or data.get('station_code') or '').strip().upper()
    company=str(data.get('company') or (station.rsplit('-',1)[-1] if '-' in station else '')).strip().upper()
    scope=company or station
    identity=str(data.get('driver_id') or '').strip()
    name=' '.join((data.get('driver') or '').split()).casefold()
    if identity:
        key=[scope,'id',identity]
    elif name and name not in ('desconocido','unknown'):
        key=[scope,'name',station,name]
    else:
        key=['pod',data.get('tracking') or '']
    return json.dumps(key,ensure_ascii=False,separators=(',',':'))


def repeated_groups(pods: Dict[str, Dict], shas: Dict[str, set]) -> None:
    """
    12/10 (pedido del usuario): paquetes del MISMO repartidor en la MISMA dirección con al menos una foto idéntica son el
    mismo POD repetido: la página los muestra en UNA tarjeta ("group" = tracking del primero) y marcarla marca a todos.
    No cambia el puntaje ni la prioridad. Medido 10-11/10: -51 tarjetas de falsas alarmas y -44 repetidas de errores
    reales; en los grupos con marcas mezcladas el usuario reportó uno y descartó los duplicados.
    """
    by_key: Dict[tuple, List[str]] = {}
    for trk, x in pods.items():
        if x.get("sample") or x.get("amazon_hub"):
            continue   # La muestra de Baja va suelta; los Amazon Hub ya se juntan por repartidor
        key = (x.get('driver_key') or driver_key(x), place_key(x["address"]))
        if key[1]:
            by_key.setdefault(key, []).append(trk)
    for trks in by_key.values():
        if len(trks) < 2:
            continue
        parent = {t: t for t in trks}
        def root(t):
            while parent[t] != t:
                t = parent[t]
            return t
        for i, a in enumerate(trks):
            for b in trks[i + 1:]:
                if shas.get(a) and shas.get(a) & shas.get(b, set()):
                    parent[root(b)] = root(a)
        members: Dict[str, List[str]] = {}
        for t in trks:
            members.setdefault(root(t), []).append(t)
        for ts in members.values():
            if len(ts) >= 2:
                gid = sorted(ts)[0]
                for t in ts:
                    pods[t]["group"] = gid


def _baja_sample(date: str, latest: Dict[str, tuple]) -> set:
    """
    Muestra al azar de albaranes en Baja (siempre la misma para un día) para encontrar errores que se escapan
    (caso real 01/10: trailer 3813 omitido). Lo que el usuario marque "reportado" ahí entra a la evaluación.
    """
    import random
    baja = sorted(t for t, r in latest.items() if r[3] is not None and r[2] == "Baja")
    return set(random.Random(date).sample(baja, min(config.BAJA_SAMPLE_SIZE, len(baja))))


def load_payload(date: str, tracking: str) -> Optional[Dict]:
    with _ro() as c:
        row = c.execute("""
            SELECT p.payload_json FROM pod_checkpoints p JOIN audit_sessions s ON s.session_id = p.session_id
            WHERE s.query_date = ? AND p.tracking_number = ? ORDER BY s.started_at DESC LIMIT 1""",
                        (date, tracking)).fetchone()
    return json.loads(row[0]) if row else None


def list_drivers(date: str) -> List[Dict]:
    """Repartidores procesados ese día (aunque no tengan albaranes Alta/Media) y si ya se marcaron como vistos."""
    with _status_db() as s:
        seen = dict(s.execute("SELECT driver, seen FROM driver_review WHERE query_date=?", (date,)))
    stats: Dict[str, Dict] = {}
    for _, name, prio, score, station in _latest_rows(date).values():
        d = stats.setdefault(" ".join((name or "Desconocido").split()), {"total": 0, "Alta": 0, "Media": 0, "Lockers": 0, "station": ""})
        d["total"] += 1
        d["station"] = d["station"] or (station or "")
        if score is not None and prio in PRIORITIES:
            d[prio] += 1
    return [{"driver": k, **v, "seen": bool(seen.get(k))} for k, v in sorted(stats.items(), key=lambda x: x[0].casefold())]


def set_driver_seen(date: str, driver: str, seen: bool) -> None:
    with _status_db() as s:
        s.execute("INSERT OR REPLACE INTO driver_review VALUES (?, ?, ?, ?)",
                  (date, driver, int(seen), datetime.now().isoformat(timespec="seconds")))


def set_status(date: str, tracking: str, status: str, notify_portal: bool = True) -> None:
    """notify_portal=False: la marca vino del portal web (no se le vuelve a enviar)."""
    if status not in STATUSES:
        raise ValueError(status)
    with _status_db() as s:
        s.execute("INSERT OR REPLACE INTO report_status VALUES (?, ?, ?, ?)",
                  (tracking, date, status, datetime.now().isoformat(timespec="seconds")))
    if notify_portal:
        from export.portal_sync import notify_status
        notify_status(date, tracking, status)


WHATSAPP_OUT = config.STORAGE_DIR / "whatsapp_out"


def whatsapp_messages(date: str, items: List[Dict]) -> Dict[str, List[Dict]]:
    """
    grupo de WhatsApp -> mensajes [{trackings, png, text}] de los albaranes elegidos (items = [{tracking, main}]).
    Cada albarán es una imagen con su texto, salvo:
    - varios paquetes del MISMO repartidor en la MISMA dirección: un solo reporte, con la imagen del primero y todos
      los trackings (regla del usuario 03/10: 3 paquetes en 208 Lemon Dr);
    - Amazon Hub de un mismo repartidor: juntos en UNA imagen con todos los trackings (regla 01/10).
    El grupo sale de la ciudad del albarán (config.WHATSAPP_GROUPS).
    """
    from export.whatsapp_sender import group_for_station
    WHATSAPP_OUT.mkdir(parents=True, exist_ok=True)
    by_group: Dict[str, List[Dict]] = {}
    hubs: Dict[tuple, Dict] = {}
    for it in items:
        report = it.get('report')
        remote = bool(it.get('portal_evidence'))
        pod = None if remote else load_payload(date, it["tracking"])
        if not report and not pod:
            continue
        if remote and (not report or not it.get('portal_card') or not Path(it['portal_card']).is_file()):
            raise ValueError(f"Falta la evidencia del portal para {it['tracking']}")
        if report:
            driver = " ".join((report.get('driver') or '').split())
            station = report.get('station') or ''
            is_hub = bool(report.get('hub'))
            address = report.get('place') or ''
        else:
            driver = " ".join((pod.get("driver_name") or "").split())
            station = pod.get("station") or ""
            is_hub = any(r.get("check") == "amazon_hub" and r.get("applicable", True) for r in pod.get("check_results") or [])
            address = place_key(pod.get("receipt_address") or pod.get("address") or "")
        group = group_for_station(station)
        identity=driver_key({**report,'tracking':it['tracking']} if report else {'driver':driver,'station':station,'driver_id':(pod.get('portal_meta') or {}).get('driver_id'),'tracking':it['tracking']})
        key = (group, identity, "amazon_hub") if is_hub else (group, identity, address or it["tracking"])
        if key in hubs:
            hubs[key]["trackings"].append(it["tracking"])
            continue
        if remote:
            png = Path(it['portal_card'])
        else:
            if not pod:
                raise ValueError(f"No encontré el albarán local {it['tracking']}")
            png = WHATSAPP_OUT / f"{it['tracking']}.png"
            png.write_bytes(render_card(pod, int(it.get("main") or 0)))
        msg = {"trackings": [it["tracking"]], "png": png, "driver": driver, "station": station, "hub": is_hub}
        hubs[key] = msg
        by_group.setdefault(group, []).append(msg)
    for msgs in by_group.values():
        for m in msgs:
            m["text"] = caption(m["driver"], m["station"], m["trackings"], amazon_hub=m["hub"])
    return by_group


def prepare_whatsapp(date: str, items: List[Dict]) -> Dict:
    """Prepara en WhatsApp Web el PRIMER grupo; los albaranes de otros grupos vuelven como 'remaining'."""
    from export.whatsapp_sender import SENDER
    by_group = whatsapp_messages(date, items)
    if not by_group:
        return {"ok": False, "message": "No encontré esos albaranes"}
    group, msgs = next(iter(by_group.items()))
    done = [t for m in msgs for t in m["trackings"]]
    try:
        res = SENDER.prepare(group, [(m["png"], m["text"]) for m in msgs])
    except Exception as exc:
        exc.uncertain_trackings = done if getattr(exc,'uncertain',True) else []
        raise
    if not res.get('ok'):
        res.setdefault('uncertain',done)
    if res.get("ok"):
        res["message"] = _copy_to_extra_groups(SENDER, group, msgs, res.get("message") or f"Enviado a {group}")
    res.update({"trackings": done, "remaining": [it for it in items if it["tracking"] not in done],
                "other_groups": [g for g in by_group if g != group]})
    return res


def _copy_to_extra_groups(sender, group: str, msgs: List[Dict], message: str) -> str:
    """
    19/10: la ciudad tiene más de un grupo (config.WHATSAPP_GROUPS con lista): las mismas imágenes con su texto van
    también a los demás. Ya salieron al grupo principal, así que quedan como reportados aunque falle una copia: el
    aviso dice a qué grupo hay que reenviarlas a mano.
    """
    from export.whatsapp_sender import groups_for_station
    extra: Dict[str, List[Dict]] = {}
    for m in msgs:
        for g in groups_for_station(m["station"])[1:]:
            if g != group:
                extra.setdefault(g, []).append(m)
    for g, ms in extra.items():
        try:
            r = sender.prepare(g, [(m["png"], m["text"]) for m in ms])
            ok, why = r.get("ok"), r.get("message") or r.get("error") or ""
        except Exception as e:
            ok, why = False, str(e)
        message += f" · también a {g}" if ok else f" · NO salió la copia a {g} ({why}): reenvíala a mano"
    return message


def local_whatsapp_client():
    if not config.PORTAL_SYNC_ENABLED:
        raise ValueError('Configura la conexión con el portal para usar la cola compartida de WhatsApp.')
    from export.portal_sync import PortalClient
    return PortalClient(config.PORTAL_URL,config.PORTAL_API_KEY)


def enqueue_local_whatsapp(day,items,client=None):
    client=client or local_whatsapp_client()
    if not isinstance(items,list) or not 1<=len(items)<=60:
        raise ValueError('Elige entre 1 y 60 reportes.')
    request={'date':day,'items':items}
    response=client.call('wa_submit.php',request)
    promoted=[]
    for tracking in response.get('missing') or []:
        payload=load_payload(day,tracking)
        if not payload: raise ValueError('No encontré el albarán local '+tracking)
        from export.portal_sync import pod_item,card_jpeg
        from models.priorities import REVIEW_CATEGORIES
        import base64
        if payload.get('priority') not in REVIEW_CATEGORIES:
            promoted.append(tracking)
            payload={**payload,'priority':'Media'}  # Selección humana de un caso fuera de la cola automática.
        entry=pod_item(payload,day)
        entry['processed_at']=int(datetime.now().timestamp())
        count=max(1,min(len(payload.get('photo_paths') or []),6))
        entry['cards']=[base64.b64encode(card_jpeg(payload,index)).decode('ascii') for index in range(count)]
        saved=client.call('ingest.php',{'items':[entry]})
        if saved.get('errors'): raise ValueError('No se pudo sincronizar '+tracking)
    if response.get('missing'):
        response=client.call('wa_submit.php',{**request,'promoted':promoted})
    return response


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):  # Silencioso: la consola es del pipeline
        pass

    def _send(self, code: int, body: bytes, ctype: str):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, code: int = 200):
        self._send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")

    def do_GET(self):
        url = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(url.query).items()}
        try:
            if url.path == "/":
                self._send(200, PAGE.read_bytes(), "text/html; charset=utf-8")
            elif url.path == "/api/dates":
                self._json(list_dates())
            elif url.path == "/api/whatsapp/status":
                self._json(local_whatsapp_client().call('wa_submit.php',{'action':'status','job':int(q['job'])}))
            elif url.path == "/api/drivers":
                self._json(list_drivers(q["date"]))
            elif url.path == "/photo":
                # Foto original (para el zoom de la página)
                pod = load_payload(q["date"], q["tracking"])
                paths = [p for p in (pod or {}).get("photo_paths") or [] if Path(p).exists()]
                i = int(q.get("i", 0))
                if not 0 <= i < len(paths):
                    return self._json({"error": "foto no encontrada"}, 404)
                self._send(200, Path(paths[i]).read_bytes(), "image/jpeg")
            elif url.path == "/api/pods":
                self._json(load_pods(q["date"]))
            elif url.path == "/api/panel":
                self._json(panel_data(q["date"]))
            elif url.path == "/api/control":
                # 15/10: control de paquetes (doble escaneo, devoluciones, perdidos; lo llena `main.py control`)
                from storage import package_control
                self._json(package_control.load(q["date"]))
            elif url.path == "/api/statuses":
                # 10/10: solo las marcas del día (liviano), para que la página refleje al momento lo hecho en el portal
                with _status_db() as s:
                    self._json(dict(s.execute("SELECT tracking_number, status FROM report_status WHERE query_date=?",
                                              (q["date"],))))
            elif url.path == "/api/backlog":
                # 07/10: faltantes de la corrida (los escribe main.py en cada bloque)
                try:
                    self._json(json.loads(Path(config.BACKLOG_PATH).read_text(encoding="utf-8")))
                except (OSError, ValueError):
                    self._json({})
            elif url.path == "/api/caption":
                trks = [t for t in q.get("trackings", "").split(",") if t]
                self._json({"text": caption(q.get("driver", ""), q.get("station", ""), trks,
                                            amazon_hub=q.get("hub") == "1")})
            elif url.path == "/card.png":
                pod = load_payload(q["date"], q["tracking"])
                if not pod:
                    return self._json({"error": "albarán no encontrado"}, 404)
                self._send(200, render_card(pod, int(q.get("main", 0))), "image/png")
            else:
                self._json({"error": "no existe"}, 404)
        except Exception as e:
            self._json({"error": f"{type(e).__name__}: {e}"}, 500)

    def do_POST(self):
        try:
            body = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
            if urlparse(self.path).path == "/api/status":
                set_status(body["date"], body["tracking"], body["status"])
                return self._json({"ok": True})
            if urlparse(self.path).path == "/api/driver_seen":
                set_driver_seen(body["date"], body["driver"], bool(body["seen"]))
                return self._json({"ok": True})
            if urlparse(self.path).path == "/api/whatsapp":
                # Deja las capturas con su texto en la vista previa de WhatsApp Web; el usuario revisa y envía
                return self._json(enqueue_local_whatsapp(body["date"], body["items"]))
            self._json({"error": "no existe"}, 404)
        except Exception as e:
            self._json({"error": f"{type(e).__name__}: {e}"}, 400)


def serve(port: int = 8765) -> None:
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    print(f"Página de reportes en http://127.0.0.1:{port}  (Ctrl+C para cerrar)")
    # 05/10: también atiende los "Enviar al grupo" del portal web (esta página tiene la sesión de WhatsApp Web)
    from export.portal_wa import start_from_config
    worker=start_from_config(prepare_whatsapp)
    from export.portal_sync import from_config
    sync=from_config()
    if worker:
        print(f"Portal web: atendiendo los envíos a WhatsApp de {config.PORTAL_URL}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        if worker: worker.stop()
        if sync: sync.stop()
        server.server_close()
