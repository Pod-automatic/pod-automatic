"""
Envíos a WhatsApp pedidos desde el portal web (05/10/2026).

El portal guarda una cola ("Enviar al grupo"); la página local (`main.py report`), que tiene la sesión de WhatsApp Web,
la revisa cada pocos segundos y manda cada albarán con el mismo envío que la página local: una imagen por albarán con
su texto como pie, Amazon Hub de un repartidor juntos y varios paquetes en la misma dirección en un solo reporte.
Al terminar le avisa al portal, que los deja "reportado" con el tipo de error elegido en la web.

Mientras la página local revisa la cola, el portal muestra "PC conectada".
"""

import io
import json
import sqlite3
import tempfile
from pathlib import Path

import logging
import threading
import time
from typing import Callable, Dict, List, Optional

import config
from export.portal_sync import PortalClient, PortalError

logger = logging.getLogger("PODAutomation.PortalWhatsApp")

POLL_S = 3   # 11/10: antes 8 s; cada "Enviar al grupo" esperaba hasta 8 s antes de empezar


def process_job(job: Dict, prepare: Callable[[str, List[Dict]], Dict], on_progress=None) -> Dict:
    """Manda todos los albaranes del envío (uno o varios grupos). Devuelve {ok, message, sent}."""
    date, pending, sent, groups = job["date"], list(job["items"]), [], []
    while pending:
        try:
            res = prepare(date, pending)
        except Exception as e:
            return {"ok": False, "sent": sent, "uncertain": getattr(e,"uncertain_trackings",[it["tracking"] for it in pending]) if getattr(e,"uncertain",True) else [], "message": f"{e}"}
        if not res.get("ok"):
            msg = res.get("message") or res.get("error") or "no se pudo enviar"
            return {"ok": False, "sent": sent, "uncertain": res.get("uncertain", [it["tracking"] for it in pending]), "message": msg}
        done = res.get("trackings") or []
        if not done:
            break
        sent = list(dict.fromkeys(sent + done))
        if on_progress:
            try:
                on_progress(sent)
            except Exception as exc:
                return {'ok':False,'sent':sent,'message':f'Enviado, pendiente de confirmar en el portal: {exc}'}
        groups.append(res.get("message") or "")
        pending = res.get("remaining") or []
    missing = [it["tracking"] for it in job["items"] if it["tracking"] not in sent]
    if missing:
        return {"ok": False, "sent": sent,
                "message": f"No están en la PC (¿cargas manuales o de otro día?): {', '.join(missing)}"}
    return {"ok": True, "sent": sent, "message": " · ".join(g for g in groups if g) or "Enviado"}


class ReceiptStore:
    """Recibos pendientes: un fallo HTTP reintenta la confirmación, nunca el envío."""
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True,exist_ok=True)
        with sqlite3.connect(self.path) as conn:
            conn.execute('CREATE TABLE IF NOT EXISTS receipts(job_id INTEGER PRIMARY KEY, body TEXT NOT NULL)')

    def put(self, body):
        with sqlite3.connect(self.path) as conn:
            conn.execute('INSERT OR REPLACE INTO receipts VALUES (?,?)',(body['id'],json.dumps(body)))

    def pending(self):
        with sqlite3.connect(self.path) as conn:
            return [json.loads(row[0]) for row in conn.execute('SELECT body FROM receipts ORDER BY job_id')]

    def done(self, body):
        with sqlite3.connect(self.path) as conn:
            conn.execute('DELETE FROM receipts WHERE job_id=? AND body=?',(body['id'],json.dumps(body)))


class PortalWhatsAppWorker:
    def __init__(self, client: PortalClient, prepare: Callable[[str, List[Dict]], Dict],
                 status_writer: Optional[Callable[[str, str, str], None]] = None, poll_s: float = POLL_S, receipt_path=None):
        self.client = client
        self.prepare = prepare
        self.status_writer = status_writer
        self.poll_s = poll_s
        self._stop = threading.Event()
        self._warned = False
        self.receipts = ReceiptStore(receipt_path or config.STORAGE_DIR / 'portal_wa_receipts.db')

    def _ack(self, body):
        self.receipts.put(body)
        self.client.call('wa_queue.php',body)
        self.receipts.done(body)

    def run_once(self) -> Optional[Dict]:
        for receipt in self.receipts.pending():
            self.client.call('wa_queue.php',receipt)
            self.receipts.done(receipt)
        job = self.client.call("wa_queue.php", query={"evidence": 2}).get("job")
        if not job:
            return None
        logger.info(f"Portal → WhatsApp: envío {job['id']} con {len(job['items'])} albarán(es)")
        started = time.time()
        # Descargar antes de enviar: un archivo faltante no debe producir un envío incompleto.
        with tempfile.TemporaryDirectory(prefix='pod-queue-wa-') as tmp:
            try:
                items = []
                for index, item in enumerate(job['items']):
                    item = dict(item)
                    if item.get('portal_evidence'):
                        from PIL import Image
                        data = self.client.download_wa_card(job['id'], item['tracking'])
                        path = Path(tmp) / f'{index}.png'
                        with Image.open(io.BytesIO(data)) as image:
                            if image.width * image.height > 16000000:
                                raise ValueError('La imagen supera el tamaño permitido')
                            image.convert('RGB').save(path, format='PNG')
                        item['portal_card'] = str(path)
                    items.append(item)
                self._ack({'id':job['id'],'progress':True,'phase':'enviando','sent':[]})
                result = process_job({**job, 'items': items}, self.prepare,
                    on_progress=lambda sent: self._ack({'id':job['id'],'progress':True,'phase':'enviando','sent':sent}))
            except Exception as exc:
                result = {'ok': False, 'sent': [], 'message': f'No se preparó el envío reservado: {exc}'}
        logger.info(f"Portal → WhatsApp: envío {job['id']} {'OK' if result['ok'] else 'FALLÓ'} en "
                    f"{time.time() - started:.0f} s: {result['message']}")
        # Las decisiones locales se sincronizan por el flujo de estados, no por repetir recibos.
        self._ack({"id": job["id"], **result})
        return result

    def loop(self) -> None:
        while not self._stop.is_set():
            try:
                self.run_once()
                self._warned = False
            except PortalError as e:
                if not self._warned:
                    logger.warning(f"Portal (cola de WhatsApp): {e}")
                    self._warned = True
            except Exception as e:
                logger.exception(f"Portal (cola de WhatsApp): error inesperado: {e}")
            self._stop.wait(self.poll_s)

    def start(self) -> "PortalWhatsAppWorker":
        threading.Thread(target=self.loop, name="portal-whatsapp", daemon=True).start()
        return self

    def stop(self) -> None:
        self._stop.set()


def start_from_config(prepare: Callable[[str, List[Dict]], Dict]) -> Optional[PortalWhatsAppWorker]:
    if not config.PORTAL_SYNC_ENABLED:
        return None
    from export.portal_sync import write_local_status
    return PortalWhatsAppWorker(PortalClient(config.PORTAL_URL, config.PORTAL_API_KEY), prepare,
                                status_writer=write_local_status).start()
