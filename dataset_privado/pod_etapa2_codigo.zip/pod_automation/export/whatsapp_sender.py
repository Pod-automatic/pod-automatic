"""
Prepara los reportes de POD en WhatsApp Web (pedido del usuario 03/10/2026).

- Abre WhatsApp Web en un navegador propio del script (perfil guardado en storage/whatsapp_profile: el QR se escanea
  una sola vez desde el teléfono, "Dispositivos vinculados").
- Busca el grupo de la ciudad (config.WHATSAPP_GROUPS), adjunta las capturas y escribe en CADA imagen su texto
  ("Motivo / Driver / Ciudad / Traking"), como lo hace el usuario a mano.
- Envía solo (pedido del usuario 04/10; antes dejaba la vista previa para revisar): solo si la vista previa tiene
  TODAS las imágenes y cada texto quedó completo; si algo no cuadra, no envía y avisa.

Playwright (API síncrona) vive en un solo hilo; la página de reportes le pasa los pedidos por una cola.
WhatsApp Web cambia su HTML seguido: cada paso prueba varios selectores y, si falla, guarda una captura de pantalla
en storage/whatsapp_debug para ajustar.
"""

import base64
import logging
import queue
import re
import threading
import time
from concurrent.futures import Future
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import config

logger = logging.getLogger("PODAutomation.WhatsApp")

PROFILE_DIR = config.STORAGE_DIR / "whatsapp_profile"
DEBUG_DIR = config.STORAGE_DIR / "whatsapp_debug"
LOGIN_TIMEOUT_S = 180          # Tiempo para escanear el QR la primera vez

CHAT_LIST = "#pane-side"
SEARCH_BOXES = ['#side div[contenteditable="true"]', 'div[contenteditable="true"][data-tab="3"]',
                'div[role="textbox"][aria-label*="Buscar"]', 'div[role="textbox"][aria-label*="Search"]']
ATTACH_BUTTONS = ['#main button[title="Adjuntar"]', '#main div[title="Adjuntar"]', '#main [aria-label="Adjuntar"]',
                  '#main button[title="Attach"]', '#main div[title="Attach"]', '#main [aria-label="Attach"]',
                  '#main span[data-icon="plus-rounded"]', '#main span[data-icon="plus"]',
                  '#main span[data-icon="attach-menu-plus"]', '#main span[data-icon="clip"]']
CAPTION_BOXES = ['div[contenteditable="true"][aria-label*="comentario"]', 'div[contenteditable="true"][aria-label*="caption"]',
                 'div[contenteditable="true"][aria-label*="Comentario"]', 'div[contenteditable="true"][data-tab="10"]']


class WhatsAppError(RuntimeError):
    def __init__(self, message, uncertain=False):
        super().__init__(message)
        self.uncertain = uncertain


def groups_for_station(station: str) -> List[str]:
    """Grupos de WhatsApp de la ciudad (19/10: puede ser una lista); el de por defecto si la ciudad no está."""
    key = (station or "").strip().upper()
    groups = config.WHATSAPP_GROUPS.get(key) or config.WHATSAPP_DEFAULT_GROUP
    return [groups] if isinstance(groups, str) else list(groups)


def group_for_station(station: str) -> str:
    """Grupo PRINCIPAL de la ciudad: con él se arma el envío; los demás reciben una copia (groups_for_station)."""
    return groups_for_station(station)[0]


class WhatsAppSender:
    """Un solo navegador de WhatsApp Web para toda la página; los pedidos se atienden de a uno."""

    def __init__(self):
        self._q: "queue.Queue[Tuple[str, Dict, Future]]" = queue.Queue()
        self._thread: Optional[threading.Thread] = None
        self._ctx = None
        self._page = None

    # ------------------------------------------------------------------ API para la página
    def prepare(self, group: str, items: List[Tuple[Path, str]], timeout: float = 600) -> Dict:
        """Deja las imágenes con su texto en la vista previa del grupo. items = [(png, texto), ...]."""
        fut: Future = Future()
        self._ensure_thread()
        self._q.put(("prepare", {"group": group, "items": items}, fut))
        return fut.result(timeout=timeout)

    # ------------------------------------------------------------------ hilo de Playwright
    def _ensure_thread(self):
        if self._thread is None or not self._thread.is_alive():
            self._thread = threading.Thread(target=self._loop, name="whatsapp", daemon=True)
            self._thread.start()

    def _loop(self):
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            self._pw = pw
            while True:
                kind, args, fut = self._q.get()
                try:
                    fut.set_result(self._prepare(**args))
                except Exception as e:
                    shot = self._debug_shot("error")
                    logger.warning(f"WhatsApp: {e} (captura: {shot})")
                    fut.set_exception(WhatsAppError(f"{e}" + (f" — captura en {shot}" if shot else ""), uncertain=getattr(e,"uncertain",False)))

    def _reset(self):
        try:
            if self._ctx is not None:
                self._ctx.close()
        except Exception:
            pass
        self._ctx = self._page = None

    def _alive(self) -> bool:
        """06/10: is_closed() seguía en False después de cerrar la ventana de Chrome ("Target page, context or browser
        has been closed" en bring_to_front): se prueba que la página responda de verdad."""
        if self._page is None or self._page.is_closed():
            return False
        try:
            self._page.evaluate("1")
            return True
        except Exception:
            return False

    def _open(self):
        if self._alive():
            return self._page
        self._reset()
        PROFILE_DIR.mkdir(parents=True, exist_ok=True)
        self._ctx = self._pw.chromium.launch_persistent_context(
            str(PROFILE_DIR), headless=False, no_viewport=True, args=["--start-maximized"])
        self._page = self._ctx.pages[0] if self._ctx.pages else self._ctx.new_page()
        self._page.goto("https://web.whatsapp.com", wait_until="domcontentloaded")
        return self._page

    def _wait_login(self, page):
        try:
            page.wait_for_selector(CHAT_LIST, timeout=LOGIN_TIMEOUT_S * 1000)
        except Exception:
            raise WhatsAppError("WhatsApp Web no inició sesión: escanea el QR con el teléfono (Dispositivos "
                                "vinculados) en la ventana que se abrió y vuelve a intentar")

    def _first(self, page, candidates, what: str, timeout: float = 15):
        """Primer elemento visible de una lista de candidatos (selectores CSS o funciones page -> Locator)."""
        deadline = time.time() + timeout
        while time.time() < deadline:
            for c in candidates:
                try:
                    loc = c(page) if callable(c) else page.locator(c)
                    if loc.count() and loc.first.is_visible():
                        return loc.first
                except Exception:
                    continue
            time.sleep(0.3)
        raise WhatsAppError(f"No encontré {what} en WhatsApp Web")

    def _open_group(self, page, group: str):
        exact = re.compile(rf"^\s*{re.escape(group)}\s*$", re.I)
        # Si el grupo ya está a la vista en la lista de chats, se abre directo (sin usar el buscador)
        in_list = page.locator(CHAT_LIST).get_by_title(group, exact=True)
        if not (in_list.count() and in_list.first.is_visible()):
            box = self._first(page, [
                lambda p: p.get_by_role("textbox", name=re.compile("Buscar|Search", re.I)),
                lambda p: p.get_by_placeholder(re.compile("Buscar|Search", re.I)),
                lambda p: p.locator('[aria-label*="Buscar"], [aria-label*="Search"]').locator(
                    'xpath=descendant-or-self::*[@contenteditable="true" or self::input]'),
            ] + SEARCH_BOXES, "el buscador de chats")
            box.click()
            page.keyboard.press("Control+A")
            page.keyboard.press("Backspace")
            page.keyboard.type(group, delay=30)
            in_list = page.locator(CHAT_LIST).get_by_title(group, exact=True)
            try:
                in_list.first.wait_for(timeout=15000)
            except Exception:
                alt = page.locator(CHAT_LIST).get_by_text(exact)
                if not alt.count():
                    raise WhatsAppError(f'No encontré el grupo "{group}" en tus chats')
                in_list = alt
        in_list.first.click()
        try:
            page.locator("#main header").get_by_text(exact).first.wait_for(timeout=10000)
        except Exception:
            raise WhatsAppError(f'No se abrió el grupo "{group}"')

    def _caption_box(self, page, timeout: float = 15):
        # En la vista previa la casilla del comentario se llama "Escribe un mensaje" (03/10/2026). OJO: la del chat
        # normal ("Escribir un mensaje para el grupo …") queda detrás de la vista previa y no se puede usar.
        return self._first(page, [
            lambda p: p.get_by_role("textbox", name="Escribe un mensaje", exact=True),
            lambda p: p.get_by_role("textbox", name="Type a message", exact=True),
            lambda p: p.get_by_role("textbox", name=re.compile("comentario|caption|Añade|Agrega", re.I)),
        ], "la casilla del comentario de la imagen", timeout=timeout)

    def _preview_open(self, page) -> bool:
        for name in ("Escribe un mensaje", "Type a message"):
            loc = page.get_by_role("textbox", name=name, exact=True)
            if loc.count() and loc.first.is_visible():
                return True
        return False

    def _type_caption(self, page, text: str):
        """
        Escribe el texto de la imagen y comprueba que quedó completo (03/10: escribiendo letra por letra se perdían
        las primeras, "an José…" en vez de "Motivo: Pod Fake / Driver: Juan José…"). Primero pega el mensaje completo;
        si no queda igual, lo escribe línea por línea.
        """
        want = " ".join(text.split())
        for attempt in range(3):
            box = self._caption_box(page)
            box.click()
            time.sleep(0.4)
            page.keyboard.press("Control+A")
            page.keyboard.press("Backspace")
            time.sleep(0.2)
            if attempt == 0:
                # Pegar el mensaje COMPLETO de una vez (como Ctrl+V): los saltos de línea entran sin enviar nada y no
                # se pierden letras. Se pega directo en la casilla, sin tocar el portapapeles de Windows.
                box.evaluate("""(el, text) => {
                    const dt = new DataTransfer();
                    dt.setData('text/plain', text);
                    el.dispatchEvent(new ClipboardEvent('paste', {clipboardData: dt, bubbles: true, cancelable: true}));
                }""", text)
            else:
                for i, line in enumerate(text.splitlines()):
                    if i:
                        page.keyboard.press("Shift+Enter")   # Enter solo ENVIARÍA el mensaje
                    page.keyboard.insert_text(line)
            time.sleep(0.4)
            got = " ".join((box.inner_text() or "").split())
            if got == want:
                return
            logger.warning(f"WhatsApp: el texto quedó distinto (intento {attempt + 1}): {got[:60]!r}")
        raise WhatsAppError("No pude escribir el texto completo de la imagen")

    def _attach_first(self, page, png: Path):
        """Botón de adjuntar -> "Fotos y videos" -> selector de archivos."""
        self._first(page, [
            lambda p: p.locator("#main").get_by_role("button", name=re.compile("Adjuntar|Attach", re.I)),
            lambda p: p.locator("#main").get_by_title(re.compile("Adjuntar|Attach", re.I)),
        ] + ATTACH_BUTTONS, "el botón de adjuntar").click()
        time.sleep(0.8)
        # 1) Directo: el selector de archivos de "Fotos y videos" acepta imágenes Y videos. OJO: "Nuevo sticker" también
        # acepta imágenes y abre el editor de stickers (03/10: se quedó ahí, con las tijeras y sin casilla de texto).
        inputs = page.locator('input[type="file"][accept*="image"][accept*="video"]')
        if inputs.count():
            inputs.first.set_input_files(str(png))
            return
        # 2) Respaldo: clic en "Fotos y videos". El menú se redibuja al abrirse ("element was detached"): se reintenta.
        for _ in range(5):
            for name in ("Fotos y videos", "Fotos y vídeos", "Photos & videos", "Photos & Videos"):
                loc = page.get_by_text(name, exact=True)
                if not (loc.count() and loc.first.is_visible()):
                    continue
                try:
                    with page.expect_file_chooser(timeout=6000) as fc:
                        loc.first.click(timeout=4000)
                    fc.value.set_files(str(png))
                    return
                except Exception:
                    time.sleep(0.5)
            time.sleep(0.5)
        raise WhatsAppError('No encontré la opción "Fotos y videos" para adjuntar')

    def _attach_more(self, page, png: Path):
        """En la vista previa: el "+" agrega otra imagen; la nueva queda seleccionada y recibe su texto."""
        plus = None
        for c in (lambda p: p.get_by_role("button", name=re.compile("Añadir archivo|Agregar archivo|Add file|Añadir|Add", re.I)),
                  lambda p: p.locator('[data-icon="plus"], [data-icon="plus-rounded"], [data-icon="media-add"]')):
            try:
                loc = c(page)
                if loc.count() and loc.last.is_visible():
                    plus = loc.last
                    break
            except Exception:
                continue
        if plus is not None:
            try:
                with page.expect_file_chooser(timeout=8000) as fc:
                    plus.click()
                fc.value.set_files(str(png))
                return
            except Exception:
                pass
        add = page.locator('input[type="file"][accept*="image"][accept*="video"]')
        if not add.count():
            add = page.locator('input[type="file"]')
        if not add.count():
            raise WhatsAppError("No encontré el botón + para agregar otra imagen en la vista previa")
        add.last.set_input_files(str(png))

    def _selected_count(self, page) -> int:
        """Imágenes en la vista previa, según el botón "Enviar N seleccionados" (1 si solo dice "Enviar")."""
        loc = page.get_by_role("button", name=re.compile(r"^(Enviar|Send)\b", re.I))
        best = 0
        for i in range(loc.count()):
            name = (loc.nth(i).get_attribute("aria-label") or "").strip()
            m = re.search(r"(\d+)", name)
            if m:
                best = max(best, int(m.group(1)))
        if best:
            return best
        return 1 if self._preview_open(page) else 0

    def _paste_image(self, page, target, png: Path) -> None:
        """Pega la imagen en la casilla (como Ctrl+V de una imagen copiada), sin tocar el portapapeles de Windows."""
        b64 = base64.b64encode(Path(png).read_bytes()).decode("ascii")
        target.evaluate("""(el, [b64, name]) => {
            const bin = atob(b64), bytes = new Uint8Array(bin.length);
            for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
            const dt = new DataTransfer();
            dt.items.add(new File([bytes], name, {type: 'image/png'}));
            el.focus();
            el.dispatchEvent(new ClipboardEvent('paste', {clipboardData: dt, bubbles: true, cancelable: true}));
        }""", [b64, Path(png).name])

    def _compose_box(self, page):
        return self._first(page, [
            lambda p: p.locator("#main").get_by_role("textbox", name=re.compile("Escribir un mensaje|Type a message", re.I)),
            lambda p: p.locator('#main footer div[contenteditable="true"]'),
        ], "la casilla de mensajes del grupo")

    def _add_first_image(self, page, png: Path) -> None:
        """Pegar la imagen en la casilla de mensajes abre la vista previa; si no, "Fotos y videos"."""
        try:
            self._paste_image(page, self._compose_box(page), png)
            self._caption_box(page, timeout=10)
            return
        except Exception as e:
            logger.info(f"WhatsApp: pegar la imagen no abrió la vista previa ({e}); uso Fotos y videos")
        self._attach_first(page, png)
        self._caption_box(page, timeout=30)

    def _add_more_image(self, page, png: Path) -> None:
        """Pegar en la vista previa agrega la imagen (queda seleccionada); si no aumenta el contador, el "+"."""
        before = self._selected_count(page)
        try:
            self._paste_image(page, self._caption_box(page), png)
            deadline = time.time() + 6
            while time.time() < deadline:
                if self._selected_count(page) > before:
                    time.sleep(0.6)
                    return
                time.sleep(0.3)
        except Exception as e:
            logger.info(f"WhatsApp: pegar en la vista previa falló ({e})")
        logger.info("WhatsApp: pegar no agregó la imagen; uso el botón +")
        self._attach_more(page, png)
        time.sleep(1.2)

    def _prepare(self, group: str, items: List[Tuple[Path, str]]) -> Dict:
        if not items:
            raise WhatsAppError("No hay capturas para preparar")
        t0 = time.time()
        reopened = not self._alive()
        page = self._open()
        page.bring_to_front()
        self._wait_login(page)
        t_open = time.time() - t0
        if self._preview_open(page):
            raise WhatsAppError("Quedó abierta una vista previa de imágenes en WhatsApp Web: ciérrala con la X "
                                "(arriba a la izquierda) y vuelve a apretar Preparar")
        self._open_group(page, group)
        t_group = time.time() - t0
        # 03/10 (idea del usuario): pegar la imagen como Ctrl+V en vez del menú de adjuntar; el menú queda de respaldo
        self._add_first_image(page, items[0][0])
        self._type_caption(page, items[0][1])
        for png, text in items[1:]:
            self._add_more_image(page, png)
            self._type_caption(page, text)
        n = self._selected_count(page)
        if n != len(items):
            raise WhatsAppError(f"La vista previa tiene {n} imagen(es) y se esperaban {len(items)}: no envié nada, "
                                f"revisa la ventana de WhatsApp")
        t_ready = time.time() - t0
        try:
            self._send(page)
        except Exception as exc:
            raise WhatsAppError(str(exc), uncertain=True) from exc
        logger.info(f"WhatsApp: {len(items)} imagen(es) enviadas a {group} en {time.time() - t0:.0f} s "
                    f"({'ventana REABIERTA, ' if reopened else ''}abrir {t_open:.0f} s, grupo {t_group:.0f} s, "
                    f"imágenes y textos {t_ready:.0f} s)")
        return {"ok": True, "sent": True, "group": group, "images": len(items),
                "message": f"Enviado a {group}: {len(items)} reporte(s)"}

    def _send(self, page) -> None:
        """Aprieta la flecha verde de la vista previa y espera a que se cierre (los mensajes salieron)."""
        btn = self._first(page, [
            lambda p: p.get_by_role("button", name=re.compile(r"^(Enviar|Send)\b", re.I)),
            lambda p: p.locator('[data-icon="send"], [data-icon="wds-ic-send-filled"]'),
        ], "el botón de enviar")
        btn.click()
        deadline = time.time() + 90
        while time.time() < deadline:
            if not self._preview_open(page):
                time.sleep(1.5)   # Que salgan de la cola local antes de seguir
                return
            time.sleep(0.5)
        raise WhatsAppError("Apreté enviar pero la vista previa no se cerró: revisa la ventana de WhatsApp")

    def _debug_shot(self, name: str) -> Optional[str]:
        """Captura de pantalla + lista de botones/casillas con su nombre (para ajustar los selectores)."""
        try:
            if self._page is None or self._page.is_closed():
                return None
            DEBUG_DIR.mkdir(parents=True, exist_ok=True)
            stem = DEBUG_DIR / f"{time.strftime('%Y%m%d_%H%M%S')}_{name}"
            self._page.screenshot(path=str(stem) + ".png")
            names = self._page.evaluate("""() => [...document.querySelectorAll(
                '[aria-label],[title],[contenteditable="true"],input,[role="button"],[role="textbox"]')]
                .slice(0, 400).map(e => [e.tagName, e.getAttribute('role') || '', e.getAttribute('aria-label') || '',
                e.getAttribute('title') || '', e.getAttribute('placeholder') || '',
                e.getAttribute('contenteditable') || '', e.getAttribute('data-tab') || ''].join(' | '))""")
            Path(str(stem) + ".txt").write_text("\n".join(names), encoding="utf-8")
            return str(stem) + ".png"
        except Exception:
            return None


SENDER = WhatsAppSender()
