"""
Imagen para reportar un POD en el grupo de WhatsApp: recrea el modal de detalle del portal de GOFO
(foto grande con bandas negras a la izquierda, datos de la entrega a la derecha y miniaturas abajo).
"""

import io
from pathlib import Path
from typing import Dict, List, Optional

from PIL import Image, ImageDraw, ImageFont, ImageOps

W, H = 1280, 760
GW, GH = 1700, 650                # Tamaño del modal de detalle del portal de GOFO (captura del usuario 03/10)
PHOTO_W = 760                     # Panel negro de la foto principal
PAD = 28
BLUE = (22, 119, 255)
GREEN = (82, 196, 26)
TEXT = (38, 38, 38)
MUTED = (140, 140, 140)
BORDER = (232, 232, 232)

_FONT_DIRS = [Path("C:/Windows/Fonts"), Path("/usr/share/fonts/truetype/dejavu")]


def _font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    names = (["segoeuib.ttf", "arialbd.ttf", "DejaVuSans-Bold.ttf"] if bold
             else ["segoeui.ttf", "arial.ttf", "DejaVuSans.ttf"])
    for d in _FONT_DIRS:
        for n in names:
            if (d / n).exists():
                return ImageFont.truetype(str(d / n), size)
    return ImageFont.load_default()


def station_label(station: str) -> str:
    """'DFW02-BAA' -> 'DFW02 - BAA' (así se escribe en los reportes del grupo)."""
    return " - ".join(p.strip() for p in (station or "").split("-") if p.strip()) or "-"


def city_code(station: str) -> str:
    return station.rsplit('-',1)[0].strip().upper() if station and '-' in station else ''


def company_code(station: str) -> str:
    return station.rsplit('-',1)[-1].strip().upper() if station else ''


def _open(path: str) -> Optional[Image.Image]:
    try:
        with Image.open(path) as im:
            return ImageOps.exif_transpose(im).convert("RGB")
    except Exception:
        return None


def _wrap(draw: ImageDraw.ImageDraw, text: str, font, width: int) -> List[str]:
    words, lines, cur = (text or "-").split(), [], ""
    for w in words:
        test = f"{cur} {w}".strip()
        if draw.textlength(test, font=font) <= width:
            cur = test
        else:
            if cur:
                lines.append(cur)
            cur = w
    return lines + ([cur] if cur else []) or ["-"]


def render_card(pod: Dict, main_index: int = 0) -> bytes:
    """
    PNG del modal de detalle de un POD (pod = payload guardado en el checkpoint), copiado del portal de GOFO
    (pedido del usuario 03/10: que la captura de la página sea igual a la del portal para mandarla directo):
    "número de albarán: X" arriba con la ✕, foto grande con bandas negras a la izquierda, datos en 3 columnas a la
    derecha (etiqueta oscura, valor gris) y las miniaturas debajo de los datos.
    """
    img = Image.new("RGB", (GW, GH), "white")
    d = ImageDraw.Draw(img)
    paths = [p for p in pod.get("photo_paths") or [] if Path(p).exists()]
    main_index = main_index if 0 <= main_index < len(paths) else 0

    # Encabezado
    head_b, head = _font(17, True), _font(17)
    d.text((22, 31), "número de albarán:", fill=TEXT, font=head_b, anchor="lm")
    hx = 22 + d.textlength("número de albarán: ", font=head_b)
    d.text((hx, 31), pod.get("tracking_number") or "-", fill=MUTED, font=head, anchor="lm")
    cx, cy = GW - 42, 28
    d.line([cx - 7, cy - 7, cx + 7, cy + 7], fill=MUTED, width=2)
    d.line([cx - 7, cy + 7, cx + 7, cy - 7], fill=MUTED, width=2)

    # Foto principal centrada sobre negro (bandas negras como en el portal)
    px0, py0, px1, py1 = 31, 68, 921, 625
    d.rectangle([px0, py0, px1, py1], fill="black")
    main = _open(paths[main_index]) if paths else None
    if main:
        main.thumbnail((px1 - px0, py1 - py0))
        img.paste(main, (px0 + (px1 - px0 - main.width) // 2, py0 + (py1 - py0 - main.height) // 2))
    else:
        d.text(((px0 + px1) // 2, (py0 + py1) // 2), "Sin foto", fill="white", font=_font(28), anchor="mm")

    # Datos en 3 columnas
    label_f, value_f = _font(15), _font(15)
    cols = (941, 1178, 1415)
    colw = 220
    driver = " ".join((pod.get("driver_name") or "").split())

    def field(col: int, y: int, label: str, value: str = "", width: int = colw) -> int:
        d.text((cols[col], y), label, fill=TEXT, font=label_f)
        vy = y + 27
        for line in (_wrap(d, value, value_f, width)[:3] if value else []):
            d.text((cols[col], vy), line, fill=MUTED, font=value_f)
            vy += 22
        return vy

    y1 = max(field(0, 70, "Ciudad / empresa:", (city_code(pod.get("station") or "") or "-") + " / " + (company_code(pod.get("station") or "") or "-")),
             field(1, 70, "Entregado:", driver),
             field(2, 70, "Fecha de firma:", pod.get("signature_datetime") or pod.get("delivery_datetime") or ""))
    y2 = max(y1 + 12, 151)
    y2 = max(field(0, y2, "Tipo de facturación:", pod.get("billing_type") or pod.get("delivery_type") or ""),
             field(1, y2, "Auditor:"), field(2, y2, "Revisor:"))
    y3 = max(y2 + 10, 210)
    y3 = max(field(0, y3, "Dirección de recibo:", pod.get("receipt_address") or pod.get("address") or "",
                   width=cols[2] - cols[0] - 20),
             field(2, y3, "fecha de revisión del POD:"))
    y4 = max(y3 + 10, 269)
    d.text((cols[0], y4), "Razones de incumplimiento de POD:", fill=TEXT, font=label_f)

    # Miniaturas (la principal con borde azul, esquinas redondeadas como en el portal)
    if paths:
        n = len(paths)
        gap = 15
        size = min(75, (GW - cols[0] - 30 - gap * (n - 1)) // n)
        ty = y4 + 39
        for i, p in enumerate(paths):
            th = _open(p)
            tx = cols[0] + 2 + i * (size + gap)
            if th:
                th = ImageOps.fit(th, (size, size))
                mask = Image.new("L", (size, size), 0)
                ImageDraw.Draw(mask).rounded_rectangle([0, 0, size - 1, size - 1], radius=4, fill=255)
                img.paste(th, (tx, ty), mask)
            if i == main_index:
                d.rounded_rectangle([tx - 3, ty - 3, tx + size + 2, ty + size + 2], radius=5, outline=BLUE, width=2)

    buf = io.BytesIO()
    img.save(buf, format="PNG", optimize=True)
    return buf.getvalue()


AMAZON_HUB_MOTIVO = "Pod Fake (Lockers de Amazon)"


def caption(driver: str, station: str, trackings: List[str], amazon_hub: bool = False) -> str:
    """
    Pie del reporte, con el formato fijo del grupo GOFO DALLAS (varios trackings, uno por línea). Los lockers de
    Amazon llevan el motivo "Pod Fake (Lockers de Amazon)" (pedido del usuario 03/10).
    """
    lines = [f"Motivo: {AMAZON_HUB_MOTIVO if amazon_hub else 'Pod Fake'}",
             f"Driver: {' '.join((driver or '').split())}",
             f"Ciudad: {station_label(station)}"]   # 28/10: vuelve el formato fijo "DFW02 - BAA" (pedido del usuario)
    trackings = list(trackings) or [""]
    lines.append(f"Traking: {trackings[0]}")
    lines += trackings[1:]
    return "\n".join(lines)
