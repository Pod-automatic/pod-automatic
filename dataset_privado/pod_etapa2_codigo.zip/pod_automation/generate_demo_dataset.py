"""
Script Generador de Demostración para la Fase 2: Crea un lote representativo de entregas
con todos los campos estandarizados de PODRecord, acumula los resultados en memoria
mediante PODMemoryStorage y exporta el archivo Excel 'output/resultados_pod.xlsx'.
"""

from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter
from datetime import datetime

import config
from models.pod import PODRecord, PODMemoryStorage, ProcessingStatusEnum, VerdictEnum
from processing.validator import PODValidator
from export.excel_exporter import PODExcelExporter


def generate_demo_dataset():
    base_demo_dir = config.POD_IMAGES_DIR / "demo_sample"
    base_demo_dir.mkdir(parents=True, exist_ok=True)

    # 1. Crear imágenes sintéticas representativas
    # Foto A: Nítida de puerta con paquete
    img_sharp = Image.new("RGB", (300, 300), color=(240, 240, 230))
    d = ImageDraw.Draw(img_sharp)
    d.rectangle([50, 80, 250, 280], fill=(160, 100, 50), outline=(80, 40, 20), width=3)
    d.rectangle([110, 190, 190, 270], fill=(210, 180, 140), outline=(100, 70, 30), width=2)
    d.text((120, 220), "GOFO EXP", fill=(0, 0, 0))
    path_sharp = base_demo_dir / "foto_nitida.jpg"
    img_sharp.save(path_sharp)

    # Foto B: Borrosa
    img_blurry = img_sharp.filter(ImageFilter.GaussianBlur(radius=7))
    path_blurry = base_demo_dir / "foto_borrosa.jpg"
    img_blurry.save(path_blurry)

    # Foto C: Muy oscura / Casi negra
    img_dark = Image.new("RGB", (300, 300), color=(12, 12, 15))
    path_dark = base_demo_dir / "foto_oscura.jpg"
    img_dark.save(path_dark)

    # Foto D: Plana / Cámara tapada
    img_flat = Image.new("RGB", (300, 300), color=(120, 120, 120))
    path_flat = base_demo_dir / "foto_tapada.jpg"
    img_flat.save(path_flat)

    # Foto E: Otra entrega nítida
    img_sharp2 = Image.new("RGB", (300, 300), color=(220, 235, 245))
    d2 = ImageDraw.Draw(img_sharp2)
    d2.rectangle([40, 60, 260, 260], fill=(180, 120, 80), outline=(50, 50, 50), width=2)
    d2.rectangle([80, 150, 180, 250], fill=(220, 190, 150), outline=(60, 40, 20), width=2)
    path_sharp2 = base_demo_dir / "foto_buzon.jpg"
    img_sharp2.save(path_sharp2)

    # 2. Generar lista de entregas simuladas con todos los atributos de Fase 2
    today = datetime.now().strftime("%Y-%m-%d")

    records = [
        # 1. Entrega Perfecta
        PODRecord(
            tracking_number="GF982001ES",
            stop_number="10",
            driver_name="Alejandro Martínez",
            station="DFW02",
            address="Calle Serrano 45, 2B, Madrid",
            delivery_status="Entregado",
            delivery_datetime=f"{today} 09:30:15",
            signature_datetime=None,
            delivery_type="Puerta",
            reviewer="Auditor DSP 01",
            photo_paths=[str(path_sharp)],
            processing_status=ProcessingStatusEnum.PROCESSED,
        ),
        # 2. Entrega con Foto Borrosa
        PODRecord(
            tracking_number="GF982002ES",
            stop_number="11",
            driver_name="Carlos Vega",
            station="DFW02",
            address="Av. de Burgos 18, Madrid",
            delivery_status="Entregado",
            delivery_datetime=f"{today} 09:45:22",
            signature_datetime=f"{today} 09:45:20",
            delivery_type="En mano",
            reviewer="Auditor DSP 01",
            photo_paths=[str(path_blurry)],
            has_signature=True,
            processing_status=ProcessingStatusEnum.PROCESSED,
        ),
        # 3. Entrega Sospechosa: Misma Foto reutilizada (Fraude)
        PODRecord(
            tracking_number="GF982003ES",
            stop_number="14",
            driver_name="Carlos Vega",
            station="DFW02",
            address="Calle Arturo Soria 112, Madrid",
            delivery_status="Entregado",
            delivery_datetime=f"{today} 10:12:00",
            signature_datetime=None,
            delivery_type="Puerta",
            reviewer="Auditor DSP 01",
            photo_paths=[str(path_sharp)],  # Reutiliza foto_nitida de Alejandro!
            processing_status=ProcessingStatusEnum.PROCESSED,
        ),
        # 4. Entrega con Foto Oscura / Noche
        PODRecord(
            tracking_number="GF982004ES",
            stop_number="18",
            driver_name="Luis Morales",
            station="DFW02",
            address="Paseo de la Habana 8, Madrid",
            delivery_status="Entregado",
            delivery_datetime=f"{today} 10:35:40",
            signature_datetime=None,
            delivery_type="Puerta",
            reviewer="Auditor DSP 01",
            photo_paths=[str(path_dark)],
            processing_status=ProcessingStatusEnum.PROCESSED,
        ),
        # 5. Entrega con Cámara Tapada
        PODRecord(
            tracking_number="GF982005ES",
            stop_number="22",
            driver_name="David Castro",
            station="DFW02",
            address="Calle Goya 72, Madrid",
            delivery_status="Entregado",
            delivery_datetime=f"{today} 10:55:18",
            signature_datetime=None,
            delivery_type="Puerta",
            reviewer="Auditor DSP 01",
            photo_paths=[str(path_flat)],
            processing_status=ProcessingStatusEnum.PROCESSED,
        ),
        # 6. Entrega Sin Foto ni Firma (Severa)
        PODRecord(
            tracking_number="GF982006ES",
            stop_number="25",
            driver_name="David Castro",
            station="DFW02",
            address="Calle Alcalá 320, Madrid",
            delivery_status="Entregado",
            delivery_datetime=f"{today} 11:10:05",
            signature_datetime=None,
            delivery_type="Buzón",
            reviewer="Auditor DSP 01",
            photo_paths=[],
            processing_status=ProcessingStatusEnum.PROCESSED,
        ),
        # 7. Entrega con Incidencia Reportada por Plataforma
        PODRecord(
            tracking_number="GF982007ES",
            stop_number="30",
            driver_name="Javier Ramos",
            station="DFW02",
            address="Calle Princesa 14, Madrid",
            delivery_status="Entregado",
            delivery_datetime=f"{today} 11:28:30",
            signature_datetime=f"{today} 11:28:25",
            delivery_type="Conserje",
            reviewer="Auditor DSP 01",
            photo_paths=[str(path_sharp2)],
            non_compliance_reason="Falta nombre de conserje receptor",
            has_signature=True,
            processing_status=ProcessingStatusEnum.PROCESSED,
        ),
        # 8. Otra Entrega Válida
        PODRecord(
            tracking_number="GF982008ES",
            stop_number="35",
            driver_name="Alejandro Martínez",
            station="DFW02",
            address="Paseo del Prado 22, Madrid",
            delivery_status="Entregado",
            delivery_datetime=f"{today} 11:45:10",
            signature_datetime=None,
            delivery_type="Puerta",
            reviewer="Auditor DSP 01",
            photo_paths=[str(path_sharp2)],
            processing_status=ProcessingStatusEnum.PROCESSED,
        ),
    ]

    # 3. Inicializar CheckpointManager y AuditLogger para demostración offline
    from storage.checkpoint_manager import CheckpointManager
    from automation.audit_logger import AuditLogger

    # 06/10: base propia del demo. Antes usaba la base real del día y sus 8 albaranes inventados aparecían en la página
    # de reportes junto a los reales (05/10)
    ckpt_mgr = CheckpointManager(db_path=config.STORAGE_DIR / "demo" / "pod_checkpoints_demo.db")
    session_id = ckpt_mgr.create_session(today, total_detected=len(records))
    audit_logger = AuditLogger(session_id=session_id)

    # 4. Guardar registros en memoria con PODMemoryStorage
    storage = PODMemoryStorage()
    for idx, pod in enumerate(records, 1):
        audit_logger.start_pod(idx, len(records), pod.albaran)
        storage.add(pod)

    # 5. Validar y auditar con Computer Vision y Detección de Duplicados (Fase 6)
    validator = PODValidator()
    validator.validate_storage(storage)

    # 6. Persistir en SQLite Checkpoints (Fase 8) y registrar en Audit Log (Fase 7)
    for idx, pod in enumerate(storage.get_all(), 1):
        ckpt_mgr.save_pod_checkpoint(session_id, pod)
        val_name = getattr(pod.classification, "value", str(pod.classification))
        audit_logger.end_pod(
            current_index=idx,
            total_pods=len(records),
            tracking=pod.albaran,
            photos_count=pod.number_of_photos,
            status=str(pod.processing_status),
            result=val_name,
            notes=pod.duplicate_status,
        )

    ckpt_mgr.mark_session_completed(session_id)

    all_pods = storage.get_all()
    total_valid = sum(1 for p in all_pods if p.verdict == VerdictEnum.VALIDO)
    total_rev = sum(1 for p in all_pods if p.verdict == VerdictEnum.REQUIERE_REVISION)
    total_err = sum(1 for p in all_pods if p.verdict == VerdictEnum.SOSPECHOSO)
    audit_logger.log_session_summary(len(all_pods), total_valid, total_rev, 0, total_err)

    # 7. Exportar desde memoria hacia Excel (Fase 3)
    exporter = PODExcelExporter()
    output_path = exporter.export(storage, filename="resultados_pod.xlsx")
    print(f"Demostración completada con éxito.")
    print(f"Reporte Excel: {output_path}")
    print(f"Base de Checkpoints: {config.CHECKPOINT_DB_PATH}")
    print(f"Log de Auditoría: {audit_logger.log_file}")
    return output_path


if __name__ == "__main__":
    generate_demo_dataset()
