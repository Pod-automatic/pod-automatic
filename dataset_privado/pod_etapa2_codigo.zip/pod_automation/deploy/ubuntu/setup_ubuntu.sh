#!/usr/bin/env bash
# Instala todo lo necesario para correr la auditoría de POD en Ubuntu 24.04 con GPU NVIDIA (22/10/2026).
# Uso (en el servidor, dentro de la carpeta del proyecto ya descomprimida):
#   bash deploy/ubuntu/setup_ubuntu.sh
# Es idempotente: se puede volver a correr si algo falló a mitad de camino.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT"
echo "== Proyecto en $ROOT"

# 1) Paquetes del sistema: Python, pantalla virtual (el navegador y WhatsApp Web necesitan una), VNC para iniciar
#    sesión a mano cuando haga falta, Tesseract (respaldo de OCR) y utilidades
sudo apt-get update
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y \
    python3 python3-venv python3-pip python3-dev build-essential \
    xvfb x11vnc fluxbox \
    tesseract-ocr \
    sqlite3 curl wget unzip ca-certificates fonts-liberation fonts-noto-color-emoji

# 2) Controlador NVIDIA: sin él no hay GPU para Paddle ni para Ollama
if ! command -v nvidia-smi >/dev/null 2>&1 || ! nvidia-smi >/dev/null 2>&1; then
    echo "== No se encontró el controlador NVIDIA: instalando (después hay que REINICIAR y volver a correr este script)"
    sudo DEBIAN_FRONTEND=noninteractive apt-get install -y ubuntu-drivers-common
    sudo ubuntu-drivers install
    echo "== Listo. Reinicia el servidor (sudo reboot) y vuelve a correr: bash deploy/ubuntu/setup_ubuntu.sh"
    exit 0
fi
nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv

# 3) Entorno principal (corrida, página local, portal)
if [ ! -x venv/bin/python ]; then python3 -m venv venv; fi
venv/bin/python -m pip install --upgrade pip wheel
venv/bin/python -m pip install -r deploy/ubuntu/requirements-linux.txt
# Navegadores de Playwright (Chromium con sus dependencias del sistema) y Google Chrome (el script lo prefiere)
venv/bin/python -m playwright install --with-deps chromium
venv/bin/python -m playwright install chrome || echo "(Google Chrome no se instaló: se usará Chromium)"

# 4) Entorno aparte de PaddleOCR (GPU, CUDA 12.6 como en Windows)
if [ ! -x venv_paddle/bin/python ]; then python3 -m venv venv_paddle; fi
venv_paddle/bin/python -m pip install --upgrade pip wheel
venv_paddle/bin/python -m pip install paddlepaddle-gpu==3.3.1 -i https://www.paddlepaddle.org.cn/packages/stable/cu126/ \
    || venv_paddle/bin/python -m pip install paddlepaddle-gpu -i https://www.paddlepaddle.org.cn/packages/stable/cu126/
venv_paddle/bin/python -m pip install -r deploy/ubuntu/requirements-paddle-linux.txt
venv_paddle/bin/python -c "import paddle; paddle.utils.run_check()" || echo "!! Paddle no ve la GPU: revisar CUDA/controlador"

# 5) Ollama (modelo de visión) + el modelo que usa el script
if ! command -v ollama >/dev/null 2>&1; then curl -fsSL https://ollama.com/install.sh | sh; fi
sudo systemctl enable --now ollama || true
MODEL="$(grep -E '^VISION_MODEL=' .env 2>/dev/null | cut -d= -f2 || true)"; MODEL="${MODEL:-qwen2.5vl:3b}"
ollama pull "$MODEL"

# 6) .env para el servidor: navegador sin ventana (la pantalla virtual igual existe para WhatsApp y el login)
touch .env
grep -q '^HEADLESS=' .env || printf '\n# 22/10: servidor Ubuntu (deploy/ubuntu)\nHEADLESS=true\n' >> .env

# 7) Pruebas (no tocan GOFO ni WhatsApp)
venv/bin/python -m pytest tests -q -x || echo "!! Fallaron pruebas: revisar antes de arrancar la corrida"

# 8) Servicios (página local + corrida con reinicio automático si se cae)
bash deploy/ubuntu/instalar_servicios.sh

echo
echo "== Instalación terminada. Siguientes pasos en deploy/ubuntu/README_UBUNTU.md"
