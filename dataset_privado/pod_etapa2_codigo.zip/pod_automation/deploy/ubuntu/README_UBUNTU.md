# Auditoría de POD en Ubuntu (servidor con GPU)

Copia del proyecto preparada el 22/10/2026 para un servidor Ubuntu 24.04 con GPU NVIDIA (p. ej. Vultr Cloud GPU).
Todo lo de Windows sigue funcionando igual; esto es lo que cambia en el servidor.

## 1. Armar la copia (en la PC con Windows)

```
venv\Scripts\python.exe deploy\ubuntu\empaquetar.py
```

Deja `output\pod_automation_ubuntu_AAAAMMDD_HHMM.tar.gz` (código, configuración, sesión de GOFO y bases).
Con `--sin-base` no lleva `pod_checkpoints.db` (~800 MB): el servidor arranca con historial vacío.

## 2. Subirla al servidor

```
scp output\pod_automation_ubuntu_*.tar.gz root@IP_DEL_SERVIDOR:~
ssh root@IP_DEL_SERVIDOR
tar xzf pod_automation_ubuntu_*.tar.gz && cd pod_automation
```

## 3. Instalar (una sola vez, ~20-40 min)

```
bash deploy/ubuntu/setup_ubuntu.sh
```

Instala Python, el navegador, PaddleOCR con GPU, Ollama con el modelo de visión, corre las pruebas y crea los
servicios. Si el servidor no tenía el controlador NVIDIA, lo instala y pide reiniciar: `sudo reboot` y volver a
correr el mismo comando.

## 4. Sesión de GOFO

La copia trae `storage/session_state.json` (la sesión de la PC). Probar:

```
sudo systemctl start pod-corrida
tail -f storage/corrida_$(date +%Y%m%d).log
```

Si dice que la sesión venció (la corrida termina con código 2), iniciar sesión a mano viendo la pantalla del servidor:

```
# En el servidor:
DISPLAY=:99 x11vnc -localhost -nopw -forever &
DISPLAY=:99 venv/bin/python main.py login
# En la PC (otra ventana): túnel y visor VNC (TightVNC/RealVNC) a localhost:5900
ssh -L 5900:localhost:5900 root@IP_DEL_SERVIDOR
```

## 5. Página local y WhatsApp

La página escucha solo dentro del servidor (no queda expuesta a internet). Para verla desde la PC:

```
ssh -L 8765:localhost:8765 root@IP_DEL_SERVIDOR
```

y abrir http://127.0.0.1:8765. WhatsApp Web se vincula una vez escaneando el QR por el mismo VNC del paso 4
(el primer "Enviar por WhatsApp" abre la ventana en la pantalla :99).

## 6. Uso diario

| Qué | Comando |
|---|---|
| Arrancar la corrida (y que arranque sola al reiniciar el servidor) | `sudo systemctl enable --now pod-corrida` |
| Detenerla | `sudo systemctl stop pod-corrida` |
| Estado | `systemctl status pod-corrida` |
| Ver el avance | `tail -f storage/corrida_$(date +%Y%m%d).log` |
| Solo una ciudad hoy | `_estaciones_solo_hoy` en `drivers_config.json` (igual que en Windows) y `sudo systemctl restart pod-corrida` |

Si la corrida se cae sola, systemd la vuelve a lanzar al minuto (menos con la sesión de GOFO vencida).
Con 16 GB de memoria de video no hace falta el vigilante de Paddle.

## Notas

- Vultr cobra mientras el servidor EXISTA (apagado también): para dejar de pagar hay que destruirlo.
- No correr la corrida en la PC y en el servidor a la vez con la misma cuenta de GOFO: la ciudad activa es una sola
  por cuenta (ver memoria "portal-una-ciudad-a-la-vez").
