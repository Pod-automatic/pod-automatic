#!/usr/bin/env bash
# Equivalente Linux de tools/arrancar_corrida.ps1 (22/10/2026). Lo usa el servicio pod-corrida (systemd), que lo vuelve
# a lanzar solo si la corrida se cae (salvo código 2 = sesión de GOFO vencida: hay que iniciar sesión a mano).
#   ESTACIONES=DFW02-BAA REPARTIDORES="456804,454409" bash deploy/ubuntu/arrancar_corrida.sh
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT"
STAMP="$(date +%Y%m%d)"
LOG="storage/arranque_${STAMP}.log"
log() { echo "$(date +%H:%M:%S)  $*" >> "$LOG"; }
mkdir -p storage
log "Arranque (Ubuntu)"

# Paddle viejo: un servidor que queda abierto de un día para otro acumula memoria de GPU
pkill -f "paddle_ocr_server" 2>/dev/null && log "Paddle viejo cerrado" || true

# Ollama (servicio del sistema)
systemctl is-active --quiet ollama || { sudo -n systemctl start ollama 2>/dev/null && log "Ollama iniciado"; } || true

# Ciudades SOLO DEL DÍA ('_estaciones_solo_hoy' en drivers_config.json), igual que en Windows
if [ -z "${ESTACIONES:-}" ]; then
    ESTACIONES="$(venv/bin/python - <<'EOF'
import json, datetime
try:
    d = json.load(open("drivers_config.json", encoding="utf-8")).get("_estaciones_solo_hoy") or {}
    if d.get("fecha") == datetime.date.today().isoformat():
        print(d.get("estaciones") or "")
except Exception:
    pass
EOF
)"
fi
ARGS=(main.py run --continuous)
[ -n "${ESTACIONES:-}" ] && ARGS+=(--stations "$ESTACIONES")
[ -n "${REPARTIDORES:-}" ] && ARGS+=(--drivers "$REPARTIDORES")
log "Corrida iniciada (${ESTACIONES:-DFW-BAA y DFW02-BAA}, modo continuo). Salida en storage/corrida_${STAMP}.log"

export PYTHONIOENCODING=utf-8
# Pantalla virtual: el navegador puede abrir ventanas aunque no haya monitor
exec xvfb-run -a --server-args="-screen 0 1600x1000x24" venv/bin/python "${ARGS[@]}" \
    >> "storage/corrida_${STAMP}.log" 2>> "storage/corrida_${STAMP}_errores.log"
