"""
Arma la copia del proyecto para Ubuntu (22/10/2026, pedido del usuario: "haz una copia de todo que permita correr en
Ubuntu"). Se corre en Windows, con la corrida andando o no:

    venv\\Scripts\\python.exe deploy\\ubuntu\\empaquetar.py            (código + configuración + bases)
    venv\\Scripts\\python.exe deploy\\ubuntu\\empaquetar.py --sin-base (sin pod_checkpoints.db, ~800 MB)

Deja output/pod_automation_ubuntu_AAAAMMDD_HHMM.tar.gz con:
- todo el código, las pruebas, deploy/ubuntu y la configuración (drivers_config.json, .env);
- la sesión de GOFO (storage/session_state.json: cookies en JSON, sirven en otra máquina mientras no venzan);
- las bases SQLite, copiadas con la API de respaldo de SQLite (consistentes aunque la corrida esté escribiendo).
No lleva: los entornos de Windows (venv, venv_paddle), las fotos (storage/pod_images), los perfiles de navegador de
Windows (no sirven en Linux: WhatsApp Web se vincula de nuevo con el QR), registros ni respaldos viejos.
"""

import argparse
import sqlite3
import sys
import tarfile
import tempfile
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CODE_DIRS = ["automation", "processing", "export", "models", "tools", "tests", "deploy", "storage"]
ROOT_FILES = ["main.py", "config.py", "requirements.txt", "README.md", "generate_demo_dataset.py",
              "drivers_config.json", ".env"]
DATA_FILES = ["storage/session_state.json", "storage/faltantes.json"]
DATABASES = ["report_status.db", "route_panel.db", "portal_outbox.db", "package_control.db", "pod_checkpoints.db", "analysis_cache.db", "portal_wa_receipts.db"]
# 28/10: _retirado_20261028 guarda el multiciudad retirado (con un zip de cookies): nunca se empaqueta
SKIP_PARTS = {"__pycache__", ".pytest_cache", "_retirado_20261028"}


def code_files():
    for d in CODE_DIRS:
        base = ROOT / d
        # De storage/ solo el código (.py); los datos van aparte
        pattern = "*.py" if d == "storage" else "**/*"
        for p in base.glob(pattern):
            if p.is_file() and not SKIP_PARTS & set(p.parts) and p.suffix not in (".pyc", ".log"):
                yield p
    for f in ROOT_FILES:
        if (ROOT / f).exists():
            yield ROOT / f


def backup_db(src: Path, dst: Path) -> None:
    """Copia consistente de una base SQLite en uso (WAL incluido)."""
    # "with sqlite3.connect()" no cierra la conexión (solo confirma): en Windows el temporal quedaba tomado
    s = sqlite3.connect(f"file:{src.as_posix()}?mode=ro", uri=True, timeout=60)
    d = sqlite3.connect(dst)
    try:
        s.backup(d)
    finally:
        d.close()
        s.close()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--sin-base", action="store_true", help="no incluir pod_checkpoints.db (la más grande)")
    args = ap.parse_args()
    out = ROOT / "output" / f"pod_automation_ubuntu_{datetime.now():%Y%m%d_%H%M}.tar.gz"
    out.parent.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp, tarfile.open(out, "w:gz") as tar:
        n = 0
        for p in code_files():
            tar.add(p, arcname=f"pod_automation/{p.relative_to(ROOT).as_posix()}")
            n += 1
        for f in DATA_FILES:
            if (ROOT / f).exists():
                tar.add(ROOT / f, arcname=f"pod_automation/{f}")
        for name in DATABASES:
            if args.sin_base and name == "pod_checkpoints.db":
                continue
            src = ROOT / "storage" / name
            if not src.exists():
                continue
            print(f"Copiando {name} ({src.stat().st_size / 1e6:.0f} MB)...", flush=True)
            dst = Path(tmp) / name
            backup_db(src, dst)
            tar.add(dst, arcname=f"pod_automation/storage/{name}")
    print(f"Listo: {out} ({out.stat().st_size / 1e6:.0f} MB, {n} archivos de código)")


if __name__ == "__main__":
    sys.exit(main())
