#!/usr/bin/env bash
# Crea los servicios systemd del proyecto (22/10/2026):
#   pod-report  : página local de reportes (127.0.0.1:8765) + envío por WhatsApp, siempre activa
#   pod-corrida : la corrida en modo continuo; si se cae, se vuelve a lanzar sola al minuto
#                 (no si termina con código 2 = sesión de GOFO vencida)
# La pantalla virtual :99 (Xvfb) la comparten WhatsApp Web y el login a mano por VNC.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
USER_NAME="$(id -un)"

sudo tee /etc/systemd/system/pod-xvfb.service >/dev/null <<EOF
[Unit]
Description=POD - pantalla virtual :99
[Service]
User=$USER_NAME
ExecStart=/usr/bin/Xvfb :99 -screen 0 1600x1000x24 -nolisten tcp
Restart=always
[Install]
WantedBy=multi-user.target
EOF

sudo tee /etc/systemd/system/pod-report.service >/dev/null <<EOF
[Unit]
Description=POD - pagina local de reportes
After=network-online.target pod-xvfb.service
Wants=pod-xvfb.service
[Service]
User=$USER_NAME
WorkingDirectory=$ROOT
Environment=DISPLAY=:99
Environment=PYTHONIOENCODING=utf-8
ExecStart=$ROOT/venv/bin/python main.py report
Restart=always
RestartSec=10
[Install]
WantedBy=multi-user.target
EOF

sudo tee /etc/systemd/system/pod-corrida.service >/dev/null <<EOF
[Unit]
Description=POD - corrida continua
After=network-online.target ollama.service pod-report.service
[Service]
User=$USER_NAME
WorkingDirectory=$ROOT
ExecStart=/bin/bash $ROOT/deploy/ubuntu/arrancar_corrida.sh
Restart=on-failure
RestartSec=60
RestartPreventExitStatus=2
[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable --now pod-xvfb pod-report
echo "Servicios creados. La corrida NO se arranca sola todavía: primero revisar la sesión de GOFO (README_UBUNTU.md)."
echo "  Arrancar:  sudo systemctl enable --now pod-corrida"
echo "  Detener:   sudo systemctl stop pod-corrida"
echo "  Estado:    systemctl status pod-corrida ; tail -f storage/corrida_\$(date +%Y%m%d).log"
