# Prompt para el portal: sección "Comparar GPU vs local"

Copia todo lo que sigue (desde la línea de abajo) y pásaselo a Claude Code abierto en la carpeta del portal
(`C:\Users\luisv\OneDrive\Desktop\Trackingint.com\trackingint-sitio\portal`).

---

Quiero agregar al portal una sección SOLO para admin, "Comparar GPU vs local", que reciba los resultados de una corrida de prueba que corre en una GPU en la nube (Kaggle) y los compare con lo que detectó la corrida local (los albaranes normales de la tabla `pods`). Nada de esto debe tocar los envíos reales ni lo que ven los clientes.

## 1. Recepción (API)

Crear `api/ingest_gpu.php`, copiando el estilo de `api/ingest.php` (mismo `api_auth()`, mismo límite de tamaño, mismas validaciones de tracking, fecha, estación y GPS). Diferencias:

- Guarda en una tabla NUEVA `gpu_pods` (migrarla sola en el bootstrap, esquema nuevo), NUNCA en `pods`. Clave única: (`delivery_date`, `tracking`, `model`).
- Columnas: `delivery_date`, `tracking`, `model` (texto, ej. `qwen2.5vl:3b`), `station_code`, `driver`, `driver_id`, `address`, `priority` (Alta/Media/Baja, **acepta Baja y la guarda**, no la retira), `score`, `reasons` (JSON), `detection`, `card_files` (JSON, solo la tarjeta; sin fotos originales), `pod_lat`, `pod_lng`, `sign_distance`, `received_at`, `updated_at`.
- Mismo cuerpo `{"items": [...]}` que `ingest.php` (hasta 25 por pedido) con un campo extra `model`. Si el albarán ya existe para ese modelo, se actualiza.
- Las tarjetas se guardan en una carpeta aparte (`files/cards_gpu/<fecha>/`) y se borran con la misma regla de `purge_old_cards()` (solo hoy y ayer).
- No debe cambiar estados, ni crear tipos de error, ni encolar WhatsApp, ni tocar `pods`.
- La clave de API es la misma de Ajustes > Conexión con el script (si prefieres una clave aparte solo para GPU, hazla y dime dónde se genera; así se puede revocar sin afectar la PC).

## 2. Pantalla (admin)

Crear `admin/gpu.php` y un enlace "Comparar GPU" en el menú del admin. Con selector de fecha (por defecto hoy), de ciudad/estación y de modelo:

1. **Resumen arriba** (tarjetas): albaranes vistos por GPU vs local; Alta/Media/Baja de cada lado; ritmo por hora de cada lado (por `received_at` / `created_at`); primer y último albarán recibido.
2. **Coincidencias**: tabla con cuántos albaranes están en los dos lados y cuántos solo en uno (GPU o local).
3. **Acuerdo de prioridad** (matriz 3×3: local en filas, GPU en columnas, con conteos clicables).
4. **Lista de diferencias**, ordenada así: (a) local Alta/Media y GPU Baja (la GPU "perdió" un error), (b) GPU Alta/Media y local Baja (la GPU encontró algo nuevo o es falsa alarma), (c) mismo nivel pero distinta detección. Cada fila: albarán, repartidor, estación, prioridad local vs GPU, puntaje de cada una, motivos de cada una lado a lado, y la tarjeta de cada lado (miniatura, clic para ampliar con el mismo visor de zoom que ya existe).
5. **Contraste con las marcas humanas**: para los albaranes que el admin ya marcó en `pods.status` (reportado / descartado), mostrar cuántos errores reales (reportados) detecta la GPU (Alta/Media) y cuántas falsas alarmas (descartados) también marca la GPU. Es la métrica que más importa: "errores reales detectados" y "falsas alarmas".
6. Botón para exportar la comparación a Excel con el generador `inc/xlsx.php` que ya existe.

## 3. Reglas

- Solo admin; los clientes no ven nada de esto.
- Mismo estilo visual y mismas funciones auxiliares que el resto del admin.
- No modificar `ingest.php`, `status.php`, `changes.php` ni `wa_queue.php`.
- Probar con Docker (php:8.2-apache + mariadb) como en las pruebas anteriores: enviar a `ingest_gpu.php` un lote con Alta, Media y Baja, verificar que `pods` no cambia, que la comparación cuadra y que el Excel abre.
- Entregarme un zip solo con los archivos nuevos o cambiados (sin `config.php` ni `.htaccess`) para extraerlo en `public_html`.
