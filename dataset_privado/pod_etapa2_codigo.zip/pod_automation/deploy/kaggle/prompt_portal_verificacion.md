# Prompt para el portal: verificación cruzada PC ↔ GPU (api/verify.php)

Pégalo en Claude Code abierto en `C:\Users\luisv\OneDrive\Desktop\Trackingint.com\trackingint-sitio\portal`.

---

Quiero que el portal coordine una **verificación cruzada** entre las dos corridas del script (la de la PC, worker `pc`, y la de la GPU en la nube, worker `gpu`): cuando una corrida marca un albarán como **Alta o Media**, la OTRA lo analiza por su cuenta y manda su propio resultado, para comparar si los dos coinciden. No debe tocar la revisión normal, los estados, el WhatsApp ni los clientes.

Antes de empezar, lee `api/ingest.php`, `api/ingest_gpu.php`, `api/claim.php`, `inc/gpu.php` y `admin/gpu.php` actuales, y respeta su estilo (auth, migraciones solas en el bootstrap, CSRF, etc.).

## 1. Tabla y endpoint

Tabla nueva `cross_checks` (migración sola): `delivery_date`, `tracking`, `origin_worker` ('pc' | 'gpu': quién lo marcó), `origin_priority`, `origin_score`, `verifier_worker` (la otra), `status` ('pendiente' | 'reservado' | 'hecho' | 'error'), `reserved_until`, `verifier_priority`, `verifier_score`, `verifier_reasons` (JSON), `verifier_detection`, `verifier_omitted_check`, `error`, `created_at`, `done_at`. Clave única: (`delivery_date`, `tracking`).

**Se alimenta sola:** al recibir un albarán Alta/Media en `ingest.php` (worker `pc`) o en `ingest_gpu.php` (worker `gpu`), crear la fila `pendiente` con `origin_worker` según quién lo mandó y `verifier_worker` la otra. Si ya existe, no se duplica ni se pisa un resultado ya hecho. Si el albarán ya es de la otra corrida porque las dos lo vieron, no se crea (ya hay comparación directa).

`POST api/verify.php` con `api_auth_gpu()` (acepta la clave de la GPU y la normal). Dos acciones:

**a) `{"action": "next", "worker": "gpu", "limit": 4, "priorities": "Alta,Media", "only_reported": false}`**
- Elige hasta `limit` filas con `verifier_worker = worker`, `status = 'pendiente'` (o `reservado` vencido) y `origin_priority` dentro de `priorities`. Si `only_reported` es true, solo las que en `pods.status` estén 'reportado' (la marca humana de Revisión; para las de la GPU, cruzar con `pods` por tracking y fecha).
- Las marca `reservado` por 10 minutos, en una transacción (que dos pedidos no se lleven la misma).
- Responde `{"ok": true, "items": [{"date","tracking","driver","driver_id","station","sign_distance","pod_lat","pod_lng","flagged_by": "pc"|"gpu"}, ...]}`. Los datos de conductor, estación, GPS y distancia salen de `pods` o `gpu_pods`. Orden: primero las Alta, luego las más antiguas.

**b) `{"action": "result", "worker": "gpu", "items": [{"date","tracking","priority","score","reasons":[...],"detection","omitted":{...},"model", "error"}]}`**
- Por cada item: si trae `error`, `status='error'` con el mensaje (no se vuelve a pedir). Si no, `status='hecho'`, guardando prioridad, puntaje, motivos, detección y el motivo de omisión (`omitted.check`) del verificador. La prioridad puede ser Alta, Media o **Baja**.
- Validar tracking y fecha como en `ingest.php`. Responder `{"ok": true, "errors": []}` (con `index` y `error` por cada item rechazado).

## 2. Pantalla (admin)

En `admin/gpu.php`, una pestaña nueva **"Verificación cruzada"**, con selector de fecha. Muestra:

1. **Resumen:** cuántas marcas hay por verificar, reservadas, hechas y con error; y del total de hechas, cuántas **coinciden** (misma prioridad), cuántas **coinciden en alerta** (las dos dicen Alta o Media aunque cambie el nivel), cuántas **discrepan** (una dice Alta/Media y la otra Baja) y cuántas son Alta contra Media.
2. **Dos filas de números separadas por origen:** "marcado por la PC y verificado por la GPU" y "marcado por la GPU y verificado por la PC".
3. **Lista** de albaranes con: albarán, repartidor, quién lo marcó, su prioridad y puntaje, quién lo verificó, su prioridad y puntaje, ambos motivos lado a lado, el motivo de omisión si el verificador lo dejó en Baja por una regla, y la marca humana de Revisión (reportado/descartado/pendiente) si existe. Filtros: coincidencia (todas, coinciden, discrepan), origen, prioridad, repartidor, y los mismos de la pantalla actual.
4. **Contraste con tus marcas** (la métrica importante): entre los que ya marcaste en Revisión, cuántos **reportados** confirmó el verificador (Alta/Media) y cuántos **descartados** también marcó como alerta. Así se ve si la verificación cruzada habría ayudado a separar errores reales de falsas alarmas.
5. Exportación a Excel con las mismas columnas y filtros.

Las tarjetas y las fotos de cada lado se muestran como ya lo hace "Comparar GPU" (reutiliza los componentes).

## 3. Reglas

- Solo admin. No modificar `status.php`, `changes.php`, `wa_queue.php`. En `ingest.php` e `ingest_gpu.php` solo agregar la creación de la fila de `cross_checks` (en un bloque que, si falla, no impida guardar el albarán).
- Limpieza: borrar filas de más de 7 días.
- Pruebas (Docker php:8.2 + mariadb): enviar Alta/Media desde cada worker, pedir con el otro (`next`), comprobar que dos pedidos simultáneos no se llevan la misma, que una reserva vencida se vuelve a ofrecer, mandar resultados (incluida una Baja y un error), y revisar las cifras de la pestaña, el contraste con marcas y el Excel.
- Entregar un zip con solo los archivos nuevos o cambiados, sin `config.php` ni `.htaccess`.
