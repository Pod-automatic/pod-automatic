r"""
Arma el paquete de la ETAPA 1 en Kaggle (prueba de OCR + modelo de visión en la GPU, sin login de GOFO).

    venv\Scripts\python.exe deploy\kaggle\empaquetar_kaggle.py [--date 2026-10-01]

Deja output/kaggle_pod_AAAAMMDD.zip, para subir como Dataset privado de Kaggle, con:
- el código (sin .env ni session_state.json: esta etapa no entra al portal);
- storage/pod_checkpoints.db reducido a ese día, con las rutas de las fotos reescritas a /kaggle/working;
- report_status.db y tests/casos_reales_<fecha>.json (la verdad que usa tools/evaluar_dia.py);
- las fotos de esos albaranes (storage/pod_images/<fecha>/...).
"""

import argparse
import json
import sqlite3
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "deploy" / "ubuntu"))

import config  # noqa: E402
from empaquetar import code_files  # noqa: E402
from tools.evaluar_dia import truth  # noqa: E402

KAGGLE_ROOT = "/kaggle/working/pod_automation"
SKIP_ROOT = {".env"}


def rewrite(obj, old_prefix: str):
    """Cambia cualquier ruta de foto de Windows por la de Kaggle, dentro del JSON del albarán."""
    if isinstance(obj, str):
        if obj.replace("\\", "/").startswith(old_prefix):
            return KAGGLE_ROOT + "/storage/pod_images/" + obj.replace("\\", "/")[len(old_prefix):]
        return obj
    if isinstance(obj, list):
        return [rewrite(x, old_prefix) for x in obj]
    if isinstance(obj, dict):
        return {k: rewrite(v, old_prefix) for k, v in obj.items()}
    return obj


def slim_db(date: str, dst: Path, trackings: set) -> list:
    src = sqlite3.connect(f"file:{config.CHECKPOINT_DB_PATH.as_posix()}?mode=ro", uri=True, timeout=60)
    out = sqlite3.connect(dst)
    for name in ("audit_sessions", "pod_checkpoints"):
        out.execute(src.execute("SELECT sql FROM sqlite_master WHERE name = ?", (name,)).fetchone()[0])
    sessions = [r[0] for r in src.execute("SELECT session_id FROM audit_sessions WHERE query_date = ?", (date,))]
    for r in src.execute("SELECT * FROM audit_sessions WHERE query_date = ?", (date,)):
        out.execute(f"INSERT INTO audit_sessions VALUES ({','.join('?' * len(r))})", r)
    cols = [c[1] for c in src.execute("PRAGMA table_info(pod_checkpoints)")]
    pj = cols.index("payload_json")
    old_prefix = (config.STORAGE_DIR / "pod_images").as_posix() + "/"
    photos = []
    for r in src.execute("SELECT p.* FROM pod_checkpoints p JOIN audit_sessions s ON s.session_id = p.session_id "
                         "WHERE s.query_date = ?", (date,)):
        if r[cols.index("tracking_number")] not in trackings:
            continue
        r = list(r)
        data = rewrite(json.loads(r[pj]), old_prefix)
        r[pj] = json.dumps(data, ensure_ascii=False)
        out.execute(f"INSERT INTO pod_checkpoints VALUES ({','.join('?' * len(r))})", r)
    out.commit()
    out.close()
    src.close()
    return sessions


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--date", default="2026-10-01")
    date = ap.parse_args().date
    out = ROOT / "output" / f"kaggle_pod_{date.replace('-', '')}.zip"
    with tempfile.TemporaryDirectory() as tmp, zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for p in code_files():
            if p.name in SKIP_ROOT and p.parent == ROOT:
                continue
            z.write(p, "pod_automation/" + p.relative_to(ROOT).as_posix())
        db = Path(tmp) / "pod_checkpoints.db"
        trackings = set(truth(date))
        slim_db(date, db, trackings)
        z.write(db, "pod_automation/storage/pod_checkpoints.db")
        z.write(config.STORAGE_DIR / "report_status.db", "pod_automation/storage/report_status.db")
        n = 0
        for p in (config.STORAGE_DIR / "pod_images" / date).rglob("*"):
            if p.is_file() and p.parent.name in trackings:
                z.write(p, "pod_automation/storage/pod_images/" + p.relative_to(config.STORAGE_DIR / "pod_images").as_posix())
                n += 1
    print(f"{out}  ({out.stat().st_size / 1e6:.0f} MB, {n} fotos)")


if __name__ == "__main__":
    main()
