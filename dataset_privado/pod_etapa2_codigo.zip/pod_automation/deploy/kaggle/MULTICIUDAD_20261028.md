# Un Kaggle, dos sesiones

Una sola maquina de Kaggle (T4 x2) ejecuta dos procesos separados, cada uno con su cuenta de GOFO:

- `gpu_luis` (cookies de Luis): DFW-BAA y DFW02-BAA. Apoya a la PC, que usa la misma cuenta, asi que se turna con ella.
- `gpu_tracking` (cookies de Tracking Int): SOLO las ciudades indicadas ese dia en la celda 4, por ejemplo `env['TRACKING_STATIONS']='DFW-BAA,DFW02-BAA'`. Hay que revisarlo cada dia. Validas: DFW-BAA, DFW02-BAA, IAH-BAA, IAH02-BAA y ORD-BAA. Sin ese valor, o con un codigo mal escrito, la celda 4 se detiene y no se lanza nada. Si coinciden con las de Luis/PC, el reparto de albaranes del portal evita repetir trabajo y el despachador de ciudades reparte los dos procesos entre ellas; como Tracking usa otra cuenta, no necesita turnos de sesion. La cuenta de Tracking debe tener acceso en GOFO a esas ciudades.

## Una cuenta de Kaggle por sesion (29/10)

`SESION` en la celda 1 elige que corre en esa cuenta de Kaggle: `'luis'`, `'tracking'` o `'luis,tracking'` (las dos en la misma maquina, como antes). Con una sesion por cuenta, cada una tiene la maquina completa (2 T4 y las 4 CPU). `tools/preparar_kaggle_cuentas.py` arma `output/kaggle_luis/` y `output/kaggle_trackingint/`, cada una con su notebook (SESION ya fijada), sus celdas, un `LEEME.md` y `dataset_privado/` con el codigo y SOLO las cookies de esa sesion. Una misma sesion nunca debe correr en dos cuentas a la vez: el portal le daria a las dos los mismos albaranes (mismo nombre de corrida) y, en Tracking, las dos cambiarian la ciudad de la misma cuenta de GOFO.

Cuando corren en la misma maquina, los dos procesos comparten los servicios OCR/vision, el cache de analisis y las coordenadas OCR. Las bases, fotos, reportes y registros de cada proceso quedan separados (`storage/multi/workers/<proceso>/`).

## Como se reparte

Hay tres repartos, cada uno con su funcion:

1. **Albaranes (portal, `claim.php`).** Cada corrida (PC, `gpu_luis`, `gpu_tracking`) pide albaranes en lotes de 5 y el portal se los reserva 10 minutos. Asi nadie analiza un albaran que ya tiene otro. Lo terminado se confirma; si una corrida se cae, su reserva vence y otra la toma. Los bloqueos del reparto no cuentan como paquetes disponibles.
2. **Turnos de la sesion de Luis (portal, `session_guard.php`).** Ver la seccion siguiente.
3. **Ciudades dentro de Kaggle (`automation/city_dispatch.py`, base local `storage/multi/cities.db`).** Cada proceso elige, entre sus ciudades, la menos atendida que el otro no este usando. Una ciudad cede el turno tras unos 240 segundos de extraccion (`CITY_TURN_S`; 90 hasta el 29/10), para que ninguna espere indefinidamente; el limite se comprueba entre bloques y no interrumpe una peticion ni un analisis a medias. Una ciudad sin trabajo descansa 2 minutos antes de volver a consultarse. Si todas estan al dia se espera 10 segundos, sin ocupar la GPU con consultas innecesarias.

## Sesion de Luis y PC

GOFO trabaja con una sola ciudad activa por cuenta: lo que choca es CAMBIAR de ciudad desde dos maquinas a la vez, no trabajar a la vez en la misma. Desde el 29/10 la PC y `gpu_luis` **comparten la ciudad**: el portal dice en cual trabajar (DFW-BAA o DFW02-BAA) y las dos extraen a la vez en esa ciudad; el reparto de albaranes evita que repitan. Cada ciudad dura un turno de 240 s (`CITY_TURN_S`, igual en la PC y en Kaggle): al vencer no entra nadie mas y, cuando las dos salieron, el portal pasa a la ciudad menos atendida. Una ciudad sin trabajo se salta 2 min. Con la ciudad compartida, la corrida no puede abrir otra ciudad aunque algun paso lo intente. `gpu_tracking` usa otras cookies y no participa de esto.

- El cierre del dia y las versiones anteriores del script piden la sesion EXCLUSIVA: esperan a que se vacie y, al vaciarse, tienen preferencia. Asi una corrida vieja nunca entra a la vez que una nueva. Las rutas listadas se reutilizan 600 s (`ROUTE_LIST_CACHE_S`) si los totales del repartidor no cambiaron, para que cada turno empiece a extraer enseguida.
- La reserva dura 180 segundos y se renueva cada 20. Si se pierde el proceso, vence sola. Un proceso antiguo no puede renovar ni liberar la reserva de uno nuevo.
- Un corte corto del portal no quita la reserva: se reintenta mientras siga vigente.
- Si el portal no responde, Kaggle siempre espera. La PC sigue sola tras 210 segundos de corte de red seguido (o el permiso mas largo dado por el portal + 30 s); se detiene si GOFO cambia de ciudad sin que ella lo pida y retoma los turnos cuando vuelve el portal.

Los archivos del portal (`portal/api/session_guard.php` y `portal/inc/session_guard.php`) vienen en el ZIP del hosting (`portal-corregido-20261028.zip`). En la PC que usa las cookies de Luis, el `.env` debe tener `GOFO_SESSION_GROUP=luisvivas`. El lanzador de Kaggle ya fija ese grupo para `gpu_luis`; `gpu_tracking` usa el grupo vacio. Los navegadores o scripts que cambien de ciudad por fuera de este mecanismo no quedan coordinados.

## GPU compartida

Cada GPU tiene qwen2.5vl:3b y un servicio Paddle. Desde el 28/10 no hay modelo de respaldo (se retiro el 7b): su escalacion gastaba el tope de 5 consultas por albaran y llenaba la GPU 1 (HTTP 500 de Ollama).

La cola compartida concede `GPU_PARALLEL` consultas de vision por GPU a la vez y elige primero la GPU con mas huecos libres. Desde el 29/10 vale 2: se fija en la celda 3 y sirve a la vez para Ollama (`OLLAMA_NUM_PARALLEL`) y para la cola del script (`GPU_SLOTS_PER_URL`), asi que no pueden quedar distintos. Medido en la 4050 (28/10): 2 = ~255-267 imagenes/min contra ~160-180 con 1, con +46 MiB de VRAM. En T4 aun no esta medido: la celda 3 muestra la memoria usada de cada GPU. Si Ollama da HTTP 500 o falta memoria, poner `GPU_PARALLEL='1'` en la celda 3 y reiniciar la sesion.

La maquina tiene cuatro CPU: el limite de cuatro analisis a la vez es global, no por cuenta. Si un proceso no tiene trabajo, el otro puede usar los cuatro cupos. Con 2 GPU x 2 consultas hay cuatro huecos de vision, uno por analisis. Los hilos de BLAS/OpenMP se limitan a uno. Un proceso no descarga los modelos compartidos por su cuenta.

Hay que medir VRAM, cola y albaranes terminados por hora en las corridas reales. Si un servicio falla, revisar los logs antes de continuar; no se suprime la segunda opinion ni se aprueban paquetes para aparentar mas velocidad.

## Archivos para Kaggle

1. Subir `pod_etapa2_codigo.zip` y, **en un dataset privado**, `pod_multisesion_secretos.zip`. Este ultimo contiene solo `luis.json` y `tracking.json`, dos credenciales existentes distintas; no publica ni crea cuentas. La vigencia se comprueba al iniciar cada navegador.
2. Opcional: adjuntar como Input el `pod_kaggle_estado.zip` de la corrida anterior para recuperar cache, coordenadas, checkpoints y fotos. Sin el, la celda 1 avisa que la maquina no tiene cache previa.
3. Importar `pod_multiciudad_20261028.ipynb` (o pegar las celdas de `output/celdas_kaggle_multiciudad/`), activar T4 x2 e Internet y guardar `PORTAL_API_KEY` en Kaggle Secrets.
4. Usar una sesion nueva de Kaggle y ejecutar las seis celdas. La PC debe tener el codigo actual y el grupo de coordinacion indicado arriba. El lanzador comprueba que el endpoint de turnos exista antes de iniciar las dos corridas.

## Las seis celdas

1. **Codigo y sesiones:** descomprime el codigo, restaura el estado anterior si se adjunto y carga las dos cookies. Exige dos GPU.
2. **Dependencias:** Chromium, Paddle, Ollama y las librerias del script.
3. **Servicios:** arranca Ollama y Paddle en cada GPU con `GPU_PARALLEL`, carga el 3b y muestra la memoria usada.
4. **Comprobacion:** lee la clave del portal, fija el cierre y valida la configuracion de los dos procesos (`--check` muestra ciudades, coordinacion con la PC y consultas de vision por GPU).
5. **Lanzamiento:** inicia el supervisor, que lanza los dos procesos.
6. **Vigilancia:** cada minuto muestra el ritmo de cada sesion, GPU, CPU/RAM y los ultimos eventos. Cada 20 minutos y al final genera `diagnostico_kaggle.zip` (logs y resultados, sin cookies, claves ni fotos). Al cerrar guarda `pod_kaggle_estado.zip` para la proxima corrida (descargar ambos de Output).

## Horario y relanzamientos

El cierre lo fija la celda 4: `MULTI_STOP_AT='10:00'` (la proxima vez que sean las 10:00 de Venezuela) y `MULTI_MAX_HOURS='11'` (tope desde el arranque, porque Kaggle corta cada sesion a las 12 horas). Sin esas variables, el lanzador cierra a las 22:30 de hoy en Venezuela. Al terminar hay que detener tambien la sesion de Kaggle para liberar su cuota.

El supervisor relanza un proceso que se detenga inesperadamente, incluso con salida 0, con esperas de 30, 60, 120, 240 y hasta 300 segundos; la espera vuelve a 30 segundos tras diez minutos de funcionamiento estable. Un proceso con cookies vencidas (salida 2) se deja detenido para renovar su sesion; el otro puede seguir. La celda 6 tambien relanza el supervisor si falla. Se conservan checkpoints y cache al relanzar.

Estos relanzamientos funcionan mientras siga viva la sesion de Kaggle. Si Kaggle apaga la maquina, agota la cuota o detiene el notebook, el codigo ya no se ejecuta y no puede crear otra sesion.

Logs: `storage/multi/gpu_luis.log`, `storage/multi/gpu_tracking.log` y `/kaggle/working/multiciudad.log`; monitor por proceso en `storage/multi/workers/`.

La implementacion se entrega preparada localmente. Subir los archivos al hosting y a Kaggle es necesario para activarla; generar los ZIP no modifica el servidor ni arranca la GPU.
