# Prompt para el portal: repartidor de trabajo entre la PC y la GPU (api/claim.php)

Pégalo en Claude Code abierto en `C:\Users\luisv\OneDrive\Desktop\Trackingint.com\trackingint-sitio\portal`.

---

Quiero que el portal sea el **repartidor de trabajo** entre dos corridas del script que revisan los mismos albaranes (la de la PC y la de una GPU en la nube), para que no repitan paquetes y se repartan según su velocidad: la más rápida pide más bloques.

## 1. Tabla y endpoint

Tabla nueva `work_claims` (migrarla sola en el bootstrap): `delivery_date`, `tracking`, `worker` (varchar 20: "pc", "gpu"…), `status` ('claimed' | 'done'), `claimed_at`, `expires_at`, `done_at`. Clave única: (`delivery_date`, `tracking`).

`POST api/claim.php`, mismo `api_auth_gpu()` (que acepta la clave de la GPU y la normal del script, y se pueden usar las dos corridas). Cuerpo:

```
{"worker": "gpu", "date": "2026-10-25", "trackings": ["GFUS…", …] (hasta 100), "done": ["GFUS…", …] (opcional, hasta 200), "lease_s": 600}
```

Lógica, en UNA transacción (para que dos corridas no se pisen):
1. Para cada tracking de `done`: marcarlo `done` (con su `worker`) si no lo estaba.
2. Para cada tracking de `trackings`, en orden:
   - Si no existe fila: crearla `claimed` para este `worker` con `expires_at = ahora + lease_s` y concederlo.
   - Si existe `done`: **no concederlo** (ya lo revisó cualquiera de las dos).
   - Si existe `claimed` del **mismo** worker: renovar la reserva y concederlo.
   - Si existe `claimed` de **otro** worker y NO venció: no concederlo.
   - Si existe `claimed` de otro worker y YA venció (se cayó): reasignarlo a este worker y concederlo.
3. Responder `{"ok": true, "granted": [trackings concedidos], "denied": N}`.

Usa `INSERT … ON DUPLICATE KEY UPDATE` o `SELECT … FOR UPDATE` según el motor para que sea atómico. Validar el formato de tracking como en `ingest.php`. Máximo 100 `trackings` y 200 `done` por pedido.

## 2. Pantalla (opcional, pequeña)

En `admin/gpu.php`, un recuadro "Reparto de trabajo" del día: cuántos albaranes tiene reservados y hechos cada worker, cuántos reservados vencidos, y el ritmo de cada uno (hechos por hora, según `done_at`). Así se ve la capacidad real de cada corrida.

## 3. Reglas

- No tocar `ingest.php`, `ingest_gpu.php`, `status.php`, `changes.php` ni `wa_queue.php`.
- Limpieza: borrar filas de más de 3 días.
- La corrida local sigue funcionando si este endpoint no responde (el script, si falla, revisa todo), así que no debe devolver errores 500 por un tracking mal formado: ignóralo y sigue.

## 4. Pruebas (Docker php:8.2 + mariadb)

- Dos workers piden el mismo lote a la vez: la unión de lo concedido no repite ningún tracking.
- Un tracking reservado por "pc" y vencido pasa a "gpu".
- Un tracking `done` ya no se concede a nadie.
- Pedir con tracking inválido no rompe el pedido.
- Entregarme un zip con solo los archivos nuevos o cambiados, sin `config.php` ni `.htaccess`.
