# ETAPA 1 en Kaggle: OCR (PaddleOCR) + modelo de visión (Ollama) sobre las fotos del 01/10, sin login de GOFO.
# Cada bloque "# %%" va en una celda aparte del notebook, en orden.
# Antes: Settings > Accelerator = GPU T4 x2 (o P100) y Internet = On. Add Input > el dataset con kaggle_pod_20261001.zip.

# %% 1. GPU, unir los 9 trozos del dataset (kaggle_pod.zip.part00..08), descomprimir y entrar a la carpeta
import glob, gzip, os, subprocess, zipfile
print(subprocess.run("nvidia-smi --query-gpu=name,memory.total --format=csv", shell=True, capture_output=True, text=True).stdout)
parts = sorted(glob.glob("/kaggle/input/**/kaggle_pod.zip.part*", recursive=True))
print(len(parts), "trozos")
if not os.path.exists("/kaggle/working/pod_automation"):
    with open("/kaggle/working/kaggle_pod.zip", "wb") as out:
        for p in parts:
            out.write(open(p, "rb").read())
    zipfile.ZipFile("/kaggle/working/kaggle_pod.zip").extractall("/kaggle/working")
db = glob.glob("/kaggle/input/**/pod_checkpoints.db.gz", recursive=True)  # base corregida (versión 2 del dataset)
if db:
    open("/kaggle/working/pod_automation/storage/pod_checkpoints.db", "wb").write(gzip.open(db[0]).read())
os.chdir("/kaggle/working/pod_automation")
print(os.listdir("."))

# %% 2. Instalación (~15-25 min la primera vez): entorno principal, entorno de Paddle, Ollama + modelo
!apt-get -qq update && apt-get -qq install -y tesseract-ocr zstd > /dev/null
!rm -rf venv venv_paddle && pip -q install virtualenv && virtualenv -q venv && venv/bin/python -m pip -q install -r deploy/ubuntu/requirements-linux.txt
!virtualenv -q venv_paddle && venv_paddle/bin/python -m pip -q install paddlepaddle-gpu==3.3.1 -i https://www.paddlepaddle.org.cn/packages/stable/cu126/
!venv_paddle/bin/python -m pip -q install -r deploy/ubuntu/requirements-paddle-linux.txt
!venv_paddle/bin/python -c "import paddle; paddle.utils.run_check()"
!curl -fsSL https://ollama.com/install.sh | sh

# %% 3. Levantar Ollama en segundo plano y bajar el modelo de visión
import subprocess, time
subprocess.Popen("ollama serve > /kaggle/working/ollama.log 2>&1", shell=True)
time.sleep(8)
!ollama pull qwen2.5vl:3b
!ollama list

# %% 4. Prueba corta (20 albaranes): Paddle arranca solo la primera vez (~1-4 min)
!cd /kaggle/working/pod_automation && venv/bin/python tools/evaluar_dia.py --date 2026-10-01 --limit 20 --out /kaggle/working/eval_kaggle.jsonl

# %% 5. Si la prueba corta salió bien: los 386 albaranes (se puede cortar y retomar, el archivo guarda el avance)
!cd /kaggle/working/pod_automation && venv/bin/python tools/evaluar_dia.py --date 2026-10-01 --out /kaggle/working/eval_kaggle.jsonl

# %% 6. Segundos por albarán en Kaggle (compararlo con la PC: output/evaluacion_2026-10-01_*.jsonl)
import json, statistics
rows = [json.loads(l) for l in open("/kaggle/working/eval_kaggle.jsonl")]
seg = [r["segundos"] for r in rows if "segundos" in r]
print(len(rows), "albaranes; mediana", statistics.median(seg), "s; promedio", round(sum(seg) / len(seg), 1), "s")

# %% 7. Dos Ollama (uno por GPU) con contexto 2048, en paralelo, y calentados
import os, subprocess, time
subprocess.run("pkill -f 'ollama serve'; pkill -f paddle_ocr_server; sleep 3", shell=True)
for gpu, port in ((0, 11434), (1, 11435)):
    env = dict(os.environ, CUDA_VISIBLE_DEVICES=str(gpu), OLLAMA_HOST=f"127.0.0.1:{port}", OLLAMA_NUM_PARALLEL="2",
               OLLAMA_CONTEXT_LENGTH="2048", OLLAMA_FLASH_ATTENTION="1", OLLAMA_KEEP_ALIVE="-1")
    subprocess.Popen("ollama serve", shell=True, env=env, stdout=open(f"/kaggle/working/ollama{gpu}.log", "w"), stderr=subprocess.STDOUT)
time.sleep(10)
for port in (11434, 11435):   # calentar: la primera consulta carga el modelo (si no, da timeout)
    print(subprocess.run(f"curl -s -m 120 localhost:{port}/api/generate -d '{{\"model\":\"qwen2.5vl:3b\",\"prompt\":\"hi\",\"stream\":false,\"keep_alive\":-1,\"options\":{{\"num_predict\":3,\"num_ctx\":2048}}}}' | head -c 160", shell=True, capture_output=True, text=True).stdout)

# %% 8. Lanzar 4 procesos en paralelo (2 por GPU, cada uno con su Paddle y su Ollama); retoma lo ya evaluado
import os, subprocess
N = 4
for i in range(N):
    gpu = 0 if i < N // 2 else 1
    env = dict(os.environ, CUDA_VISIBLE_DEVICES=str(gpu), PADDLE_OCR_PORT=str(8770 + i), OLLAMA_URL=f"http://127.0.0.1:{11434 + gpu}")
    cmd = (f"cd /kaggle/working/pod_automation && venv/bin/python tools/evaluar_dia.py --date 2026-10-01 --shard {i}/{N} "
           f"--skip-from /kaggle/working/eval_kaggle.jsonl --out /kaggle/working/eval_s{i}.jsonl > /kaggle/working/log_s{i}.txt 2>&1")
    subprocess.Popen(cmd, shell=True, env=env)
print("lanzados", N)

# %% 9. Avance y uso de GPU (se puede correr varias veces mientras los procesos trabajan)
!for i in 0 1 2 3; do echo "shard $i: $(wc -l < /kaggle/working/eval_s$i.jsonl 2>/dev/null || echo 0) evaluados"; done; wc -l < /kaggle/working/eval_kaggle.jsonl
!nvidia-smi --query-gpu=index,utilization.gpu,memory.used,memory.total --format=csv
!tail -n 2 /kaggle/working/log_s0.txt /kaggle/working/log_s2.txt

# %% 10. Resumen final (juntando los 4 procesos y lo evaluado antes)
import glob, json, sys
sys.path.insert(0, "/kaggle/working/pod_automation/tools")
from evaluar_dia import resumen
rows = {}
for f in ["/kaggle/working/eval_kaggle.jsonl"] + sorted(glob.glob("/kaggle/working/eval_s*.jsonl")):
    for l in open(f):
        r = json.loads(l); rows[r["tracking"]] = r
rows = list(rows.values())
print(len(rows), "albaranes; aciertos", sum(r.get("acierto", False) for r in rows))
resumen(rows)
