# ETAPA 2 en Kaggle: corrida de DFW02-BAA con dos GPUs y envio a Comparar GPU mediante Kaggle Secrets.
# Antes: Settings > Accelerator = GPU T4 x2, Internet = On, Add Input = dataset privado pod-etapa2 (código + secretos).
# Una celda "# %%" por bloque, en orden. La celda 6 detiene los procesos al terminar el plazo.

# %% 1. Descomprimir código y sesión de GOFO, y entrar a la carpeta (Kaggle a veces ya descomprime los .zip del dataset)
import glob, os, shutil, subprocess, zipfile
print(subprocess.run("nvidia-smi --query-gpu=name,memory.total --format=csv", shell=True, capture_output=True, text=True).stdout)
W = "/kaggle/working"
if not os.path.exists(f"{W}/pod_automation"):
    zc = glob.glob("/kaggle/input/**/pod_etapa2_codigo.zip", recursive=True)
    if zc:
        zipfile.ZipFile(zc[0]).extractall(W)
    else:   # ya descomprimido por Kaggle
        shutil.copytree(os.path.dirname(glob.glob("/kaggle/input/**/pod_automation/main.py", recursive=True)[0]), f"{W}/pod_automation")
os.makedirs(f"{W}/pod_automation/storage", exist_ok=True)
zs = glob.glob("/kaggle/input/**/pod_etapa2_secretos.zip", recursive=True)
if zs:
    zipfile.ZipFile(zs[0]).extractall(f"{W}/pod_automation/storage")
else:
    ss = glob.glob("/kaggle/input/**/session_state.json", recursive=True)
    if ss:
        shutil.copy(ss[0], f"{W}/pod_automation/storage/session_state.json")
os.chdir(f"{W}/pod_automation")
print("sesión de GOFO presente:", os.path.exists("storage/session_state.json"))

# %% 2. Instalación (~25 min): entornos, Chromium de Playwright, Xvfb, Ollama
!apt-get -qq update && apt-get -qq install -y tesseract-ocr zstd xvfb > /dev/null
!rm -rf venv venv_paddle && pip -q install virtualenv && virtualenv -q venv && venv/bin/python -m pip -q install -r deploy/ubuntu/requirements-linux.txt
!venv/bin/python -m playwright install --with-deps chromium > /dev/null
!virtualenv -q venv_paddle && venv_paddle/bin/python -m pip -q install paddlepaddle-gpu==3.3.1 -i https://www.paddlepaddle.org.cn/packages/stable/cu126/
!venv_paddle/bin/python -m pip -q install -r deploy/ubuntu/requirements-paddle-linux.txt
!curl -fsSL https://ollama.com/install.sh | sh

# %% 3. Dos Ollama (puertos 11434 en la GPU 0 y 11435 en la GPU 1) y dos Paddle (8770 y 8771); calentar todos
# CASCADA=True: GPU 0 = qwen2.5vl:3b (rápido, el de siempre) y GPU 1 = qwen2.5vl:7b (solo se llama cuando el 3b no confirma el número).
# CASCADA=False: el 3b en las dos GPU (como la prueba del 25/10).
import os, subprocess, time
CASCADA = False
MODELOS = {0: "qwen2.5vl:3b", 1: "qwen2.5vl:7b" if CASCADA else "qwen2.5vl:3b"}
subprocess.run("pkill -f 'ollama serve'; pkill -f paddle_ocr_server; sleep 2", shell=True)
for g in (0, 1):
    envg = dict(os.environ, CUDA_VISIBLE_DEVICES=str(g), OLLAMA_HOST=f"127.0.0.1:{11434 + g}", OLLAMA_NUM_PARALLEL="2",
                OLLAMA_CONTEXT_LENGTH="2048", OLLAMA_FLASH_ATTENTION="1", OLLAMA_KEEP_ALIVE="-1")
    subprocess.Popen("ollama serve", shell=True, env=envg, stdout=open(f"/kaggle/working/ollama{g}.log", "w"), stderr=subprocess.STDOUT)
    time.sleep(8)
    print(subprocess.run(f"ollama pull {MODELOS[g]}", shell=True, env=envg, capture_output=True, text=True).stdout[-200:])
    envp = dict(os.environ, CUDA_VISIBLE_DEVICES=str(g))
    subprocess.Popen(f"cd /kaggle/working/pod_automation && venv_paddle/bin/python tools/paddle_ocr_server.py --port {8770 + g}",
                     shell=True, env=envp, stdout=open(f"/kaggle/working/paddle{g}.log", "w"), stderr=subprocess.STDOUT)
for g in (0, 1):
    print(subprocess.run("curl -s -m 300 localhost:%d/api/generate -d '{\"model\":\"%s\",\"prompt\":\"hi\",\"stream\":false,\"keep_alive\":-1,\"options\":{\"num_predict\":3,\"num_ctx\":2048}}' | head -c 120" % (11434 + g, MODELOS[g]),
                         shell=True, capture_output=True, text=True).stdout)
time.sleep(45)
for g in (0, 1):
    print(subprocess.run(f"curl -s -m 20 localhost:{8770 + g}/health", shell=True, capture_output=True, text=True).stdout)

# %% 4. Comprobar la sesión de GOFO desde Kaggle (solo lee; nunca inicia sesión ni procesa nada)
import subprocess
open("/kaggle/working/check_session.py", "w").write("""
from automation.browser import BrowserManager
from automation.login import LoginManager
b = BrowserManager(headless=True)
b.start()
try:
    LoginManager(b).require_valid_session()
    print("SESION_OK")
except Exception as e:
    print("SESION_NO", type(e).__name__, e)
b.close()
""")
r = subprocess.run("cd /kaggle/working/pod_automation && PYTHONPATH=. HEADLESS=true xvfb-run -a venv/bin/python /kaggle/working/check_session.py 2>&1 | tail -6",
                   shell=True, capture_output=True, text=True)
print(r.stdout)

# %% 5. Lanzar la corrida de DFW02-BAA (modo continuo). Los resultados van SOLO a la sección "Comparar GPU" del portal (PORTAL_MODE=gpu)
# La clave es la "Clave para la GPU" del portal (Ajustes > Conexión con el script); en Kaggle: Add-ons > Secrets > PORTAL_API_KEY (con el notebook vinculado).
import os, subprocess
CASCADA = globals().get("CASCADA", True)   # se define en la celda 3
EXTRACT_PREFETCH = 3   # albaranes cuyas fotos se bajan en segundo plano mientras se pide el detalle del siguiente (0 = como antes)
REQUEST_DELAY_S = 0.5   # pausa entre llamadas a GOFO (antes 1.0): prueba 25/10; si GOFO responde con errores o límites, volver a 1.0
OCR_WORKERS = 4   # procesos de análisis en paralelo (4 CPU en Kaggle: probar 3 si la CPU se satura)
REPARTO = True    # True: reparte el trabajo con la corrida de la PC a través del portal (api/claim.php); la PC debe lanzarse con CLAIM_WORK=1 y CLAIM_WORKER=pc. False: como antes (esta corrida revisa todo)
GPU_WORKER = "gpu"   # nombre de ESTA corrida en el reparto; si lanzas un segundo notebook (otra cuenta de Kaggle), ponle otro (gpu2) para que no repitan trabajo entre sí
VERIFICAR = False   # True: verificación cruzada (analiza lo que marca la PC y manda su resultado al portal; requiere api/verify.php). La PC lo activa con VERIFY_WORK=1 en su .env
ENVIAR_FOTOS = True   # manda al portal las fotos originales (1600 px) de los Alta/Media, para el zoom de lo que solo ve la GPU (si no, el zoom abre la tarjeta)
PADDLE_PUERTOS = "8770,8771"   # 28/10: como el 25/10, reparto parejo entre las dos GPU. Alternativa sin medir: 8771,8771,8770,8771 (3 de 4 procesos en la GPU 1). Valor del 25/10: "8770,8771"
from kaggle_secrets import UserSecretsClient
key =UserSecretsClient().get_secret("PORTAL_API_KEY")
assert key, "Falta el secreto PORTAL_API_KEY (Add-ons > Secrets)"
env = dict(os.environ, HEADLESS="true", PYTHONIOENCODING="utf-8", VISION_MODEL="qwen2.5vl:3b",
           OPERATION_TIMEZONE="America/Caracas", ANALYSIS_CACHE_ENABLED="true", CLAIM_DENY_TTL_S="30", CLAIM_BATCH_SIZE="5",
           OLLAMA_URL="http://127.0.0.1:11434", PADDLE_OCR_PORT="8770",
           OLLAMA_URLS="http://127.0.0.1:11434" if CASCADA else "http://127.0.0.1:11434,http://127.0.0.1:11435",
           VISION_FALLBACK_MODEL="qwen2.5vl:7b" if CASCADA else "", VISION_FALLBACK_URL="http://127.0.0.1:11435" if CASCADA else "",
           PADDLE_OCR_PORTS=PADDLE_PUERTOS,
           OCR_WORKERS=str(OCR_WORKERS), EXTRACT_PREFETCH=str(EXTRACT_PREFETCH), REQUEST_DELAY_S=str(REQUEST_DELAY_S),
           PORTAL_URL="https://trackingint.com/portal", PORTAL_API_KEY=key, PORTAL_MODE="gpu", CLAIM_WORK="1" if REPARTO else "", CLAIM_WORKER=GPU_WORKER,
           GPU_SEND_PHOTOS="1" if (ENVIAR_FOTOS or REPARTO) else "0",
           VERIFY_WORK="1" if VERIFICAR else "",
           PORTAL_PHOTO_MAX_SIDE="1600", PORTAL_PHOTO_QUALITY="80")   # mismas fotos que manda la PC (por defecto del script)
subprocess.Popen("cd /kaggle/working/pod_automation && xvfb-run -a venv/bin/python main.py run --continuous --stations DFW02-BAA "
                 "> /kaggle/working/corrida.log 2>&1", shell=True, env=env)
print("corrida lanzada (envía a Comparar GPU)")

# %% 6. Vigilar hasta las 6 am de Venezuela o RUN_HOURS horas, lo que ocurra primero; la celda en ejecución mantiene la sesión viva. Al final PARA todo.
import time, datetime, sqlite3, subprocess
from zoneinfo import ZoneInfo
RUN_HOURS = 9   # tope de horas (28/10, corrida nocturna); además se detiene a las 6 am de Venezuela
t0 = time.time()
now = datetime.datetime.now(ZoneInfo(env.get('OPERATION_TIMEZONE','America/Caracas')))
stop_at = now.replace(hour=6, minute=0, second=0, microsecond=0)
if stop_at <= now:
    stop_at += datetime.timedelta(days=1)
end = min(t0 + RUN_HOURS * 3600, t0 + max(0,(stop_at - now).total_seconds()))
while time.time() < end:
    time.sleep(min(300, max(0, end - time.time())))
    try:
        n = sqlite3.connect("/kaggle/working/pod_automation/storage/pod_checkpoints.db").execute("select count(*) from pod_checkpoints").fetchone()[0]
    except Exception as e:
        n = f"? ({e})"
    print(datetime.datetime.now(ZoneInfo(env.get('OPERATION_TIMEZONE','America/Caracas'))).strftime("%Y-%m-%d %H:%M %Z"), n, "albaranes", flush=True)
    activity = subprocess.run(['venv/bin/python','tools/activity_report.py','--window','300','--json'],
                              cwd='/kaggle/working/pod_automation',env=env,capture_output=True,text=True)
    print(activity.stdout.strip() if activity.returncode==0 else 'No se pudo medir actividad reciente: '+activity.stderr[-200:],flush=True)
    print(subprocess.run("cat /kaggle/working/pod_automation/storage/etapas_extraccion.json 2>/dev/null; echo; grep \"Promedio por albar\" /kaggle/working/corrida.log | tail -n 1; tail -n 2 /kaggle/working/corrida.log; nvidia-smi --query-gpu=utilization.gpu,memory.used,memory.total --format=csv,noheader", shell=True, capture_output=True, text=True).stdout, flush=True)
subprocess.run('pkill -f "main.py run"; pkill -f paddle_ocr_server; pkill -f "ollama serve"', shell=True)
print("parado")
