# Prompt para el portal: mostrar por qué la GPU dejó un albarán en Baja (regla de omisión)

Pégalo en Claude Code abierto en `C:\Users\luisv\OneDrive\Desktop\Trackingint.com\trackingint-sitio\portal`.

---

El script, en modo GPU, ahora manda en cada item de `api/ingest_gpu.php` un campo opcional nuevo cuando una regla de la operación omitió el albarán (entrega en mano / casillero: el puntaje se fuerza a 0 aunque haya motivos):

```
"omitted": {"check": "entrega_en_mano", "why": "texto de la explicación", "score_without_rule": 40.0}
```

Hay que:

1. En `gpu_pods` agregar columnas (migradas solas en el bootstrap): `omitted_check` (varchar 40, NULL), `omitted_why` (varchar 255, NULL), `score_without_rule` (decimal, NULL). En `ingest_gpu.php` validar y guardar el campo (si no viene, quedan en NULL; tolerar que no venga). Al actualizar un albarán existente, sobrescribirlas (si ahora no viene, poner NULL).
2. En `admin/gpu.php`:
   - En la columna GPU de cada albarán con `omitted_check`, mostrar un distintivo "Omitido por regla: entrega en mano" (o "casillero", según `omitted_check`) con el `omitted_why` en un texto pequeño y "sin la regla sería X" usando `score_without_rule`.
   - En la lista de diferencias, separar la categoría "local Alta/Media y GPU Baja" en dos: **"GPU lo omitió por regla"** (con `omitted_check`) y **"GPU lo calificó Baja sin omisión"**. La primera es la sospechosa de esconder errores reales.
   - En el resumen, un contador "Omitidos por regla en la GPU" y cuántos de esos son Alta/Media en la corrida local.
   - Incluir `omitted_check` y `score_without_rule` en la exportación a Excel.
3. No tocar `ingest.php`, `status.php`, `changes.php`, `wa_queue.php` ni la revisión normal.

Pruebas (Docker php:8.2 + mariadb): enviar un lote con un Baja con `omitted` y otro sin él, verificar el distintivo, la separación en categorías y el Excel. Entregar un zip solo con los archivos nuevos o cambiados (sin `config.php` ni `.htaccess`).
