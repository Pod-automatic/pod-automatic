# Continuidad y medicion de la corrida — 28/10/2026

El cambio se aplica a la PC y al codigo preparado para Kaggle. Conserva las coordenadas del OCR y el cache existente. No cambia los umbrales que mandan un paquete a revision.

## Comportamiento

- El dia operativo usa `OPERATION_TIMEZONE=America/Caracas`, tanto en Windows como en Kaggle. Las 00:00 UTC siguen siendo las 20:00 del dia anterior en Venezuela y no provocan un cierre anticipado. `--date` sigue permitiendo una fecha fija.
- El cierre anterior queda en SQLite. Se verifican hasta 10 albaranes o 5 segundos por bloque, solo cuando una pasada no extrae trabajo nuevo. El presupuesto se comprueba entre peticiones; una peticion lenta puede excederlo. Los fallos se reintentan con espera progresiva y los bloques pendientes sobreviven a un reinicio. La sesion anterior se completa cuando termina su cola y se exporta su reporte.
- El monitor mide los analisis completados en los ultimos 300 segundos, separa extraccion de analisis y muestra el tiempo sin completar otro albaran. Una mediana antigua ya no representa actividad actual. Los registros nuevos llevan zona horaria; los antiguos sin zona se interpretan con la hora local del servidor. Se lee un tramo final de hasta 2 MB y se indica `tail_limited` cuando el archivo fue recortado.
- Los pendientes incluyen disponibles listados, estimados sin listar, excluidos, sin POD, fuera de muestra, revisados y solicitudes no concedidas por el reparto. El protocolo actual del portal no diferencia una reserva ajena de un albaran ya terminado por otra corrida; se presentan juntos como **sin conceder**, sin afirmar que estan disponibles. `scope_stations` identifica las ciudades consultadas.
- PC y Kaggle piden reservas de hasta 5 albaranes, renuevan el trabajo activo y confirman despues de guardar el resultado analizado. Las confirmaciones pendientes se guardan en SQLite para reintentarlas con el mismo worker y fecha. Una parada ordenada acorta las reservas propias inconclusas al minimo de 30 segundos del servidor; un corte abrupto conserva el plazo normal (600 segundos por defecto). Nunca se fuerza la toma de una reserva vigente de otro worker.
- La descarga paralela conserva separado el reloj de cada albaran del reloj de la pasada, para que el refresco de rutas mantenga su plazo.

## Aplicar

En la PC, la siguiente corrida usa el codigo actualizado. Instalar las dependencias actualizadas si hace falta (`venv\Scripts\python.exe -m pip install -r requirements.txt`); se agrego `tzdata` para las zonas horarias de Windows. No se borran bases, fotos ni cache.

En Kaggle, actualizar el dataset privado con `output/pod_etapa2_codigo.zip` e importar `output/pod_etapa2_optimizado_20261028.ipynb`. Usar una nueva sesion para que la celda de extraccion cargue el nuevo codigo. Conservar la sesion de GOFO y el secreto de Kaggle existentes. El ZIP de codigo contiene un `.env` minimo, sin la clave ni cookies.

Una sesion nueva de Kaggle no conserva por si sola los archivos de `/kaggle/working`: para reutilizar cache, checkpoints y cierres pendientes hay que conservar/restaurar su almacenamiento entre sesiones. El paquete de codigo no incluye esas bases.

Para consultar actividad en la PC:

```powershell
.\venv\Scripts\python.exe tools/activity_report.py --window 300 --json
```

El campo `runtime.phase` distingue extraccion, analisis, espera, cierre y parada; `updated_at` permite detectar si ese estado es antiguo. La velocidad y el porcentaje final de revision deben medirse en la siguiente corrida real. Estas mejoras corrigen continuidad y coordinacion; no acreditan por si solas una tasa de revision de 1–3 %.
