# PRUEBA qwen2.5vl:7b en Kaggle: solo los 42 casos explicados + los 53 errores reales del 01/10 (95 albaranes).
# Compara contra qwen2.5vl:3b (misma selección): errores reales 47/53 detectados, casos 36/42, 6 errores perdidos en Baja.
# Antes: Settings > Accelerator = GPU T4 x2, Internet = On, Add Input = pod-etapa1 (versión 2). Una celda "# %%" por bloque.
# Las celdas 1 y 2 son las mismas de notebook_etapa1.py (se copian al armar el .ipynb); la 3 de abajo reemplaza a la 3 y 3b.

# %% 3. Actualizar evaluar_dia.py (--subset, --shard, --skip-from); en el .ipynb va el archivo completo incrustado
# (cuando el dataset se vuelva a empaquetar con empaquetar_kaggle.py este paso ya no hace falta)

# %% 4. Dos Ollama (uno por GPU, contexto 2048), bajar qwen2.5vl:7b y calentarlos
import os, subprocess, time
subprocess.run("pkill -f 'ollama serve'; pkill -f paddle_ocr_server; sleep 2", shell=True)
for gpu, port in ((0, 11434), (1, 11435)):
    env = dict(os.environ, CUDA_VISIBLE_DEVICES=str(gpu), OLLAMA_HOST=f"127.0.0.1:{port}", OLLAMA_NUM_PARALLEL="2",
               OLLAMA_CONTEXT_LENGTH="2048", OLLAMA_FLASH_ATTENTION="1", OLLAMA_KEEP_ALIVE="-1")
    subprocess.Popen("ollama serve", shell=True, env=env, stdout=open(f"/kaggle/working/ollama{gpu}.log", "w"), stderr=subprocess.STDOUT)
time.sleep(10)
print(subprocess.run("OLLAMA_HOST=127.0.0.1:11434 ollama pull qwen2.5vl:7b", shell=True, capture_output=True, text=True).stdout[-300:])
for port in (11434, 11435):   # calentar: la primera consulta carga el modelo (si no, da timeout)
    print(subprocess.run(f"curl -s -m 300 localhost:{port}/api/generate -d '{{\"model\":\"qwen2.5vl:7b\",\"prompt\":\"hi\",\"stream\":false,\"keep_alive\":-1,\"options\":{{\"num_predict\":3,\"num_ctx\":2048}}}}' | head -c 200", shell=True, capture_output=True, text=True).stdout)

# %% 5. Lanzar 2 procesos (uno por GPU, cada uno con su Paddle y su Ollama 7b) sobre los 95 albaranes
import os, subprocess
N = 2
for i in range(N):
    env = dict(os.environ, CUDA_VISIBLE_DEVICES=str(i), PADDLE_OCR_PORT=str(8770 + i), OLLAMA_URL=f"http://127.0.0.1:{11434 + i}",
               VISION_MODEL="qwen2.5vl:7b")
    cmd = (f"cd /kaggle/working/pod_automation && venv/bin/python tools/evaluar_dia.py --date 2026-10-01 --subset casos-reportados "
           f"--shard {i}/{N} --out /kaggle/working/eval7b_s{i}.jsonl > /kaggle/working/log7b_s{i}.txt 2>&1")
    subprocess.Popen(cmd, shell=True, env=env)
print("lanzados", N)

# %% 6. Avance y uso de GPU (correr varias veces; deben llegar a 95 entre los dos)
!for i in 0 1; do echo "shard $i: $(wc -l < /kaggle/working/eval7b_s$i.jsonl 2>/dev/null || echo 0) evaluados"; done
!nvidia-smi --query-gpu=index,utilization.gpu,memory.used,memory.total --format=csv
!tail -n 2 /kaggle/working/log7b_s0.txt /kaggle/working/log7b_s1.txt

# %% 7. Resumen final del 7b (compararlo con el 3b: errores reales 47/53, casos 36/42)
import glob, json, statistics, sys
sys.path.insert(0, "/kaggle/working/pod_automation/tools")
from evaluar_dia import resumen
rows = [json.loads(l) for f in sorted(glob.glob("/kaggle/working/eval7b_s*.jsonl")) for l in open(f)]
seg = [r["segundos"] for r in rows if "segundos" in r]
print(len(rows), "albaranes; aciertos", sum(r.get("acierto", False) for r in rows), "; mediana", statistics.median(seg), "s; promedio", round(sum(seg) / len(seg), 1), "s")
resumen(rows)
