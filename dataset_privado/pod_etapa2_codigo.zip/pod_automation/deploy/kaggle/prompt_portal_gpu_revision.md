# Prompt para el portal: botón "Pasar a revisión" en Comparar GPU

Pégalo en Claude Code abierto en `C:\Users\luisv\OneDrive\Desktop\Trackingint.com\trackingint-sitio\portal`.

---

En `admin/gpu.php` (Comparar GPU) quiero poder pasar un albarán que detectó la GPU a la revisión normal del portal, para reportarlo y mandarlo a WhatsApp con el flujo de siempre. Hoy esa pantalla es solo de lectura.

## Qué agregar

1. En cada fila de la lista de diferencias y en cada albarán Alta/Media de la GPU, un botón **"Pasar a revisión"**. También una casilla por fila y un botón arriba **"Pasar seleccionados"** (hasta 50 a la vez).
2. Solo se puede pasar un albarán que en `gpu_pods` sea **Alta o Media**. Los Baja no tienen el botón.
3. Al pasarlo, se crea (o se completa) el albarán en la tabla `pods` como si lo hubiera enviado el script:
   - `source = 'script'`, `status = 'pendiente'`, y los mismos campos que llena `api/ingest.php`: fecha, tracking, estación y empresa, repartidor, `driver_id`, dirección, prioridad, score, motivos, detección, GPS y distancia.
   - Copia las tarjetas de `files/cards_gpu/<fecha>/` a `files/cards/<fecha>/` con los mismos nombres que usa `ingest.php` (`<tracking>_<n>.jpg`) y llena `card_file` y `card_files`. Las fotos originales no existen en la GPU: déjalas en NULL y que la pantalla de revisión lo tolere.
   - Si el albarán ya existe en `pods` para esa fecha (lo envió la PC), **no lo pises**: no cambies su estado, su tipo de error ni sus tarjetas. Solo avisa "ya estaba en revisión" y enlázalo.
4. Marca en `gpu_pods` que ese albarán ya fue pasado (columnas `promoted_at` y `promoted_by`; migrarlas solas en el bootstrap) y muestra en la lista un distintivo "Ya en revisión", con enlace a la revisión. El botón no debe aparecer otra vez.
5. Debe ser idempotente: pulsarlo dos veces no duplica nada.

## Reglas

- Solo admin, con el mismo token CSRF y el mismo estilo de acción que `admin/review_action.php` (una acción nueva `gpu_promote` ahí o un `admin/gpu_action.php` nuevo, lo que sea más limpio).
- Un solo albarán o varios, siempre con confirmación.
- No toques `api/ingest.php`, `api/status.php`, `api/changes.php` ni `api/wa_queue.php`.
- No encoles nada a WhatsApp: eso lo sigue haciendo el admin desde la revisión normal.
- Guarda en el registro de actividad (si el portal tiene uno) quién lo pasó y cuándo.

## Pruebas (Docker php:8.2-apache + mariadb, como las anteriores)

- Enviar a `ingest_gpu.php` un lote con Alta, Media y Baja y tarjetas.
- Pasar uno Alta y uno Media: aparecen en `admin/review.php` como pendientes con sus tarjetas.
- Pasar de nuevo el mismo: no se duplica.
- Pasar uno que ya existe en `pods` con estado "reportado": su estado y su tarjeta no cambian.
- El botón no aparece en un Baja.
- Entrégame un zip solo con los archivos nuevos o cambiados (sin `config.php` ni `.htaccess`) para extraer en `public_html`.
