r"""
Arma los dos zips de la ETAPA 2 en Kaggle (corrida real de una ciudad con GPU):

    venv\Scripts\python.exe deploy\kaggle\empaquetar_etapa2.py

output/pod_etapa2_codigo.zip   código + drivers_config.json + un .env mínimo SIN clave del portal (la prueba no sube nada
                               al portal ni a WhatsApp); sin bases ni fotos (historial vacío)
output/pod_etapa2_secretos.zip storage/session_state.json (cookies de GOFO). Es una credencial viva: va a un Dataset PRIVADO
                               de Kaggle y se borra cuando termine la prueba.
"""

import argparse
import json
import re
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "deploy" / "ubuntu"))
from empaquetar import code_files  # noqa: E402

ENV_MINIMO = """# Etapa 2 en Kaggle: SIN PORTAL_URL ni PORTAL_API_KEY (no se sube nada al portal)
HEADLESS=true
CONTINUOUS_POLL_INTERVAL_S=60
PASS_REFRESH_MIN=15
OPERATION_TIMEZONE=America/Caracas
ANALYSIS_CACHE_ENABLED=true
CLAIM_DENY_TTL_S=30
CLAIM_BATCH_SIZE=5
"""


def write_notebook(out_dir: Path, source_name='notebook_etapa2.py', output_name='pod_etapa2_optimizado_20261028.ipynb',
                   cells_dir=None, replace=None) -> Path:
    """Notebook importable, sin salidas ni credenciales; el fuente sigue siendo el .py. `replace` = {texto: nuevo}
    para variantes (29/10: un notebook por cuenta de Kaggle); cada texto debe aparecer exactamente una vez."""
    source = (ROOT / 'deploy/kaggle' / source_name).read_text(encoding='utf-8')
    for old, new in (replace or {}).items():
        if source.count(old) != 1:
            raise ValueError(f'{source_name}: se esperaba una vez {old!r}')
        source = source.replace(old, new)
    parts = re.split(r'^# %% (.*)\n', source, flags=re.MULTILINE)
    cells = [{'cell_type':'markdown','metadata':{},'source':parts[0].splitlines(keepends=True)}]
    for i in range(1,len(parts),2):
        body = '# ' + parts[i] + '\n' + parts[i+1]
        # Las lineas ! son comandos de IPython, no Python de terminal.
        compile('\n'.join(line for line in body.splitlines() if not line.startswith('!')),
                f'notebook cell {(i+1)//2}', 'exec')
        cells.append({'cell_type':'code','execution_count':None,'outputs':[],
                      'metadata':{},'source':body.splitlines(keepends=True)})
    # 4.4: las celdas no llevan 'id' (obligatorio desde 4.5); con 4.5 el importador de Kaggle se quedaba en "Loading file..." (28/10)
    notebook = {'nbformat':4,'nbformat_minor':4,'cells':cells,
                'metadata':{'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'},
                            'language_info':{'name':'python'}}}
    path = out_dir / output_name
    path.write_text(json.dumps(notebook,ensure_ascii=False,indent=1),encoding='utf-8')
    if cells_dir:
        # 29/10: las celdas para pegar a mano salen del mismo fuente (antes quedaban viejas: seguían cargando el 7b)
        folder = out_dir / cells_dir
        folder.mkdir(exist_ok=True)
        for old in folder.glob('celda_*.py'):
            old.unlink()
        for n, cell in enumerate(cells[1:], 1):
            (folder / f'celda_{n}.py').write_bytes(''.join(cell['source']).encode('utf-8'))
    return path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--solo-codigo',action='store_true',help='No crear ni modificar el ZIP de cookies.')
    args = parser.parse_args()
    out_dir = ROOT / "output"
    out_dir.mkdir(parents=True,exist_ok=True)
    codigo = out_dir / "pod_etapa2_codigo.zip"
    with zipfile.ZipFile(codigo, "w", zipfile.ZIP_DEFLATED) as z:
        for p in code_files():
            if p.name == ".env" and p.parent == ROOT:
                continue
            z.write(p, "pod_automation/" + p.relative_to(ROOT).as_posix())
        z.writestr("pod_automation/.env", ENV_MINIMO)
    files = [codigo,write_notebook(out_dir),write_notebook(out_dir,'notebook_multiciudad.py','pod_multiciudad_20261028.ipynb',
                                                         'celdas_kaggle_multiciudad')]
    if not args.solo_codigo:
        secretos = out_dir / "pod_etapa2_secretos.zip"
        sesion = ROOT / "storage" / "session_state.json"
        with zipfile.ZipFile(secretos, "w", zipfile.ZIP_DEFLATED) as z:
            z.write(sesion, "session_state.json")
        files.append(secretos)
    for f in files:
        print(f"{f}  ({f.stat().st_size / 1e6:.1f} MB)")


if __name__ == "__main__":
    main()
