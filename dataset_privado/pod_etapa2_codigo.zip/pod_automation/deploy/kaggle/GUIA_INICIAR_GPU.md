# Cómo iniciar la corrida en la GPU de Kaggle (sin ayuda)

Tiempo: unos 10 minutos tuyos + ~14 minutos de instalación automática. La corrida dura hasta 6 horas o hasta las 10 pm de Venezuela.

## Lo que ya debe existir (se hace una sola vez)
- Cuenta de Kaggle con el notebook `notebook4d2fc63dbc`, GPU **T4 x2** e **Internet On** (panel derecho > Session options).
- Los datasets privados `pod-etapa1` y `pod-etapa2` agregados al notebook (panel derecho > Input).
- El secreto `PORTAL_API_KEY` (Add-ons > Secrets), marcado como vinculado al notebook. Su valor es la **"Clave para la GPU"** del portal (Ajustes > Conexión con el script).

## Paso 1. Prepara los archivos en la PC (solo si cambió el código o las cookies de GOFO)
1. Abre una terminal en la carpeta del proyecto y ejecuta:
   `venv\Scripts\python.exe deploy\kaggle\empaquetar_etapa2.py`
2. Se crean dos archivos en `output\`:
   - `pod_etapa2_codigo.zip` (el programa)
   - `pod_etapa2_secretos.zip` (tus cookies de GOFO; son una credencial, no los compartas)

## Paso 2. Sube los archivos al dataset
1. Kaggle > Datasets > **pod-etapa2** > **New Version**.
2. Pulsa la **X** de los `.zip` viejos y sube los nuevos (si no cambiaron las cookies, deja el de secretos).
3. Pulsa **Create** y espera a que la versión diga "Successful".

## Paso 3. Importa el notebook
1. Abre el notebook en modo edición.
2. **File > Import Notebook**, elige `deploy\kaggle\etapa2.ipynb` y pulsa **Import**.
3. Revisa la **celda 5**:
   - La ciudad: `--stations DFW02-BAA` (cámbialo a `DFW-BAA` si quieres la otra).
   - Arriba de la celda: `OCR_WORKERS = 4`, `EXTRACT_PREFETCH = 3`, `REQUEST_DELAY_S = 0.5`.
4. En la **celda 6** puedes cambiar `RUN_HOURS = 6` (horas máximas).

## Paso 4. Lanza la corrida (en segundo plano)
1. Arriba a la derecha pulsa **Save Version**.
2. En "Version Type" deja **Save & Run All (Commit)**.
3. Abre **Advanced Settings** y deja "Run with GPU for this session".
4. Ponle un nombre (ej. `DFW02 26-10`) y pulsa **Save**.
5. Con eso ya puedes cerrar la página: corre en los servidores de Kaggle. **No uses "Run All" en el editor ni dejes una sesión interactiva abierta**: se apaga sola por inactividad y gasta horas de GPU.

## Paso 5. Comprueba que arrancó
1. Abre el panel de eventos (icono del reloj, abajo a la izquierda en el editor): debe decir **Running**.
2. Para ver el avance: en ese panel pulsa los tres puntos de la versión > **Open Logs in Viewer**. Busca líneas como `17:42 UTC 120 albaranes`.
3. En ~14 minutos debes ver `SESION_OK` y `corrida lanzada`. Si dice `SESION_NO`, ver "Problemas".
4. En el portal: **Comparar GPU** debe empezar a mostrar albaranes de hoy.

## Paso 6. Detenerla antes de tiempo (solo si hace falta)
- Panel de eventos > tres puntos de la versión > **Stop Session**.
- Se detiene sola a las 6 horas o a las 10 pm de Venezuela.

## Antes de lanzar otra corrida
- **Solo una a la vez.** Detén la anterior primero.
- **La PC y Kaggle no deben trabajar la misma ciudad a la vez** (salen falsos errores por la ciudad activa de GOFO).
- Mira tu cuota semanal: perfil de Kaggle > horas de GPU (hay 30 por semana, una corrida de 6 h gasta ~6,5).

## Importante: actualizar el dataset en el notebook (aprendido el 26/10)
Cada vez que subas una versión nueva de `pod-etapa2`, el notebook **sigue con la versión anterior** hasta que lo actualices: en el panel derecho, Input > los tres puntos de `pod-etapa2` > **Check for updates** > **Update**. Si no, la corrida arranca con el código o las cookies viejos (el registro dice `sesión de GOFO presente: False`). Comprueba en el registro, a los ~30 segundos, que diga **`sesión de GOFO presente: True`**; si dice False, detén la corrida de inmediato (tres puntos > Stop Session) para no gastar GPU.
Después de subir el zip de cookies, comprueba también en la página del dataset (Data Explorer) que aparezca la carpeta `pod_etapa2_secretos`.

## Problemas frecuentes
- **`SESION_NO` en el registro**: las cookies de GOFO caducaron. Inicia sesión en GOFO en la PC (la corrida local renueva `storage\session_state.json`), repite el Paso 1 y sube de nuevo el zip de secretos.
- **No llegan datos a Comparar GPU**: revisa el secreto `PORTAL_API_KEY` (¿vinculado al notebook?, ¿es la clave de la GPU?). Si el hosting responde "One moment, please...", pide al soporte que exente `/portal/api/`.
- **No aparece nada en el registro los primeros 14 minutos**: es la instalación, es normal.
- **Mucha CPU o errores de GOFO**: baja `OCR_WORKERS` a 3 o sube `REQUEST_DELAY_S` a 1.0.

## Al terminar las pruebas
- Borra el dataset `pod-etapa2` (tiene tus cookies) y el secreto `PORTAL_API_KEY`.

## Repartir el trabajo entre la PC y la GPU (25/10)
Las dos corridas **no repiten albaranes** y la más rápida revisa más: cada una le pide al portal (`api/claim.php`) un bloque de albaranes, el portal se lo reserva y la otra lo salta. Si el portal no responde, cada corrida revisa todo como siempre.

**Ya está activado:**
- **PC:** el `.env` del proyecto trae `CLAIM_WORK=1`, `CLAIM_WORKER=pc` y `GOFO_SESSION_GROUP=luisvivas` (28/10: Kaggle con la sesión de Luis apoya a la PC en DFW y DFW02; la sesión tracking revisa IAH e IAH02). Se aplica al reiniciar la corrida (`main.py run`).
- **Kaggle:** la celda 5 trae `REPARTO = True` (worker `gpu`; también manda las fotos originales de los Alta/Media, para poder acercarlas en Comparar GPU y pasarlas a Revisión). Para apagarlo, pon `REPARTO = False`.

**Requiere** haber subido al hosting `actualizacion-gpu-tarjetas.zip` (trae `api/claim.php`; la base pasa sola a la versión 17).

**Comprobar:** en el portal, **Comparar GPU > Resumen y comparación > Reparto de trabajo** muestra, por corrida, albaranes reservados, vencidos, hechos y el ritmo por hora.
Si la GPU deja de enviar más de 20 minutos dentro del horario de vigilancia, el portal avisa por Telegram (y otra vez cuando vuelve).

Ojo con la nota de arriba ("la PC y Kaggle no deben trabajar la misma ciudad a la vez"): con el reparto las dos sí trabajan la misma ciudad. Mira que no aparezcan falsos errores por la ciudad activa de GOFO; si aparecen, apaga el reparto (arriba).
Los `done` acumulados (portal caído un rato) se mandan en pedidos de máximo 200, y los albaranes en pedidos de máximo 100, como exige el portal.

## Varias claves para la GPU
En el portal, **Ajustes > Conexión con el script > Claves para la GPU**, puedes crear una clave por cuenta o notebook de Kaggle (con un nombre, por ejemplo "Kaggle cuenta 2") y revocar cada una por separado, sin afectar a las otras ni a la PC. Cada notebook usa la suya en su secreto `PORTAL_API_KEY`. En el reparto, cada notebook puede tener su propio `CLAIM_WORKER` (por ejemplo `gpu`, `gpu2`) para que el recuadro "Reparto de trabajo" los muestre por separado.
