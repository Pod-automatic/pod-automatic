"""
Módulo de Gestión de Checkpoints y Reanudación con SQLite para POD Automation (Fase 8).

Proporciona almacenamiento transaccional local atómico (ACID) mediante SQLite:
- Detección de última sesión incompleta y último POD procesado (ej. 500 de 1000).
- Evita duplicar registros ya procesados en la base de datos y en memoria.
- Permite reanudar exactamente desde el siguiente POD sin reprocesar trabajo ya hecho.
"""

import sqlite3
import json
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, List, Set, Tuple, Any

from config import CHECKPOINT_DB_PATH
from automation.business_time import operation_now
from models.pod import PODRecord

# Errores de extracción por un corte de red (se reintentan); "sin permiso" (otra ciudad) u otros no
CONNECTION_ERROR_HINTS = ("failed to fetch", "sin respuesta", "timed out", "timeout", "getaddrinfo",
                          "connection", "conexión", "network",
                          # 11/10: el navegador se cerró a mitad de un bloque ("Target page, context or browser has been
                          # closed"): 21 albaranes de Carla Colina quedaron "sin foto" y no se volvían a extraer
                          "has been closed", "target closed", "browser closed")


def is_connection_error(message: Optional[str]) -> bool:
    m = (message or "").lower()
    return any(h in m for h in CONNECTION_ERROR_HINTS) and "permiso" not in m


def needs_retry(processing_status: Optional[str], error: Optional[str]) -> bool:
    """
    Albarán que se vuelve a extraer en la pasada siguiente: falló por un corte de red (06/10) o se guardó con fotos de
    menos porque se cortó la red al descargarlas (22/10: GFUS01078769112322, 1 de 5 fotos).
    """
    if not is_connection_error(error):
        return False
    return str(processing_status).endswith("FAILED") or "no se pudieron descargar" in (error or "")


class CheckpointManager:
    """Administrador de puntos de control (checkpoints) y persistencia transaccional SQLite."""

    def __init__(self, db_path: Optional[Path] = None):
        self.db_path = db_path or CHECKPOINT_DB_PATH
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        """Obtiene una conexión a la base de datos con modo WAL activado para alta concurrencia."""
        conn = sqlite3.connect(str(self.db_path), timeout=15.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode = WAL;")
        conn.execute("PRAGMA foreign_keys = ON;")
        return conn

    def _init_db(self):
        """Inicializa las tablas de sesiones y checkpoints si no existen."""
        with self._get_connection() as conn:
            conn.execute("""
            CREATE TABLE IF NOT EXISTS audit_sessions (
                session_id TEXT PRIMARY KEY,
                query_date TEXT NOT NULL,
                started_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                status TEXT NOT NULL,
                total_detected INTEGER DEFAULT 0,
                total_processed INTEGER DEFAULT 0,
                last_processed_tracking TEXT
            );
            """)

            conn.execute("""
            CREATE TABLE IF NOT EXISTS pod_checkpoints (
                session_id TEXT NOT NULL,
                tracking_number TEXT NOT NULL,
                query_date TEXT NOT NULL,
                stop_number TEXT,
                driver_name TEXT,
                processing_status TEXT,
                validation_result TEXT,
                confidence_score REAL,
                payload_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                PRIMARY KEY (session_id, tracking_number),
                FOREIGN KEY (session_id) REFERENCES audit_sessions(session_id) ON DELETE CASCADE
            );
            """)
            # Migración: columnas de triaje en bases creadas antes de existir el score
            existing = {row["name"] for row in conn.execute("PRAGMA table_info(pod_checkpoints);")}
            for column, ddl in (("risk_score", "REAL"), ("priority", "TEXT"), ("portal_status", "TEXT"),
                                ("driver_id", "TEXT"), ("needs_recheck", "INTEGER DEFAULT 0"),
                                ("status_change", "TEXT")):
                if column not in existing:
                    conn.execute(f"ALTER TABLE pod_checkpoints ADD COLUMN {column} {ddl};")

            # Repartidores vistos alguna vez (para marcar "nuevos")
            conn.execute("""
            CREATE TABLE IF NOT EXISTS driver_roster (
                driver_id TEXT PRIMARY KEY,
                driver_name TEXT,
                station_id TEXT,
                first_seen TEXT NOT NULL,
                last_seen TEXT NOT NULL
            );
            """)

            # Avance por ruta (conductor) y día, en la misma base
            conn.execute("""
            CREATE TABLE IF NOT EXISTS route_progress (
                session_id TEXT NOT NULL,
                station_id TEXT NOT NULL,
                driver_id TEXT NOT NULL,
                driver_name TEXT,
                assigned_in_portal INTEGER,
                delivered_in_portal INTEGER,
                listed_this_pass INTEGER,
                updated_at TEXT NOT NULL,
                PRIMARY KEY (session_id, station_id, driver_id),
                FOREIGN KEY (session_id) REFERENCES audit_sessions(session_id) ON DELETE CASCADE
            );
            """)
            conn.commit()

    def create_session(self, query_date: str, total_detected: int = 0) -> str:
        """Crea y registra una nueva sesión de auditoría."""
        # Microsegundos: dos sesiones en el mismo segundo (ej. cambio de día) no deben chocar
        session_id = f"session_{operation_now().strftime('%Y%m%d_%H%M%S_%f')}"
        now_str = operation_now().strftime("%Y-%m-%d %H:%M:%S")

        with self._get_connection() as conn:
            conn.execute("""
            INSERT INTO audit_sessions (
                session_id, query_date, started_at, updated_at, status, total_detected, total_processed, last_processed_tracking
            ) VALUES (?, ?, ?, ?, 'IN_PROGRESS', ?, 0, NULL);
            """, (session_id, query_date, now_str, now_str, total_detected))
            conn.commit()

        return session_id

    def get_latest_incomplete_session(self, query_date: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        Retorna la sesión más reciente que quedó en estado IN_PROGRESS para permitir reanudarla.
        """
        with self._get_connection() as conn:
            if query_date:
                cursor = conn.execute("""
                SELECT * FROM audit_sessions 
                WHERE status = 'IN_PROGRESS' AND query_date = ?
                ORDER BY updated_at DESC LIMIT 1;
                """, (query_date,))
            else:
                cursor = conn.execute("""
                SELECT * FROM audit_sessions 
                WHERE status = 'IN_PROGRESS'
                ORDER BY updated_at DESC LIMIT 1;
                """)
            row = cursor.fetchone()
            return dict(row) if row else None

    def save_pod_checkpoint(self, session_id: str, pod: PODRecord):
        """
        Guarda atómicamente el estado y datos del POD procesado.
        Actualiza el contador y el último tracking de la sesión.
        """
        now_str = operation_now().strftime("%Y-%m-%d %H:%M:%S")
        pod_dict = pod.to_dict()
        meta = getattr(pod, "portal_meta", None) or {}
        payload_json = json.dumps(pod_dict, ensure_ascii=False)

        confidence_score = getattr(pod, "quality_score", 100.0) / 100.0
        val_result = getattr(pod, "classification", "VALID")
        if hasattr(val_result, "value"):
            val_result = val_result.value

        with self._get_connection() as conn:
            # 1. Insertar o actualizar registro de checkpoint
            conn.execute("""
            INSERT INTO pod_checkpoints (
                session_id, tracking_number, query_date, stop_number, driver_name,
                processing_status, validation_result, confidence_score, payload_json, created_at,
                risk_score, priority, portal_status, driver_id, needs_recheck, status_change
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(session_id, tracking_number) DO UPDATE SET
                portal_status = excluded.portal_status,
                driver_id = excluded.driver_id,
                needs_recheck = MAX(pod_checkpoints.needs_recheck, excluded.needs_recheck),
                status_change = COALESCE(excluded.status_change, pod_checkpoints.status_change),
                risk_score = excluded.risk_score,
                priority = excluded.priority,
                stop_number = excluded.stop_number,
                driver_name = excluded.driver_name,
                processing_status = excluded.processing_status,
                validation_result = excluded.validation_result,
                confidence_score = excluded.confidence_score,
                payload_json = excluded.payload_json,
                created_at = excluded.created_at;
            """, (
                session_id,
                pod.tracking_number,
                pod.delivery_datetime[:10] if pod.delivery_datetime else now_str[:10],
                pod.stop_number,
                pod.driver_name,
                str(pod.processing_status),
                val_result,
                confidence_score,
                payload_json,
                now_str,
                pod.risk_score,
                pod.priority,
                meta.get("portal_status"),
                meta.get("driver_id"),
                1 if meta.get("status_change") else 0,
                json.dumps(meta["status_change"], ensure_ascii=False) if meta.get("status_change") else None,
            ))

            # 2. Actualizar sesión: incremento de conteo y último tracking
            conn.execute("""
            UPDATE audit_sessions
            SET updated_at = ?,
                total_processed = (SELECT COUNT(*) FROM pod_checkpoints WHERE session_id = ?),
                last_processed_tracking = ?
            WHERE session_id = ?;
            """, (now_str, session_id, pod.tracking_number, session_id))
            conn.commit()

    def get_processed_trackings(self, session_id: str) -> Set[str]:
        """Obtiene el conjunto de números de tracking ya procesados en la sesión."""
        with self._get_connection() as conn:
            cursor = conn.execute(
                "SELECT tracking_number FROM pod_checkpoints WHERE session_id = ?;",
                (session_id,),
            )
            return {row["tracking_number"] for row in cursor.fetchall()}

    def load_session_pods(self, session_id: str) -> List[PODRecord]:
        """Carga todos los objetos PODRecord previamente guardados para una sesión."""
        pods: List[PODRecord] = []
        with self._get_connection() as conn:
            cursor = conn.execute(
                "SELECT payload_json FROM pod_checkpoints WHERE session_id = ? ORDER BY created_at ASC;",
                (session_id,),
            )
            for row in cursor.fetchall():
                data = json.loads(row["payload_json"])
                pods.append(PODRecord.from_dict(data))
        return pods

    def load_unscored_pods(self, session_id: str) -> List[PODRecord]:
        """
        Solo los albaranes que quedaron sin puntaje (corrida cortada antes del score). 03/10: cargar los ~3000 del día
        completos en CADA pasada tardaba y ocupaba varios GB, y con las pasadas por bloques se repetía seguido.
        """
        pods: List[PODRecord] = []
        with self._get_connection() as conn:
            cursor = conn.execute(
                "SELECT payload_json FROM pod_checkpoints WHERE session_id = ? AND risk_score IS NULL "
                "ORDER BY created_at ASC;", (session_id,))
            for row in cursor.fetchall():
                pods.append(PODRecord.from_dict(json.loads(row["payload_json"])))
        return pods

    def get_status_map(self, session_id: str) -> Dict[str, Optional[str]]:
        """
        tracking -> firma de estado del portal guardada (la clave de "ya procesado" es el tracking).
        06/10: los que fallaron por un corte de conexión ("Failed to fetch", "sin respuesta") NO cuentan como procesados:
        se vuelven a extraer en la pasada siguiente (antes quedaban "sin foto" todo el día; 8 albaranes el 06/10).
        """
        with self._get_connection() as conn:
            rows = conn.execute(
                """SELECT tracking_number, portal_status, processing_status,
                          json_extract(payload_json, '$.error_message') AS error
                   FROM pod_checkpoints WHERE session_id = ?;""", (session_id,)
            ).fetchall()
        return {r["tracking_number"]: r["portal_status"] for r in rows
                if not needs_retry(r["processing_status"], r["error"])}

    def mark_status_change(self, session_id: str, tracking: str, old: Optional[str], new: str) -> None:
        """Un albarán ya revisado cambió de estado en el portal (ej. Anulado): marcarlo para volver a revisar."""
        from processing.scoring import CheckResult, priority_for
        now_str = operation_now().strftime("%Y-%m-%d %H:%M:%S")
        change = {"from": old, "to": new, "detected_at": now_str}
        with self._get_connection() as conn:
            row = conn.execute(
                "SELECT payload_json, risk_score FROM pod_checkpoints WHERE session_id = ? AND tracking_number = ?;",
                (session_id, tracking),
            ).fetchone()
            if not row:
                return
            payload = json.loads(row["payload_json"])
            meta = payload.setdefault("portal_meta", {})
            meta["status_change"] = change
            meta["portal_status"] = new
            checks = [c for c in payload.get("check_results") or [] if c.get("check") != "cambio_estado"]
            # Un anulado (o cualquier cambio de estado tras revisado) se toma como error: reportar
            checks.append(CheckResult(
                "cambio_estado", 100, 1.0, f"Cambió de estado en el portal después de revisado (ej. anulado).",
                force_report=True, details={"antes": old, "ahora": new},
            ).to_dict())
            payload["check_results"] = checks
            risk = 100.0
            payload["risk_score"], payload["priority"] = risk, priority_for(risk).value
            conn.execute("""
            UPDATE pod_checkpoints SET portal_status = ?, needs_recheck = 1, status_change = ?,
                   risk_score = ?, priority = ?, payload_json = ?
            WHERE session_id = ? AND tracking_number = ?;
            """, (new, json.dumps(change, ensure_ascii=False), risk, payload["priority"],
                  json.dumps(payload, ensure_ascii=False), session_id, tracking))
            conn.commit()

    def mark_portal_false_pod(self, session_id: str, tracking: str, whether_reported, false_signature) -> None:
        """El portal marcó el albarán como POD falso sospechoso DESPUÉS de revisado: reportar y subirlo primero."""
        from processing.scoring import CheckResult
        with self._get_connection() as conn:
            row = conn.execute(
                "SELECT payload_json FROM pod_checkpoints WHERE session_id = ? AND tracking_number = ?;",
                (session_id, tracking),
            ).fetchone()
            if not row:
                return
            payload = json.loads(row["payload_json"])
            meta = payload.setdefault("portal_meta", {})
            meta["whether_reported"], meta["false_signature"] = whether_reported, false_signature
            meta["false_pod_flag_detected_at"] = operation_now().strftime("%Y-%m-%d %H:%M:%S")
            checks = [c for c in payload.get("check_results") or [] if c.get("check") != "pod_falso_portal"]
            checks.insert(0, CheckResult(
                "pod_falso_portal", 100, 3.0,
                "El portal marcó este POD como FALSO SOSPECHOSO (detectado en el control de cierre del día).",
                force_report=True, details={"whetherReported": whether_reported, "falseSignature": false_signature},
            ).to_dict())
            payload["check_results"] = checks
            payload["risk_score"], payload["priority"] = 100.0, "Alta"
            from models.priorities import category_for_payload
            payload['priority'] = category_for_payload(payload)
            conn.execute("""
            UPDATE pod_checkpoints SET risk_score = 100, priority = ?, needs_recheck = 1, payload_json = ?
            WHERE session_id = ? AND tracking_number = ?;
            """, (payload['priority'], json.dumps(payload, ensure_ascii=False), session_id, tracking))
            conn.commit()

    def save_route_snapshot(self, session_id: str, station_id, courier: Dict[str, Any], stats: Dict[str, int]) -> None:
        """Guarda lo que el portal informa de la ruta (asignadas / con POD) para mostrar el avance X de N."""
        now_str = operation_now().strftime("%Y-%m-%d %H:%M:%S")
        with self._get_connection() as conn:
            conn.execute("""
            INSERT INTO route_progress (session_id, station_id, driver_id, driver_name, assigned_in_portal,
                                        delivered_in_portal, listed_this_pass, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(session_id, station_id, driver_id) DO UPDATE SET
                driver_name = excluded.driver_name, assigned_in_portal = excluded.assigned_in_portal,
                delivered_in_portal = excluded.delivered_in_portal, listed_this_pass = excluded.listed_this_pass,
                updated_at = excluded.updated_at;
            """, (session_id, str(station_id), str(courier.get("userId") or courier.get("driverName")),
                  courier.get("driverName"), courier.get("checkOutPieces") or stats.get("listed"),
                  stats.get("with_pod"), stats.get("listed"), now_str))
            day = conn.execute("SELECT query_date FROM audit_sessions WHERE session_id = ?;",
                               (session_id,)).fetchone()
            day = day["query_date"] if day else now_str[:10]
            conn.execute("""
            INSERT INTO driver_roster (driver_id, driver_name, station_id, first_seen, last_seen)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(driver_id) DO UPDATE SET driver_name = excluded.driver_name,
                station_id = excluded.station_id, last_seen = MAX(driver_roster.last_seen, excluded.last_seen);
            """, (str(courier.get("userId") or courier.get("driverName")), courier.get("driverName"),
                  str(station_id), day, day))
            conn.commit()

    def count_reviewed_since(self, session_id: str, since: str) -> int:
        """Albaranes con score guardados desde `since` ('YYYY-MM-DD HH:MM:SS'): el ritmo real de la corrida."""
        with self._get_connection() as conn:
            return conn.execute(
                "SELECT COUNT(*) FROM pod_checkpoints WHERE session_id = ? AND risk_score IS NOT NULL AND created_at >= ?;",
                (session_id, since),
            ).fetchone()[0]

    def top_error_drivers(self, status_db: Path, since: str, min_errors: int, limit: int,
                          per_station_min: int) -> List[Dict[str, Any]]:
        """
        07/10 (pedido del usuario): repartidores con más errores REALES (marcados "reportado") desde `since`, para
        revisarlos primero. Los `limit` con más errores (al menos `min_errors`), asegurando los `per_station_min`
        primeros de cada ciudad aunque tengan menos que los de la otra.
        """
        if not Path(status_db).exists():
            return []
        marks = sqlite3.connect(f"file:{Path(status_db).as_posix()}?mode=ro", uri=True, timeout=30)
        try:
            rows = marks.execute("SELECT tracking_number, query_date FROM report_status "
                                 "WHERE status = 'reportado' AND query_date >= ?;", (since,)).fetchall()
        finally:
            marks.close()
        stats: Dict[str, Dict[str, Any]] = {}
        with self._get_connection() as conn:
            for trk, day in rows:
                r = conn.execute("""
                    SELECT p.driver_id, p.driver_name, json_extract(p.payload_json, '$.station') AS station
                    FROM pod_checkpoints p JOIN audit_sessions s ON s.session_id = p.session_id
                    WHERE s.query_date = ? AND p.tracking_number = ? ORDER BY s.started_at DESC LIMIT 1;""",
                                 (day, trk)).fetchone()
                if not r or not (r["driver_id"] or r["driver_name"]):
                    continue
                d = stats.setdefault(str(r["driver_id"] or r["driver_name"]),
                                     {"driver_id": str(r["driver_id"] or ""), "driver_name": r["driver_name"],
                                      "station": r["station"] or "", "errors": 0})
                d["errors"] += 1
        ranked = sorted((d for d in stats.values() if d["errors"] >= min_errors), key=lambda d: -d["errors"])
        chosen = ranked[:limit]
        for station in {d["station"] for d in ranked}:
            for d in [x for x in ranked if x["station"] == station][:per_station_min]:
                if d not in chosen:
                    chosen.append(d)
        return chosen

    def count_by_driver(self, session_id: str) -> Dict[str, int]:
        """driver_id -> albaranes guardados en la sesión (para estimar faltantes sin listar la ruta en el portal)."""
        with self._get_connection() as conn:
            rows = conn.execute("SELECT driver_id, processing_status, json_extract(payload_json, '$.error_message') "
                                "FROM pod_checkpoints WHERE session_id = ?;", (session_id,)).fetchall()
        # 22/10: los que se van a reintentar no cuentan como revisados (si no, la ruta parecía al día y no se relistaba)
        out: Dict[str, int] = {}
        for driver, status, error in rows:
            if driver and not needs_retry(status, error):
                out[str(driver)] = out.get(str(driver), 0) + 1
        return out

    def last_activity(self, session_id: str) -> Dict[str, Any]:
        """Para el latido al portal: cuántos revisados lleva la sesión y cuándo se guardó el último."""
        with self._get_connection() as conn:
            row = conn.execute(
                "SELECT COUNT(*) AS n, MAX(created_at) AS last FROM pod_checkpoints "
                "WHERE session_id = ? AND risk_score IS NOT NULL;", (session_id,)).fetchone()
        return {"reviewed_today": row["n"], "last_reviewed_at": row["last"]}

    def get_route_progress(self, session_id: str) -> List[Dict[str, Any]]:
        """Por conductor: revisadas X (con score) de N entregadas con POD, más las asignadas en el portal."""
        with self._get_connection() as conn:
            rows = conn.execute("""
            SELECT r.station_id, r.driver_id, r.driver_name, r.assigned_in_portal, r.delivered_in_portal,
                   (SELECT COUNT(*) FROM pod_checkpoints c WHERE c.session_id = r.session_id
                        AND c.driver_id = r.driver_id AND c.risk_score IS NOT NULL) AS reviewed,
                   (SELECT COUNT(*) FROM pod_checkpoints c WHERE c.session_id = r.session_id
                        AND c.driver_id = r.driver_id AND c.needs_recheck = 1) AS needs_recheck,
                   r.updated_at,
                   -- "Nuevo": visto por primera vez este día, y no es el primer día de uso del sistema
                   CASE WHEN d.first_seen = s.query_date AND EXISTS (
                        SELECT 1 FROM driver_roster o WHERE o.first_seen < s.query_date)
                        THEN 1 ELSE 0 END AS is_new
            FROM route_progress r
            JOIN audit_sessions s ON s.session_id = r.session_id
            LEFT JOIN driver_roster d ON d.driver_id = r.driver_id
            WHERE r.session_id = ?
            ORDER BY r.station_id, r.driver_name;
            """, (session_id,)).fetchall()
        return [dict(r) for r in rows]

    def get_review_queue(self, session_id: str) -> List[PODRecord]:
        """Albaranes de la sesión ordenados de mayor a menor riesgo (sin score al final)."""
        pods: List[PODRecord] = []
        with self._get_connection() as conn:
            cursor = conn.execute(
                """SELECT payload_json FROM pod_checkpoints WHERE session_id = ?
                ORDER BY risk_score IS NULL, risk_score DESC, tracking_number ASC;""",
                (session_id,),
            )
            for row in cursor.fetchall():
                pods.append(PODRecord.from_dict(json.loads(row["payload_json"])))
        from processing.scoring import queue_sort_key
        return sorted(pods, key=lambda p: (queue_sort_key(p)[0], -(p.risk_score if p.risk_score is not None else -1),
                                           p.tracking_number))

    def mark_session_completed(self, session_id: str):
        """Marca una sesión como COMPLETADA exitosamente."""
        now_str = operation_now().strftime("%Y-%m-%d %H:%M:%S")
        with self._get_connection() as conn:
            conn.execute("""
            UPDATE audit_sessions
            SET status = 'COMPLETED', updated_at = ?
            WHERE session_id = ?;
            """, (now_str, session_id))
            conn.commit()

    def delete_session(self, session_id: str):
        """Elimina una sesión y sus checkpoints asociados."""
        with self._get_connection() as conn:
            conn.execute("DELETE FROM audit_sessions WHERE session_id = ?;", (session_id,))
            conn.commit()
