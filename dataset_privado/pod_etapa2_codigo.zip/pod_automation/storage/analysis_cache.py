"""Caché SQLite de lecturas por bytes de imagen, dirección, reglas y configuración.

No almacena estados de revisión ni puntajes. Un error nunca se guarda como lectura definitiva.
"""
from contextlib import contextmanager
from contextvars import ContextVar
import functools
import hashlib
import importlib.metadata
import json
import re
import sqlite3
import time
from dataclasses import asdict
from pathlib import Path

import config

_READ_FAILURES = ContextVar('analysis_read_failures',default=0)

def track_read_failures(function):
    @functools.wraps(function)
    def wrapped(*args,**kwargs):
        try:
            result=function(*args,**kwargs)
            if getattr(result,'error',None) or (isinstance(result,tuple) and result and result[0] is None):
                _READ_FAILURES.set(_READ_FAILURES.get()+1)
            return result
        except Exception:
            _READ_FAILURES.set(_READ_FAILURES.get()+1)
            raise
    return wrapped


def analysis_signature():
    code = hashlib.sha256(Path(__file__).read_bytes())
    referenced = set()
    sources = [config.PROJECT_ROOT / 'processing' / name for name in ('pipeline.py','ocr_address.py','vision_llm.py')]
    sources.append(config.PROJECT_ROOT / 'tools/paddle_ocr_server.py')
    for source in sources:
        content = source.read_bytes()
        code.update(content)
        referenced.update(re.findall(r'\bconfig\.([A-Z][A-Z0-9_]*)',content.decode('utf-8')))
    # Los directorios de almacenamiento no cambian la lectura; sí todos los parámetros usados por el código.
    settings = {key:getattr(config,key) for key in referenced - {'PROJECT_ROOT','STORAGE_DIR'} if hasattr(config,key)}
    settings['epoch'] = config.ANALYSIS_CACHE_EPOCH
    settings['code'] = code.hexdigest()
    settings['cache_format'] = 1
    for package in ('numpy','Pillow','easyocr','paddleocr','opencv-python','pytesseract'):
        try: settings[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError: settings[package] = 'external-or-unavailable'
    return hashlib.sha256(json.dumps(settings,sort_keys=True,default=str).encode()).hexdigest()


def reading_key(kind, paths, options):
    if not paths or not config.ANALYSIS_CACHE_ENABLED:
        return None
    try:
        digests=[]
        for path in paths:
            digest=hashlib.sha256()
            with open(path,'rb') as stream:
                for chunk in iter(lambda: stream.read(1024*1024),b''): digest.update(chunk)
            digests.append(digest.hexdigest())
        return hashlib.sha256(json.dumps([kind,digests,options,analysis_signature()],sort_keys=True,default=str).encode()).hexdigest()
    except OSError:
        return None


class ReadingCache:
    def __init__(self,path=None):
        self.path=Path(path or config.ANALYSIS_CACHE_PATH)

    @contextmanager
    def connect(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        connection=sqlite3.connect(self.path,timeout=5)
        connection.execute('PRAGMA journal_mode=WAL')
        connection.execute('CREATE TABLE IF NOT EXISTS readings(cache_key TEXT PRIMARY KEY, payload TEXT NOT NULL, created REAL NOT NULL, accessed REAL NOT NULL)')
        connection.execute('CREATE INDEX IF NOT EXISTS readings_accessed ON readings(accessed)')
        try:
            with connection: yield connection
        finally:
            connection.close()

    def get(self,key):
        if key is None: return None
        try:
            with self.connect() as conn:
                row=conn.execute('SELECT payload,created FROM readings WHERE cache_key=?',(key,)).fetchone()
                if row is None or time.time()-row[1] > config.ANALYSIS_CACHE_TTL_DAYS*86400: return None
                conn.execute('UPDATE readings SET accessed=? WHERE cache_key=?',(time.time(),key))
                return json.loads(row[0])
        except (OSError,sqlite3.Error,ValueError): return None

    def put(self,key,value):
        if key is None: return
        try:
            with self.connect() as conn:
                now=time.time()
                conn.execute('INSERT OR REPLACE INTO readings VALUES (?,?,?,?)',(key,json.dumps(value),now,now))
                conn.execute('DELETE FROM readings WHERE created < ?',(now-config.ANALYSIS_CACHE_TTL_DAYS*86400,))
                conn.execute('DELETE FROM readings WHERE cache_key IN (SELECT cache_key FROM readings ORDER BY accessed DESC LIMIT -1 OFFSET ?)',(max(1,config.ANALYSIS_CACHE_MAX_ENTRIES),))
        except (OSError,sqlite3.Error,ValueError,TypeError): pass


def _restore(rows,paths):
    from processing.ocr_address import PhotoOCR
    if not isinstance(rows,list) or len(rows)!=len(paths): return None
    try: return [PhotoOCR(**{**row,'path':str(path)}) for row,path in zip(rows,paths)]
    except (TypeError,ValueError): return None


def cached_photo_reading(function):
    @functools.wraps(function)
    def wrapped(path,min_conf=None,max_side=None):
        key=reading_key('photo',[path],[min_conf,max_side])
        cache=ReadingCache()
        saved=cache.get(key)
        restored=_restore(saved,[path]) if saved is not None else None
        if restored is not None: return restored[0]
        result=function(path,min_conf,max_side)
        if not result.error and not result.vision_error and key and key==reading_key('photo',[path],[min_conf,max_side]):
            cache.put(key,[asdict(result)])
        return result
    return wrapped


def cached_photo_batch(function):
    @functools.wraps(function)
    def wrapped(paths,expected_address=None):
        key=reading_key('batch',paths,expected_address)
        cache=ReadingCache()
        saved=cache.get(key)
        restored=_restore(saved,paths) if saved is not None else None
        if restored is not None:
            from processing import pipeline,vision_llm
            vision_llm.reset_stats()
            pipeline.LAST_STAGES.clear()
            pipeline.LAST_STAGES.update({'cache_reutilizada':len(restored),'llamadas_vision':0})
            return restored
        token=_READ_FAILURES.set(0)
        try:
            result=function(paths,expected_address)
            failed=_READ_FAILURES.get()
        finally:
            _READ_FAILURES.reset(token)
        if not failed and result and len(result)==len(paths) and all(not photo.error and not photo.vision_error for photo in result) and key and key==reading_key('batch',paths,expected_address):
            cache.put(key,[asdict(photo) for photo in result])
        return result
    return wrapped
