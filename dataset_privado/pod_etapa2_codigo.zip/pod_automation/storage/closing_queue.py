"""Cierre persistente por bloques. Se atiende SOLO despues de la extraccion pendiente."""
import json
import time

import config
from automation.browser import SessionExpiredError


class ClosingQueue:
    def __init__(self,checkpoints):
        self.checkpoints=checkpoints
        with checkpoints._get_connection() as con:
            con.executescript('''
                CREATE TABLE IF NOT EXISTS closing_runs(session_id TEXT PRIMARY KEY,day TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending');
                CREATE TABLE IF NOT EXISTS closing_jobs(session_id TEXT NOT NULL,tracking TEXT NOT NULL,sign_id TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'pending',attempts INTEGER NOT NULL DEFAULT 0,next_try REAL NOT NULL DEFAULT 0,
                    last_error TEXT, PRIMARY KEY(session_id,tracking));
                CREATE INDEX IF NOT EXISTS closing_jobs_pending ON closing_jobs(status,next_try);
            ''')

    def enqueue(self,session_id,day):
        from processing.scoring import portal_info_is_false_pod
        with self.checkpoints._get_connection() as con:
            exists=con.execute('SELECT 1 FROM closing_runs WHERE session_id=?',(session_id,)).fetchone()
            if exists:
                return
            con.execute('INSERT INTO closing_runs(session_id,day) VALUES (?,?)',(session_id,day))
            for row in con.execute("SELECT tracking_number,json_extract(payload_json,'$.portal_meta') FROM pod_checkpoints WHERE session_id=?",(session_id,)):
                meta=json.loads(row[1] or '{}')
                if meta.get('sign_id') and not portal_info_is_false_pod({'whetherReported':meta.get('whether_reported'),'falseSignature':meta.get('false_signature')}):
                    con.execute('INSERT OR IGNORE INTO closing_jobs(session_id,tracking,sign_id) VALUES (?,?,?)',
                                (session_id,row[0],str(meta['sign_id'])))

    def pending_count(self):
        with self.checkpoints._get_connection() as con:
            return con.execute("SELECT COUNT(*) FROM closing_jobs WHERE status='pending'").fetchone()[0]

    def run_some(self,api,limit=None,budget_s=None):
        from processing.scoring import portal_info_is_false_pod
        limit=config.CLOSING_BATCH_SIZE if limit is None else limit
        budget_s=config.CLOSING_BUDGET_S if budget_s is None else budget_s
        started=time.monotonic()
        with self.checkpoints._get_connection() as con:
            jobs=con.execute("SELECT session_id,tracking,sign_id,attempts FROM closing_jobs WHERE status='pending' AND next_try<=? ORDER BY next_try,session_id,tracking LIMIT ?",
                             (time.time(),max(0,limit))).fetchall()
        attempted=flagged=0
        for sid,tracking,sign_id,attempts in jobs:
            if time.monotonic()-started>=budget_s:
                break
            attempted+=1
            try:
                with self.checkpoints._get_connection() as con:
                    current=con.execute("SELECT json_extract(payload_json,'$.portal_meta.sign_id'),json_extract(payload_json,'$.portal_meta.station_id'),json_extract(payload_json,'$.station') FROM pod_checkpoints WHERE session_id=? AND tracking_number=?",(sid,tracking)).fetchone()
                if current and current[0] and str(current[0])!=sign_id:
                    with self.checkpoints._get_connection() as con:
                        con.execute('UPDATE closing_jobs SET sign_id=?,next_try=0,attempts=0 WHERE session_id=? AND tracking=?',(str(current[0]),sid,tracking))
                    continue
                if current and current[0]:
                    station=current[1] or next((i for i,n in config.GOFO_STATION_NAMES.items() if n==current[2]),None)
                    if station and hasattr(api,'switch_station'):
                        api.switch_station(int(station))
                    elif getattr(api,'require_station',False) is True:
                        raise ValueError('Falta ciudad en este checkpoint anterior; se conserva para cierre manual.')
                info=api.get_sign_info(sign_id) if current and current[0] else {}
                if current and current[0] and portal_info_is_false_pod(info):
                    self.checkpoints.mark_portal_false_pod(sid,tracking,info.get('whetherReported'),info.get('falseSignature'))
                    flagged+=1
                with self.checkpoints._get_connection() as con:
                    con.execute("UPDATE closing_jobs SET status='done',last_error=NULL WHERE session_id=? AND tracking=?",(sid,tracking))
            except SessionExpiredError:
                raise
            except Exception as error:
                with self.checkpoints._get_connection() as con:
                    con.execute('UPDATE closing_jobs SET attempts=attempts+1,next_try=?,last_error=? WHERE session_id=? AND tracking=?',
                                (time.time()+min(300,2**min(8,attempts+1)),str(error)[:500],sid,tracking))
        return {'attempted':attempted,'flagged':flagged,'remaining':self.pending_count()}

    def ready_to_finish(self):
        with self.checkpoints._get_connection() as con:
            return [dict(r) for r in con.execute("SELECT session_id,day FROM closing_runs r WHERE status='pending' AND NOT EXISTS (SELECT 1 FROM closing_jobs j WHERE j.session_id=r.session_id AND j.status='pending')")]

    def finish(self,session_id):
        with self.checkpoints._get_connection() as con:
            con.execute("UPDATE closing_runs SET status='done' WHERE session_id=?",(session_id,))
