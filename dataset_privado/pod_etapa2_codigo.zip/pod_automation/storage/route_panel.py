"""
Panel de rutas (11/10/2026, pedido del usuario: replicar el Dashboard(DSP) de GOFO en la página local).

La corrida ya pide en cada pasada el resumen de los repartidores (getPodDetailsGroupUP_v3) y la lista de albaranes de
cada ruta; aquí se guarda lo que muestra el panel de GOFO:
- por repartidor: asignados, entregados, devueltos a la estación, fallidos, reasignados, en espera, tasa de POD;
- por albarán con problema: tipo ("No Acceso", "Dirección incorrecta"…), observación, hora y parada.
Base aparte (storage/route_panel.db) para no competir con la de los albaranes.
"""

import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Dict, Iterable, List

import config

PANEL_DB = config.STORAGE_DIR / "route_panel.db"


def _db(path: Path = None) -> sqlite3.Connection:
    conn = sqlite3.connect(str(path or PANEL_DB), timeout=30)
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS couriers (
            date TEXT NOT NULL, user_id TEXT NOT NULL, driver TEXT, station TEXT,
            checkout INTEGER, pod INTEGER, returned INTEGER, failed INTEGER, reassigned INTEGER, delivering INTEGER,
            pod_rate REAL, warn_level INTEGER, updated_at TEXT NOT NULL, PRIMARY KEY (date, user_id));
        CREATE TABLE IF NOT EXISTS exceptions (
            date TEXT NOT NULL, tracking TEXT NOT NULL, user_id TEXT, driver TEXT, station TEXT, stop TEXT,
            status TEXT, issue TEXT, remark TEXT, issue_time TEXT, updated_at TEXT NOT NULL,
            PRIMARY KEY (date, tracking));
    """)
    return conn


def _int(v):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return None


def save_couriers(date: str, station: str, couriers: Iterable[Dict], path: Path = None) -> None:
    now = datetime.now().isoformat(timespec="seconds")
    rows = []
    for c in couriers:
        uid = str(c.get("userId") or c.get("driverName") or "")
        if not uid:
            continue
        rate = c.get("podRate2400")
        rows.append((date, uid, " ".join((c.get("driverName") or "").split()), station or c.get("siteName") or "",
                     _int(c.get("checkOutPieces")), _int(c.get("podPieces")), _int(c.get("returnCenter")),
                     _int(c.get("deliveryFailPieces")), _int(c.get("reassigned")), _int(c.get("deliveringPieces")),
                     float(rate) if rate is not None else None, _int(c.get("warnLevel")), now))
    with _db(path) as conn:
        conn.executemany("INSERT OR REPLACE INTO couriers VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)


def save_exception(date: str, station: str, courier: Dict, record: Dict, path: Path = None) -> None:
    """Un albarán de la lista de la ruta con problema de entrega (deliveryIssueName)."""
    if not record.get("deliveryIssueName") and not record.get("deliveryIssueRemark"):
        return
    with _db(path) as conn:
        conn.execute("INSERT OR REPLACE INTO exceptions VALUES (?,?,?,?,?,?,?,?,?,?,?)", (
            date, record.get("waybillNo") or "", str(courier.get("userId") or ""),
            " ".join((courier.get("driverName") or "").split()), station, record.get("stopIndex") or "",
            str(record.get("waybillDeliveryStatus") or ""), (record.get("deliveryIssueName") or "").strip(),
            (record.get("deliveryIssueRemark") or "").strip(), record.get("deliveryIssusTime") or "",
            datetime.now().isoformat(timespec="seconds")))


def load(date: str, path: Path = None) -> Dict[str, List[Dict]]:
    with _db(path) as conn:
        conn.row_factory = sqlite3.Row
        couriers = [dict(r) for r in conn.execute("SELECT * FROM couriers WHERE date = ? ORDER BY driver", (date,))]
        exceptions = [dict(r) for r in conn.execute(
            "SELECT * FROM exceptions WHERE date = ? ORDER BY issue_time DESC", (date,))]
    return {"couriers": couriers, "exceptions": exceptions}
