"""
Limpieza del historial de albaranes (05/10/2026).

De los días pasados solo se guardan los "casos guía": los que sirven para comprobar que una corrección no rompe nada
(tools/evaluar_dia.py vuelve a calificarlos con el código actual). Son:
- los marcados en la página de reportes (report_status.db): reportado / descartado / pendiente;
- los mencionados en output/pendientes_*.md (falsos positivos anotados durante el día);
- los de tests/casos_reales_*.json.

Se guardan completos: el día en curso y los días de referencia (config.HISTORY_REFERENCE_DAYS), que sirven para medir
cuántas alarmas da el modelo en un día entero.

Del resto de los días pasados se borra: su registro en pod_checkpoints, el avance por ruta y sus fotos en pod_images.
Se conservan siempre audit_sessions (lista de fechas), driver_roster (repartidores nuevos) y report_status.db.

Uso:  python main.py limpiar            (muestra el resumen y pide confirmación)
      python main.py limpiar --yes      (sin confirmación)
"""

import re
import shutil
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Set

import config

TRACKING_RE = re.compile(r"\b(?:GFUS|YT)\d{10,}\b")


@dataclass
class CleanupPlan:
    keep_days: Set[str]
    guide: Set[str]
    rows_by_day: Dict[str, int] = field(default_factory=dict)        # albaranes que se borran, por día
    kept_rows_by_day: Dict[str, int] = field(default_factory=dict)   # casos guía que se quedan, por día
    photo_dirs: List[Path] = field(default_factory=list)
    photo_bytes: int = 0
    purge_sessions: List[str] = field(default_factory=list)

    @property
    def total_rows(self) -> int:
        return sum(self.rows_by_day.values())


def guide_trackings(status_db: Path = None, output_dir: Path = None, tests_dir: Path = None) -> Set[str]:
    """Albaranes que el usuario revisó o explicó: no se borran nunca."""
    status_db = status_db or config.STORAGE_DIR / "report_status.db"
    output_dir = output_dir or config.OUTPUT_DIR
    tests_dir = tests_dir or config.PROJECT_ROOT / "tests"
    found: Set[str] = set()
    if status_db.exists():
        with sqlite3.connect(f"file:{status_db.as_posix()}?mode=ro", uri=True) as st:
            found.update(r[0] for r in st.execute("SELECT tracking_number FROM report_status"))
    for path in list(output_dir.glob("pendientes_*.md")) + list(tests_dir.glob("casos_reales_*.json")):
        found.update(TRACKING_RE.findall(path.read_text(encoding="utf-8", errors="ignore")))
    return found


def _dir_size(path: Path) -> int:
    return sum(f.stat().st_size for f in path.rglob("*") if f.is_file())


def build_plan(conn: sqlite3.Connection, today: Optional[str] = None, images_dir: Path = None,
               reference_days=None, guide: Optional[Set[str]] = None) -> CleanupPlan:
    """Calcula qué se borraría, sin tocar nada."""
    images_dir = images_dir or config.POD_IMAGES_DIR
    today = today or datetime.now().strftime("%Y-%m-%d")
    # El día en curso es hoy o la última sesión (si la limpieza se corre pasada la medianoche)
    last = conn.execute("SELECT MAX(query_date) FROM audit_sessions").fetchone()[0]
    keep_days = {today, *(reference_days if reference_days is not None else config.HISTORY_REFERENCE_DAYS)}
    if last:
        keep_days.add(last)
    plan = CleanupPlan(keep_days=keep_days, guide=guide if guide is not None else guide_trackings())

    sessions = conn.execute("SELECT session_id, query_date FROM audit_sessions").fetchall()
    plan.purge_sessions = [sid for sid, day in sessions if day not in keep_days]
    for sid, day in sessions:
        if day in keep_days:
            continue
        for (trk,) in conn.execute("SELECT tracking_number FROM pod_checkpoints WHERE session_id = ?", (sid,)):
            bucket = plan.kept_rows_by_day if trk in plan.guide else plan.rows_by_day
            bucket[day] = bucket.get(day, 0) + 1

    if images_dir.exists():
        for day_dir in sorted(p for p in images_dir.iterdir() if p.is_dir()):
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", day_dir.name) or day_dir.name in keep_days:
                continue  # demo_sample y otras carpetas que no son de un día
            for pod_dir in day_dir.iterdir():
                if pod_dir.is_dir() and pod_dir.name not in plan.guide:
                    plan.photo_dirs.append(pod_dir)
                    plan.photo_bytes += _dir_size(pod_dir)
    return plan


def apply_plan(conn: sqlite3.Connection, plan: CleanupPlan) -> None:
    """Borra lo calculado en build_plan y compacta la base."""
    conn.execute("CREATE TEMP TABLE IF NOT EXISTS keep_trk (t TEXT PRIMARY KEY)")
    conn.execute("DELETE FROM keep_trk")
    conn.executemany("INSERT OR IGNORE INTO keep_trk VALUES (?)", [(t,) for t in plan.guide])
    for sid in plan.purge_sessions:
        conn.execute("DELETE FROM pod_checkpoints WHERE session_id = ? AND tracking_number NOT IN (SELECT t FROM keep_trk)",
                     (sid,))
        conn.execute("DELETE FROM route_progress WHERE session_id = ?", (sid,))
    conn.commit()
    for pod_dir in plan.photo_dirs:
        shutil.rmtree(pod_dir, ignore_errors=True)
    for day_dir in {p.parent for p in plan.photo_dirs}:
        if day_dir.exists() and not any(day_dir.iterdir()):
            day_dir.rmdir()
    conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    conn.execute("VACUUM")
