"""
Base del control de paquetes (15/10/2026): doble escaneo, devoluciones y perdidos (ver processing/package_control.py).

- roster: todos los albaranes de cada ruta listada por la corrida (entregados o no), por día.
- tracks: historial de escaneos ya pedido a GOFO (solo lo necesario: hora, código, quién, dónde; el texto solo de
  fallos y pérdidas) y si ya no cambia (entregado, perdido o viejo).
- scans / returns / lost: resultado de los tres controles; se recalculan cada vez que se pide el historial.
Base aparte (storage/package_control.db) para no competir con la de los albaranes.
"""

import json
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Iterable, List, Optional

import config
from processing.package_control import FAILED, LOST_CODES, Event, Track

CONTROL_DB = config.STORAGE_DIR / "package_control.db"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS roster (
    date TEXT NOT NULL, tracking TEXT NOT NULL, user_id TEXT, driver TEXT, station TEXT, status TEXT,
    updated_at TEXT NOT NULL, PRIMARY KEY (date, tracking));
CREATE TABLE IF NOT EXISTS tracks (
    tracking TEXT PRIMARY KEY, fetched_at TEXT NOT NULL, settled INTEGER NOT NULL DEFAULT 0,
    last_event TEXT, events_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS scans (
    date TEXT NOT NULL, tracking TEXT NOT NULL, driver TEXT NOT NULL, station TEXT, out_time TEXT, verdict TEXT,
    own_scan TEXT, scanned_by TEXT, after_by TEXT, PRIMARY KEY (date, tracking, driver));
CREATE TABLE IF NOT EXISTS returns (
    tracking TEXT NOT NULL, start_time TEXT NOT NULL, kind TEXT, date TEXT, driver TEXT, station TEXT, issue TEXT,
    deadline TEXT, outcome TEXT, resolved_time TEXT, resolved_by TEXT, hours REAL, PRIMARY KEY (tracking, start_time));
CREATE TABLE IF NOT EXISTS lost (
    tracking TEXT NOT NULL, lost_time TEXT NOT NULL, date TEXT, code TEXT, label TEXT, station TEXT,
    last_scan_by TEXT, last_scan_code TEXT, last_scan_time TEXT, last_out_by TEXT, last_fail_time TEXT,
    PRIMARY KEY (tracking, lost_time));
CREATE TABLE IF NOT EXISTS runs (
    finished_at TEXT PRIMARY KEY, days TEXT, fetched INTEGER, scans INTEGER, returns INTEGER, lost INTEGER);
CREATE INDEX IF NOT EXISTS ix_scans_date ON scans(date);
CREATE INDEX IF NOT EXISTS ix_returns_date ON returns(date);
"""


def _db(path: Path = None) -> sqlite3.Connection:
    conn = sqlite3.connect(str(path or CONTROL_DB), timeout=30)
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.executescript(_SCHEMA)
    return conn


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


# ---------------------------------------------------------------- roster (lo llena la corrida)
def save_route(date: str, station: str, courier: Dict, waybills: Iterable, path: Path = None) -> None:
    now = _now()
    uid = str(courier.get("userId") or "")
    driver = " ".join((courier.get("driverName") or "").split())
    rows = [(date, w.waybill_no, uid, driver, station, w.delivery_status_code, now) for w in waybills if w.waybill_no]
    with _db(path) as conn:
        conn.executemany("INSERT OR REPLACE INTO roster VALUES (?,?,?,?,?,?,?)", rows)


# ---------------------------------------------------------------- historial
def _dump(track: Track) -> str:
    keep_text = {FAILED, *LOST_CODES}
    return json.dumps([[e.when.isoformat(sep=" "), e.code, e.by, e.location, e.text if e.code in keep_text else ""]
                       for e in track.events], ensure_ascii=False, separators=(",", ":"))


def _load(tracking: str, data: str) -> Track:
    return Track(tracking, [Event(datetime.fromisoformat(w), c, b, l, t) for w, c, b, l, t in json.loads(data)])


def save_tracks(tracks: Iterable[Track], settled: Dict[str, bool], path: Path = None) -> None:
    now = _now()
    rows = [(t.tracking, now, int(settled.get(t.tracking, False)),
             t.events[-1].when.isoformat(sep=" ") if t.events else None, _dump(t)) for t in tracks]
    with _db(path) as conn:
        conn.executemany("INSERT OR REPLACE INTO tracks VALUES (?,?,?,?,?)", rows)


def load_tracks(trackings: Iterable[str], path: Path = None) -> List[Track]:
    trackings = list(trackings)
    out = []
    with _db(path) as conn:
        for i in range(0, len(trackings), 500):
            chunk = trackings[i:i + 500]
            q = f"SELECT tracking, events_json FROM tracks WHERE tracking IN ({','.join('?' * len(chunk))})"
            out += [_load(t, d) for t, d in conn.execute(q, chunk)]
    return out


def settled_trackings(path: Path = None) -> set:
    with _db(path) as conn:
        return {r[0] for r in conn.execute("SELECT tracking FROM tracks WHERE settled = 1")}


def recent_trackings(max_age_days: int = 15, path: Path = None) -> List[str]:
    """Todos los historiales guardados con movimiento en los últimos días (para recalcular con reglas nuevas)."""
    since = (datetime.now() - timedelta(days=max_age_days)).isoformat(sep=" ")
    with _db(path) as conn:
        return [r[0] for r in conn.execute("SELECT tracking FROM tracks WHERE last_event >= ?", (since,))]


def open_trackings(max_age_days: int = 10, path: Path = None) -> List[str]:
    """Historiales que todavía pueden cambiar (sin entregar ni perder) con movimiento en los últimos días."""
    since = (datetime.now() - timedelta(days=max_age_days)).isoformat(sep=" ")
    with _db(path) as conn:
        return [r[0] for r in conn.execute("SELECT tracking FROM tracks WHERE settled = 0 AND last_event >= ?", (since,))]


# ---------------------------------------------------------------- resultados
def save_results(results: Dict[str, List[Dict]], path: Path = None) -> None:
    with _db(path) as conn:
        conn.executemany(
            "INSERT OR REPLACE INTO scans VALUES (:date,:tracking,:driver,:station,:out_time,:verdict,:own_scan,"
            ":scanned_by,:after_by)", results.get("scans") or [])
        conn.executemany(
            "INSERT OR REPLACE INTO returns VALUES (:tracking,:start_time,:kind,:date,:driver,:station,:issue,:deadline,"
            ":outcome,:resolved_time,:resolved_by,:hours)", results.get("returns") or [])
        conn.executemany(
            "INSERT OR REPLACE INTO lost VALUES (:tracking,:lost_time,:date,:code,:label,:station,:last_scan_by,"
            ":last_scan_code,:last_scan_time,:last_out_by,:last_fail_time)", results.get("lost") or [])


def save_run(days: List[str], fetched: int, counts: Dict[str, int], path: Path = None) -> None:
    with _db(path) as conn:
        conn.execute("INSERT OR REPLACE INTO runs VALUES (?,?,?,?,?,?)",
                     (_now(), ",".join(days), fetched, counts.get("scans", 0), counts.get("returns", 0),
                      counts.get("lost", 0)))


def roster_trackings(days: Iterable[str], path: Path = None) -> Dict[str, Dict]:
    days = list(days)
    with _db(path) as conn:
        conn.row_factory = sqlite3.Row
        q = f"SELECT * FROM roster WHERE date IN ({','.join('?' * len(days))})"
        return {r["tracking"]: dict(r) for r in conn.execute(q, days)}


def load(date: str, path: Path = None) -> Dict:
    """Lo que muestra la página local para un día: doble escaneo de ese día, devoluciones abiertas o de ese día y
    perdidos de los últimos 14 días."""
    since = (datetime.fromisoformat(date) - timedelta(days=14)).date().isoformat()
    with _db(path) as conn:
        conn.row_factory = sqlite3.Row
        scans = [dict(r) for r in conn.execute("SELECT * FROM scans WHERE date = ? ORDER BY driver, out_time", (date,))]
        returns = [dict(r) for r in conn.execute(
            "SELECT * FROM returns WHERE date = ? OR (date < ? AND outcome IN ('pendiente','vencido')) "
            "ORDER BY start_time DESC", (date, date))]
        lost = [dict(r) for r in conn.execute(
            "SELECT * FROM lost WHERE date BETWEEN ? AND ? ORDER BY lost_time DESC", (since, date))]
        run = conn.execute("SELECT * FROM runs ORDER BY finished_at DESC LIMIT 1").fetchone()
        roster = conn.execute("SELECT COUNT(*) FROM roster WHERE date = ?", (date,)).fetchone()[0]
    return {"scans": scans, "returns": returns, "lost": lost, "last_run": dict(run) if run else None,
            "roster": roster}
