"""29/10 (pedido del usuario): PC y Kaggle Luis comparten la ciudad en curso de la cuenta de Luis en vez de turnarse la cuenta.

Lo que choca en GOFO es CAMBIAR de ciudad (una sola activa por cuenta), no trabajar a la vez en la misma.
"""
from unittest.mock import MagicMock

import pytest

import config
from automation import session_guard
from automation.session_guard import SessionGuard, SessionCoordinationError


class Portal:
    """Respuestas del portal nuevo (ciudad compartida) o del anterior (sin 'city')."""

    def __init__(self, answers):
        self.answers = list(answers); self.bodies = []

    def call(self, path, body):
        self.bodies.append(dict(body))
        if body['action'] == 'release':
            return {'granted': False}
        return self.answers.pop(0)


@pytest.fixture(autouse=True)
def clean(monkeypatch):
    monkeypatch.setattr(session_guard, 'OUTAGE_SINCE', [None])
    monkeypatch.setattr(session_guard, 'SEEN_LEASE', [0])
    monkeypatch.setattr(session_guard, 'CONFLICT', [None])


def test_pide_sus_ciudades_y_trabaja_en_la_que_dice_el_portal():
    portal = Portal([{'granted': True, 'lease_s': 180, 'city': 'DFW02-BAA', 'turn_s': 170}])
    guard = SessionGuard(portal, 'luisvivas', 'pc', renew_s=60, cities=['DFW-BAA', 'DFW02-BAA'], turn_s=240)
    assert guard.acquire()
    assert portal.bodies[0]['cities'] == ['DFW-BAA', 'DFW02-BAA'] and portal.bodies[0]['turn_s'] == 240
    assert guard.city == 'DFW02-BAA' and guard.turn_left == 170
    guard.close(empty=True)
    assert portal.bodies[-1] == {**portal.bodies[-1], 'action': 'release', 'empty': True}


def test_portal_anterior_sin_ciudad_sigue_como_antes():
    portal = Portal([{'granted': True, 'lease_s': 180}])
    guard = SessionGuard(portal, 'luisvivas', 'pc', renew_s=60, cities=['DFW-BAA'])
    assert guard.acquire() and guard.city is None and guard.turn_left is None
    guard.close(empty=True)
    assert 'empty' not in portal.bodies[-1]          # sin ciudad compartida no hay ciudad que saltar


def test_sin_ciudades_es_exclusiva_como_antes():
    portal = Portal([{'granted': True, 'lease_s': 180, 'city': 'DFW-BAA', 'turn_s': 100}])
    guard = SessionGuard(portal, 'luisvivas', 'pc', renew_s=60)
    assert guard.acquire() and 'cities' not in portal.bodies[0] and guard.city is None
    guard.close()


def test_al_volver_el_portal_la_pc_sin_portal_pide_exclusiva():
    """Sin portal la PC pudo estar en cualquier ciudad: no se une a una ciudad compartida a mitad de su pasada."""
    import time
    portal = Portal([{'granted': True, 'lease_s': 180}])
    guard = SessionGuard(portal, 'luisvivas', 'pc', renew_s=60, retry_s=0.01, cities=['DFW-BAA', 'DFW02-BAA'])
    guard.start_offline()
    end = time.monotonic() + 3
    while guard.offline and time.monotonic() < end:
        time.sleep(0.01)
    guard.stop.set()
    assert not guard.offline and 'cities' not in portal.bodies[0]


def test_con_ciudad_compartida_no_se_abre_otra_ciudad(monkeypatch):
    from automation.portal_api import PortalAPI
    page = MagicMock()
    page.evaluate.return_value = {'status': 200, 'text': '{"code":200}', 'url': ''}
    api = PortalAPI(page, sleep=lambda _: None)
    api.session_guard = MagicMock(city='DFW02-BAA')
    with pytest.raises(SessionCoordinationError, match='DFW02-BAA'):
        api.switch_station(297)                      # DFW-BAA: le cambiaria la ciudad a la otra corrida
    page.evaluate.assert_not_called()
    api.switch_station(1888)                         # la misma ciudad compartida: permitido
    assert api.current_station == 1888


def test_el_extractor_corta_al_terminar_el_turno_de_la_ciudad(tmp_path, monkeypatch):
    """El turno lo marca lo que queda de la ciudad compartida (el portal), no CITY_TURN_S."""
    from automation.api_extractor import ApiPODExtractor
    from tests.test_api_extractor import FakeAPI, _fake_downloader
    monkeypatch.setattr(config, 'GOFO_SESSION_GROUP', 'luisvivas')
    monkeypatch.setattr(config, 'CITY_DISPATCH_DB', '')
    monkeypatch.setattr(config, 'CITY_TURN_S', 1e9)
    monkeypatch.setattr(config, 'ROUTES_PER_BLOCK', 1)
    monkeypatch.setattr(config, 'ROUTE_LIST_CACHE_S', 0)

    def listed_routes(turn_s):
        api = FakeAPI(); real = api.iter_waybills; calls = []
        api.iter_waybills = lambda *a, **k: (calls.append(a[2]['userId']), (yield from real(*a, **k)))[1]
        ext = ApiPODExtractor(api, images_dir=tmp_path, downloader=_fake_downloader)
        ext.turn_s = turn_s
        ext.run_pass([1888], '2026-10-29', set(), lambda p: None)
        return calls, ext.capped

    assert listed_routes(None) == ([1, 2], False)    # sin ciudad compartida: CITY_TURN_S (enorme) no corta
    calls, capped = listed_routes(1e-9)
    assert calls == [1] and capped                   # turno vencido: corta tras el primer bloque y deja lo demas
