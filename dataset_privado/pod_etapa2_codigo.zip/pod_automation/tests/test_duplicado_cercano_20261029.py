"""29/10: foto repetida con otro albarán, pero tomada junto a la dirección de este (930/932 W Rochelle Rd)."""
import pytest
import config
from models.pod import DuplicateStatusEnum, PODRecord
from processing.scoring import check_duplicates


def _pod(distance, exact=True):
    pod = PODRecord(tracking_number="T1", receipt_address="930 W Rochelle Rd Apt 158 Irving TX", driver_name="X", station="DFW-BAA")
    pod.duplicate_status = (DuplicateStatusEnum.EXACT_DUPLICATE.value if exact
                            else DuplicateStatusEnum.POSSIBLE_VISUAL_DUPLICATE.value)
    pod.duplicate_matched_tracking = "T2"
    if distance is not None:
        pod.portal_meta["sign_distance"] = str(distance)
    return pod


@pytest.mark.parametrize("exact", [True, False])
def test_foto_repetida_tomada_junto_a_esta_direccion_no_es_error(exact):
    r = check_duplicates(_pod(3.0, exact), other_of=lambda t: None)
    assert r.score == 0 and not r.applicable and "entrega múltiple" in r.explanation


def test_el_limite_es_inclusivo_y_mas_alla_sigue_alertando():
    assert check_duplicates(_pod(50.0), other_of=lambda t: None).score == 0
    assert check_duplicates(_pod(50.5), other_of=lambda t: None).score == 100
    assert check_duplicates(_pod(759.4), other_of=lambda t: None).score == 100        # el único error real del historial
    assert check_duplicates(_pod(759.4, exact=False), other_of=lambda t: None).score == 80


def test_sin_distancia_gps_se_mantiene_la_alerta():
    assert check_duplicates(_pod(None), other_of=lambda t: None).score == 100
    assert check_duplicates(_pod("n/d"), other_of=lambda t: None).score == 100


def test_se_puede_apagar(monkeypatch):
    monkeypatch.setattr(config, "DUPLICATE_NEAR_ADDRESS_M", 0)
    assert check_duplicates(_pod(3.0), other_of=lambda t: None).score == 100

