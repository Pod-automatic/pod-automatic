"""
Pruebas Unitarias para la Fase 3: Exportación a Excel con pandas y openpyxl.

Verifica:
- Hoja 'POD Results' con las 20 columnas exactas requeridas.
- Formato condicional: VERDE (VALID/APPROVED), AMARILLO (REVIEW REQUIRED), ROJO (POSSIBLE INVALID POD/ERROR).
- Hoja 'Summary' con las 6 métricas clave de auditoría.
"""

from pathlib import Path
import openpyxl

from models.pod import (
    PODRecord,
    VerdictEnum,
    ProcessingStatusEnum,
    PODMemoryStorage,
)
from export.excel_exporter import PODExcelExporter


def test_excel_export_structure(tmp_path):
    exporter = PODExcelExporter(output_dir=tmp_path)

    # 1. Crear conjunto variado de registros
    pods = [
        PODRecord(
            tracking_number="GF001",
            stop_number="1",
            driver_name="Pedro Sánchez",
            station="DFW02",
            address="Calle Alcalá 1, Madrid",
            delivery_status="Entregado",
            delivery_datetime="2026-09-12 10:00:00",
            delivery_type="Puerta",
            verdict=VerdictEnum.VALIDO,
            quality_score=95.0,
            number_of_photos=1,
            processing_status=ProcessingStatusEnum.PROCESSED,
        ),
        PODRecord(
            tracking_number="GF002",
            stop_number="2",
            driver_name="María López",
            station="DFW02",
            address="Calle Goya 25, Madrid",
            delivery_status="Entregado",
            delivery_datetime="2026-09-12 10:15:00",
            delivery_type="En mano",
            verdict=VerdictEnum.REQUIERE_REVISION,
            quality_score=65.0,
            anomalies=["[FOTO_BORROSA] Foto movida"],
            number_of_photos=1,
            processing_status=ProcessingStatusEnum.PROCESSED,
        ),
        PODRecord(
            tracking_number="GF003",
            stop_number="3",
            driver_name="Luis Fernández",
            station="DFW02",
            address="Gran Vía 10, Madrid",
            delivery_status="Entregado",
            delivery_datetime="2026-09-12 10:30:00",
            delivery_type="Puerta",
            verdict=VerdictEnum.SOSPECHOSO,
            quality_score=30.0,
            anomalies=["[FOTO_DUPLICADA] Misma foto que GF001"],
            number_of_photos=1,
            processing_status=ProcessingStatusEnum.PROCESSED,
        ),
        PODRecord(
            tracking_number="GF004",
            stop_number="4",
            driver_name="Ana Ruiz",
            station="DFW02",
            address="Calle Mayor 5, Madrid",
            delivery_status="Fallido",
            delivery_datetime="2026-09-12 10:45:00",
            delivery_type="Puerta",
            verdict=VerdictEnum.SOSPECHOSO,
            quality_score=0.0,
            processing_status=ProcessingStatusEnum.FAILED,
            error_message="Timeout cargando modal de entrega",
        ),
    ]

    excel_file = exporter.export(pods, filename="test_phase3_report.xlsx")

    assert excel_file.exists()
    assert excel_file.suffix == ".xlsx"

    # Cargar libro con openpyxl
    wb = openpyxl.load_workbook(excel_file)

    # 2. Verificar hojas requeridas
    sheet_names = wb.sheetnames
    assert "POD Results" in sheet_names
    assert "Summary" in sheet_names

    ws_results = wb["POD Results"]

    # 3. Verificar las 20 columnas requeridas de 'POD Results'
    expected_headers = [
        "Tracking",
        "Stop",
        "Driver",
        "Station",
        "Address",
        "Delivery Status",
        "Delivery Date",
        "Delivery Type",
        "Photos Count",
        "Package Visible",
        "Property/Door Visible",
        "Address Visible",
        "Image Quality",
        "Duplicate Photo",
        "Validation Result",
        "Confidence Score",
        "Requires Manual Review",
        "Non Compliance Reason",
        "Processing Status",
        "Error",
    ]

    actual_headers = [cell.value for cell in ws_results[1]]
    assert actual_headers == expected_headers

    # Verificar 4 filas de datos + 1 encabezado = 5 filas
    assert ws_results.max_row == 5

    # 4. Verificar valores y formatos en 'Validation Result' (Columna 15)
    val_col_idx = 15
    row_val1 = ws_results.cell(row=2, column=val_col_idx).value
    row_val2 = ws_results.cell(row=3, column=val_col_idx).value
    row_val3 = ws_results.cell(row=4, column=val_col_idx).value
    row_val4 = ws_results.cell(row=5, column=val_col_idx).value

    assert row_val1 == "VALID"
    assert row_val2 == "REVIEW REQUIRED"
    assert row_val3 in ("POSSIBLE INVALID POD", "POSSIBLE ISSUE")
    assert row_val4 == "ERROR"

    # Verificar colores de formato condicional aplicados
    # Fila 2 (VALID) -> Verde (#D4EDDA)
    assert ws_results.cell(row=2, column=val_col_idx).fill.start_color.rgb == "00D4EDDA"
    # Fila 3 (REVIEW REQUIRED) -> Amarillo (#FFF3CD)
    assert ws_results.cell(row=3, column=val_col_idx).fill.start_color.rgb == "00FFF3CD"
    # Fila 4 (POSSIBLE INVALID POD) -> Rojo (#F8D7DA)
    assert ws_results.cell(row=4, column=val_col_idx).fill.start_color.rgb == "00F8D7DA"
    # Fila 5 (ERROR) -> Rojo (#F8D7DA)
    assert ws_results.cell(row=5, column=val_col_idx).fill.start_color.rgb == "00F8D7DA"

    # 5. Verificar Hoja 'Summary'
    ws_summary = wb["Summary"]
    summary_text = [str(cell.value) for cell in ws_summary["A"] if cell.value is not None]

    assert any("Total POD procesados" in t for t in summary_text)
    assert any("Total válidos" in t for t in summary_text)
    assert any("Total que requieren revisión" in t for t in summary_text)
    assert any("Total con errores" in t for t in summary_text)
    assert any("Total fotografías analizadas" in t for t in summary_text)
    assert any("Total posibles duplicados" in t for t in summary_text)

    # Verificar valores numéricos del resumen
    summary_dict = {}
    for row in range(4, 10):
        label = ws_summary.cell(row=row, column=1).value
        val = ws_summary.cell(row=row, column=2).value
        if label:
            summary_dict[label] = val

    assert summary_dict["Total POD procesados"] == 4
    assert summary_dict["Total válidos"] == 1
    assert summary_dict["Total que requieren revisión"] == 1
    assert summary_dict["Total con errores"] == 2
    assert summary_dict["Total posibles duplicados"] == 1

    wb.close()
