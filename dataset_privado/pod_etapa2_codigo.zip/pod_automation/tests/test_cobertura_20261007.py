"""
07/10: cobertura. El 06/10 quedaron ~800 entregados de DFW-BAA sin revisar: la pasada iba en orden fijo (todo DFW,
luego DFW02, 30 por repartidor) y cada reinicio volvía al primero de la lista. Ahora se listan las dos ciudades y se
atiende siempre al más atrasado, y los faltantes quedan a la vista.
"""

import json
from datetime import datetime
from pathlib import Path

import config
from automation.api_extractor import ApiPODExtractor, backlog_summary
from automation.portal_api import WaybillSummary
from models.pod import PODRecord
from storage.checkpoint_manager import CheckpointManager

DFW, DFW02 = 297, 1888


class TwoCitiesAPI:
    """Rutas por ciudad: {station: {driver: cantidad entregada}}. Abre el detalle solo en la ciudad activa."""

    def __init__(self, routes):
        self.routes, self.current_station, self.switches, self.opened, self.listed = routes, None, [], [], []

    def list_couriers(self, sid, date):
        # podPieces: entregas con POD según el resumen del portal (sirve para estimar faltantes sin listar la ruta)
        return [{"driverName": d, "userId": f"{sid}-{d}", "podPieces": n} for d, n in self.routes.get(sid, {}).items()]
    def switch_station(self, sid):
        self.switches.append(sid)
        self.current_station = sid

    def iter_waybills(self, sid, date, courier, page_size=50):
        assert self.current_station == sid, "listó otra ciudad sin cambiar"
        self.listed.append(courier["driverName"])
        for i in range(self.routes[sid][courier["driverName"]]):
            yield WaybillSummary(waybill_no=f"{courier['driverName']}-{i}", sign_id=f"{sid}|{i}",
                                 driver_name=courier["driverName"])

    def get_sign_info(self, sign_id):
        assert int(sign_id.split("|")[0]) == self.current_station, "abrió un POD de otra ciudad"
        self.opened.append(sign_id)
        return {"toAddress": "x", "imageList": []}


def _ext(api, **kw):
    return ApiPODExtractor(api, images_dir=Path("/tmp/x"), downloader=lambda u, d: [], **kw)


def _drivers(got):
    return [p.tracking_number.rsplit("-", 1)[0] for p in got]


def test_atiende_primero_al_mas_atrasado_aunque_este_en_la_segunda_ciudad(monkeypatch):
    monkeypatch.setattr(config, "MAX_PER_DRIVER_PER_PASS", 2)
    monkeypatch.setattr(config, "ROUTES_PER_BLOCK", 1)   # 12/10: el comportamiento de 1 ruta por bloque
    api = TwoCitiesAPI({DFW02: {"Ana": 2}, DFW: {"Beto": 6}})
    got = []
    _ext(api).run_pass([DFW02, DFW], "2026-10-07", set(), on_record=got.append)
    # Beto (DFW, debe 6) va antes que Ana (DFW02, debe 2), aunque DFW02 se lista primero
    assert _drivers(got)[:2] == ["Beto", "Beto"]
    assert len(got) == 8   # En la misma pasada se termina todo


def test_un_reinicio_no_vuelve_al_primero_de_la_lista(monkeypatch):
    # Caso 06/10: tras cada reinicio los primeros de DFW-BAA recibían otro bloque y el resto quedaba atrás
    monkeypatch.setattr(config, "MAX_PER_DRIVER_PER_PASS", 3)
    monkeypatch.setattr(config, "ROUTES_PER_BLOCK", 1)   # 12/10: el comportamiento de 1 ruta por bloque
    api = TwoCitiesAPI({DFW: {"Primero": 6, "Ultimo": 6}})
    ya_revisados = {f"Primero-{i}" for i in range(3)}            # La corrida anterior alcanzó a hacer un bloque
    ext = _ext(api)
    ext.reviewed_counts = lambda: {f"{DFW}-Primero": 3}          # Lo guardado en la base
    got = []
    ext.run_pass([DFW], "2026-10-07", set(ya_revisados), on_record=got.append, max_records=3)
    assert _drivers(got) == ["Ultimo"] * 3 and api.listed == ["Ultimo"]   # Ni siquiera hizo falta listar a Primero


def test_ruta_al_dia_no_se_vuelve_a_listar_hasta_que_no_hay_nada_mas(monkeypatch):
    # 07/10: listar cada ruta son ~4 llamadas de ~10 s; las que ya están al día se dejan para el final
    monkeypatch.setattr(config, "MAX_PER_DRIVER_PER_PASS", 30)
    api = TwoCitiesAPI({DFW: {"AlDia": 3, "Nueva": 2}})
    ext = _ext(api)
    ext.reviewed_counts = lambda: {f"{DFW}-AlDia": 3}
    got = []
    ext.run_pass([DFW], "2026-10-07", {f"AlDia-{i}" for i in range(3)}, on_record=got.append)
    assert api.listed == ["Nueva", "AlDia"] and _drivers(got) == ["Nueva", "Nueva"]   # AlDia, al final y sin nada nuevo
    # Siguiente pasada: AlDia se listó hace poco y sigue al día → no se pide; Nueva ya está al día también
    api.listed.clear()
    routes = []
    ext.reviewed_counts = lambda: {f"{DFW}-AlDia": 3, f"{DFW}-Nueva": 2}
    ext.run_pass([DFW], "2026-10-07", {f"AlDia-{i}" for i in range(3)} | {"Nueva-0", "Nueva-1"},
                 on_record=got.append, on_route=lambda st, c, s: routes.append(s))
    assert api.listed == [] and [r["with_pod"] for r in routes] == [3, 2]   # El avance sale del resumen


def test_no_salta_de_ciudad_en_cada_bloque(monkeypatch):
    monkeypatch.setattr(config, "MAX_PER_DRIVER_PER_PASS", 1)
    monkeypatch.setattr(config, "STATION_STAY_RATIO", 0.5)
    api = TwoCitiesAPI({DFW: {"A": 4, "B": 4}, DFW02: {"C": 4, "D": 4}})
    got = []
    _ext(api).run_pass([DFW, DFW02], "2026-10-07", set(), on_record=got.append)
    assert len(got) == 16
    # 2 cambios para listar + pocos durante el proceso (sin la tolerancia serían ~16, uno por bloque)
    # 12/10: con el turno estricto de 30 en 30 puede hacer falta un cambio más por vuelta (antes <= 5)
    assert len(api.switches) <= 6


def test_corta_la_pasada_para_volver_a_listar(monkeypatch):
    monkeypatch.setattr(config, "MAX_PER_DRIVER_PER_PASS", 2)
    monkeypatch.setattr(config, "ROUTES_PER_BLOCK", 1)   # 12/10: el comportamiento de 1 ruta por bloque
    monkeypatch.setattr(config, "PASS_REFRESH_MIN", 1e-9)   # Vencido desde el primer bloque
    api = TwoCitiesAPI({DFW: {"A": 4, "B": 4}})
    ext = _ext(api)
    got = []
    ext.run_pass([DFW], "2026-10-07", set(), on_record=got.append)
    # No corta mientras falten rutas por listar: A (bloque), B (bloque) y ahí sí, a pedir los resúmenes de nuevo
    assert len(got) == 4 and ext.capped


def test_faltantes_por_ciudad_y_mas_atrasados(monkeypatch):
    monkeypatch.setattr(config, "MAX_PER_DRIVER_PER_PASS", 2)
    api = TwoCitiesAPI({DFW: {"A": 5, "B": 1}, DFW02: {"C": 3}})
    seen = []
    _ext(api, on_backlog=seen.append).run_pass([DFW, DFW02], "2026-10-07", set(), on_record=lambda p: None)
    first = seen[0]   # Apenas listadas las rutas
    assert first["total"] == 9 and first["by_station"] == {"DFW-BAA": 6, "DFW02-BAA": 3}
    assert [t["driver"] for t in first["top"]] == ["A", "C", "B"]
    assert seen[-1]["total"] == 0


def test_primero_los_repartidores_con_mas_errores_reales(monkeypatch):
    # 07/10 (pedido del usuario): aunque deba menos, el repartidor con historial de errores va primero
    monkeypatch.setattr(config, "MAX_PER_DRIVER_PER_PASS", 2)
    api = TwoCitiesAPI({DFW: {"Atrasado": 8}, DFW02: {"Juan  Jose": 4}})
    ext = _ext(api)
    ext.priority_drivers = {"juan jose"}   # Nombre normalizado (el portal a veces trae dobles espacios)
    got = []
    ext.run_pass([DFW, DFW02], "2026-10-07", set(), on_record=got.append)
    assert _drivers(got)[:4] == ["Juan  Jose"] * 4 and len(got) == 12   # Después, el resto igual se revisa


def test_lista_manual_de_prioridad_por_nombre_o_id(tmp_path):
    from automation.drivers import manual_priority
    p = tmp_path / "d.json"
    p.write_text(json.dumps({"prioridad": ["Michelle  Cabrera", "399379", " "]}), encoding="utf-8")
    assert manual_priority(p) == {"michelle cabrera", "399379"}
    assert manual_priority(tmp_path / "no_existe.json") == set()


def test_lista_de_prioridad_incluye_a_los_peores_de_cada_ciudad(tmp_path):
    import sqlite3
    ckpt = CheckpointManager(db_path=tmp_path / "c.db")
    sid = ckpt.create_session("2026-10-06")
    marcas = []
    for driver, did, station, n in (("Ana", "1", "DFW02-BAA", 9), ("Beto", "2", "DFW02-BAA", 7),
                                    ("Caro", "3", "DFW-BAA", 5), ("Dani", "4", "DFW-BAA", 2)):
        for i in range(n):
            p = PODRecord(tracking_number=f"{driver}{i}", driver_name=driver, risk_score=90.0, priority="Alta",
                          station=station)
            p.portal_meta = {"driver_id": did}
            ckpt.save_pod_checkpoint(sid, p)
            marcas.append((f"{driver}{i}", "2026-10-06", "reportado"))
    with sqlite3.connect(tmp_path / "s.db") as c:
        c.execute("CREATE TABLE report_status (tracking_number TEXT PRIMARY KEY, query_date TEXT, status TEXT, updated_at TEXT)")
        c.executemany("INSERT INTO report_status VALUES (?, ?, ?, 'x')", marcas)
    top = ckpt.top_error_drivers(tmp_path / "s.db", "2026-09-30", min_errors=5, limit=1, per_station_min=1)
    # El peor en total (Ana) + el peor de DFW-BAA (Caro); Dani no llega al mínimo de errores
    assert [(d["driver_name"], d["errors"]) for d in top] == [("Ana", 9), ("Caro", 5)]


def test_muestreo_solo_a_los_sin_prioridad_y_nunca_los_lejanos(monkeypatch):
    monkeypatch.setattr(config, "MAX_PER_DRIVER_PER_PASS", 500)
    api = TwoCitiesAPI({DFW: {"Prio": 100, "Comun": 100}})
    lejos = {"Comun-7"}
    orig = api.iter_waybills

    def iter_con_distancia(sid, date, courier, page_size=50):
        for w in orig(sid, date, courier, page_size):
            w.sign_distance = "1500" if w.waybill_no in lejos else "20"
            yield w
    api.iter_waybills = iter_con_distancia
    ext = _ext(api)
    ext.priority_drivers, ext.sample_pct = {"prio"}, 30
    got = []
    ext.run_pass([DFW], "2026-10-07", set(), on_record=got.append)
    por = {d: _drivers(got).count(d) for d in ("Prio", "Comun")}
    assert por["Prio"] == 100 and 15 <= por["Comun"] <= 45        # ~30 % al azar
    assert "Comun-7" in {p.tracking_number for p in got}           # Lejos de la dirección: siempre entra
    # La misma muestra en otra pasada / tras un reinicio (nada nuevo para revisar)
    again = []
    ext.run_pass([DFW], "2026-10-07", {p.tracking_number for p in got}, on_record=again.append)
    assert again == []


def test_muestreo_vale_solo_el_dia_indicado(tmp_path):
    from automation.drivers import sampling_for
    p = tmp_path / "d.json"
    p.write_text(json.dumps({"muestreo": {"fecha": "2026-10-07", "porcentaje": 30}}), encoding="utf-8")
    assert sampling_for("2026-10-07", p) == 30 and sampling_for("2026-10-08", p) is None
    p.write_text(json.dumps({"muestreo": {"fecha": "2026-10-07", "porcentaje": 100}}), encoding="utf-8")
    assert sampling_for("2026-10-07", p) is None


def test_sin_relectura_girada_si_el_numero_no_se_leyo():
    # 08/10: con número no leído la relectura (~11-16 s por foto) no cambió ningún resultado en los 321 del 07/10
    from processing import pipeline
    from processing.ocr_address import PhotoOCR
    llamadas = []
    pipeline.confirm_doubtful_number([PhotoOCR(path="casa.jpg", text="")], "Plano 3033 Creekbend Dr",
                                     rereader=lambda p: llamadas.append(p) or [])
    assert llamadas == []
    # Con un número casi igual sí se relee (puede confirmar la puerta o la casa vecina)
    casi = PhotoOCR(path="puerta.jpg", text="3034", numbers=["3034"], number_conf={"3034": 0.9})
    pipeline.confirm_doubtful_number([casi], "Plano 3033 Creekbend Dr", rereader=lambda p: llamadas.append(p) or [])
    assert llamadas == ["puerta.jpg"]


def test_backlog_summary_sin_rutas():
    assert backlog_summary([]) == {"total": 0, "by_station": {}, "top": []}


def test_guarda_faltantes_con_ritmo_real_y_estimado(tmp_path):
    import main
    ckpt = CheckpointManager(db_path=tmp_path / "c.db")
    sid = ckpt.create_session("2026-10-07")
    for i in range(45):
        ckpt.save_pod_checkpoint(sid, PODRecord(tracking_number=f"GF{i}", risk_score=10.0))
    now = datetime.now()
    summary = {"total": 90, "by_station": {"DFW-BAA": 80, "DFW02-BAA": 10},
               "top": [{"driver": "Ana", "station": "DFW-BAA", "pending": 40}]}
    data = main.save_backlog(summary, ckpt, sid, "2026-10-07", path=tmp_path / "f.json", now=now)
    assert data["per_hour"] == 45 and data["eta_hours"] == 2.0
    assert json.loads((tmp_path / "f.json").read_text(encoding="utf-8"))["total"] == 90
    line = main.backlog_line(data)
    assert line.startswith("Faltan 90 (DFW-BAA 80, DFW02-BAA 10) · ~2.0 h a 45/h") and "Ana 40" in line


def test_sin_ritmo_suficiente_no_inventa_estimado(tmp_path):
    import main
    ckpt = CheckpointManager(db_path=tmp_path / "c.db")
    sid = ckpt.create_session("2026-10-07")
    data = main.save_backlog({"total": 5, "by_station": {"DFW-BAA": 5}, "top": []}, ckpt, sid, "2026-10-07",
                             path=tmp_path / "f.json")
    assert data["eta_hours"] is None and "h a" not in main.backlog_line(data)
    assert main.backlog_line(dict(data, total=0)).startswith("Al día")


def test_al_dia_corta_la_pasada_para_pedir_el_resumen_de_nuevo(monkeypatch):
    # 22/10 (pedido del usuario): al día con lo listado, cada AL_DIA_REFRESH_MIN se vuelve a pedir la lista completa en
    # vez de seguir relistando rutas al día con el resumen viejo (130 revisados y GOFO ya marcaba más de 200)
    monkeypatch.setattr(config, "MAX_PER_DRIVER_PER_PASS", 30)
    monkeypatch.setattr(config, "AL_DIA_REFRESH_MIN", 1e-9)
    api = TwoCitiesAPI({DFW: {"AlDia": 3, "Nueva": 2}})
    ext = _ext(api)
    ext.reviewed_counts = lambda: {f"{DFW}-AlDia": 3}
    got = []
    ext.run_pass([DFW], "2026-10-22", {f"AlDia-{i}" for i in range(3)}, on_record=got.append)
    assert _drivers(got) == ["Nueva", "Nueva"]      # Lo pendiente se termina igual
    assert api.listed == ["Nueva"]                  # Y en vez de relistar AlDia, se corta para pedir el resumen
