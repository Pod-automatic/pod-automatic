import pytest
import config

@pytest.fixture(autouse=True)
def isolated_receipts(monkeypatch,tmp_path):
    monkeypatch.setattr(config,'STORAGE_DIR',tmp_path)

from export.portal_sync import PortalError
from export.portal_wa import PortalWhatsAppWorker, process_job

JOB = {"id": 7, "date": "2026-10-05", "items": [{"tracking": "A", "main": 0}, {"tracking": "B", "main": 2},
                                                  {"tracking": "C", "main": 1}]}


def fake_prepare(groups):
    """prepare_whatsapp simulado: cada llamada manda el primer grupo y devuelve el resto."""
    calls = []

    def prepare(date, items):
        calls.append([dict(i) for i in items])
        group = groups.pop(0)
        done = [i["tracking"] for i in items if i["tracking"] in group]
        return {"ok": True, "message": f"Enviado a {'+'.join(group)}", "trackings": done,
                "remaining": [i for i in items if i["tracking"] not in done]}
    return prepare, calls


def test_manda_todos_los_grupos_con_la_foto_elegida():
    prepare, calls = fake_prepare([["A", "B"], ["C"]])
    res = process_job(JOB, prepare)
    assert res["ok"] and res["sent"] == ["A", "B", "C"]
    assert calls[0][1] == {"tracking": "B", "main": 2}          # la foto grande elegida en la web
    assert calls[1] == [{"tracking": "C", "main": 1}]


def test_error_de_whatsapp_avisa_lo_que_si_salio():
    def prepare(date, items):
        if items[0]["tracking"] == "A":
            return {"ok": True, "trackings": ["A"], "remaining": items[1:], "message": "ok"}
        raise RuntimeError("Quedó abierta una vista previa")
    res = process_job(JOB, prepare)
    assert not res["ok"] and res["sent"] == ["A"] and "vista previa" in res["message"]


def test_albaranes_que_no_estan_en_la_pc():
    def prepare(date, items):
        return {"ok": True, "trackings": ["A"], "remaining": [], "message": "ok"}
    res = process_job(JOB, prepare)
    assert not res["ok"] and res["sent"] == ["A"] and "B, C" in res["message"]


class FakeClient:
    def __init__(self, job):
        self.job, self.posted = job, []

    def call(self, path, body=None, query=None):
        if body is None:
            job, self.job = self.job, None
            return {"ok": True, "job": job}
        self.posted.append(body)
        return {"ok": True}


def test_worker_toma_el_envio_avisa_al_portal_y_marca_local():
    prepare, _ = fake_prepare([["A", "B", "C"]])
    marks = []
    client = FakeClient(JOB)
    w = PortalWhatsAppWorker(client, prepare, status_writer=lambda d, t, s: marks.append((d, t, s)))
    assert w.run_once()["ok"]
    assert client.posted[-1] == {"id": 7, "ok": True, "sent": ["A", "B", "C"], "message": "Enviado a A+B+C"}
    assert any(body.get("progress") and body["sent"]==["A","B","C"] for body in client.posted)
    assert marks == []  # Un recibo no vuelve a escribir decisiones humanas locales.
    assert w.run_once() is None                                 # cola vacía


def test_worker_sin_conexion_no_se_cae():
    class Down:
        def call(self, *a, **k):
            raise PortalError("sin conexión")
    w = PortalWhatsAppWorker(Down(), lambda d, i: {}, poll_s=0.01)
    import threading
    t = threading.Thread(target=w.loop)
    t.start()
    import time
    time.sleep(0.05)
    w.stop()
    t.join(1)
    assert not t.is_alive()


def test_worker_gpu_usa_portal_sin_archivos_locales_y_limpia_temporales(monkeypatch, tmp_path):
    import io
    from pathlib import Path
    from PIL import Image
    import config
    from export import report_server, whatsapp_sender
    raw = io.BytesIO()
    Image.new('RGB', (10, 10), 'blue').save(raw, format='JPEG')
    report = {'driver': 'Jose Paredes', 'station': 'DFW02-BAA', 'hub': True, 'place': 'otra direccion'}
    job = {'id': 8, 'date': '2026-10-27', 'items': [
        {'tracking': t, 'main': i, 'portal_evidence': True, 'report': report} for i, t in enumerate(('GPU1', 'GPU2'))]}
    class Client(FakeClient):
        downloads = []
        def download_wa_card(self, job_id, tracking):
            self.downloads.append((job_id, tracking))
            return raw.getvalue()
    def no_local(*args):
        raise AssertionError('GPU no debe consultar archivos locales')
    monkeypatch.setattr(report_server, 'load_payload', no_local)
    monkeypatch.setattr(report_server, 'render_card', no_local)
    monkeypatch.setattr(report_server, 'WHATSAPP_OUT', tmp_path)
    monkeypatch.setattr(config, 'WHATSAPP_GROUPS', {'DFW02-BAA': 'Prueba'})
    paths = []
    def send(group, items):
        assert group == 'Prueba' and len(items) == 1
        for path, caption in items:
            paths.append(path)
            assert path.read_bytes().startswith(b'\x89PNG')
            assert 'Lockers de Amazon' in caption and caption.endswith('Traking: GPU1\nGPU2')
        return {'ok': True, 'message': 'prueba'}
    monkeypatch.setattr(whatsapp_sender.SENDER, 'prepare', send)
    client = Client(job)
    result = PortalWhatsAppWorker(client, report_server.prepare_whatsapp).run_once()
    assert result['ok'] and result['sent'] == ['GPU1', 'GPU2']
    assert client.downloads == [(8, 'GPU1'), (8, 'GPU2')]
    assert paths and all(not path.exists() for path in paths)
    assert client.posted[-1]['sent'] == ['GPU1', 'GPU2']


def test_worker_gpu_evidencia_faltante_no_envia_ni_reporta():
    job = {'id': 8, 'date': '2026-10-27', 'items': [{'tracking':'GPU1', 'portal_evidence':True}]}
    class Client(FakeClient):
        def download_wa_card(self, *args):
            raise PortalError('Evidencia no disponible')
    client = Client(job)
    def no_send(*args):
        raise AssertionError('No debe enviar sin evidencia')
    result = PortalWhatsAppWorker(client, no_send).run_once()
    assert not result['ok'] and result['sent'] == []
    assert 'Evidencia no disponible' in result['message']
    assert client.posted[0]['sent'] == []


def test_final_receipt_http_failure_replays_receipt_without_resending(tmp_path):
    prepare,calls=fake_prepare([['A','B','C']])
    class Client(FakeClient):
        fail=True
        def call(self,path,body=None,query=None):
            if body and not body.get('progress') and self.fail:
                self.fail=False
                raise PortalError('HTTP después de enviar')
            return super().call(path,body,query)
    client=Client(JOB)
    worker=PortalWhatsAppWorker(client,prepare,receipt_path=tmp_path/'receipts.db')
    with pytest.raises(PortalError): worker.run_once()
    assert len(calls)==1 and len(worker.receipts.pending())==1
    # Otro objeto representa el reinicio de la PC; solo reenvía el recibo al portal.
    restarted=PortalWhatsAppWorker(client,prepare,receipt_path=tmp_path/'receipts.db')
    assert restarted.run_once() is None
    assert len(calls)==1 and restarted.receipts.pending()==[]


def test_process_job_preserves_confirmed_sends_on_uncertain_failure():
    prepare,_=fake_prepare([['A']])
    def attempt(day,items):
        if items[0]['tracking']=='A': return prepare(day,items)
        raise TimeoutError('sin confirmación')
    result=process_job(JOB,attempt)
    assert result['sent']==['A'] and result['uncertain']==['B','C']
