"""Reglas del 11/10: la ficha del lugar en Google Maps compartida entre unidades del mismo complejo no es error."""
from models.pod import DuplicateStatusEnum, PODRecord
from processing import scoring
from processing.map_screenshot import is_place_card
from processing.ocr_address import PhotoOCR
from processing.scoring import score_pod

FICHA = ("9:10 5G+ 30% Magnolia Grove A... Información Servicios Opiniones Fotos Ver todas las opiniones > Calificar y "
         "opinar Agregar fotos y videos De la empresa > Magnolia Grove Apartments Acerca de Editar 551 Crossroads Pkwy, "
         "Terrell, TX 75160 (844) 787-1392 magnoliagroveapartments.com Reservar Llamar")


def _pod(tmp_path, shared_text, own_number="5204"):
    shared = tmp_path / "ficha.jpg"
    shared.write_bytes(b"misma-captura")
    door = tmp_path / "locker.jpg"
    door.write_bytes(b"otra-foto")
    pod = PODRecord(tracking_number="T5204", receipt_address="Terrell Terrell 551 Crossroads Pkwy Apt 5204",
                    driver_name="X", station="DFW02-BAA")
    pod.photo_paths = [str(shared), str(door)]
    pod.duplicate_status = DuplicateStatusEnum.EXACT_DUPLICATE.value
    pod.duplicate_matched_tracking = "T7305"
    pod.duplicate_matched_photo = str(shared)
    pod.portal_meta["duplicate_same_building"] = True
    nums = [n for n in ("7305",) if n in shared_text]
    photos = [PhotoOCR(path=str(shared), text=shared_text, numbers=nums), PhotoOCR(path=str(door), numbers=[own_number] if own_number else [],
                                                                    number_conf={own_number: 95.0} if own_number else {})]
    return pod, photos


def _otra_unidad_confirmada(monkeypatch):
    # check_duplicates toma other_pod_summary como valor por defecto: se reemplaza la función entera
    real = scoring.check_duplicates
    fake = lambda t: {"address": "Terrell 551 CROSSROADS PKWY APT 7305", "number_status": "match"}
    monkeypatch.setattr(scoring, "check_duplicates", lambda pod, other_of=fake: real(pod, other_of=other_of))


def test_ficha_de_google_maps_se_reconoce():
    assert is_place_card(FICHA)
    assert not is_place_card("WELCOME 5204 Apt")


def test_ficha_compartida_con_otra_unidad_no_es_alta(tmp_path, monkeypatch):
    # Caso real 11/10 (GFUS01076934591873): la ficha de Magnolia Grove repetida con la unidad 7305
    _otra_unidad_confirmada(monkeypatch)
    pod, photos = _pod(tmp_path, FICHA)
    score_pod(pod, photos)
    dup = next(r for r in pod.check_results if r["check"] == "fotos_duplicadas")
    assert dup["score"] == 0 and "no muestra la puerta" in dup["explanation"]


def test_foto_de_puerta_compartida_con_otra_unidad_sigue_siendo_alta(tmp_path, monkeypatch):
    _otra_unidad_confirmada(monkeypatch)
    pod, photos = _pod(tmp_path, "7305", own_number=None)   # Solo se ve la puerta 7305
    score_pod(pod, photos)
    dup = next(r for r in pod.check_results if r["check"] == "fotos_duplicadas")
    assert dup["score"] == 100


def test_navegador_cerrado_se_reintenta():
    from storage.checkpoint_manager import is_connection_error
    assert is_connection_error("Page.evaluate: Target page, context or browser has been closed")
    assert not is_connection_error("Sin permiso para ver el albarán")


# ---------- Cierre 11/10: capturas de mapa y casilleros ----------
from processing.map_screenshot import is_map_screenshot, screenshot_address_status  # noqa: E402

STREET_VIEW = "10:35 5GE 64 enero de 2024 Aérea 2816 W Aspen Ct Q ga niiar omrtir Hace 5 meses- Ver más fechas"
MAPA = "10:10 1h 37 Buscar aquí f Casa Restaurantes Compras Cafete 2313 2321 2309 50 pies Garland 78° 60 AQI Explorar Tú Contribuir"
HISTORIAL = ("12:06 5G36 7 Historial POD Los comprobantes de entrega (POD) históricos son solo una guía. La entrega debe "
             "basarse en la dirección real. Maps 601 Rose HI Rd x Terrell,T")
GOFO_MAPA = ("Ridg 12:27 79 6350 Ridge Rd < POD 96 9005 9037 170 37 1 Agregar Pendiente Firmado Excepción paquete 7136 383 "
             "2 Mitchell Dr 382 7121 7066 mapbox")


def test_nuevas_pantallas_de_mapa_se_reconocen():
    for t in (STREET_VIEW, MAPA, HISTORIAL):
        assert is_map_screenshot(t), t[:40]


def test_street_view_y_historial_confirman_la_direccion():
    assert screenshot_address_status(STREET_VIEW, "2816", "W Aspen Ct")[0] == "match"
    assert screenshot_address_status(HISTORIAL, "601", "Rose Hill Rd")[0] == "match"


def test_categoria_de_google_maps_no_es_otra_direccion():
    t = "Oaklyn 11:45 5G66 Buscar aquí 769 Edificio multiusos Cómo llegar Iniciar Compartir"
    assert screenshot_address_status(t, "1003", "West St")[0] != "mismatch"


def test_mapa_de_la_app_gofo_con_la_calle_correcta_no_es_otra_direccion():
    assert screenshot_address_status(GOFO_MAPA, "7112", "MITCHELL DR")[0] == "unknown"
    assert screenshot_address_status(GOFO_MAPA, "500", "Elm St")[0] == "mismatch"


def test_captura_del_edificio_no_tapa_otra_unidad():
    # Caso real 11/10 (reportado): Street View de 951 Greenside Dr y la puerta dice 7223; el paquete era para la 7326
    pod = PODRecord(tracking_number="T", receipt_address="Richardson Richardson 951 Greenside Dr 7326", driver_name="X",
                    station="DFW-BAA")
    pod.photo_paths = ["a.jpg", "b.jpg", "c.jpg"]
    sv = "11:46 5G mayo de 2026 X Aérea 951 Greenside Dr Hace 5 meses- Ver más fechas"
    photos = [PhotoOCR(path="a.jpg"), PhotoOCR(path="b.jpg", text=sv),
              PhotoOCR(path="c.jpg", text="7223", numbers=["7223"], number_conf={"7223": 95.0})]
    score_pod(pod, photos)
    assert pod.priority in ("Alta", "Media")


def _locker_pod(address):
    pod = PODRecord(tracking_number="T", receipt_address=address, driver_name="X", station="DFW-BAA")
    pod.photo_paths = ["k.jpg", "b.jpg", "c.jpg"]
    return pod


def test_casillero_con_la_unidad_correcta_se_omite_aunque_muestre_la_oficina():
    # Caso real 11/10: "1116 Hidden Rdg Apt 2090"; el kiosco dice "1100 Hidden Ridge 2090" (oficina del complejo)
    pod = _locker_pod("Irving Irving 1116 Hidden Rdg Apt 2090")
    kiosk = PhotoOCR(path="k.jpg", text="Select Locker Size For Divine Djene 1100 Hidden Ridge 2090 X-SMALL DELIVER TO OFFICE",
                     numbers=["1100", "2090"], number_conf={"1100": 95.0, "2090": 95.0})
    score_pod(pod, [kiosk, PhotoOCR(path="b.jpg"), PhotoOCR(path="c.jpg")])
    assert pod.priority == "Baja"


def test_casillero_con_otra_unidad_no_se_omite():
    pod = _locker_pod("Irving Irving 1116 Hidden Rdg Apt 2090")
    kiosk = PhotoOCR(path="k.jpg", text="Select Locker Size For Otro Vecino 1100 Hidden Ridge 2094",
                     numbers=["1100", "2094"], number_conf={"1100": 95.0, "2094": 95.0})
    score_pod(pod, [kiosk, PhotoOCR(path="b.jpg"), PhotoOCR(path="c.jpg")])
    assert pod.priority in ("Alta", "Media")


def test_calle_con_solo_palabras_genericas():
    # Caso real 11/10: la captura dice "1003 West St" y se esperaba 1003 West St
    assert screenshot_address_status("11:45 Buscar aquí 1003 West St McKinney Cómo llegar", "1003", "West St")[0] == "match"


def test_cartel_del_complejo_compartido_con_otra_unidad_no_es_alta(tmp_path, monkeypatch):
    # Caso real 11/10 (1212 Hidden Rdg apt 1042): el cartel "RANCHO MIRAGE APARTMENT HOMES" repetido con la unidad 3102
    _otra_unidad_confirmada(monkeypatch)
    pod, photos = _pod(tmp_path, "200- RANCHO mirage APARTMENT HOMES", own_number=None)
    score_pod(pod, photos)
    dup = next(r for r in pod.check_results if r["check"] == "fotos_duplicadas")
    assert dup["score"] == 0


def test_foto_compartida_sin_el_numero_de_la_otra_unidad_es_media(tmp_path, monkeypatch):
    _otra_unidad_confirmada(monkeypatch)
    pod, photos = _pod(tmp_path, "", own_number=None)
    score_pod(pod, photos)
    dup = next(r for r in pod.check_results if r["check"] == "fotos_duplicadas")
    assert dup["score"] == 50


def test_etiqueta_de_otro_paquete_misma_direccion_otro_repartidor_ya_no_es_error():
    # 11/10 (reportados): la etiqueta es de otro paquete para el MISMO apartamento, entregado por otro repartidor.
    # 25/10 (pedido del usuario): esa etiqueta ya no cuenta como error (siempre es la dirección correcta)
    from processing.scoring import check_label_photos
    pod = PODRecord(tracking_number="T1", receipt_address="Grand Prairie 2425 BARDIN RD APT 6128", driver_name="Ana",
                    station="DFW-BAA")
    lbl = [PhotoOCR(path="l.jpg", is_label=True, label_tracking="T2")]
    same_addr = lambda t: "Grand Prairie 2425 BARDIN RD APT 6128"
    assert check_label_photos(pod, lbl, address_of=same_addr, driver_of=lambda t: "Dhanna Jaimes").score == 0
    # 12/10: mismo repartidor pero solo se ve la etiqueta del otro paquete -> Media (50)
    assert check_label_photos(pod, lbl, address_of=same_addr, driver_of=lambda t: " ana ").score == 50
    assert check_label_photos(pod, lbl, address_of=same_addr, driver_of=lambda t: None).score == 50
