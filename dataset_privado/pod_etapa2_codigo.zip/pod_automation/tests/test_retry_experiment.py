from copy import deepcopy
import io
import json
import unittest
from unittest.mock import patch

from PIL import Image

from processing.ocr_address import PhotoOCR
from processing.retry_experiment import retry_photos, read_local
from processing.vision_llm import VisionResult


class RetryExperimentTests(unittest.TestCase):
    def test_local_request_and_complete_json_response(self):
        def respond(request, timeout):
            body = json.loads(request.data)
            self.assertIsInstance(body['keep_alive'], int)
            self.assertNotIn('2905', body['prompt'])
            return io.BytesIO(json.dumps({'done': True, 'response': json.dumps(
                {'numbers': ['2905'], 'photo_type': 'door'})}).encode())
        with patch('processing.retry_experiment.urllib.request.urlopen', side_effect=respond):
            result = read_local('unused.jpg', 1, image=Image.new('RGB', (10, 10)))
        self.assertEqual(result.error, '')
        self.assertEqual(result.numbers, ['2905'])

    def test_truncated_response_does_not_count_as_success(self):
        response = io.BytesIO(json.dumps({'done': True, 'done_reason': 'length',
            'response': '{"numbers": [], "photo_type": "door"}'}).encode())
        with patch('processing.retry_experiment.urllib.request.urlopen', return_value=response):
            result = read_local('unused.jpg', 1, image=Image.new('RGB', (10, 10)))
        self.assertTrue(result.error)

    def test_label_never_queried(self):
        photos = [PhotoOCR('label.jpg', is_label=True)]
        def reader(*args, **kwargs):
            self.fail('No debe consultar la etiqueta')
        result, stats = retry_photos(photos, reader=reader)
        self.assertEqual(result, photos)

    def test_failed_read_preserves_error_and_numbers(self):
        photo = PhotoOCR('door.jpg', numbers=['2903'], vision_error='timeout')
        before = deepcopy(photo)
        result, _ = retry_photos([photo], reader=lambda *a, **k: VisionResult('door.jpg', error='timeout nuevo'))
        self.assertEqual(result[0], before)
        self.assertEqual(photo, before)

    def test_crop_cannot_confirm_number_alone(self):
        def reader(path, timeout, image=None):
            return VisionResult(path, numbers=['2905'] if image else [], photo_type='door')
        result, _ = retry_photos([PhotoOCR('door.jpg')], reader=reader, cropper=lambda *a, **k: object())
        self.assertEqual(result[0].numbers, [])

    def test_corroboration_preserves_prior_contradiction(self):
        photo = PhotoOCR('door.jpg', numbers=['2903'], vision_error='timeout')
        result, _ = retry_photos([photo], reader=lambda *a, **k: VisionResult('door.jpg', numbers=['2905'], photo_type='door'),
                                 cropper=lambda *a, **k: object())
        self.assertEqual(result[0].numbers, ['2903', '2905'])
        self.assertEqual(photo.numbers, ['2903'])
        self.assertEqual(result[0].vision_error, '')

    def test_reclassification_does_not_clear_failure(self):
        photo = PhotoOCR('door.jpg', vision_error='timeout')
        result, _ = retry_photos([photo], reader=lambda *a, **k: VisionResult('door.jpg', photo_type='label'))
        self.assertEqual(result[0].vision_error, 'timeout')
        self.assertFalse(result[0].is_label)

    def test_exhausted_budget_does_not_query(self):
        def reader(*args, **kwargs):
            self.fail('Presupuesto agotado')
        _, stats = retry_photos([PhotoOCR('door.jpg')], budget=0, reader=reader)
        self.assertEqual(stats['eventos'], [])
