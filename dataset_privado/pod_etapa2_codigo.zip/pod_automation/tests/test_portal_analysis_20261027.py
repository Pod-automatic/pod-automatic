import json
from datetime import date

import config
from export.portal_sync import Outbox, PortalError, PortalSync, analysis_item
from tests.test_portal_sync import FakeClient, make_pod


def build(tmp_path):
    client = FakeClient()
    sync = PortalSync(client, Outbox(tmp_path / 'outbox.db'), card_maker=lambda p, i: b'card',
                      status_writer=lambda *args: None)
    return sync, client


def test_baja_se_registra_sin_crear_caso_y_no_se_duplica(tmp_path, monkeypatch):
    monkeypatch.setattr(config, 'PORTAL_GPU', False)
    sync, client = build(tmp_path)
    day = date.today().isoformat()
    pod = make_pod(priority='Baja', score=5)
    sync.enqueue_pod(pod, day)
    sync.enqueue_pod(pod, day)
    assert sync.outbox.analysis_snapshots()[0]['analyzed'] == 1
    assert sync.outbox.analysis_snapshots()[0]['pending'] == 1
    assert sync.push_analyses() == 1
    assert client.pods == {}
    assert len(client.analyses) == 1
    assert next(iter(client.analyses.values()))['processed_at'] is not None
    assert sync.outbox.analysis_snapshots()[0]['pending'] == 0


def test_fallo_del_historial_no_bloquea_envio_de_errores(tmp_path, monkeypatch):
    monkeypatch.setattr(config, 'PORTAL_GPU', False)
    sync, client = build(tmp_path)
    call = client.call
    def fail(path, body=None, query=None):
        if path == 'analysis.php':
            raise PortalError('HTTP 404: portal antiguo')
        return call(path, body, query)
    client.call = fail
    sync.enqueue_pod(make_pod(), '2026-10-27')
    sync.sync_once(pull=False)
    assert len(client.pods) == 1
    assert sync.outbox.counts()['analysis'] == 1
    assert sync.outbox.due('analysis', 10) == []  # reintento con espera


def test_solo_borra_confirmados_y_conserva_rechazados(tmp_path, monkeypatch):
    monkeypatch.setattr(config, 'PORTAL_GPU', False)
    sync, client = build(tmp_path)
    for n in range(3):
        sync.enqueue_pod(make_pod(f'GFUS000000000000{n}', 'Baja', 5), '2026-10-27')
    client.call = lambda *args, **kwargs: {'accepted': [0, 999, '1'], 'errors': [{'index': 1, 'error': 'fallo'}]}
    assert sync.push_analyses() == 1
    assert sync.outbox.counts()['analysis'] == 2


def test_origen_y_modelo_del_historial_no_cambian_al_reenviar(tmp_path, monkeypatch):
    monkeypatch.setattr(config, 'PORTAL_GPU', True)
    monkeypatch.setattr(config, 'VISION_MODEL', 'modelo-kaggle')
    sync, client = build(tmp_path)
    sync.enqueue_pod(make_pod(priority='Baja', score=5), '2026-10-27')
    monkeypatch.setattr(config, 'PORTAL_GPU', False)
    monkeypatch.setattr(config, 'VISION_MODEL', 'modelo-pc')
    sync.push_analyses()
    got = next(iter(client.analyses.values()))
    assert (got['worker'], got['model']) == ('gpu', 'modelo-kaggle')


def test_recuperacion_no_pisa_version_mas_nueva(tmp_path, monkeypatch):
    monkeypatch.setattr(config, 'PORTAL_GPU', False)
    box = Outbox(tmp_path / 'outbox.db')
    newest = analysis_item(make_pod().to_dict(), '2026-10-27', 1793100000)
    box.record_analysis(newest)
    old = {**newest, 'priority': 'Baja', 'processed_at': None}
    box.record_analysis(old)
    assert box.due('analysis', 1)[0]['body']['priority'] == 'Alta'


def test_reenvio_de_fotos_historicas_no_inventa_hora_de_analisis(tmp_path, monkeypatch):
    monkeypatch.setattr(config, 'PORTAL_GPU', False)
    sync, client = build(tmp_path)
    sync.enqueue_pod(make_pod(), '2026-10-25', analyzed_now=False)
    sync.sync_once(pull=False)
    assert len(client.pods) == 1 and client.analyses == {}


def test_fotos_encoladas_conservan_modelo_y_origen(tmp_path, monkeypatch):
    monkeypatch.setattr(config, 'PORTAL_GPU', True)
    monkeypatch.setattr(config, 'VISION_MODEL', 'kaggle-modelo-original')
    sync, client = build(tmp_path)
    sync.enqueue_pod(make_pod(), '2026-10-27')
    monkeypatch.setattr(config, 'PORTAL_GPU', False)
    monkeypatch.setattr(config, 'VISION_MODEL', 'pc-modelo-nuevo')
    sent = []
    def capture(path, body=None, query=None):
        sent.append((path, body))
        return {'saved': len(body['items']), 'errors': []}
    client.call = capture
    assert sync.push_pods() == 1
    assert sent[0][0] == 'ingest_gpu.php'
    assert sent[0][1]['items'][0]['model'] == 'kaggle-modelo-original'


def test_recuperacion_usa_fecha_sesion_y_no_inventa_hora(tmp_path, monkeypatch):
    import sqlite3
    from tools.portal_recuperar_analisis import recover
    db = tmp_path / 'checkpoints.db'
    monkeypatch.setattr(config, 'CHECKPOINT_DB_PATH', db)
    monkeypatch.setattr(config, 'PORTAL_GPU', False)
    with sqlite3.connect(db) as c:
        c.executescript('CREATE TABLE audit_sessions(session_id TEXT,query_date TEXT,started_at TEXT);'
                       'CREATE TABLE pod_checkpoints(session_id TEXT,payload_json TEXT,risk_score REAL,created_at TEXT);')
        c.execute('INSERT INTO audit_sessions VALUES (?,?,?)', ('a', '2026-10-27', '2026-10-27 01:00:00'))
        for priority in ['Alta', 'Baja']:
            c.execute('INSERT INTO pod_checkpoints VALUES (?,?,?,?)',
                      ('a', json.dumps(make_pod(priority=priority).to_dict()), 5, '2026-10-27 02:00:00' if priority == 'Alta' else '2026-10-27 03:00:00'))
    got = recover('2026-10-27')
    assert len(got) == 1
    item = next(iter(got.values()))
    assert item['priority'] == 'Baja' and item['processed_at'] is None
    assert item['model'] == 'historico-desconocido'
