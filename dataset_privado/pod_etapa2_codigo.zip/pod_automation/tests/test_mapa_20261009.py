"""09/10: botón "Ver en mapa" en la página local para confirmar un Alta con el GPS del POD."""

from export.report_server import map_links, maps_address


def test_direccion_sin_ciudad_repetida_ni_unidad():
    assert maps_address("Kennedale Kennedale 3100 Joplin Rd Apt 1102 5203") == "3100 Joplin Rd, Kennedale, TX"
    assert maps_address("NORTH RICHLAND HILLS NORTH RICHLAND HILLS 6701 Tabor St") == "6701 Tabor St, North Richland Hills, TX"
    assert maps_address("Plano Plano 4701 14th St,19205") == "4701 14th St, Plano, TX"
    assert maps_address("MCKINNEY MCKINNEY 409 S Church St Apartamento 114") == "409 S Church St, Mckinney, TX"
    assert maps_address("Irving Irving 4019 W Northgate Dr APT 203") == "4019 W Northgate Dr, Irving, TX"


def test_con_gps_ruta_desde_la_foto_y_street_view():
    links = map_links("Kennedale Kennedale 3100 Joplin Rd Apt 1102 5203",
                      {"pod_lat": "32.64466265761235", "pod_lng": "-97.19066239929874", "sign_distance": "60.76"})
    assert links["map"].startswith("https://www.google.com/maps/dir/?api=1&origin=32.644663,-97.190662&destination=3100%20Joplin")
    assert "viewpoint=32.644663,-97.190662" in links["street"]
    assert links["distance"] == 61


def test_sin_gps_solo_la_direccion():
    links = map_links("Garland Garland 1405 mccallum dr", {})
    assert links["map"] == "https://www.google.com/maps/search/?api=1&query=1405%20mccallum%20dr%2C%20Garland%2C%20TX"
    assert links["street"] is None and links["distance"] is None
