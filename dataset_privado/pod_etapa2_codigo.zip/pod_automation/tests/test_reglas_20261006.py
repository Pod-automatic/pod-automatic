"""Reglas nuevas del 06/10 (casos reales del 05/10)."""
from models.pod import DuplicateStatusEnum, PODRecord
from processing import scoring
from processing.ocr_address import PhotoOCR
from processing.scoring import check_duplicates, score_pod


def _pod(tracking, address, dup_with=None, same_building=False, exact=True):
    pod = PODRecord(tracking_number=tracking, receipt_address=address, driver_name="X", station="DFW-BAA")
    pod.photo_paths = ["a.jpg", "b.jpg", "c.jpg"]
    if dup_with:
        pod.duplicate_status = (DuplicateStatusEnum.EXACT_DUPLICATE.value if exact
                                else DuplicateStatusEnum.POSSIBLE_VISUAL_DUPLICATE.value)
        pod.duplicate_matched_tracking = dup_with
        pod.portal_meta["duplicate_same_building"] = same_building
    return pod


def test_foto_compartida_con_otra_unidad_que_confirmo_su_puerta_es_alta():
    pod = _pod("T38", "4500 W Northgate Dr Apt 38 Irving TX", dup_with="T40", same_building=True)
    r = check_duplicates(pod, other_of=lambda t: {"address": "4500 W NORTHGATE DR appartement 40", "number_status": "match"})
    assert r.score == 100 and "unidad 38" in r.explanation


def test_foto_compartida_con_otra_unidad_sin_confirmar_es_media():
    pod = _pod("T38", "4500 W Northgate Dr Apt 38", dup_with="T40", same_building=True)
    r = check_duplicates(pod, other_of=lambda t: {"address": "4500 W Northgate Dr Apt 40", "number_status": "partial"})
    assert r.score == 50


def test_foto_compartida_misma_unidad_sigue_siendo_normal():
    pod = _pod("T1", "400 Settlers Bnd", dup_with="T2", same_building=True)
    r = check_duplicates(pod, other_of=lambda t: {"address": "400 Settlers Bnd", "number_status": "match"})
    assert r.score == 0


def test_numero_confirmado_anula_foto_repetida_de_otra_direccion(monkeypatch):
    pod = _pod("T3947", "3947 N O Connor Rd Irving TX", dup_with="T3733")
    monkeypatch.setattr(scoring, "other_pod_summary", lambda t: None)
    photos = [PhotoOCR(path="a.jpg", text="3947", numbers=["3947"]), PhotoOCR(path="b.jpg", text=""),
              PhotoOCR(path="c.jpg", text="")]
    score_pod(pod, photos)
    dup = next(r for r in pod.check_results if r["check"] == "fotos_duplicadas")
    assert dup["score"] == 0 and pod.priority == "Baja"


def test_sin_numero_confirmado_la_foto_repetida_de_otra_direccion_sigue_siendo_alta(monkeypatch):
    pod = _pod("T5", "5 Main St", dup_with="T9")
    monkeypatch.setattr(scoring, "other_pod_summary", lambda t: None)
    photos = [PhotoOCR(path="a.jpg", text=""), PhotoOCR(path="b.jpg", text=""), PhotoOCR(path="c.jpg", text="")]
    score_pod(pod, photos)
    assert pod.priority == "Alta"


def test_etiqueta_de_otro_paquete_misma_direccion_aun_no_procesado():
    from processing.scoring import check_label_photos
    pod = _pod("GFUS01076079752451", "Grapevine Grapevine 2400 Timberline Dr Apt 106 Apartamento 106")
    label = PhotoOCR(path="c.jpg", text="GOFO SHIP TO Hector 2400 Timberline Dr Apt 106 Grapevine TX 76051 GFUS01076011665027",
                     is_label=True, label_tracking="GFUS01076011665027")
    r = check_label_photos(pod, [PhotoOCR(path="a.jpg", text="106"), label], number_seen=True, address_of=lambda t: None)
    # 12/10: solo se ve la etiqueta del otro paquete (no la de este) -> Media para revisar
    assert r.score == 50 and r.details.get("misma_direccion") == ["GFUS01076011665027"]


def test_etiqueta_de_otro_paquete_otra_direccion_ya_no_es_error():
    # 25/10 (pedido del usuario): siempre son de la dirección correcta (varios paquetes en la misma dirección)
    from processing.scoring import check_label_photos
    pod = _pod("T1", "2400 Timberline Dr Apt 106")
    label = PhotoOCR(path="c.jpg", text="GOFO SHIP TO 2400 Timberline Dr Apt 108 GFUS01076099999999",
                     is_label=True, label_tracking="GFUS01076099999999")
    r = check_label_photos(pod, [label], number_seen=True, address_of=lambda t: None)
    assert r.score == 0


def test_tienda_de_buzones_local_buzon():
    pod = _pod("T1", "COLLEYVILLE COLLEYVILLE 4843 Colleyville Blvd 251-126")
    photos = [PhotoOCR(path="a.jpg", text="THE UPS STORE Open 251", numbers=["251"]), PhotoOCR(path="b.jpg", text=""),
              PhotoOCR(path="c.jpg", text="")]
    score_pod(pod, photos)
    assert pod.priority == "Baja"


def test_local_buzon_con_otro_numero_sigue_siendo_problema():
    pod = _pod("T1", "COLLEYVILLE COLLEYVILLE 4843 Colleyville Blvd 251-126")
    photos = [PhotoOCR(path="a.jpg", text="4810", numbers=["4810"]), PhotoOCR(path="b.jpg", text=""),
              PhotoOCR(path="c.jpg", text="")]
    score_pod(pod, photos)
    assert pod.priority in ("Alta", "Media")


def test_recepcion_de_hotel_no_exige_numero():
    pod = _pod("T1", "Grapevine Grapevine 1750 N Highway 121 Hampton Inn And Suites Dfw N")
    photos = [PhotoOCR(path="a.jpg", text=""), PhotoOCR(path="b.jpg", text=""), PhotoOCR(path="c.jpg", text="")]
    score_pod(pod, photos)
    assert pod.priority == "Baja"


def test_casillero_parcel_pending_por_quadient():
    pod = _pod("T1", "Irving Irving 357 Las Colinas Blvd E Apt 125")
    photos = [PhotoOCR(path="a.jpg", text="////PARCEL by Quadient 1239 CAMRY"), PhotoOCR(path="b.jpg", text=""),
              PhotoOCR(path="c.jpg", text="")]
    score_pod(pod, photos)
    assert pod.priority == "Baja"


def test_sala_special_deliveries():
    pod = _pod("T1", "North Richland Hills 6253 Iron Horse Blvd Unit 3307")
    photos = [PhotoOCR(path="a.jpg", text="SPECIAL DELIVERIES"), PhotoOCR(path="b.jpg", text="6309", numbers=["6309"]),
              PhotoOCR(path="c.jpg", text="")]
    score_pod(pod, photos)
    num = next(r for r in pod.check_results if r["check"] == "numero_direccion")
    assert not num["applicable"]


def test_sala_special_deliveries_con_numero_confirmado_por_vision(monkeypatch):
    """Como en el caso real: el modelo de visión confirmó el 6309 (edificio de la sala)."""
    pod = _pod("T1", "North Richland Hills 6253 Iron Horse Blvd Unit 3307")
    photos = [PhotoOCR(path="a.jpg", text="SPECIAL DELIVERIES"),
              PhotoOCR(path="b.jpg", text="6309", numbers=["6309"], vision_used=True, vision_all=["6309"]),
              PhotoOCR(path="c.jpg", text="")]
    score_pod(pod, photos)
    assert pod.priority == "Baja", pod.check_results


def test_sala_de_correo_no_tapa_un_numero_lejano():
    pod = _pod("T1", "6253 Iron Horse Blvd Unit 3307")
    photos = [PhotoOCR(path="a.jpg", text="MAIL ROOM"),
              PhotoOCR(path="b.jpg", text="8120", numbers=["8120"], vision_used=True, vision_all=["8120"]),
              PhotoOCR(path="c.jpg", text="")]
    score_pod(pod, photos)
    assert pod.priority in ("Alta", "Media")


def test_cartel_con_rango_que_incluye_la_casa():
    pod = _pod("T1", "PLANO PLANO 89 Beechwood Pl")
    photos = [PhotoOCR(path="a.jpg", text=""), PhotoOCR(path="b.jpg", text="18 87-94", numbers=["18", "87-94"]),
              PhotoOCR(path="c.jpg", text="")]
    score_pod(pod, photos)
    assert pod.priority == "Baja", pod.check_results


def test_cartel_con_rango_que_no_incluye_la_casa():
    pod = _pod("T1", "PLANO PLANO 99 Beechwood Pl")
    photos = [PhotoOCR(path="a.jpg", text=""), PhotoOCR(path="b.jpg", text="18 87-94", numbers=["18", "87-94"]),
              PhotoOCR(path="c.jpg", text="")]
    score_pod(pod, photos)
    assert pod.priority in ("Alta", "Media")


def test_captura_de_apple_maps_con_el_pin():
    pod = _pod("T1", "ALLEN ALLEN 6741 County Road 889")
    photos = [PhotoOCR(path="a.jpg", text=""),
              PhotoOCR(path="b.jpg", text="10:50 5G 68 ICA 40 COUNTY ROAD 391 COUNTY ROAD 890 6741 County Road 889 N 3D 887",
                       numbers=["391", "890", "6741", "889", "887"]),
              PhotoOCR(path="c.jpg", text="")]
    score_pod(pod, photos)
    assert pod.priority == "Baja", pod.check_results


def test_unidad_con_letra_edificio_y_placa_de_la_puerta():
    pod = _pod("T1", "NORTH RICHLAND HILLS 6484 Iron Horse Blvd 17B")
    photos = [PhotoOCR(path="a.jpg", text=""), PhotoOCR(path="b.jpg", text="B", photo_type="door"),
              PhotoOCR(path="c.jpg", text="6484 AI 17E 17A", numbers=["6484", "17E", "17A", "17"], photo_type="building")]
    score_pod(pod, photos)
    assert pod.priority == "Baja", pod.check_results


def test_pantalla_luxer_con_la_direccion_completa():
    pod = _pod("T1", "Irving Irving 1537 Meridian Dr. 2204")
    photos = [PhotoOCR(path="a.jpg", text="APARTMENTS & FURNISHED SUITES 1501", numbers=["1501"]),
              PhotoOCR(path="b.jpg", text="< Back Select Recipient Match 1 Result Dairius Benton 1537 Meridian Drive 2204",
                       numbers=["1", "1537", "2204"]),
              PhotoOCR(path="c.jpg", text="", numbers=["7778"], vision_used=True, vision_all=["7778"], photo_type="building")]
    score_pod(pod, photos)
    assert pod.priority == "Baja", pod.check_results


def test_chat_de_gofo_con_confirmacion_del_cliente():
    pod = _pod("T1", "RICHARDSON RICHARDSON 807 Cavalier Plz")
    chat = ("9:01 < GFUS01075184061696 Actualizar El número de mensajes enviados está limitado Hi, this is your driver "
            "from GOFO Express. Please provide the correct address. 08:58:5510/05/2026 793? 08:59:00 10/05/2026 Si "
            "09:01:1110/05/2026 Por favor ingrese")
    photos = [PhotoOCR(path="a.jpg", text="793", numbers=["793"]), PhotoOCR(path="b.jpg", text=chat, is_label=True),
              PhotoOCR(path="c.jpg", text="793", numbers=["793"])]
    score_pod(pod, photos)
    assert pod.priority == "Baja", pod.check_results


def test_chat_sin_confirmacion_no_cuenta():
    pod = _pod("T1", "RICHARDSON RICHARDSON 807 Cavalier Plz")
    chat = "9:01 Actualizar mensajes enviados 08:58:55 10/05/2026 793? 08:59:00 10/05/2026 No, es el 807 09:01:11 10/05/2026"
    photos = [PhotoOCR(path="a.jpg", text="793", numbers=["793"]), PhotoOCR(path="b.jpg", text=chat, is_label=True),
              PhotoOCR(path="c.jpg", text="")]
    score_pod(pod, photos)
    assert pod.priority in ("Alta", "Media")


def test_foto_tomada_por_etiqueta_solo_por_vision_se_relee_si_no_tiene_texto_de_etiqueta(monkeypatch):
    from processing import pipeline
    from processing.ocr_address import match_numbers, parse_us_address
    curb = PhotoOCR(path="cordon.jpg", text="", is_label=True)
    curb.vision_label = True
    photos = [PhotoOCR(path="casa.jpg", text=""), curb]
    monkeypatch.setattr(pipeline, "label_text_free", lambda path: True)
    pipeline.confirm_doubtful_number(photos, "Bedford 2704 Meadow Creek", rereader=lambda p: [("2704", 90.0)] if p == "cordon.jpg" else [])
    assert match_numbers(parse_us_address("Bedford 2704 Meadow Creek"), photos).status == "match"


def test_etiqueta_de_verdad_no_confirma_su_propia_direccion(monkeypatch):
    from processing import pipeline
    from processing.ocr_address import match_numbers, parse_us_address
    lbl = PhotoOCR(path="etiqueta.jpg", text="", is_label=True)
    lbl.vision_label = True
    photos = [PhotoOCR(path="casa.jpg", text=""), lbl]
    monkeypatch.setattr(pipeline, "label_text_free", lambda path: False)   # la lectura ampliada muestra "SHIP TO … GOFO"
    pipeline.confirm_doubtful_number(photos, "Bedford 2704 Meadow Creek",
                                     rereader=lambda p: [("2704", 90.0)] if p == "etiqueta.jpg" else [])
    assert match_numbers(parse_us_address("Bedford 2704 Meadow Creek"), photos).status != "match"


def test_media_baja_queda_en_media_pero_debajo_de_numero_no_leido():
    # 06/10: las lecturas dudosas siguen en Media (no se pierden) pero van después de "número no leído"
    import config
    from processing.scoring import combine_scores, priority_for, CheckResult
    weak = combine_scores([CheckResult("numero_direccion", config.WEAK_NUMBER_SCORE, 3.0, "x")])
    unread = combine_scores([CheckResult("numero_direccion", config.FAR_NUMBERS_SCORE, 3.0, "x")])
    assert priority_for(weak).value == "Media" and weak < unread


def _poste_6644():
    # Caso 05/10: el OCR lee "664" en el poste (el último 4 es más chico)
    return [PhotoOCR(path="poste.jpg", text="664", numbers=["664"]), PhotoOCR(path="casa.jpg", text="")]


def test_franja_vertical_confirma_numero_apilado(monkeypatch):
    from processing import pipeline
    from processing.ocr_address import match_numbers, parse_us_address
    monkeypatch.setattr(pipeline, "label_text_free", lambda path: True)
    photos = _poste_6644()
    pipeline.confirm_doubtful_number(photos, "WATAUGA 6644 INWOOD DR", rereader=lambda p: [],
                                     strip_reader=lambda p: ["6644"] if p == "poste.jpg" else [])
    assert match_numbers(parse_us_address("WATAUGA 6644 INWOOD DR"), photos).status == "match"


def test_franja_vertical_con_otro_numero_no_confirma(monkeypatch):
    # El modelo no conoce el número esperado: si lee otro (casa vecina), no confirma nada
    from processing import pipeline
    from processing.ocr_address import match_numbers, parse_us_address
    monkeypatch.setattr(pipeline, "label_text_free", lambda path: True)
    photos = _poste_6644()
    pipeline.confirm_doubtful_number(photos, "WATAUGA 6644 INWOOD DR", rereader=lambda p: [],
                                     strip_reader=lambda p: ["6646"])
    assert match_numbers(parse_us_address("WATAUGA 6644 INWOOD DR"), photos).status != "match"


def test_franja_vertical_no_vale_en_una_etiqueta(monkeypatch):
    # Caso 06/10: las franjas de la etiqueta leían "6528 Windrock Dr" impreso
    from processing import pipeline
    from processing.ocr_address import match_numbers, parse_us_address
    monkeypatch.setattr(pipeline, "label_text_free", lambda path: False)
    photos = _poste_6644()
    pipeline.confirm_doubtful_number(photos, "WATAUGA 6644 INWOOD DR", rereader=lambda p: [],
                                     strip_reader=lambda p: ["6644"])
    assert match_numbers(parse_us_address("WATAUGA 6644 INWOOD DR"), photos).status != "match"


def test_franja_vertical_no_se_usa_si_el_numero_no_concuerda(monkeypatch):
    # Un número distinto leído con claridad (mismatch) no se "arregla" con la franja: sigue siendo error
    from processing import pipeline
    llamadas = []
    monkeypatch.setattr(pipeline, "label_text_free", lambda path: True)
    photos = [PhotoOCR(path="puerta.jpg", text="6646", numbers=["6646"], number_conf={"6646": 95.0})]
    pipeline.confirm_doubtful_number(photos, "WATAUGA 6644 INWOOD DR", rereader=lambda p: [],
                                     strip_reader=lambda p: llamadas.append(p) or ["6644"])
    assert llamadas == []


def test_foto_compartida_no_es_error_si_esta_puerta_concuerda():
    # Caso 06/10: 5302 Carnaby St Apt 207 con la foto del locker de Amazon de otro albarán (unidad 220)
    pod = _pod("T207", "5302 CARNABY ST APT 207 Irving TX", dup_with="T220", same_building=True)
    photos = [PhotoOCR(path="puerta.jpg", text="207", numbers=["207"], number_conf={"207": 95.0}),
              PhotoOCR(path="a.jpg", text=""), PhotoOCR(path="b.jpg", text="")]
    import processing.scoring as sc
    orig = sc.other_pod_summary
    sc.other_pod_summary = lambda t: {"address": "5334 Bond St Apt 220", "number_status": "match"}
    try:
        score_pod(pod, photos)
    finally:
        sc.other_pod_summary = orig
    dup = next(r for r in pod.check_results if r["check"] == "fotos_duplicadas")
    assert dup["score"] == 0 and pod.priority != "Alta"


def test_locker_de_otra_unidad_no_cuenta_como_puerta_confirmada(monkeypatch, tmp_path):
    import json, sqlite3, config
    db = tmp_path / "c.db"
    con = sqlite3.connect(db)
    con.execute("create table pod_checkpoints (tracking_number text, payload_json text, created_at text)")
    checks = [{"check": "numero_direccion", "applicable": False, "details": {"status": "match"}},
              {"check": "amazon_hub", "applicable": True}]
    con.execute("insert into pod_checkpoints values ('T220', ?, '2026-10-06')",
                (json.dumps({"address": "5334 Bond St Apt 220", "check_results": checks}),))
    con.commit(); con.close()
    monkeypatch.setattr(config, "CHECKPOINT_DB_PATH", db)
    assert scoring.other_pod_summary("T220")["number_status"] == "sala"


def test_locker_deposit_package_se_omite():
    # Caso 06/10: kiosco "Deposit Package" de 1156 Hidden Ridge (8 Alta falsos "1100 no concuerda con 1308")
    pod = _pod("TDP", "Irving Irving 1156 hidden ridge 1308")
    photos = [PhotoOCR(path="a.jpg", text="1100 OFFICE", numbers=["1100"], number_conf={"1100": 95.0}),
              PhotoOCR(path="b.jpg", text="Deposit Package Jorge Felix Velazquez 1100 Hidden Ridge 1308 Close Door and "
                                          "Press Package Deposited Button PACKAGE TOO LARGE WRONG CUSTOMER",
                       numbers=["1100", "1308"]),
              PhotoOCR(path="c.jpg", text="")]
    photos[0].vision_used, photos[0].vision_all = True, ["1100"]   # el modelo también lee 1100 (cartel de la oficina)
    score_pod(pod, photos)
    assert pod.priority == "Baja"


def test_pantalla_llegaste_a_es_captura_de_mapa():
    # Caso 06/10: a tamaño normal solo se leía "Llegaste a × 81 05" (2816 Wateridge Ct)
    from processing.map_screenshot import is_map_screenshot
    assert is_map_screenshot("3:47 LTE 20 GOFO Driver Silvercrest Ln Llegaste a × 81 05 eiar p in Coavg in?")
    assert not is_map_screenshot("Llegaste a casa")   # sin la hora del teléfono no alcanza


def test_foto_repetida_de_otra_direccion_en_sala_de_paquetes_no_suma():
    # Caso 06/10: sala de paquetes de N O'Connor Rd; Building 7 con la misma foto que el 4459 (otra dirección)
    pod = _pod("TB7", "Irving Irving 4395 N O Connor Rd Building 7", dup_with="T4459", same_building=False)
    photos = [PhotoOCR(path="a.jpg", text="PACKAGE ROOM"), PhotoOCR(path="b.jpg", text=""), PhotoOCR(path="c.jpg", text="")]
    score_pod(pod, photos)
    assert pod.priority == "Baja"


def test_codigo_de_producto_en_la_caja_no_es_numero_de_puerta():
    # Caso 06/10: "XU-1340-Create" impreso en la caja hizo "dos puertas distintas (1340 y 1935)"
    from processing.ocr_address import _numeric_tokens
    assert _numeric_tokens({"text": ["XU-1340-CreaiN"], "conf": [95]}, 50) == []
    assert _numeric_tokens({"text": ["7-205"], "conf": [95]}, 50) == ["7-205"]


def test_app_de_gofo_con_fm_pegado_y_parada_concuerda():
    # Caso 06/10: app de GOFO "8974 FM148, Terrell, Texas, 75160 ... 274 GFUS01075830767360" (Alta falso "274 GFUS")
    from processing.map_screenshot import screenshot_address_status
    text = ("10:05 132 Pendiente 37 Firmado 0 Excepción Agregar paquete Dirección incorrecta? 8974 FM148, Terrell, "
            "Texas, 75160 Control de acceso Granja 274 GFUS01075830767360 Tim Murphy Fallido Entregar")
    assert screenshot_address_status(text, "8974", "FM148")[0] == "match"
    assert screenshot_address_status("10:05 Pendiente Firmado 274 GFUS01075830767360", "8974", "FM148")[0] != "mismatch"


def test_vecina_no_se_confirma_si_algun_giro_lee_el_numero_correcto():
    # Caso 06/10: placa en relieve 4205 leída 4805 / 4205 / 4206 por el modelo
    from types import SimpleNamespace
    from processing.pipeline import _vision_repeats
    reads = iter([["4805"], ["4805"], ["4205"]])
    rr = lambda path, angle: SimpleNamespace(error="", numbers=next(reads))
    assert not _vision_repeats("placa.jpg", "4805", rr, expected=["4205"])
    reads2 = iter([["4805"], ["4805"], ["4805"]])
    rr2 = lambda path, angle: SimpleNamespace(error="", numbers=next(reads2))
    assert _vision_repeats("placa.jpg", "4805", rr2, expected=["4205"])


def test_unidad_5i_es_51():
    from processing.ocr_address import parse_us_address
    assert "51" in parse_us_address("BEDFORD BEDFORD 2413 meadow park circle #5i 5i").expected_numbers()["unit"]


def test_cartel_parcel_es_sala_de_paquetes():
    # Caso 06/10: 6520 Browning Dr Apt 5314; cartel "PARCEL 21" y el del complejo "CAVA AT IRON HORSE STATION 6490"
    pod = _pod("TPA", "NORTH RICHLAND HILLS 6520 Browning Dr Apt 5314")
    photos = [PhotoOCR(path="a.jpg", text=""), PhotoOCR(path="b.jpg", text="PARCEL 21", numbers=["21"]),
              PhotoOCR(path="c.jpg", text="CAVA AT IRON HORSESTATION 6490", numbers=["6490"], number_conf={"6490": 95.0})]
    photos[2].vision_used, photos[2].vision_all = True, ["6490"]
    score_pod(pod, photos)
    assert pod.priority == "Baja"
    # Una etiqueta de envío que dice "parcel" no es un cartel (texto largo)
    from processing.scoring import _is_parcel_sign
    assert not _is_parcel_sign("SHIP TO John Smith 123 Main St Dallas TX parcel 75001")


def test_sala_de_paquetes_por_la_escena_omite_el_albaran():
    # Caso 06/10: 3549 Medical Center Dr 3204, estantes con paquetes y cartel de papel "BUILDING 3"
    from processing.pipeline import detect_package_room
    pod = _pod("TES", "Mckinney Mckinney 3549 Medical Center Dr 3204")
    photos = [PhotoOCR(path="edificio.jpg", text=""), PhotoOCR(path="estantes.jpg", text="BUILDING 3", numbers=["3"]),
              PhotoOCR(path="c.jpg", text="")]
    score_pod(pod, photos)
    assert pod.priority in ("Alta", "Media")
    assert detect_package_room(pod, photos, asker=lambda path: path == "estantes.jpg")
    score_pod(pod, photos)
    assert pod.priority == "Baja"


def test_sala_por_la_escena_no_tapa_otra_puerta_en_otra_foto():
    from processing.pipeline import detect_package_room
    pod = _pod("TES2", "Mckinney Mckinney 3549 Medical Center Dr 3204")
    photos = [PhotoOCR(path="puerta.jpg", text="3208", numbers=["3208"], number_conf={"3208": 95.0}),
              PhotoOCR(path="estantes.jpg", text=""), PhotoOCR(path="c.jpg", text="")]
    photos[0].vision_used, photos[0].vision_all = True, ["3208"]
    score_pod(pod, photos)
    detect_package_room(pod, photos, asker=lambda path: path == "estantes.jpg")
    score_pod(pod, photos)
    assert pod.priority == "Alta"


def test_numero_escrito_en_una_caja_no_es_puerta():
    # Caso 05/10: "113" a mano en la caja (610 Nightshade Dr) hacía "dos puertas distintas (113 y 610)"
    from processing.pipeline import drop_numbers_on_packages
    pod = _pod("T610", "ARLINGTON ARLINGTON 610 Nightshade Dr")
    photos = [PhotoOCR(path="garaje.jpg", text="610", numbers=["610"], number_conf={"610": 99.0}),
              PhotoOCR(path="porche.jpg", text="113", numbers=["113"], number_conf={"113": 99.0}),
              PhotoOCR(path="c.jpg", text="")]
    drop_numbers_on_packages(photos, pod.expected_address, asker=lambda path, n: "package" if path == "porche.jpg" else "wall")
    score_pod(pod, photos)
    assert pod.priority == "Baja"


def test_numero_en_la_pared_que_no_concuerda_sigue_siendo_error():
    from processing.pipeline import drop_numbers_on_packages
    pod = _pod("T610b", "ARLINGTON ARLINGTON 610 Nightshade Dr")
    photos = [PhotoOCR(path="puerta.jpg", text="612", numbers=["612"], number_conf={"612": 99.0}),
              PhotoOCR(path="b.jpg", text=""), PhotoOCR(path="c.jpg", text="")]
    photos[0].vision_used, photos[0].vision_all = True, ["612"]
    drop_numbers_on_packages(photos, pod.expected_address, asker=lambda path, n: "wall")
    score_pod(pod, photos)
    assert pod.priority == "Alta"


def test_captura_ilegible_se_confirma_con_el_modelo_y_nunca_marca_otra(monkeypatch):
    from processing import vision_llm
    from processing import scoring as sc
    monkeypatch.setattr(sc, "reread_screenshot_text", lambda path: "")
    text = "9:57 1:38 66 SweetGumLn Spruce Ln O Sweet Gurm llete a X 31 67 05 ear Apie PGuardar el estacionamie ¿Cómo estuvo la navegación?"
    pod = _pod("T3317", "Grapevine Grapevine 3317 SWEET GUM LN")
    shot = [PhotoOCR(path="mapa.jpg", text=text)]
    monkeypatch.setattr(vision_llm, "screenshot_address", lambda path: "3317 Sweet Gum Ln, Grapevine, TX 76051")
    assert sc.check_map_screenshot(pod, shot).details["status"] == "match"
    monkeypatch.setattr(vision_llm, "screenshot_address", lambda path: "1234 Elm Street")   # invento del modelo
    assert sc.check_map_screenshot(pod, shot).details["status"] == "unknown"
