"""09/10: el GPS de la foto y la distancia viajan al portal (botones "Ver en mapa" / "Street View" del panel admin)."""

import json
import sqlite3

from export import portal_sync
from export.portal_sync import Outbox, pod_item, requeue_day
from export import report_server
from storage.checkpoint_manager import CheckpointManager


def _payload(priority="Alta", meta=None, tracking="GFUS0000000000001"):
    return {"tracking_number": tracking, "priority": priority, "driver_name": "Ana", "station": "DFW02-BAA",
            "receipt_address": "Kennedale Kennedale 3100 Joplin Rd Apt 1102 5203", "risk_score": 80.0,
            "portal_meta": meta if meta is not None else {}, "check_results": []}


def test_alta_lleva_gps_y_distancia_como_numeros():
    item = pod_item(_payload(meta={"pod_lat": "32.64466265761235", "pod_lng": "-97.19066239929874", "sign_distance": "60.76"}), "2026-10-09")
    assert item["pod_lat"] == 32.64466265761235
    assert item["pod_lng"] == -97.19066239929874
    assert item["sign_distance"] == 60.76


def test_media_tambien_y_sin_datos_va_como_none():
    assert pod_item(_payload("Media", {"pod_lat": 1.5, "pod_lng": 2.5, "sign_distance": 3}), "2026-10-09")["pod_lat"] == 1.5
    item = pod_item(_payload(meta={}), "2026-10-09")
    assert item["pod_lat"] is None and item["pod_lng"] is None and item["sign_distance"] is None


def test_valores_raros_se_mandan_como_none():
    item = pod_item(_payload(meta={"pod_lat": "abc", "pod_lng": "nan", "sign_distance": "inf"}), "2026-10-09")
    assert item["pod_lat"] is None and item["pod_lng"] is None and item["sign_distance"] is None
    assert json.dumps(item)   # sigue siendo JSON válido


def test_baja_no_lleva_gps():
    item = pod_item(_payload("Baja", {"pod_lat": 1, "pod_lng": 2, "sign_distance": 3}), "2026-10-09")
    assert "pod_lat" not in item and "pod_lng" not in item and "sign_distance" not in item


def _db_con_dia(tmp_path, monkeypatch):
    db = tmp_path / "pod.db"
    CheckpointManager(db)
    monkeypatch.setattr(report_server, "CHECKPOINT_DB", db)
    conn = sqlite3.connect(db)
    conn.execute("INSERT INTO audit_sessions VALUES ('s1', '2026-10-09', 'x', 'x', 'COMPLETED', 0, 0, NULL)")
    for trk, prio, score in (("GFUS0000000000001", "Alta", 80.0), ("GFUS0000000000002", "Media", 50.0),
                             ("GFUS0000000000003", "Baja", 5.0), ("GFUS0000000000004", "Alta", None)):
        p = _payload(prio, {"pod_lat": "32.6", "pod_lng": "-97.1", "sign_distance": "10"}, trk)
        p["risk_score"] = score
        conn.execute("INSERT INTO pod_checkpoints (session_id, tracking_number, query_date, driver_name, payload_json, created_at) "
                     "VALUES ('s1', ?, '2026-10-09', 'Ana', ?, 'x')", (trk, json.dumps(p)))
    conn.commit()
    conn.close()


def test_requeue_day_solo_cuenta_por_defecto(tmp_path, monkeypatch):
    _db_con_dia(tmp_path, monkeypatch)
    outbox = Outbox(tmp_path / "outbox.db")
    assert requeue_day("2026-10-09", outbox) == 2          # Alta y Media ya calificados; no la Baja ni la que sigue sin puntaje
    assert outbox.due("pod", 10) == []


def test_requeue_day_encola_alta_y_media_con_su_payload(tmp_path, monkeypatch):
    _db_con_dia(tmp_path, monkeypatch)
    outbox = Outbox(tmp_path / "outbox.db")
    assert requeue_day("2026-10-09", outbox, dry_run=False) == 2
    due = {r["tracking"]: r for r in outbox.due("pod", 10)}
    assert set(due) == {"GFUS0000000000001", "GFUS0000000000002"}
    assert pod_item(due["GFUS0000000000001"]["body"]["payload"], "2026-10-09")["pod_lat"] == 32.6
    assert requeue_day("2026-10-08", outbox, dry_run=False) == 0
