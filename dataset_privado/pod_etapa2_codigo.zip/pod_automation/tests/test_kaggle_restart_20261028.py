from datetime import datetime,timezone
from tools.run_kaggle_multi import stop_timestamp,restart_plan,restart_delay


def test_8pm_restarts_are_allowed_until_1030pm_venezuela():
    now=datetime(2026,10,29,0,0,tzinfo=timezone.utc)  # 28/10 20:00 Venezuela
    stop=stop_timestamp(now)
    assert stop-now.timestamp()==2.5*3600
    assert datetime.fromtimestamp(stop,timezone.utc)==datetime(2026,10,29,2,30,tzinfo=timezone.utc)


def test_after_1030pm_does_not_extend_deadline_to_tomorrow():
    now=datetime(2026,10,29,3,0,tzinfo=timezone.utc)
    assert stop_timestamp(now)<now.timestamp()


def test_transient_exit_and_normal_unexpected_exit_are_restarted():
    for code in (0,1,-9,137):
        plan=restart_plan(code,0,60,1000)
        assert not plan['disabled'] and plan['next_try']==1030


def test_expired_cookies_are_not_restarted_in_a_loop():
    assert restart_plan(2,0,60,1000)['disabled']


def test_backoff_is_bounded_and_resets_after_stable_work():
    assert [restart_delay(n) for n in range(1,7)]==[30,60,120,240,300,300]
    assert restart_plan(1,12,600,1000)['next_try']==1030


def test_supervisor_recovery_only_stops_workers_from_its_own_run(tmp_path,monkeypatch):
    import json,psutil,signal
    from unittest.mock import MagicMock
    from tools.run_kaggle_multi import cleanup_previous_workers
    state=tmp_path/'supervisor.json'
    state.write_text(json.dumps({'run_id':'our-run','workers':[101,202]}))
    own=MagicMock();own.environ.return_value={'MULTI_RUN_ID':'our-run'}
    own.cmdline.return_value=['python','main.py','run'];own.children.return_value=[]
    other=MagicMock();other.environ.return_value={'MULTI_RUN_ID':'another-run'}
    monkeypatch.setattr(psutil,'Process',lambda pid:{101:own,202:other}[pid])
    monkeypatch.setattr(psutil,'wait_procs',lambda processes,timeout:(processes,[]))
    cleanup_previous_workers(state,'our-run')
    own.send_signal.assert_called_once_with(signal.SIGINT)
    other.send_signal.assert_not_called()


def test_stale_pid_file_from_another_run_is_ignored(tmp_path,monkeypatch):
    import json,psutil
    from unittest.mock import MagicMock
    from tools.run_kaggle_multi import cleanup_previous_workers
    state=tmp_path/'supervisor.json';state.write_text(json.dumps({'run_id':'old','workers':[101]}))
    process=MagicMock();monkeypatch.setattr(psutil,'Process',process)
    cleanup_previous_workers(state,'new')
    process.assert_not_called()


def test_overnight_stop_uses_next_10am_venezuela_and_caps_hours():
    # 28/10 21:30 Venezuela (01:30 UTC): el corte configurado es la PROXIMA 10:00, con tope de horas de la sesion de Kaggle
    now=datetime(2026,10,29,1,30,tzinfo=timezone.utc)
    env={'MULTI_STOP_AT':'10:00'}
    assert datetime.fromtimestamp(stop_timestamp(now,env),timezone.utc)==datetime(2026,10,29,14,0,tzinfo=timezone.utc)
    env['MULTI_MAX_HOURS']='11'
    assert stop_timestamp(now,env)==now.timestamp()+11*3600       # el tope de 11 h llega antes que las 10:00
    env['MULTI_MAX_HOURS']='20'
    assert datetime.fromtimestamp(stop_timestamp(now,env),timezone.utc)==datetime(2026,10,29,14,0,tzinfo=timezone.utc)


def test_overnight_stop_before_10am_is_the_same_morning():
    now=datetime(2026,10,29,6,0,tzinfo=timezone.utc)               # 02:00 Venezuela
    got=stop_timestamp(now,{'MULTI_STOP_AT':'10:00'})
    assert datetime.fromtimestamp(got,timezone.utc)==datetime(2026,10,29,14,0,tzinfo=timezone.utc)


def test_without_configuration_behaviour_is_unchanged():
    now=datetime(2026,10,29,0,0,tzinfo=timezone.utc)
    assert stop_timestamp(now,{})-now.timestamp()==2.5*3600
