"""Repartidores: se revisan todos menos los excluidos; los nuevos se revisan y se marcan."""

import json
from pathlib import Path

import config
from automation.api_extractor import ApiPODExtractor
from automation.drivers import DriverSelection, normalize_name
from automation.portal_api import WaybillSummary
from storage.checkpoint_manager import CheckpointManager


class TwoDriversAPI:
    def __init__(self, drivers):
        self.drivers = drivers
        self.listed_for = []

    def list_couriers(self, station_id, date_iso):
        return [{"driverName": n, "userId": i, "checkOutPieces": 1} for i, n in self.drivers]

    def iter_waybills(self, station_id, date_iso, courier, page_size=50):
        self.listed_for.append(courier["driverName"])
        yield WaybillSummary(waybill_no=f"GF{courier['userId']}", sign_id=f"s{courier['userId']}",
                             driver_name=courier["driverName"], order_status="5", delivery_status_code="208")

    def get_sign_info(self, sign_id):
        return {"toAddress": "ALLEN ALLEN 1530 Broadmoor Dr", "imageList": []}


def _write(excluir):
    Path(config.DRIVERS_CONFIG_PATH).write_text(json.dumps({"excluir": excluir}), encoding="utf-8")


def test_normalize_handles_double_spaces_and_case():
    assert normalize_name("Mirielys  Hermoso") == normalize_name("mirielys hermoso ")


def test_everyone_is_reviewed_without_config_file():
    assert DriverSelection().should_review({"driverName": "Cualquiera", "userId": 1})


def test_excluded_by_name_or_id_are_skipped_before_listing_stops(tmp_path):
    _write(["mirielys hermoso", "555"])
    api = TwoDriversAPI([(1, "Mirielys  Hermoso"), (555, "Otro Nombre"), (2, "Fijo Diario")])
    got = []
    ext = ApiPODExtractor(api, images_dir=tmp_path, downloader=lambda u, d: [])
    ext.run_pass([1888], "2026-09-30", {}, got.append, should_review=DriverSelection().should_review)
    assert [p.tracking_number for p in got] == ["GF2"]
    assert api.listed_for == ["Fijo Diario"]  # A los excluidos ni se les piden las paradas


def test_new_driver_is_reviewed_and_flagged(tmp_path):
    ckpt = CheckpointManager(db_path=tmp_path / "c.db")
    ext_for = lambda api: ApiPODExtractor(api, images_dir=tmp_path, downloader=lambda u, d: [])

    def day(date, drivers):
        sid = ckpt.create_session(date)
        api = TwoDriversAPI(drivers)
        got = []
        ext_for(api).run_pass([1888], date, ckpt.get_status_map(sid), got.append,
                              on_route=lambda st, c, s: ckpt.save_route_snapshot(sid, st, c, s),
                              should_review=DriverSelection().should_review)
        ckpt.mark_session_completed(sid)
        return {r["driver_name"]: r["is_new"] for r in ckpt.get_route_progress(sid)}, got

    first, _ = day("2026-09-29", [(1, "Fijo Uno"), (2, "Fijo Dos")])
    assert first == {"Fijo Uno": 0, "Fijo Dos": 0}           # Primer día de uso: nadie es "nuevo"
    second, got = day("2026-09-30", [(1, "Fijo Uno"), (2, "Fijo Dos"), (3, "Recien Llegado")])
    assert second == {"Fijo Uno": 0, "Fijo Dos": 0, "Recien Llegado": 1}
    assert "GF3" in {p.tracking_number for p in got}         # El nuevo se revisa igual


def test_update_catalog_keeps_exclusions(tmp_path):
    _write(["Fijo Dos"])
    path = DriverSelection().update_catalog({"DFW02-BAA": [{"driverName": "Fijo  Uno", "userId": 1},
                                                           {"driverName": "Fijo Dos", "userId": 2}]})
    data = json.loads(path.read_text(encoding="utf-8"))
    assert data["excluir"] == ["Fijo Dos"]
    assert [(c["nombre"], c["excluido"]) for c in data["catalogo"]] == [("Fijo Dos", True), ("Fijo Uno", False)]
