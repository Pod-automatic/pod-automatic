"""La página local reserva en el portal; estas pruebas nunca abren WhatsApp."""
import pytest

from export import report_server
from export.portal_sync import PortalError


DAY = '2026-10-27'
ITEMS = [{'tracking': 'LOCALTEST001', 'main': 0}]


class Client:
    def __init__(self, responses):
        self.responses = iter(responses)
        self.calls = []

    def call(self, path, body=None):
        self.calls.append((path, body))
        return next(self.responses)


def test_local_page_only_reserves_shared_queue(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError('La página local no envía directamente ni carga evidencias ya sincronizadas')
    monkeypatch.setattr(report_server, 'prepare_whatsapp', forbidden)
    monkeypatch.setattr(report_server, 'load_payload', forbidden)
    expected = {'ok': True, 'job': 91, 'queued': ['LOCALTEST001']}
    client = Client([expected])
    assert report_server.enqueue_local_whatsapp(DAY, ITEMS, client) == expected
    assert client.calls == [('wa_submit.php', {'date': DAY, 'items': ITEMS})]


def test_duplicate_returns_without_sending_or_uploading():
    expected = {'ok': True, 'job': None, 'skipped': {'busy': ['LOCALTEST001']}}
    client = Client([expected])
    assert report_server.enqueue_local_whatsapp(DAY, ITEMS, client) == expected
    assert len(client.calls) == 1


@pytest.mark.parametrize('priority,promoted', [('Alta', []), ('Baja', ['LOCALTEST001'])])
def test_missing_case_is_synced_before_reservation(monkeypatch, priority, promoted):
    from export import portal_sync
    payload = {'tracking_number': 'LOCALTEST001', 'priority': priority, 'photo_paths': ['one.jpg']}
    monkeypatch.setattr(report_server, 'load_payload', lambda *args: payload)
    monkeypatch.setattr(portal_sync, 'pod_item', lambda data, day: {'tracking': data['tracking_number'], 'priority': data['priority'], 'date': day})
    monkeypatch.setattr(portal_sync, 'card_jpeg', lambda data, index: b'fake-jpeg')
    client = Client([{'ok': False, 'missing': ['LOCALTEST001']}, {'ok': True, 'saved': 1}, {'ok': True, 'job': 92}])
    assert report_server.enqueue_local_whatsapp(DAY, ITEMS, client)['job'] == 92
    assert [path for path, body in client.calls] == ['wa_submit.php', 'ingest.php', 'wa_submit.php']
    uploaded = client.calls[1][1]['items'][0]
    assert uploaded['priority'] in ('Alta', 'Media') and uploaded['cards'] == ['ZmFrZS1qcGVn']
    assert client.calls[2][1]['promoted'] == promoted
    assert payload['priority'] == priority


def test_upload_failure_stops_before_reservation(monkeypatch):
    from export import portal_sync
    monkeypatch.setattr(report_server, 'load_payload', lambda *args: {'priority': 'Alta'})
    monkeypatch.setattr(portal_sync, 'pod_item', lambda *args: {})
    monkeypatch.setattr(portal_sync, 'card_jpeg', lambda *args: b'fake-jpeg')
    client = Client([{'missing': ['LOCALTEST001']}, {'errors': ['Fallo de prueba']}])
    with pytest.raises(ValueError, match='No se pudo sincronizar'):
        report_server.enqueue_local_whatsapp(DAY, ITEMS, client)
    assert len(client.calls) == 2


def test_connection_failure_does_not_fall_back_to_direct_send(monkeypatch):
    class Offline:
        def call(self, *args, **kwargs):
            raise PortalError('sin conexión')
    monkeypatch.setattr(report_server, 'prepare_whatsapp', lambda *args: pytest.fail('No debe enviar por fuera de la cola'))
    with pytest.raises(PortalError):
        report_server.enqueue_local_whatsapp(DAY, ITEMS, Offline())
