"""28/10: un corte corto del portal no debe tirar el permiso de la sesion compartida de GOFO.

Hasta hoy una sola renovacion fallida mataba el hilo y marcaba error: la PC dejaba de consultar GOFO aunque el permiso
siguiera vigente varios minutos (caso real: 28/10 entre 12:00 y 17:00 con el portal inestable)."""
import time

import pytest
import config
from automation.session_guard import (SessionGuard, SessionCoordinationError, classify_failure, WAIT)
from export.portal_sync import PortalError


class Server:
    timeout = 1

    def __init__(self):
        self.state = {}; self.fail = None; self.calls = []

    def call(self, path, body):
        self.calls.append(body['action'])
        if self.fail: raise self.fail
        if body['action'] == 'release':
            self.state = {}; return {'granted': False}
        mine = self.state.get('token') == body['token']
        if self.state and not mine and self.state['until'] > time.monotonic() and body['action'] == 'acquire':
            return {'granted': False}
        if body['action'] == 'renew' and not mine:
            return {'granted': False}
        self.state = {'token': body['token'], 'until': time.monotonic() + body['lease_s']}
        return {'granted': True, 'lease_s': body['lease_s']}


def wait_for(cond, seconds=2.0):
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        if cond(): return True
        time.sleep(.01)
    return cond()


def make(server, **kw):
    return SessionGuard(server, 'luisvivas', 'pc', renew_s=.01, retry_s=.01, **kw)


def test_short_portal_outage_keeps_lease_and_recovers():
    server = Server(); guard = make(server)
    assert guard.acquire()
    server.fail = PortalError('sin conexión con el portal (timed out)')
    before = guard.until
    assert wait_for(lambda: guard.failures >= 3)
    assert guard.error is None            # un corte NO es una perdida del permiso
    guard.check()                         # el permiso sigue vigente: se sigue consultando GOFO
    assert guard.until == before          # sin renovar, el vencimiento no se estira
    server.fail = None
    assert wait_for(lambda: guard.until > before)   # al volver el portal se renueva solo
    guard.check()
    guard.close()


def test_lease_that_really_expires_still_blocks_gofo():
    server = Server(); guard = make(server)
    assert guard.acquire()
    server.fail = PortalError('sin conexión con el portal (timed out)')
    guard.until = time.monotonic() + 5    # queda menos que el margen de seguridad
    with pytest.raises(SessionCoordinationError): guard.check()
    server.fail = None; guard.close()


def test_invalid_api_key_is_definitive_and_explained():
    server = Server(); guard = make(server)
    assert guard.acquire()
    server.fail = PortalError('HTTP 401: Clave de API inválida.')
    assert wait_for(lambda: guard.error is not None)
    with pytest.raises(SessionCoordinationError, match='401'): guard.check()
    server.fail = None; guard.close()


def test_lease_taken_by_another_worker_is_definitive():
    server = Server(); guard = make(server)
    assert guard.acquire()
    server.state = {'token': 'otro', 'until': time.monotonic() + 100}
    assert wait_for(lambda: guard.error is not None)
    with pytest.raises(SessionCoordinationError, match='otro proceso'): guard.check()
    guard.close()


def test_failure_classification():
    assert classify_failure(PortalError('HTTP 401: Clave de API inválida.')) == 'auth'
    assert classify_failure(PortalError('HTTP 403: prohibido')) == 'auth'
    assert classify_failure(PortalError('sin conexión con el portal (timed out)')) == 'network'
    assert classify_failure(PortalError('HTTP 502: Bad Gateway')) == 'network'
    assert classify_failure(PortalError('HTTP 500: error')) == 'network'
    assert classify_failure(TimeoutError('x')) == 'network'
    assert classify_failure(ValueError('x')) == 'other'


def test_lease_length_comes_from_config(monkeypatch):
    monkeypatch.setattr(config, 'GOFO_SESSION_LEASE_S', 420)
    server = Server(); guard = make(server)
    assert guard.acquire()
    assert guard.until - time.monotonic() > 400
    guard.close()


def test_wait_counter_accumulates_seconds():
    WAIT.reset()
    WAIT.add(30); WAIT.add(12.5)
    assert WAIT.total == pytest.approx(42.5)
    WAIT.reset()
    assert WAIT.total == 0
