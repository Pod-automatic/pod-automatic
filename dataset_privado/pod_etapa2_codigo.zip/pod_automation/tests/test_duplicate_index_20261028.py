import random
import pytest

from processing.duplicate_detection import DuplicateImageDetector
from processing.image_analysis import ImageQualityAnalyzer


def reference(records, tracking, dhash, sha256, phash, threshold):
    if not (dhash or sha256 or phash): return None,False
    exact=visual=None
    for record in records:
        if record['tracking']==tracking: continue
        sha=bool(sha256 and sha256==record['sha256'])
        d=ImageQualityAnalyzer.hamming_distance(dhash,record['dhash']) if dhash and record['dhash'] else 64
        p=ImageQualityAnalyzer.hamming_distance(phash,record['phash']) if phash and record['phash'] else 64
        distance=min(d,p)
        if sha or distance==0:
            if exact is None: exact=(record['tracking'],distance)
        elif distance<=threshold and visual is None:
            visual=(record['tracking'],distance)
    return exact or visual, exact is not None


@pytest.mark.parametrize('include_nonmetric',[False,True])
def test_index_matches_exhaustive_reference_including_missing_hashes_and_thresholds(include_nonmetric):
    rng=random.Random(20261028)
    detector=DuplicateImageDetector()
    records=[]
    for n in range(1200):
        tracking=f'T{n%317}'
        sha=f'sha-{n}' if rng.random()<.8 else ''
        dhash=f'{rng.getrandbits(64):016x}' if rng.random()<.8 else ''
        phash=f'{rng.getrandbits(64):016x}' if rng.random()<.6 else ''
        if records and n%3==0:
            previous=rng.choice(records)
            if n%2: sha=previous['sha256']
            else: dhash=previous['dhash']
        if include_nonmetric and n%71==0: dhash='-1'
        if n%59==0: phash='no-es-hex'
        threshold=rng.choice([-1,0,2,8,64])
        expected,exact=reference(records,tracking,dhash,sha,phash,threshold)
        result=detector.check_duplicate(tracking,'Driver','photo.jpg',dhash,sha,phash,threshold)
        assert result.is_duplicate==bool(expected)
        if expected:
            assert (result.matched_tracking,result.hamming_distance)==expected
            assert ('Exact' in result.classification)==exact
        elif dhash or sha or phash:
            records.append({'tracking':tracking,'dhash':dhash,'sha256':sha,'phash':phash})
        assert len(result.comparisons_log)<=24
        assert len(detector.registry)==len(records)


def test_sha_only_batch_does_not_scan_or_log_unrelated_photos():
    detector=DuplicateImageDetector()
    results=[detector.check_duplicate(str(n),'Driver','photo.jpg',sha256=f'sha-{n}') for n in range(300)]
    assert sum(result.candidates_evaluated for result in results)==0
    assert sum(len(result.comparisons_log) for result in results)==0
    duplicate=detector.check_duplicate('OTHER','Driver','photo.jpg',sha256='sha-299')
    assert duplicate.matched_tracking=='299' and duplicate.candidates_evaluated==1
    detector.clear()
    assert not detector.check_duplicate('OTHER','Driver','photo.jpg',sha256='sha-299').is_duplicate


def test_visual_index_prefers_exact_over_earlier_similar_and_ignores_same_tracking():
    detector=DuplicateImageDetector(max_hamming_distance=0)
    detector.check_duplicate('A','Driver','a.jpg',dhash='0000000000000000')
    detector.check_duplicate('B','Driver','b.jpg',dhash='0000000000000003')
    result=detector.check_duplicate('C','Driver','c.jpg',dhash='0000000000000003',threshold=4)
    assert result.matched_tracking=='B' and result.classification=='Exact Duplicate'
    # El hash exacto del propio tracking no oculta una coincidencia visual con otro.
    result=detector.check_duplicate('B','Driver','b2.jpg',dhash='0000000000000003',threshold=4)
    assert result.matched_tracking=='A' and result.classification=='Possible Visual Duplicate'


def test_bounded_trace_keeps_winning_match_on_fallback():
    detector=DuplicateImageDetector(max_hamming_distance=-1)
    for n in range(100): detector.check_duplicate(str(n),'Driver',f'{n}.jpg',sha256=f'sha-{n}')
    detector.check_duplicate('negative','Driver','negative.jpg',dhash='-1')
    result=detector.check_duplicate('OTHER','Driver','other.jpg',sha256='sha-99',threshold=64)
    assert result.matched_tracking=='99' and len(result.comparisons_log)==24
    assert any(item['compared_tracking']=='99' for item in result.comparisons_log)
