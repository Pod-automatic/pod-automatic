"""ScoringPipeline: OCR en paralelo, finalización en el proceso principal, contrapresión y fallos."""

from concurrent.futures import ThreadPoolExecutor

from models.pod import PODRecord, ProcessingStatusEnum
from processing.ocr_address import PhotoOCR
from processing.pipeline import ScoringPipeline
from processing.validator import PODValidator


def fake_ocr(paths, address=None):
    # Simula: la primera foto muestra 1350 y la dirección es 1530
    # (el modelo de visión también lee 1350: solo así llega a Alta, regla 02/10)
    return [PhotoOCR(path=p, numbers=["1350"] if i == 0 else [], vision_all=["1350"] if i == 0 else [])
            for i, p in enumerate(paths)]


def _pod(trk, photos=3, status=ProcessingStatusEnum.PROCESSED):
    return PODRecord(tracking_number=trk, address="ALLEN ALLEN 1530 Broadmoor Dr",
                     receipt_address="ALLEN ALLEN 1530 Broadmoor Dr", billing_type="En la puerta/Patio",
                     photo_paths=[f"/no/existe/{trk}_{i}.jpg" for i in range(photos)], processing_status=status)


def test_pipeline_scores_all_pods_and_keeps_every_one():
    scored = []
    pipe = ScoringPipeline(PODValidator(), scored.append, executor=ThreadPoolExecutor(2), ocr_fn=fake_ocr, max_pending=2)
    for i in range(7):
        pipe.submit(_pod(f"GF{i}"))
    pipe.close()
    assert sorted(p.tracking_number for p in scored) == [f"GF{i}" for i in range(7)]
    assert all(p.risk_score is not None and p.priority for p in scored)
    num = next(r for r in scored[0].check_results if r["check"] == "numero_direccion")
    assert num["details"]["status"] == "mismatch" and scored[0].priority == "Alta"


def test_failed_or_photoless_pods_skip_ocr_but_get_scored():
    calls, scored = [], []

    def ocr(paths, address=None):
        calls.append(paths)
        return []

    pipe = ScoringPipeline(PODValidator(), scored.append, executor=ThreadPoolExecutor(1), ocr_fn=ocr)
    pipe.submit(_pod("FAIL", status=ProcessingStatusEnum.FAILED))
    pipe.submit(_pod("NOPHOTO", photos=0))
    pipe.close()
    assert calls == [] and {p.tracking_number for p in scored} == {"FAIL", "NOPHOTO"}
    nophoto = next(p for p in scored if p.tracking_number == "NOPHOTO")
    assert nophoto.priority == "Alta"  # Sin fotos -> reportar


def test_ocr_crash_does_not_lose_the_pod():
    scored = []

    def boom(paths, address=None):
        raise RuntimeError("GPU sin memoria")

    pipe = ScoringPipeline(PODValidator(), scored.append, executor=ThreadPoolExecutor(1), ocr_fn=boom)
    pipe.submit(_pod("GF1"))
    pipe.close()
    assert scored[0].risk_score is not None
    num = next(r for r in scored[0].check_results if r["check"] == "numero_direccion")
    # 04/10: sin OCR no se castiga al conductor (no es Alta) pero tampoco se esconde en Baja: revisión manual
    assert num["details"]["status"] == "ocr_error" and scored[0].priority == "Media"


def test_pipeline_records_analysis_time_and_projection_uses_the_bottleneck():
    from automation.politeness import ThroughputTracker
    tracker = ThroughputTracker(durations=[3.0], analysis_workers=1)
    scored = []
    pipe = ScoringPipeline(PODValidator(), scored.append, executor=ThreadPoolExecutor(1), ocr_fn=fake_ocr, tracker=tracker)
    pipe.submit(_pod("GF1"))
    pipe.close()
    assert len(tracker.analysis_durations) == 1 and scored
    tracker.analysis_durations = [12.0]  # OCR 12 s/albarán vs extracción 3 s: manda el OCR
    p = tracker.projection(daily_target=24000)
    assert p["per_hour"] == 300.0 and p["bottleneck"].startswith("análisis") and p["sampling_needed"] is True


def test_ocr_mismatch_gets_vision_second_opinion():
    # Caso real: el OCR leyó "210" (94%) en el cordón; el modelo de visión lee "218" = la dirección
    from processing.pipeline import add_vision_opinion
    from processing.ocr_address import match_numbers, parse_us_address
    from processing.vision_llm import VisionResult
    addr = "ARLINGTON ARLINGTON 218 E Embercrest Dr"
    photos = [PhotoOCR(path="a.jpg", numbers=["210"], number_conf={"210": 94.0})]
    assert match_numbers(parse_us_address(addr), photos).status in ("mismatch", "near_match")
    out = add_vision_opinion(photos, addr, reader=lambda p: VisionResult(path=p, numbers=["218"], photo_type="building"))
    assert out[0].vision_used and match_numbers(parse_us_address(addr), out).status == "match"


def test_painted_curb_number_called_label_by_vision_still_counts():
    # Caso real GFUS01074219107716: "3301" pintado en la acera; el modelo lo leyó bien pero dijo "label"
    from processing.pipeline import add_vision_opinion
    from processing.ocr_address import match_numbers, parse_us_address
    from processing.vision_llm import VisionResult
    addr = "PLANO PLANO 3301 Colt Dr"
    curb = PhotoOCR(path="acera.jpg", text="4301", numbers=["4301"], number_conf={"4301": 40.0})
    out = add_vision_opinion([curb], addr, reader=lambda p: VisionResult(path=p, numbers=["3301"], photo_type="label"))
    assert not out[0].is_label and "3301" in out[0].numbers
    assert match_numbers(parse_us_address(addr), out).status == "match"


def test_real_label_with_lots_of_text_stays_label():
    # Una etiqueta real (aunque el OCR no la reconozca) deja mucho texto: el modelo sigue mandando
    from processing.pipeline import add_vision_opinion
    from processing.vision_llm import VisionResult
    addr = "PLANO PLANO 3301 Colt Dr"
    label = PhotoOCR(path="etiqueta.jpg", text="8 3 9 0 ! 1 2 5 26 F 54 1 1 4 8 02 8 8 L")
    out = add_vision_opinion([label], addr, reader=lambda p: VisionResult(path=p, numbers=["3301"], photo_type="label"))
    assert out[0].is_label and out[0].numbers == []


def test_unrecognized_label_does_not_skip_vision():
    # Caso real GFUS01075275832839: la etiqueta (sin QR detectado) trae "1808 Drew Ln" impreso y el
    # "1808" del bordillo solo lo lee el modelo. La etiqueta no puede confirmar el número.
    from processing.pipeline import add_vision_opinion
    from processing.ocr_address import match_numbers, parse_us_address
    from processing.vision_llm import VisionResult
    addr = "RICHARDSON RICHARDSON 1808 Drew Ln"
    curb = PhotoOCR(path="bordillo.jpg")
    label = PhotoOCR(path="etiqueta.jpg", text="SHIP TO 1808 DREW LN RICHARDSON TX 75082", numbers=["1808", "75082"])
    calls = []
    out = add_vision_opinion([curb, label], addr,
                             reader=lambda p: calls.append(p) or VisionResult(path=p, numbers=["1808"], photo_type="other"))
    assert calls == ["bordillo.jpg"]
    assert "1808" in out[0].vision_numbers


def _vr(nums, ptype="building"):
    from processing.vision_llm import VisionResult
    return VisionResult(path="x.jpg", numbers=nums, photo_type=ptype)


def test_tilted_photo_confirmed_by_rotation():
    # Caso real "8750 Rodeo Dr": derecha el modelo lee "80750"; girada 45/-45 lee "8750"
    from processing.pipeline import add_vision_opinion
    addr = "Terrell Terrell 8750 Rodeo Dr"
    reads = {45: ["8750"], -45: ["8750"], 90: ["8750"]}
    out = add_vision_opinion([PhotoOCR(path="porche.jpg")], addr, reader=lambda p: _vr(["80750"]),
                             rotated_reader=lambda p, a: _vr(reads[a]))
    assert out[0].vision_numbers == ["8750"]


def test_rotation_needs_two_agreeing_reads():
    from processing.pipeline import add_vision_opinion
    addr = "Terrell Terrell 8750 Rodeo Dr"
    reads = {45: ["8750"], -45: ["5050"], 90: []}
    out = add_vision_opinion([PhotoOCR(path="porche.jpg")], addr, reader=lambda p: _vr(["80750"]),
                             rotated_reader=lambda p, a: _vr(reads[a]))
    assert out[0].vision_numbers == ["80750"]


def test_pickup_point_and_mail_room_skip_ocr():
    from processing.pipeline import skip_analysis
    from models.pod import PODRecord
    mk = lambda b, **kw: PODRecord(tracking_number="GFUS1", billing_type=b, **kw)
    assert skip_analysis(mk("Punto de Recogida de Paquetes"))
    assert skip_analysis(mk("Sala de Correo"))
    assert not skip_analysis(mk("En la puerta/Patio"))
    assert not skip_analysis(mk("Sala de Correo", portal_meta={"whether_reported": "1"}))


def test_rotation_not_tried_for_fragments():
    from processing.pipeline import _confirmed_by_rotation
    calls = []
    assert not _confirmed_by_rotation("x.jpg", ["14"], "2955", lambda p, a: calls.append(a))
    assert calls == []


def test_se_puntua_en_el_mismo_orden_en_que_llegan_aunque_el_ocr_termine_en_desorden():
    # 25/10: con varios procesos de OCR, el primero puede tardar más; la puntuación espera su turno para que las
    # comparaciones entre albaranes den el mismo resultado en cada corrida
    import threading
    import time
    gate = threading.Event()
    scored = []

    def ocr(paths, address=None):
        if "SLOW" in paths[0]:
            gate.wait(timeout=5)       # El primero termina de último
        return fake_ocr(paths)

    pipe = ScoringPipeline(PODValidator(), scored.append, executor=ThreadPoolExecutor(3), ocr_fn=ocr)
    for trk in ("SLOW1", "GF2", "GF3"):
        pipe.submit(_pod(trk))
    time.sleep(0.3)
    pipe.collect(block=False)
    assert scored == []                 # GF2 y GF3 ya terminaron pero esperan a SLOW1
    gate.set()
    pipe.close()
    assert [p.tracking_number for p in scored] == ["SLOW1", "GF2", "GF3"]


def test_los_que_se_omiten_sin_ocr_tambien_esperan_su_turno():
    import threading
    gate = threading.Event()
    scored = []

    def ocr(paths, address=None):
        gate.wait(timeout=5)
        return fake_ocr(paths)

    pipe = ScoringPipeline(PODValidator(), scored.append, executor=ThreadPoolExecutor(1), ocr_fn=ocr)
    pipe.submit(_pod("GF1"))
    pipe.submit(_pod("FAIL", status=ProcessingStatusEnum.FAILED))
    assert scored == []
    gate.set()
    pipe.close()
    assert [p.tracking_number for p in scored] == ["GF1", "FAIL"]


def test_cascada_el_modelo_mayor_solo_entra_si_el_normal_no_confirma():
    # 25/10: el 3b no lee la puerta (queda dudoso); el 7b sí lee la casa y se confirma
    from processing.pipeline import add_vision_opinion
    from processing.ocr_address import match_numbers, parse_us_address
    from processing.vision_llm import VisionResult
    addr = "ARLINGTON ARLINGTON 218 E Embercrest Dr"
    calls = {"normal": 0, "mayor": 0}

    def normal(p):
        calls["normal"] += 1
        return VisionResult(path=p, numbers=[], photo_type="building")

    def mayor(p):
        calls["mayor"] += 1
        return VisionResult(path=p, numbers=["218"], photo_type="building")

    photos = [PhotoOCR(path="a.jpg", numbers=["210"], number_conf={"210": 94.0})]
    out = add_vision_opinion(photos, addr, reader=normal, fallback_reader=mayor)
    assert match_numbers(parse_us_address(addr), out).status == "match"
    assert calls == {"normal": 1, "mayor": 1}


def test_cascada_no_llama_al_mayor_si_el_normal_ya_confirmo():
    from processing.pipeline import add_vision_opinion
    from processing.vision_llm import VisionResult
    addr = "ARLINGTON ARLINGTON 218 E Embercrest Dr"
    called = []
    photos = [PhotoOCR(path="a.jpg", numbers=["210"], number_conf={"210": 94.0})]
    add_vision_opinion(photos, addr, reader=lambda p: VisionResult(path=p, numbers=["218"], photo_type="building"),
                       fallback_reader=lambda p: called.append(p) or VisionResult(path=p))
    assert called == []


def test_cascada_apagada_sin_modelo_configurado(monkeypatch):
    import config
    from processing.pipeline import add_vision_opinion
    from processing.vision_llm import VisionResult
    monkeypatch.setattr(config, "VISION_FALLBACK_MODEL", "")
    addr = "ARLINGTON ARLINGTON 218 E Embercrest Dr"
    photos = [PhotoOCR(path="a.jpg", numbers=["210"], number_conf={"210": 94.0})]
    # Sin fallback_reader y sin modelo configurado: solo corre el modelo normal
    add_vision_opinion(photos, addr, reader=lambda p: VisionResult(path=p, numbers=[], photo_type="building"))
    assert photos[0].vision_used


def test_cascada_el_error_del_modelo_mayor_no_rompe_nada():
    from processing.pipeline import add_vision_opinion
    from processing.vision_llm import VisionResult
    addr = "ARLINGTON ARLINGTON 218 E Embercrest Dr"
    photos = [PhotoOCR(path="a.jpg", numbers=["210"], number_conf={"210": 94.0})]
    out = add_vision_opinion(photos, addr, reader=lambda p: VisionResult(path=p, numbers=[], photo_type="building"),
                             fallback_reader=lambda p: VisionResult(path=p, error="sin respuesta"))
    assert out[0].numbers == ["210"]
