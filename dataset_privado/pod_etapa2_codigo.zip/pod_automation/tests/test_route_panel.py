"""11/10: panel de rutas de la página local (resumen de repartidores y entregas con problema de GOFO)."""
from storage import route_panel

COURIER = {"siteName": "DFW02-BAA", "userId": "264084", "driverName": "Jaider  Esneider", "checkOutPieces": 244,
           "podPieces": 215, "returnCenter": 27, "deliveryFailPieces": 2, "reassigned": 0, "deliveringPieces": 0,
           "podRate2400": 88.11, "warnLevel": 3}
ISSUE = {"waybillNo": "GFUS01076874347781", "stopIndex": "S1058", "waybillDeliveryStatus": "206",
         "deliveryIssusTime": "10/284/2026 11:24:48", "deliveryIssueRemark": "(Sin código de acceso) ",
         "deliveryIssueName": "No Acceso"}


def test_guarda_y_lee_el_panel(tmp_path):
    db = tmp_path / "panel.db"
    route_panel.save_couriers("2026-10-11", "DFW02-BAA", [COURIER], path=db)
    route_panel.save_couriers("2026-10-11", "DFW02-BAA", [dict(COURIER, podPieces=216)], path=db)   # Se actualiza
    route_panel.save_exception("2026-10-11", "DFW02-BAA", COURIER, ISSUE, path=db)
    route_panel.save_exception("2026-10-11", "DFW02-BAA", COURIER, {"waybillNo": "SIN-PROBLEMA"}, path=db)
    data = route_panel.load("2026-10-11", path=db)
    assert len(data["couriers"]) == 1
    c = data["couriers"][0]
    assert (c["driver"], c["checkout"], c["pod"], c["returned"], c["failed"]) == ("Jaider Esneider", 244, 216, 27, 2)
    assert [(e["tracking"], e["issue"], e["remark"]) for e in data["exceptions"]] == [
        ("GFUS01076874347781", "No Acceso", "(Sin código de acceso)")]
    assert route_panel.load("2026-10-10", path=db) == {"couriers": [], "exceptions": []}


def test_envio_del_panel_al_portal(tmp_path, monkeypatch):
    from export.portal_sync import Outbox, PortalSync
    db = tmp_path / "panel.db"
    route_panel.save_couriers("2026-10-11", "DFW02-BAA", [COURIER], path=db)
    route_panel.save_exception("2026-10-11", "DFW02-BAA", COURIER, ISSUE, path=db)
    monkeypatch.setattr(route_panel, "PANEL_DB", db)
    calls = []

    class Client:
        def call(self, path, body=None, query=None):
            calls.append((path, body))
            return {"ok": True}
    assert PortalSync(Client(), Outbox(tmp_path / "o.db")).push_panel("2026-10-11")
    path, body = calls[0]
    assert path == "panel.php" and body["date"] == "2026-10-11"
    assert body["couriers"][0]["failed"] == 2 and body["exceptions"][0]["issue"] == "No Acceso"
    assert not PortalSync(Client(), Outbox(tmp_path / "o2.db")).push_panel("2026-10-10")   # Sin datos: no se manda
