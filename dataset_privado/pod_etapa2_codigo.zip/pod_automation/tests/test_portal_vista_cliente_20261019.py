"""19/10: lo que el script manda al portal para la "Vista del cliente / administrador" (como el Dashboard(DSP) de GOFO):
Lockers de Amazon, parada, hora de entrega, revisados por el script, todas las fotos y el control de paquetes."""

import base64
import json

import pytest

from export import portal_sync
from export.portal_sync import Outbox, PortalError, PortalSync, pod_item
from storage import package_control
from tests.test_portal_sync import FakeClient, make_pod


def _payload(**kw):
    p = {"tracking_number": "GFUS1", "priority": "Alta", "driver_name": "Ana", "station": "DFW02-BAA", "receipt_address": "Plano Plano 1113 Kit Ln",
         "risk_score": 80.0, "portal_meta": {}, "check_results": []}
    p.update(kw)
    return p


def test_pod_item_lleva_parada_hora_de_entrega_y_marca_de_lockers():
    item = pod_item(_payload(stop_number="S783", signature_datetime="2026-10-19 11:20:05",
                             check_results=[{"check": "amazon_hub", "score": 100, "weight": 2.0, "explanation": "x", "applicable": True}]), "2026-10-19")
    assert item["hub"] is True and item["stop"] == "S783" and item["signed"] == "2026-10-19 11:20:05"


def test_sin_firma_usa_la_hora_de_entrega_y_sin_lockers_no_es_hub():
    item = pod_item(_payload(delivery_datetime="2026-10-19 09:00:00", check_results=[
        {"check": "amazon_hub", "score": 0, "weight": 1.0, "explanation": "x", "applicable": False},
        {"check": "calidad_imagen", "score": 50, "weight": 1.0, "explanation": "Foto oscura", "applicable": True}]), "2026-10-19")
    assert item["hub"] is False and item["stop"] == "" and item["signed"] == "2026-10-19 09:00:00"


def test_baja_no_lleva_los_datos_nuevos():
    item = pod_item({"tracking_number": "GFUS2", "priority": "Baja"}, "2026-10-19")
    assert "hub" not in item and "stop" not in item and "signed" not in item


@pytest.fixture
def env(tmp_path):
    client = FakeClient()
    calls = []
    orig = client.call

    def call(path, body=None, query=None):
        calls.append((path, body))
        if path in ("panel.php", "control.php"):
            if client.down:
                raise PortalError("sin conexión con el portal (prueba)")
            return {"ok": True}
        return orig(path, body, query)

    client.call = call
    sync = PortalSync(client, Outbox(tmp_path / "outbox.db"), status_writer=lambda d, t, s: None,
                      card_maker=lambda payload, i: b"\xff\xd8\xffJPG" + str(i).encode(), pull_interval=0,
                      photo_maker=lambda path: b"\xff\xd8\xffFOTO")
    return sync, client, calls


def test_manda_todas_las_fotos_originales_hasta_12_y_6_tarjetas(env, tmp_path):
    sync, client, _ = env
    fotos = []
    for i in range(14):
        f = tmp_path / f"foto_{i}.jpg"
        f.write_bytes(b"x")
        fotos.append(str(f))
    pod = make_pod()
    pod.photo_paths = fotos[:9]
    sync.enqueue_pod(pod, "2026-10-19")
    sync.sync_once()
    it = client.pods[("GFUS0000000000001", "2026-10-19")]
    assert len(it["photos"]) == 9 and len(it["cards"]) == 6      # todas las fotos del POD; las tarjetas siguen en 6
    pod2 = make_pod("GFUS0000000000002")
    pod2.photo_paths = fotos
    sync.enqueue_pod(pod2, "2026-10-19")
    sync.sync_once()
    assert len(client.pods[("GFUS0000000000002", "2026-10-19")]["photos"]) == 12


def test_panel_manda_los_revisados_por_el_script(env, monkeypatch):
    sync, client, calls = env
    data = {"couriers": [{"user_id": "7", "driver": "Ana", "station": "DFW02-BAA", "checkout": 100, "pod": 90, "returned": 1, "failed": 2,
                          "reassigned": 0, "delivering": 7, "revisados": 85, "alta": 3, "pod_rate": 90.0, "updated_at": "2026-10-19 11:00"}],
            "exceptions": []}
    import export.report_server as rs
    monkeypatch.setattr(rs, "panel_data", lambda day: data)
    assert sync.push_panel("2026-10-19") is True
    path, body = calls[-1]
    assert path == "panel.php" and body["couriers"][0]["revisados"] == 85 and "alta" not in body["couriers"][0]


def _control(**kw):
    d = {"scans": [], "returns": [], "lost": [], "last_run": {"finished_at": "2026-10-19T10:00:00"}, "roster": 5}
    d.update(kw)
    return d


def test_control_manda_perdidos_devoluciones_con_problema_y_escaneos_dudosos(env, monkeypatch):
    sync, client, calls = env
    monkeypatch.setattr(package_control, "load", lambda day: _control(
        lost=[{"tracking": "T1", "lost_time": "2026-10-18 10:00:00", "date": "2026-10-18", "code": "x", "label": "Perdido en ruta", "station": "DFW02-BAA",
               "last_scan_by": "Ana", "last_out_by": "Ana", "last_scan_code": "q", "last_scan_time": "t", "last_fail_time": None}],
        returns=[{"tracking": "T2", "start_time": "s", "kind": "fallido", "date": "2026-10-19", "driver": "Ana", "station": "DFW02-BAA", "issue": "i",
                  "deadline": "2026-10-19 20:00:00", "outcome": "a_tiempo", "resolved_time": "r", "resolved_by": "b", "hours": 1.0},
                 {"tracking": "T3", "start_time": "s", "kind": "fallido", "date": "2026-10-19", "driver": "Ana", "station": "DFW02-BAA", "issue": "i",
                  "deadline": "2026-10-19 20:00:00", "outcome": "pendiente", "resolved_time": None, "resolved_by": None, "hours": None},
                 {"tracking": "T4", "start_time": "s", "kind": "salio", "date": "2026-10-19", "driver": "Ana", "station": "DFW02-BAA", "issue": "",
                  "deadline": "d", "outcome": "vencido", "resolved_time": None, "resolved_by": None, "hours": None}],
        scans=[{"tracking": "T5", "driver": "Ana", "station": "DFW02-BAA", "date": "2026-10-19", "out_time": "o", "verdict": "ok", "own_scan": "x",
                "scanned_by": "Ana", "after_by": None},
               {"tracking": "T6", "driver": "Ana", "station": "DFW02-BAA", "date": "2026-10-19", "out_time": "o", "verdict": "otro", "own_scan": "x",
                "scanned_by": "Luis", "after_by": None}]))
    assert sync.push_control("2026-10-19") is True
    path, body = calls[-1]
    assert path == "control.php" and body["date"] == "2026-10-19"
    assert [x["tracking"] for x in body["lost"]] == ["T1"] and body["lost"][0]["last_out_by"] == "Ana"
    assert [x["tracking"] for x in body["returns"]] == ["T3", "T4"]       # sin "a_tiempo"; "pendiente" sí (el portal la vence por plazo)
    assert [x["tracking"] for x in body["scans"]] == ["T6"]               # sin los "ok"
    assert set(body["returns"][0]) == {"tracking", "driver", "station", "kind", "issue", "date", "start_time", "deadline", "outcome", "resolved_time", "resolved_by"}
    n = len(calls)
    assert sync.push_control("2026-10-19") is False and len(calls) == n    # sin cambios: no se vuelve a mandar


def test_control_sin_datos_no_manda_nada(env, monkeypatch):
    sync, client, calls = env
    monkeypatch.setattr(package_control, "load", lambda day: _control(roster=0))
    assert sync.push_control("2026-10-19") is False and not calls


def test_control_con_el_portal_caido_no_lanza_error_y_se_reintenta(env, monkeypatch):
    sync, client, calls = env
    monkeypatch.setattr(package_control, "load", lambda day: _control(lost=[{"tracking": "T1", "lost_time": "t", "date": "2026-10-18", "label": "x",
                                                                            "station": "S", "last_scan_by": "a", "last_out_by": "a"}]))
    client.down = True
    assert sync.push_control("2026-10-19") is False          # el portal no responde: se ignora
    client.down = False
    assert sync.push_control("2026-10-19") is True            # y al volver, sale (no quedó marcado como enviado)
