import config
from export import report_server
from export.whatsapp_sender import group_for_station


def test_group_by_city_with_default(monkeypatch):
    monkeypatch.setattr(config, "WHATSAPP_GROUPS", {"DFW02-BAA": "GOFO DALLAS", "AUS-BAA": "GOFO AUSTIN"})
    monkeypatch.setattr(config, "WHATSAPP_DEFAULT_GROUP", "GOFO DALLAS")
    assert group_for_station("DFW02-BAA") == "GOFO DALLAS"
    assert group_for_station("aus-baa") == "GOFO AUSTIN"
    assert group_for_station("HOU-BAA") == "GOFO DALLAS"     # Ciudad nueva sin grupo: el de por defecto


def test_messages_one_per_pod_and_amazon_hub_together(monkeypatch, tmp_path):
    hub = [{"check": "amazon_hub", "applicable": True}]
    pods = {
        "A": {"driver_name": "Juan  Perez", "station": "DFW02-BAA", "check_results": []},
        "B": {"driver_name": "Juan Perez", "station": "DFW02-BAA", "check_results": hub},
        "C": {"driver_name": "Juan Perez", "station": "DFW02-BAA", "check_results": hub},
        "D": {"driver_name": "Ana Ruiz", "station": "AUS-BAA", "check_results": []},
    }
    monkeypatch.setattr(report_server, "load_payload", lambda date, t: pods.get(t))
    monkeypatch.setattr(report_server, "render_card", lambda pod, main=0: b"png")
    monkeypatch.setattr(report_server, "WHATSAPP_OUT", tmp_path)
    monkeypatch.setattr(config, "WHATSAPP_GROUPS", {"DFW02-BAA": "GOFO DALLAS", "AUS-BAA": "GOFO AUSTIN"})
    out = report_server.whatsapp_messages("2026-10-02", [{"tracking": t} for t in "ABCD"])
    assert list(out) == ["GOFO DALLAS", "GOFO AUSTIN"]
    dallas = out["GOFO DALLAS"]
    assert [m["trackings"] for m in dallas] == [["A"], ["B", "C"]]      # Amazon Hub: una imagen con los 2
    assert dallas[0]["text"] == "Motivo: Pod Fake\nDriver: Juan Perez\nCiudad: DFW02 - BAA\nTraking: A"
    assert dallas[1]["text"].endswith("Traking: B\nC")


def test_same_driver_same_address_is_one_report(monkeypatch, tmp_path):
    # Regla del usuario 03/10: 3 paquetes en 208 Lemon Dr -> un solo reporte con los 3 trackings
    pods = {t: {"driver_name": "Gipsy Ceballos", "station": "DFW02-BAA", "check_results": [],
                "receipt_address": "ARLINGTON ARLINGTON 208 Lemon Dr"} for t in ("X1", "X2", "X3")}
    pods["Y"] = {"driver_name": "Gipsy Ceballos", "station": "DFW02-BAA", "check_results": [],
                 "receipt_address": "ARLINGTON 210 Lemon Dr"}
    monkeypatch.setattr(report_server, "load_payload", lambda date, t: pods.get(t))
    monkeypatch.setattr(report_server, "render_card", lambda pod, main=0: b"png")
    monkeypatch.setattr(report_server, "WHATSAPP_OUT", tmp_path)
    out = report_server.whatsapp_messages("2026-10-02", [{"tracking": t} for t in ("X1", "Y", "X2", "X3")])
    msgs = out["GOFO DALLAS"]
    assert [m["trackings"] for m in msgs] == [["X1", "X2", "X3"], ["Y"]]
    assert msgs[0]["text"].endswith("Traking: X1\nX2\nX3")


def _two_groups(monkeypatch, tmp_path, fail=None):
    from export import whatsapp_sender
    pods = {"A": {"driver_name": "Juan Perez", "station": "DFW02-BAA", "check_results": []},
            "B": {"driver_name": "Ana Ruiz", "station": "DFW02-BAA", "check_results": []}}
    monkeypatch.setattr(report_server, "load_payload", lambda date, t: pods.get(t))
    monkeypatch.setattr(report_server, "render_card", lambda pod, main=0: b"png")
    monkeypatch.setattr(report_server, "WHATSAPP_OUT", tmp_path)
    monkeypatch.setattr(config, "WHATSAPP_GROUPS", {"DFW02-BAA": ["GOFO DALLAS", "Paquetes (Reportes)"]})
    calls = []

    def prepare(group, items, timeout=600):
        calls.append((group, [t for _, t in items]))
        if group == fail:
            return {"ok": False, "message": "no encontré el grupo"}
        return {"ok": True, "message": f"Enviado a {group}: {len(items)} reporte(s)"}
    monkeypatch.setattr(whatsapp_sender.SENDER, "prepare", prepare)
    return calls


def test_city_with_two_groups_sends_same_reports_to_both(monkeypatch, tmp_path):
    # 19/10 (pedido del usuario): Dallas va a GOFO DALLAS y también a Paquetes (Reportes)
    calls = _two_groups(monkeypatch, tmp_path)
    res = report_server.prepare_whatsapp("2026-10-19", [{"tracking": "A"}, {"tracking": "B"}])
    assert [g for g, _ in calls] == ["GOFO DALLAS", "Paquetes (Reportes)"]
    assert calls[0][1] == calls[1][1]                       # mismas imágenes y textos
    assert res["ok"] and res["trackings"] == ["A", "B"] and res["remaining"] == []
    assert "también a Paquetes (Reportes)" in res["message"]


def test_failed_copy_still_reported_and_warns(monkeypatch, tmp_path):
    _two_groups(monkeypatch, tmp_path, fail="Paquetes (Reportes)")
    res = report_server.prepare_whatsapp("2026-10-19", [{"tracking": "A"}])
    assert res["ok"] and res["trackings"] == ["A"]         # salió al grupo principal: queda reportado
    assert "NO salió la copia a Paquetes (Reportes)" in res["message"]


def test_failed_main_group_sends_no_copy(monkeypatch, tmp_path):
    calls = _two_groups(monkeypatch, tmp_path, fail="GOFO DALLAS")
    res = report_server.prepare_whatsapp("2026-10-19", [{"tracking": "A"}])
    assert not res["ok"] and [g for g, _ in calls] == ["GOFO DALLAS"]
