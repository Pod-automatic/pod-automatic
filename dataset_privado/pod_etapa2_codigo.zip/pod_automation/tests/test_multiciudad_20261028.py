import json
import sqlite3
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from unittest.mock import MagicMock

import pytest
import config
from automation.city_dispatch import CityDispatcher
from automation.gpu_dispatch import gpu_slot
from automation.session_guard import SessionGuard,SessionCoordinationError
from tools.run_kaggle_multi import validate_sessions,worker_env


class GuardServer:
    timeout=1
    def __init__(self): self.state={}; self.fail=False; self.now=1000
    def call(self,path,body):
        assert path=='session_guard.php'
        if self.fail: raise TimeoutError('offline')
        state=self.state; mine=state.get('token')==body['token']; live=state.get('until',0)>self.now
        action=body['action']
        if action=='release':
            if mine: self.state={}
            return {'granted':False}
        granted=not (action=='renew' and (not live or not mine)) and not (live and not mine)
        if granted: self.state={'token':body['token'],'until':self.now+body['lease_s']}
        return {'granted':granted,'lease_s':body['lease_s'] if granted else 0}


def test_shared_cookies_have_exclusive_extraction_and_release(tmp_path):
    server=GuardServer();pc=SessionGuard(server,'luisvivas','pc');gpu=SessionGuard(server,'luisvivas','gpu_luis')
    try:
        assert pc.acquire()
        assert not gpu.acquire()
        pc.check()
        pc.close()
        assert gpu.acquire()
        gpu.check()
    finally: pc.close();gpu.close()


def test_old_process_cannot_renew_or_release_new_owner():
    server=GuardServer();old=SessionGuard(server,'luisvivas','pc');new=SessionGuard(server,'luisvivas','pc')
    assert old.request('acquire')
    server.now+=181
    assert new.request('acquire')
    assert not old.request('renew')
    old.request('release')
    assert server.state['token']==new.token
    new.close()


def test_expired_lease_blocks_browser_reads_and_city_switch(monkeypatch):
    from automation.portal_api import PortalAPI
    server=GuardServer();guard=SessionGuard(server,'luisvivas','gpu_luis')
    page=MagicMock();api=PortalAPI(page,sleep=lambda _:None);api.session_guard=guard
    monkeypatch.setattr(config,'MAX_RETRIES',1)
    with pytest.raises(SessionCoordinationError): api.get_sign_info('test')
    with pytest.raises(SessionCoordinationError): api.switch_station(297)
    page.evaluate.assert_not_called()


def test_cities_rotate_and_prefer_unoccupied_city(tmp_path):
    db=tmp_path/'cities.db';cities=[297,1888,1695]
    a=CityDispatcher(db,'a',cities);b=CityDispatcher(db,'b',cities)
    assert a.choose('2026-10-28')==297
    assert b.choose('2026-10-28')==1888
    a.finish('2026-10-28',297)
    assert a.choose('2026-10-28')==1695
    a.finish('2026-10-28',1695,empty=True)
    b.finish('2026-10-28',1888,empty=True)
    assert a.choose('2026-10-28')==297
    a.finish('2026-10-28',297,empty=True)
    assert b.choose('2026-10-28') is None
    # Un dia nuevo no hereda el cooldown del anterior.
    assert b.choose('2026-10-29') in cities


def test_expired_local_city_assignment_does_not_hold_work_forever(tmp_path):
    db=tmp_path/'cities.db';a=CityDispatcher(db,'a',[297]);b=CityDispatcher(db,'b',[297])
    assert a.choose('2026-10-28')==297
    with sqlite3.connect(db) as con: con.execute('UPDATE city_workers SET until=0')
    assert b.choose('2026-10-28')==297


def test_gpu_queue_enforces_two_services_and_releases_on_failure(tmp_path):
    path=str(tmp_path/'slots.db');lock=threading.Lock();active=set();peak=[0];seen=set()
    barrier=threading.Barrier(2);entered=[0]
    def work(i):
        with gpu_slot(path,['gpu0','gpu1'],5) as url:
            with lock:
                assert url not in active
                active.add(url);seen.add(url);peak[0]=max(peak[0],len(active))
                entered[0]+=1
                first_pair=entered[0]<=2
            if first_pair: barrier.wait(timeout=5)
            time.sleep(.02)
            with lock: active.remove(url)
    with ThreadPoolExecutor(max_workers=6) as pool: list(pool.map(work,range(8)))
    assert peak[0]==2 and seen=={'gpu0','gpu1'}
    with pytest.raises(ValueError):
        with gpu_slot(path,['gpu0'],1): raise ValueError('inference failed')
    with gpu_slot(path,['gpu0'],1) as url: assert url=='gpu0'


def test_gpu_capacity_allows_n_concurrent_per_service_and_no_more(tmp_path):
    path=str(tmp_path/'cap.db');lock=threading.Lock();active={}
    peak={'gpu0':0};barrier=threading.Barrier(2)
    def work(i):
        with gpu_slot(path,['gpu0'],5,capacity=2) as url:
            with lock:
                active[url]=active.get(url,0)+1;peak[url]=max(peak[url],active[url])
            if i<2: barrier.wait(timeout=5)   # los dos primeros deben coincidir dentro del servicio
            time.sleep(.02)
            with lock: active[url]-=1
    with ThreadPoolExecutor(max_workers=6) as pool: list(pool.map(work,range(8)))
    assert peak['gpu0']==2


def test_gpu_capacity_spreads_over_services_first(tmp_path):
    path=str(tmp_path/'spread.db')
    with gpu_slot(path,['gpu0','gpu1'],1,capacity=2) as a:
        with gpu_slot(path,['gpu0','gpu1'],1,capacity=2) as b:
            assert {a,b}=={'gpu0','gpu1'}


def test_stale_gpu_slots_can_be_recovered(tmp_path):
    path=str(tmp_path/'gpu.db')
    with gpu_slot(path,['gpu0'],1): pass
    with sqlite3.connect(path) as con:
        con.execute("UPDATE gpu_slots SET token='crashed',until=0")
    with gpu_slot(path,['gpu0'],1) as url: assert url=='gpu0'


def test_worker_storage_is_separate_cache_is_shared_and_only_luis_is_coordinated(tmp_path):
    a=worker_env({},'gpu_luis',tmp_path/'a.json',tmp_path,True)
    b=worker_env({},'gpu_tracking',tmp_path/'b.json',tmp_path,False)
    assert a['SESSION_FILE']!=b['SESSION_FILE'] and a['STORAGE_DIR']!=b['STORAGE_DIR']
    assert a['ANALYSIS_CACHE_PATH']==b['ANALYSIS_CACHE_PATH']
    assert a['CITY_DISPATCH_DB']==b['CITY_DISPATCH_DB']
    assert a['GOFO_SESSION_GROUP']=='luisvivas' and not b['GOFO_SESSION_GROUP']
    assert a['ANALYSIS_POOL_DB']==b['ANALYSIS_POOL_DB']
    assert a['OLLAMA_URLS'].split(',')==['http://127.0.0.1:11434','http://127.0.0.1:11435']
    assert a['VISION_FALLBACK_MODEL']=='' and a['VISION_FALLBACK_URL']==''   # 28/10: sin el 7b


def test_same_session_is_rejected_even_if_files_have_different_names(tmp_path):
    a=tmp_path/'a.json';b=tmp_path/'b.json'
    data={'cookies':[{'name':'sid','value':'same'}],'origins':[]}
    a.write_text(json.dumps(data));b.write_text(json.dumps(data))
    with pytest.raises(ValueError,match='misma sesion'): validate_sessions(a,b)
    data['cookies'][0]['value']='different';b.write_text(json.dumps(data))
    validate_sessions(a,b)


def test_both_sessions_can_use_all_four_analysis_slots_when_other_is_idle(tmp_path,monkeypatch):
    from processing.pipeline import _timed_ocr
    monkeypatch.setattr(config,'ANALYSIS_POOL_DB',str(tmp_path/'analysis.db'))
    monkeypatch.setattr(config,'ANALYSIS_POOL_SIZE',4)
    photos,seconds,stages=_timed_ocr(lambda paths,address:['read'],[],None)
    assert photos==['read'] and seconds>=0


def test_dispatch_deadline_rotates_before_exhausting_a_large_city(tmp_path,monkeypatch):
    from tests.test_cobertura_20261007 import TwoCitiesAPI,DFW
    from automation.api_extractor import ApiPODExtractor
    monkeypatch.setattr(config,'CITY_DISPATCH_DB',str(tmp_path/'cities.db'))
    monkeypatch.setattr(config,'CITY_TURN_S',.000000001)
    monkeypatch.setattr(config,'MAX_PER_DRIVER_PER_PASS',2)
    api=TwoCitiesAPI({DFW:{'Driver':100}})
    ext=ApiPODExtractor(api,images_dir=tmp_path,downloader=lambda *a:[])
    records=[];ext.run_pass([DFW],'2026-10-28',set(),records.append)
    assert len(records)==2 and ext.capped


@pytest.mark.parametrize('prefetch',[0,3])
def test_lost_coordination_never_saves_a_false_failed_pod(tmp_path,monkeypatch,prefetch):
    from tests.test_cobertura_20261007 import TwoCitiesAPI,DFW
    from automation.api_extractor import ApiPODExtractor
    api=TwoCitiesAPI({DFW:{'Driver':2}})
    def lost(_): raise SessionCoordinationError('No hay coordinacion vigente.')
    api.get_sign_info=lost
    extractor=ApiPODExtractor(api,images_dir=tmp_path,downloader=lambda *a:[])
    extractor.prefetch=prefetch
    records=[]
    with pytest.raises(SessionCoordinationError): extractor.run_pass([DFW],'2026-10-28',set(),records.append)
    assert records==[]


def test_tracking_solo_revisa_las_ciudades_indicadas_ese_dia():
    """29/10 (pedido del usuario): Tracking ya no revisa IAH fijo; revisa lo indicado en la celda 4."""
    from tools.run_kaggle_multi import tracking_stations
    assert tracking_stations({'TRACKING_STATIONS': 'dfw-baa, DFW02-BAA,DFW-BAA'}) == 'DFW-BAA,DFW02-BAA'
    assert tracking_stations({'TRACKING_STATIONS': 'IAH-BAA'}) == 'IAH-BAA'
    with pytest.raises(ValueError, match='Falta TRACKING_STATIONS'):
        tracking_stations({})
    with pytest.raises(ValueError, match='DFW2-BAA'):
        tracking_stations({'TRACKING_STATIONS': 'DFW-BAA,DFW2-BAA'})    # error de tipeo: no se revisa otra cosa en silencio


def test_cada_cuenta_de_kaggle_puede_correr_una_sola_sesion():
    """29/10 (pedido del usuario): Kaggle Luis y Kaggle Trackingint, cada una con la maquina completa."""
    from tools.run_kaggle_multi import selected_sessions
    assert selected_sessions({}) == ['luis', 'tracking']                    # como antes: las dos
    assert selected_sessions({'MULTI_SESSIONS': 'luis'}) == ['luis']
    assert selected_sessions({'MULTI_SESSIONS': ' Tracking '}) == ['tracking']
    with pytest.raises(ValueError, match='MULTI_SESSIONS'):
        selected_sessions({'MULTI_SESSIONS': 'trackingint'})


def test_notebook_por_cuenta_fija_su_sesion(tmp_path):
    import importlib.util, re
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    spec = importlib.util.spec_from_file_location('emp', root / 'deploy/kaggle/empaquetar_etapa2.py')
    emp = importlib.util.module_from_spec(spec); spec.loader.exec_module(emp)
    for sesion in ('luis', 'tracking'):
        nb = emp.write_notebook(tmp_path, 'notebook_multiciudad.py', f'{sesion}.ipynb', f'celdas_{sesion}',
                                replace={"SESION='luis,tracking'": f"SESION='{sesion}'"})
        cell1 = (tmp_path / f'celdas_{sesion}' / 'celda_1.py').read_text(encoding='utf-8')
        assert f"SESION='{sesion}'" in cell1 and "SESION='luis,tracking'" not in nb.read_text(encoding='utf-8')
    with pytest.raises(ValueError):
        emp.write_notebook(tmp_path, 'notebook_multiciudad.py', 'x.ipynb', replace={'NO EXISTE': 'x'})
