from models.pod import PODRecord
from processing.ocr_address import PhotoOCR
from processing.scoring import _locker_screen_unit, score_pod

# Caso real 18/10 (GFUS01077974640514 / GFUS01078146078480, 9590 Eden Rd Apt 6301): kiosco Luxer en español; la unidad
# sale con guion ("6-301"). Era un falso Media "números lejanos (5, E04)".
PANTALLA = ("Destinatario Atrás Seleccione la coincidencia de destinatarios 6 Resultados Yashma Masoom 9590 Eden Road "
            "6-301 Shahzaib Chaudry 9590 Eden Road 6-301 > Jaylin McElroy 9586 Eden Road 4-301 > No Match")


def _pod():
    pod = PODRecord(tracking_number="T", receipt_address="Arlington Arlington 9590 Eden Rd Apt 6301", driver_name="X",
                    station="DFW02-BAA", billing_type="En la puerta/Patio")
    pod.photo_paths = ["k.jpg", "s.jpg", "b.jpg", "l.jpg"]
    return pod


def _fotos(texto=PANTALLA):
    return [PhotoOCR(path="k.jpg", text=texto, numbers=["9590", "6", "301"], number_conf={"9590": 90.0}),
            PhotoOCR(path="s.jpg", text="5 GOFO HT E04 cVo EA", numbers=["5"], number_conf={"5": 80.0}),
            PhotoOCR(path="b.jpg", text="9 102-6418 9590", numbers=["9", "1026418", "9590"],
                     number_conf={"9": 70.0, "1026418": 70.0, "9590": 90.0}),
            PhotoOCR(path="l.jpg", is_label=True)]


def test_pantalla_luxer_con_unidad_con_guion_es_la_misma_unidad():
    assert _locker_screen_unit(_pod(), _fotos()) == "same"


def test_casillero_luxer_en_espanol_no_es_media():
    pod = _pod()
    score_pod(pod, _fotos())
    assert pod.priority == "Baja"


def test_pantalla_con_otra_unidad_con_guion_no_se_omite():
    otra = PANTALLA.replace("6-301", "6-305")
    assert _locker_screen_unit(_pod(), _fotos(otra)) == "other"


# Caso real 19/10 (GFUS01077635241858, 3500 Northstar Rd #814, Richardson): kiosco "Select a locker size" sin la unidad;
# el "21 available" (casilleros libres) se tomaba como OTRA unidad y el casillero no se omitía (falso Media).
KIOSCO_NORTHSTAR = ("19735 Select a lockersize Ratikelabieonoto Match Fatima Bano Muhammad Obaid Pau 3500 Northstar R. "
                    "21 availabie Medium Add Another Package Small for Same Customer 1 avatlable XLarge")


def _northstar():
    pod = PODRecord(tracking_number="T", receipt_address="RICHARDSON RICHARDSON 3500 Northstar Rd #814", driver_name="X",
                    station="DFW02-BAA", billing_type="En la puerta/Patio")
    pod.photo_paths = ["k.jpg", "s.jpg", "l.jpg"]
    fotos = [PhotoOCR(path="k.jpg", text=KIOSCO_NORTHSTAR, numbers=["19735", "3500", "21", "1"],
                      number_conf={"19735": 80.0, "3500": 90.0, "21": 90.0}),
             PhotoOCR(path="s.jpg", text="Q020 5022416A1", numbers=["5022416"], number_conf={"5022416": 70.0}),
             PhotoOCR(path="l.jpg", is_label=True)]
    return pod, fotos


def test_contador_de_casilleros_libres_no_es_otra_unidad():
    pod, fotos = _northstar()
    assert _locker_screen_unit(pod, fotos) is None


def test_kiosco_select_locker_size_no_es_media():
    pod, fotos = _northstar()
    score_pod(pod, fotos)
    assert pod.priority == "Baja"


def test_ubicacion_del_numero_no_la_corta_el_tope_del_albaran(monkeypatch):
    # 20/10: con las 5 consultas del albarán gastadas, la pregunta "¿dónde está el 259?" (escrito a mano en la etiqueta)
    # no se hacía y quedaba "dos puertas" (Alta). Casos 801 Edgewood Dr (259) y 761 Private Rd (258).
    import importlib.util
    import config
    from processing import vision_llm as real
    # Copia aparte del módulo: conftest reemplaza number_location por una versión sin modelo
    spec = importlib.util.spec_from_file_location("vision_llm_copia", real.__file__)
    vision_llm = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(vision_llm)
    sent = []
    monkeypatch.setattr(config, "VISION_MAX_CALLS_PER_POD", 5)
    monkeypatch.setattr(vision_llm, "_image_b64", lambda *a, **k: "img")
    monkeypatch.setattr(vision_llm, "_post_generate", lambda body, timeout: sent.append(body) or '{"where": "label"}')
    vision_llm.start_capped()
    vision_llm.STATS["llamadas_vision"] = 5
    try:
        assert vision_llm.number_location("x.jpg", "259") == "label"
        assert "_sin_tope" not in sent[0]                          # no se manda a Ollama
        try:
            vision_llm.read_photo("x.jpg")                          # las lecturas sí siguen con tope
        except vision_llm.VisionCapped:
            pass
        assert len(sent) == 1
    finally:
        vision_llm.stop_capped()
        vision_llm.reset_stats()


def test_county_road_con_sigla_del_condado_no_es_unidad():
    # Caso real 20/10 (GFUS01078322562945, Doris Arevalo): "1200 Vz County Road 3119" (VZ = Van Zandt)
    from processing.ocr_address import parse_us_address
    a = parse_us_address("Edgewood Edgewood 1200 Vz County Road 3119")
    assert a.house_number == "1200" and not a.unit
    assert parse_us_address("Edgewood 1200 VZ County Rd 3119").unit in (None, "")
    assert parse_us_address("Plano 1000 Murray Farm Rd 619").unit == "619"     # nombre propio: sigue siendo unidad
