"""29/10: veredicto de cuello de botella de Kaggle a partir de las muestras por minuto."""
import json
import sqlite3
import time
import zipfile
from datetime import datetime, timedelta, timezone

from tools.cuello_kaggle import evaluate, evaluate_bundle, format_report, informe_cuello
from tools.kaggle_diagnostico import sample, _slot_busy


def _rows(n=10, gpu=(10, 10), cpu=30.0, hot=0, vision=20.0, analysis=40.0):
    t0 = datetime(2026, 10, 29, 20, 0, tzinfo=timezone.utc)
    return [{'time_utc': (t0 + timedelta(minutes=i)).isoformat(),
             'gpus': [{'gpu': k, 'util_pct': u, 'mem_used_mib': 6000, 'mem_total_mib': 15360} for k, u in enumerate(gpu)],
             'cpu': {'logicas': 4, 'cpu_pct': cpu, 'nucleos_calientes': hot, 'nucleo_max_pct': cpu, 'ram_pct': 50},
             'top': {'python': cpu},
             'occupancy': {'vision': {'http://127.0.0.1:11434': {'ocupado_pct': vision, 'cupos': 2}},
                           'analysis': {'analysis-0': {'ocupado_pct': analysis, 'cupos': 4}}}} for i in range(n)]


def test_cpu_saturada_es_el_limite_aunque_la_gpu_este_libre():
    r = evaluate(_rows(cpu=92, hot=4, gpu=(5, 8), analysis=95))
    assert r['veredicto'] == 'cpu' and 'Más GPU no ayuda' in r['texto']


def test_gpu_o_cola_de_vision_saturada():
    assert evaluate(_rows(gpu=(95, 40)))['veredicto'] == 'gpu'
    assert evaluate(_rows(vision=97))['veredicto'] == 'gpu'


def test_analisis_ocupado_sin_gpu_ni_cpu_saturadas_espera_algo_externo():
    assert evaluate(_rows(analysis=96))['veredicto'] == 'analisis_espera'


def test_analisis_ocioso_significa_que_falta_trabajo():
    r = evaluate(_rows(analysis=12))
    assert r['veredicto'] == 'sin_trabajo' and '12 %' in r['texto']


def test_sin_muestras_no_inventa_un_veredicto():
    assert evaluate([])['veredicto'] == 'sin_datos'
    assert 'Sin muestras' in format_report(evaluate([]))


def test_solo_cuenta_la_ventana_pedida():
    rows = _rows(n=30, analysis=10)
    for r in rows[:15]:      # los primeros 15 min estaban saturados, los últimos 10 no
        r['occupancy']['analysis']['analysis-0']['ocupado_pct'] = 99
    assert evaluate(rows, ventana_min=10)['veredicto'] == 'sin_trabajo'
    assert evaluate(rows, ventana_min=30)['analisis_ocupado_pct'] > 50


def test_ritmo_de_extraccion_y_analisis_por_hora():
    rows = _rows()
    end = datetime(2026, 10, 29, 20, 9, tzinfo=timezone.utc)
    thr = [{'ts': (end - timedelta(minutes=m)).isoformat(), 'status': 'PROCESSED'} for m in range(0, 10)] + \
          [{'ts': (end - timedelta(minutes=m)).isoformat(), 'status': 'ANALYZED'} for m in range(0, 5)] + \
          [{'ts': (end - timedelta(minutes=40)).isoformat(), 'status': 'ANALYZED'}]      # fuera de la ventana
    r = evaluate(rows, thr, ventana_min=10)
    assert r['ritmo_por_hora'] == {'extraidos': 60, 'analizados': 30}
    assert '60 extraídos/h y 30 analizados/h' in format_report(r)


def test_zip_descargado_se_analiza_igual(tmp_path):
    rows = _rows(analysis=12)
    zpath = tmp_path / 'diagnostico_kaggle.zip'
    with zipfile.ZipFile(zpath, 'w') as z:
        z.writestr('metricas.jsonl', '\n'.join(json.dumps(r) for r in rows))
        z.writestr('workers/gpu_luis/throughput.jsonl', json.dumps({'ts': rows[-1]['time_utc'], 'status': 'PROCESSED'}))
    assert evaluate_bundle(zpath, 10)['veredicto'] == 'sin_trabajo'


def test_informe_en_vivo_lee_muestras_y_ritmo_de_cada_sesion(tmp_path):
    metrics = tmp_path / 'diag' / 'metricas.jsonl'; metrics.parent.mkdir()
    metrics.write_text('\n'.join(json.dumps(r) for r in _rows(analysis=12)))
    worker = tmp_path / 'storage' / 'multi' / 'workers' / 'gpu_luis'; worker.mkdir(parents=True)
    (worker / 'throughput.jsonl').write_text(json.dumps({'ts': _rows()[-1]['time_utc'], 'status': 'ANALYZED'}) + '\n')
    text = informe_cuello(metrics, tmp_path, 10)
    assert 'VEREDICTO' in text and 'analizados/h' in text


def test_ocupacion_de_la_cola_se_lee_de_sqlite(tmp_path):
    db = tmp_path / 'gpu_slots.db'
    con = sqlite3.connect(db)
    con.execute('CREATE TABLE gpu_slots(url TEXT PRIMARY KEY,token TEXT,until REAL,last_used REAL)')
    now = time.time()
    con.executemany('INSERT INTO gpu_slots VALUES (?,?,?,?)',
                    [('http://a', 'x', now + 50, now), ('http://a#1', None, 0, 0), ('http://b', 'y', now + 50, now)])
    con.commit(); con.close()
    assert _slot_busy(db) == {'http://a': (1, 2), 'http://b': (1, 1)}
    assert _slot_busy(tmp_path / 'no_existe.db') == {}


def test_la_muestra_incluye_cpu_por_nucleo_y_ocupacion_sin_fallar_sin_gpu(tmp_path):
    shared = tmp_path / 'storage' / 'multi'; shared.mkdir(parents=True)
    con = sqlite3.connect(shared / 'analysis_pool.db')
    con.execute('CREATE TABLE gpu_slots(url TEXT PRIMARY KEY,token TEXT,until REAL,last_used REAL)')
    con.execute('INSERT INTO gpu_slots VALUES (?,?,?,?)', ('analysis-0', 'x', time.time() + 99, time.time()))
    con.commit(); con.close()
    def sin_nvidia(*a, **k): raise FileNotFoundError('nvidia-smi')
    row = sample(tmp_path, ['gpu_luis'], runner=sin_nvidia, activity=lambda w: {}, burst=3, gap=0.05)
    assert row['gpus'] == [] and 'nucleo_max_pct' in row['cpu'] and 'nucleos_calientes' in row['cpu']
    assert row['occupancy']['analysis']['analysis-0']['ocupado_pct'] == 100.0
