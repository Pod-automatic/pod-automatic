"""
Paso 4: scraping respetuoso. Backoff con jitter, detección de sesión vencida durante la
corrida, medición de throughput y retoma del modo continuo desde el checkpoint. Todo con mocks.
"""

import random
from unittest.mock import MagicMock

import pytest

import config
from automation.browser import SessionExpiredError
from automation.politeness import backoff_delay, retry_with_backoff, ThroughputTracker
from automation.pod_scraper import PODScraper
from models.pod import PODRecord, ProcessingStatusEnum

PORTAL = "https://dms.gofoexpress.com/gofo-report/report/reportCenter/siteDashboardUs"
LOGIN = "https://dms.gofoexpress.com/login"


# ---------------------------------------------------------------- backoff con jitter

def test_backoff_grows_exponentially_within_jitter_bounds():
    rng = random.Random(42)
    for attempt, expected in [(1, 2.0), (2, 4.0), (3, 8.0), (4, 16.0)]:
        for _ in range(200):
            d = backoff_delay(attempt, base=2.0, cap=60.0, rng=rng)
            assert expected / 2 <= d <= expected, (attempt, d)


def test_backoff_is_capped():
    rng = random.Random(1)
    delays = [backoff_delay(20, base=2.0, cap=60.0, rng=rng) for _ in range(200)]
    assert max(delays) <= 60.0 and min(delays) >= 30.0


def test_backoff_has_real_jitter():
    rng = random.Random(7)
    delays = {round(backoff_delay(3, base=2.0, cap=60.0, rng=rng), 4) for _ in range(50)}
    assert len(delays) > 40  # No todas iguales: reintentos no sincronizados


def test_retry_succeeds_after_transient_failures_and_sleeps_between():
    calls, sleeps = [], []

    def flaky():
        calls.append(1)
        if len(calls) < 3:
            raise TimeoutError("portal lento")
        return "ok"

    result = retry_with_backoff(flaky, max_attempts=3, sleep=sleeps.append, rng=random.Random(0))
    assert result == "ok"
    assert len(calls) == 3
    assert len(sleeps) == 2
    assert 1.0 <= sleeps[0] <= 2.0 and 2.0 <= sleeps[1] <= 4.0


def test_retry_exhausted_raises_last_error_without_final_sleep():
    sleeps = []

    def always_fails():
        raise ValueError("boom")

    with pytest.raises(ValueError, match="boom"):
        retry_with_backoff(always_fails, max_attempts=3, sleep=sleeps.append)
    assert len(sleeps) == 2  # No espera después del último intento


def test_session_expired_is_never_retried():
    calls, sleeps = [], []

    def expired():
        calls.append(1)
        raise SessionExpiredError("vencida")

    with pytest.raises(SessionExpiredError):
        retry_with_backoff(expired, max_attempts=5, sleep=sleeps.append)
    assert calls == [1] and sleeps == []


# ---------------------------------------------------------------- scraper con mocks

def _mock_scraper(rows, open_detail, checkpoint=None):
    bm = MagicMock()
    bm.page.url = PORTAL
    sleeps = []
    scraper = PODScraper(bm, throughput=ThroughputTracker(), sleep=sleeps.append, portal_url=PORTAL)
    scraper.get_currently_visible_rows = lambda: rows
    scraper.extract_row_summary = lambda r: PODRecord(tracking_number=r)
    scraper.open_pod_detail = lambda r: open_detail(bm, r)
    scraper._get_scrollable_table_element = lambda: None
    scraper._scroll_next_batch = lambda c: False
    scraper._go_to_next_page = lambda: False
    scraper.close_pod_detail = lambda: None
    return scraper, bm, sleeps


def test_scraper_stops_when_session_expires_mid_run():
    def open_detail(bm, row):
        if row == "GF2":
            bm.page.url = LOGIN  # El portal redirige al login al abrir el 2º albarán
        return None

    ckpt = MagicMock()
    scraper, bm, sleeps = _mock_scraper(["GF1", "GF2", "GF3"], open_detail)
    with pytest.raises(SessionExpiredError, match="main.py login"):
        scraper.scrape_all_pods(query_date="2026-09-29", checkpoint_manager=ckpt, session_id="s1")

    saved = [c.args[1].tracking_number for c in ckpt.save_pod_checkpoint.call_args_list]
    assert saved == ["GF1"]                       # GF1 quedó en checkpoint; GF2/GF3 no
    assert bm.session_valid is False              # No se re-guarda la sesión vencida
    assert sleeps == [config.REQUEST_DELAY_S]     # Solo la pausa tras GF1; ningún backoff


def test_scraper_detects_expired_session_before_first_pod():
    scraper, bm, _ = _mock_scraper(["GF1"], lambda bm, r: None)
    bm.page.url = LOGIN
    with pytest.raises(SessionExpiredError):
        scraper.scrape_all_pods(query_date="2026-09-29")


def test_scraper_retries_with_backoff_then_succeeds():
    attempts = {"GF1": 0}

    def open_detail(bm, row):
        attempts[row] += 1
        if attempts[row] == 1:
            raise TimeoutError("modal no abrió")
        return None

    scraper, _, sleeps = _mock_scraper(["GF1"], open_detail)
    records = scraper.scrape_all_pods(query_date="2026-09-29")
    assert attempts["GF1"] == 2
    assert records[0].processing_status != ProcessingStatusEnum.FAILED
    backoff = config.RETRY_BASE_DELAY_S
    assert backoff / 2 <= sleeps[0] <= backoff     # 1 espera de backoff...
    assert sleeps[1] == config.REQUEST_DELAY_S     # ...y la pausa de cortesía
    assert len(scraper.throughput.durations) == 1


def test_scraper_marks_failed_after_retries_and_continues():
    def open_detail(bm, row):
        if row == "GF1":
            raise TimeoutError("siempre falla")
        return None

    scraper, _, sleeps = _mock_scraper(["GF1", "GF2"], open_detail)
    records = scraper.scrape_all_pods(query_date="2026-09-29")
    by_trk = {r.tracking_number: r for r in records}
    assert by_trk["GF1"].processing_status == ProcessingStatusEnum.FAILED
    assert by_trk["GF2"].processing_status != ProcessingStatusEnum.FAILED
    assert len(sleeps) == (config.MAX_RETRIES - 1) + 2  # backoffs de GF1 + 2 pausas


# ---------------------------------------------------------------- throughput

def test_throughput_projection_math_and_log_roundtrip(tmp_path):
    log = tmp_path / "t.jsonl"
    tracker = ThroughputTracker(log_path=log)
    for i, s in enumerate([3.0, 3.0, 4.0, 2.0]):
        tracker.record(f"GF{i}", s, "PROCESSED")
    p = tracker.projection(daily_target=24000)
    assert p["avg_seconds"] == 3.0
    assert p["per_hour"] == 1200.0
    assert p["per_day"] == 28800
    assert p["coverage_pct"] == 120.0 and p["sampling_needed"] is False

    reloaded = ThroughputTracker.from_log(log)
    assert reloaded.projection(daily_target=24000) == p
    assert ThroughputTracker(durations=[10.0]).projection(24000)["sampling_needed"] is True


# ---------------------------------------------------------------- modo continuo

def _patch_continuous(monkeypatch, tmp_path, portal_batches, login_raises=False):
    import main
    from storage.checkpoint_manager import CheckpointManager

    db = tmp_path / "c.db"
    monkeypatch.setattr(main, "CheckpointManager", lambda: CheckpointManager(db_path=db))
    monkeypatch.setattr(main.config, "THROUGHPUT_LOG_PATH", tmp_path / "t.jsonl")
    monkeypatch.setattr(main.config, "EXTRACTION_MODE", "ui")
    monkeypatch.setattr(main, "AuditLogger", lambda **kw: MagicMock())
    from export.excel_exporter import PODExcelExporter
    monkeypatch.setattr(main, "PODExcelExporter", lambda: PODExcelExporter(output_dir=tmp_path))  # No tocar output/ real  # No escribir en storage/logs real
    monkeypatch.setattr(main, "BrowserManager", lambda **kw: MagicMock())
    monkeypatch.setattr(main, "DashboardManager", lambda bm: MagicMock())

    login = MagicMock()
    if login_raises:
        login.require_valid_session.side_effect = SessionExpiredError("vencida: python main.py login")
    monkeypatch.setattr(main, "LoginManager", lambda bm: login)

    class FakeScraper:
        def __init__(self, bm, throughput=None):
            pass

        def scrape_all_pods(self, query_date, checkpoint_manager, session_id, preloaded_records, **kw):
            records = list(preloaded_records)
            seen = {p.tracking_number for p in records}
            for trk in portal_batches.pop(0):
                if trk not in seen:
                    pod = PODRecord(tracking_number=trk, address="100 Main St, Dallas, TX")
                    checkpoint_manager.save_pod_checkpoint(session_id, pod)
                    records.append(pod)
            return records

    monkeypatch.setattr(main, "PODScraper", FakeScraper)
    return main, db


def test_continuous_processes_only_new_pods_and_resumes_after_restart(monkeypatch, tmp_path):
    # El portal va mostrando albaranes nuevos; la corrida se "corta" tras 2 pasadas y se reinicia.
    batches = [["GF1", "GF2"], ["GF1", "GF2", "GF3"], ["GF1", "GF2", "GF3", "GF4"]]
    main, db = _patch_continuous(monkeypatch, tmp_path, batches)
    sleeps = []

    main.run_continuous_workflow(poll_interval=300, max_passes=2, sleep=sleeps.append)
    main.run_continuous_workflow(poll_interval=300, max_passes=1, sleep=sleeps.append)  # reinicio

    from storage.checkpoint_manager import CheckpointManager
    import sqlite3
    with sqlite3.connect(db) as conn:
        sessions = conn.execute("SELECT session_id, status FROM audit_sessions").fetchall()
        trks = [r[0] for r in conn.execute("SELECT tracking_number FROM pod_checkpoints ORDER BY tracking_number")]
    assert len(sessions) == 1 and sessions[0][1] == "IN_PROGRESS"  # Mismo día → misma sesión
    assert trks == ["GF1", "GF2", "GF3", "GF4"]                    # Sin duplicados
    assert sleeps == [300]                                         # Solo entre pasada 1 y 2


def test_continuous_stops_with_exit_2_when_session_expired(monkeypatch, tmp_path):
    main, _ = _patch_continuous(monkeypatch, tmp_path, [["GF1"]], login_raises=True)
    with pytest.raises(SystemExit) as exc:
        main.run_continuous_workflow(poll_interval=1, max_passes=1, sleep=lambda s: None)
    assert exc.value.code == 2


def test_throughput_log_keeps_extraction_and_analysis_apart(tmp_path):
    log = tmp_path / "t.jsonl"
    tracker = ThroughputTracker(log_path=log, analysis_workers=2)
    tracker.record("GF1", 3.0, "PROCESSED")
    tracker.record("GF1", 10.0, "ANALYZED", stage="analisis")
    reloaded = ThroughputTracker.from_log(log)
    assert reloaded.durations == [3.0] and reloaded.analysis_durations == [10.0]
    assert tracker.projection(24000)["analysis_per_hour"] == 720.0  # 2 workers × 3600 / 10
