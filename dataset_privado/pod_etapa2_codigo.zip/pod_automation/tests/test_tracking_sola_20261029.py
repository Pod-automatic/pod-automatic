"""29/10: Tracking sola en DFW02 pasaba 5 min sin sacar nada (con 2.345 disponibles) y luego quedaba 2 min en pausa.

1. Con una sola ciudad y sin sesion compartida, la pasada no se corta cada CITY_TURN_S (solo relistaba).
2. Los albaranes negados por el reparto (los tiene otra corrida) cuentan como vistos para elegir repartidor.
"""
import config
from automation.api_extractor import ApiPODExtractor
from tests.test_api_extractor import FakeAPI, _fake_downloader


def _setup(monkeypatch):
    monkeypatch.setattr(config, 'GOFO_SESSION_GROUP', '')
    monkeypatch.setattr(config, 'CITY_DISPATCH_DB', 'cities.db')   # Kaggle siempre lo tiene
    monkeypatch.setattr(config, 'ROUTES_PER_BLOCK', 1)
    monkeypatch.setattr(config, 'ROUTE_LIST_CACHE_S', 0)


def _listed(tmp_path, api_cls=FakeAPI, **attrs):
    api = api_cls(); real = api.iter_waybills; calls = []
    api.iter_waybills = lambda *a, **k: (calls.append(a[2]['userId']), (yield from real(*a, **k)))[1]
    ext = ApiPODExtractor(api, images_dir=tmp_path, downloader=_fake_downloader)
    for k, v in attrs.items():
        setattr(ext, k, v)
    ext.run_pass([1888], '2026-10-29', set(), lambda p: None)
    return calls, ext


def test_una_sola_ciudad_no_corta_la_pasada_por_turno(tmp_path, monkeypatch):
    _setup(monkeypatch)
    monkeypatch.setattr(config, 'CITY_TURN_S', 1e-9)
    calls, ext = _listed(tmp_path, rotate=False)
    assert calls == [1, 2] and not ext.capped
    calls, ext = _listed(tmp_path, rotate=True)                 # varias ciudades: sigue rotando como antes
    assert calls == [1] and ext.capped


class WithPods(FakeAPI):
    def list_couriers(self, station_id, date_iso):
        return [{"driverName": "Driver A", "userId": 1, "podPieces": 2},
                {"driverName": "Driver B", "userId": 2, "podPieces": 2}]


def test_lo_que_tiene_otra_corrida_cuenta_como_visto(tmp_path, monkeypatch):
    _setup(monkeypatch)
    monkeypatch.setattr(config, 'CITY_TURN_S', 1e9)
    calls, _ = _listed(tmp_path, WithPods)
    assert calls[0] == 1                                        # sin datos: el primero de la lista
    calls, _ = _listed(tmp_path, WithPods, _taken={'1': {'GF101', 'GF103'}})
    assert calls[0] == 2                                        # A lo tiene otra corrida: primero B


def test_negados_se_anotan_por_repartidor_y_salen_al_concederse(tmp_path, monkeypatch):
    _setup(monkeypatch)
    monkeypatch.setattr(config, 'CITY_TURN_S', 1e9)
    granted = set()
    calls, ext = _listed(tmp_path, claim_fn=lambda t, done: [x for x in t if x in granted])
    assert ext._taken == {'1': {'GF101', 'GF103'}, '2': {'GF201', 'GF203'}}
    granted.add('GF101')                                        # la otra corrida lo solto: ahora es de esta
    ext._claim(['GF101'])
    assert ext._taken['1'] == {'GF103'}


class LongRoutes(FakeAPI):
    """Dos rutas de 12 albaranes con POD; las 10 primeras de cada una ya las hizo otra corrida."""
    def iter_waybills(self, station_id, date_iso, courier, page_size=50):
        from automation.api_extractor import WaybillSummary
        n = courier["userId"]
        for i in range(1, 13):
            yield WaybillSummary(waybill_no=f"GF{n}{i:02d}", sign_id=f"s{n}{i:02d}", driver_name=courier["driverName"])


def test_ruta_con_el_inicio_ya_hecho_no_pierde_su_turno(tmp_path, monkeypatch):
    _setup(monkeypatch)
    monkeypatch.setattr(config, 'CITY_TURN_S', 1e9)
    monkeypatch.setattr(config, 'CLAIM_BATCH_SIZE', 5)
    monkeypatch.setattr(config, 'MAX_PER_DRIVER_PER_PASS', 5)
    order = []
    api = LongRoutes(); real = api.iter_waybills
    api.iter_waybills = lambda *a, **k: (order.append(('lista', a[2]['userId'])), (yield from real(*a, **k)))[1]
    ext = ApiPODExtractor(api, images_dir=tmp_path, downloader=_fake_downloader)
    ext.claim_fn = lambda t, done: [x for x in t if int(x[-2:]) > 10]
    ext._process = lambda courier, w, d: (order.append(('revisa', w.waybill_no)), ext.build_record(courier, w, d))[1]
    ext.run_pass([1888], '2026-10-29', set(), lambda p: None)
    # Antes: listaba la ruta 2 tras el primer bloque negado de la 1. Ahora revisa lo libre de la 1 antes de listar la 2.
    assert order.index(('revisa', 'GF111')) < order.index(('lista', 2))
