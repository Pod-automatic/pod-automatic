"""30/10: pasada la medianoche se sigue con lo pendiente del día anterior hasta que el nuevo tenga entregas."""
from datetime import datetime
from zoneinfo import ZoneInfo

import pytest

import config
from automation.day_carry import DayCarry

TZ = ZoneInfo("America/Caracas")


class Clock:
    def __init__(self):
        self.t = 0.0
        self.now = datetime(2026, 10, 30, 0, 16, tzinfo=TZ)

    def mono(self):
        return self.t


@pytest.fixture(autouse=True)
def _on(monkeypatch):
    monkeypatch.setattr(config, "DAY_CARRY_OVER", True)
    monkeypatch.setattr(config, "DAY_CARRY_UNTIL_H", 12)
    monkeypatch.setattr(config, "DAY_CARRY_PROBE_S", 600)


def _carry(work):
    c = Clock()
    probes = []

    def has_work(day):
        probes.append(day)
        return work[0]

    return DayCarry(has_work, now=lambda: c.now, clock=c.mono), c, probes


def test_a_medianoche_sigue_el_dia_anterior_y_pasa_cuando_el_nuevo_tiene_entregas():
    work = [False]
    dc, c, probes = _carry(work)
    assert dc.pick("2026-10-29", lambda d: True) == "2026-10-29" and dc.active("2026-10-29")
    c.t = 300
    assert dc.pick("2026-10-29", lambda d: True) == "2026-10-29" and probes == ["2026-10-30"]   # Mira cada 10 min, no siempre
    work[0] = True
    c.t = 601
    assert dc.pick("2026-10-29", lambda d: True) == "2026-10-30" and not dc.active("2026-10-29")
    assert dc.pick("2026-10-30", lambda d: True) == "2026-10-30"                              # No vuelve atrás


def test_sin_trabajo_del_anterior_pasa_al_nuevo_y_no_vuelve():
    dc, c, _ = _carry([False])
    assert dc.pick("2026-10-29", lambda d: True) == "2026-10-29"
    assert dc.stop("sin trabajo") == "2026-10-30"
    assert dc.pick("2026-10-29", lambda d: True) == "2026-10-30"


def test_al_mediodia_termina():
    dc, c, _ = _carry([False])
    assert dc.pick("2026-10-29", lambda d: True) == "2026-10-29"
    c.now = c.now.replace(hour=12)
    assert dc.pick("2026-10-29", lambda d: True) == "2026-10-30"


def test_relanzada_de_madrugada_sigue_el_anterior_si_no_esta_cerrado():
    dc, _, _ = _carry([False])
    assert dc.pick(None, lambda d: True) == "2026-10-29"
    closed, _, _ = _carry([False])
    assert closed.pick(None, lambda d: False) == "2026-10-30"   # Día anterior ya cerrado en este equipo: no se reabre


def test_de_dia_o_apagado_es_como_antes(monkeypatch):
    dc, c, probes = _carry([False])
    c.now = c.now.replace(hour=14)
    assert dc.pick(None, lambda d: True) == "2026-10-30" and probes == []
    monkeypatch.setattr(config, "DAY_CARRY_OVER", False)
    dc2, _, probes2 = _carry([False])
    assert dc2.pick("2026-10-29", lambda d: True) == "2026-10-30" and probes2 == []


@pytest.mark.parametrize("pods,day", [(0, "2026-10-27"), (50, "2026-10-28")])
def test_corrida_continua_sigue_el_anterior_hasta_que_el_nuevo_tiene_entregas(tmp_path, monkeypatch, pods, day):
    import sqlite3
    from datetime import timedelta, timezone
    from unittest.mock import MagicMock
    from tests.test_step4_politeness import _patch_continuous
    main, db = _patch_continuous(monkeypatch, tmp_path, [['OLD'], ['NEW']])
    now = [datetime(2026, 10, 27, 23, 59, tzinfo=timezone(timedelta(hours=-4)))]
    monkeypatch.setattr(main, 'operation_now', lambda: now[0])
    api = MagicMock()
    api.list_couriers.return_value = [{"podPieces": pods}]
    monkeypatch.setattr(main, 'PortalAPI', lambda page: api)

    def next_day(seconds):
        now[0] = datetime(2026, 10, 28, 0, 30, tzinfo=timezone(timedelta(hours=-4)))
    main.run_continuous_workflow(1, max_passes=2, sleep=next_day)
    with sqlite3.connect(db) as con:
        got = con.execute("SELECT s.query_date FROM pod_checkpoints p JOIN audit_sessions s ON s.session_id=p.session_id "
                          "WHERE p.tracking_number='NEW'").fetchone()[0]
    assert got == day   # Sin entregas del 28: NEW se guarda en el 27; con entregas, en el 28


def test_si_no_se_puede_consultar_sigue_el_anterior():
    c = Clock()
    dc = DayCarry(lambda day: (_ for _ in ()).throw(RuntimeError("sin red")), now=lambda: c.now, clock=c.mono)
    assert dc.pick("2026-10-29", lambda d: True) == "2026-10-29"
