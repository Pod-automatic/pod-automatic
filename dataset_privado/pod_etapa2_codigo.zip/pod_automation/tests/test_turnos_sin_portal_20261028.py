"""28/10: si el portal no responde GOFO_SESSION_OFFLINE_S, la PC sigue sola con la sesion; Kaggle nunca."""
import time

import pytest

import config
from automation import session_guard
from automation.session_guard import SessionGuard, SessionCoordinationError, offline_fallback_allowed


class _Portal:
    def __init__(self, answers):
        self.answers = list(answers)

    def call(self, path, body):
        a = self.answers.pop(0) if self.answers else TimeoutError('sin conexion')
        if isinstance(a, Exception):
            raise a
        return a


@pytest.fixture(autouse=True)
def clean_outage(monkeypatch):
    monkeypatch.setattr(session_guard, 'OUTAGE_SINCE', [None])
    monkeypatch.setattr(session_guard, 'SEEN_LEASE', [0])
    monkeypatch.setattr(session_guard, 'CONFLICT', [None])
    monkeypatch.setattr(config, 'GOFO_SESSION_LEASE_S', 180)
    monkeypatch.setattr(config, 'GOFO_SESSION_OFFLINE_S', 210)


def test_pc_continues_only_after_the_offline_window(monkeypatch):
    monkeypatch.setattr(config, 'CLAIM_WORKER', 'pc')
    monkeypatch.setattr(session_guard, 'OUTAGE_SINCE', [time.monotonic() - 100])
    assert not offline_fallback_allowed(TimeoutError('x'))
    monkeypatch.setattr(session_guard, 'OUTAGE_SINCE', [time.monotonic() - 215])
    assert offline_fallback_allowed(TimeoutError('x'))
    assert not offline_fallback_allowed(RuntimeError('HTTP 401: Clave de API invalida.'))


def test_kaggle_never_continues_without_portal(monkeypatch):
    monkeypatch.setattr(config, 'CLAIM_WORKER', 'gpu_luis')
    monkeypatch.setattr(session_guard, 'OUTAGE_SINCE', [time.monotonic() - 4000])
    assert not offline_fallback_allowed(TimeoutError('x'))


def test_window_starts_at_first_failure_not_at_last_contact(monkeypatch):
    """29/10: tras 20 min sin pedir turno, un solo fallo dejaba seguir sola a la PC al instante."""
    monkeypatch.setattr(config, 'CLAIM_WORKER', 'pc')
    monkeypatch.setattr(session_guard, 'LAST_CONTACT', [time.monotonic() - 1200])
    g = SessionGuard(_Portal([TimeoutError('sin conexion')]), 'g', 'pc')
    with pytest.raises(TimeoutError):
        g.acquire()
    assert not offline_fallback_allowed(TimeoutError('x'))     # el corte empezo recien


def test_any_answer_resets_the_outage(monkeypatch):
    monkeypatch.setattr(session_guard, 'OUTAGE_SINCE', [time.monotonic() - 999])
    g = SessionGuard(_Portal([{'granted': False, 'holder_lease_s': 300}]), 'g', 'pc')
    assert not g.acquire()
    assert session_guard.OUTAGE_SINCE[0] is None and session_guard.SEEN_LEASE[0] == 300


def test_only_network_failures_count_as_portal_down(monkeypatch):
    """Un bloqueo del hosting a la PC (HTML, 429, 406) no significa que Kaggle tampoco llegue al portal."""
    monkeypatch.setattr(config, 'CLAIM_WORKER', 'pc')
    monkeypatch.setattr(session_guard, 'OUTAGE_SINCE', [time.monotonic() - 4000])
    from export.portal_sync import PortalError
    assert offline_fallback_allowed(PortalError('sin conexión con el portal (timed out)'))
    assert offline_fallback_allowed(PortalError('HTTP 503: Coordinacion no disponible.'))
    assert not offline_fallback_allowed(PortalError('respuesta inválida del portal (Expecting value)'))
    assert not offline_fallback_allowed(PortalError('HTTP 429: Too Many Requests'))
    assert not offline_fallback_allowed(PortalError('HTTP 406: Not Acceptable'))


def test_wait_covers_the_longest_lease_given(monkeypatch):
    assert session_guard.offline_wait_s() == 210
    monkeypatch.setattr(session_guard, 'SEEN_LEASE', [300])
    assert session_guard.offline_wait_s() == 330
    monkeypatch.setattr(config, 'GOFO_SESSION_OFFLINE_S', 600)
    assert session_guard.offline_wait_s() == 600
    monkeypatch.setattr(config, 'GOFO_SESSION_OFFLINE_S', 60)
    monkeypatch.setattr(session_guard, 'SEEN_LEASE', [0])
    assert session_guard.offline_wait_s() == 210                # nunca menos que el permiso + margen


def test_foreign_city_change_stops_offline_pc_until_portal_answers(monkeypatch):
    monkeypatch.setattr(config, 'CLAIM_WORKER', 'pc')
    monkeypatch.setattr(session_guard, 'OUTAGE_SINCE', [time.monotonic() - 4000])
    g = SessionGuard(_Portal([]), 'g', 'pc', renew_s=60, retry_s=60)
    g.start_offline()
    assert g.foreign_switch('sin permiso para GF1')
    with pytest.raises(SessionCoordinationError):
        g.check()
    assert not offline_fallback_allowed(TimeoutError('x'))     # no vuelve a seguir sola
    g.stop.set()
    SessionGuard(_Portal([{'granted': True, 'lease_s': 180}]), 'g', 'pc').request('acquire')
    assert session_guard.CONFLICT[0] is None                    # el portal volvio: se puede coordinar de nuevo


def test_foreign_city_change_with_lease_is_fixed_as_before():
    g = SessionGuard(_Portal([]), 'g', 'pc')
    assert not g.foreign_switch('sin permiso para GF1') and g.error is None


def _wait(cond, s=3):
    end = time.monotonic() + s
    while time.monotonic() < end and not cond():
        time.sleep(0.02)


def test_offline_guard_takes_the_turn_when_portal_returns():
    g = SessionGuard(_Portal([TimeoutError('x'), {'granted': True, 'lease_s': 180}]), 'g', 'pc', renew_s=60, retry_s=0.01)
    g.start_offline()
    g.check()   # sin portal: sigue
    _wait(lambda: not g.offline)
    assert not g.offline and g.until > time.monotonic()
    g.check()
    g.stop.set()


def test_offline_guard_stops_if_another_worker_has_the_turn():
    g = SessionGuard(_Portal([{'granted': False}]), 'g', 'pc', renew_s=60, retry_s=0.01)
    g.start_offline()
    _wait(lambda: g.error)
    with pytest.raises(SessionCoordinationError):
        g.check()
