"""Extracción vía API: mapeo de campos, fotos en paralelo, checkpoint y respaldo a la interfaz (mocks)."""

import sqlite3
import threading
import time
from pathlib import Path
from unittest.mock import MagicMock

import pytest

import config
from automation.api_extractor import ApiPODExtractor, download_images_parallel
from automation.browser import SessionExpiredError
from automation.portal_api import WaybillSummary
from models.pod import PODRecord, ProcessingStatusEnum

S3 = "https://gofo-sys-admin.s3.us-west-2.amazonaws.com/sys-mod-file/2026-09-29/app-file"


class FakeAPI:
    """Imita PortalAPI: 2 conductores; un albarán sin POD (sin signId)."""

    def __init__(self, fail_sign=None):
        self.fail_sign = fail_sign or set()
        self.sign_calls = []

    def list_couriers(self, station_id, date_iso):
        return [{"driverName": "Driver A", "userId": 1}, {"driverName": "Driver B", "userId": 2}]

    def iter_waybills(self, station_id, date_iso, courier, page_size=50):
        n = courier["userId"]
        yield WaybillSummary(waybill_no=f"GF{n}01", sign_id=f"s{n}01", driver_name=courier["driverName"],
                             stop_index=f"S{n}01", sign_distance="12.5m", pod_lat="32.7", pod_lng="-97.1")
        yield WaybillSummary(waybill_no=f"GF{n}02", sign_id=None, driver_name=courier["driverName"])
        yield WaybillSummary(waybill_no=f"GF{n}03", sign_id=f"s{n}03", driver_name=courier["driverName"])

    def get_sign_info(self, sign_id):
        self.sign_calls.append(sign_id)
        if sign_id in self.fail_sign:
            raise RuntimeError("portal caído")
        return {
            "delivery": "DFW02-BAA", "courierName": "Driver X", "signTypeName": "En la puerta/Patio",
            "signTime": "2026-09-29 09:58:47", "toAddress": "ARLINGTON ARLINGTON 700 Eden Rd 7-205",
            "podCompliance": 3, "reasonNoCompliance": None,
            "imageList": [f"{S3}/a.jpg", f"{S3}/b.jpg", f"{S3}/a.jpg"],  # repetida (carrusel)
        }


def _fake_downloader(urls, dest_dir):
    return [str(dest_dir / f"foto_{i}.jpg") for i, _ in enumerate(urls, 1)]


def test_build_record_maps_portal_fields():
    ext = ApiPODExtractor(FakeAPI(), images_dir=Path("/tmp/x"), downloader=_fake_downloader)
    w = WaybillSummary(waybill_no="GF101", sign_id="s101", driver_name="Driver A", stop_index="S101",
                       sign_distance="12.5m", pod_lat="32.7", pod_lng="-97.1")
    pod = ext.build_record({"driverName": "Driver A"}, w, "2026-09-29")
    assert pod.tracking_number == "GF101"
    assert pod.station == "DFW02-BAA"
    assert pod.billing_type == "En la puerta/Patio"
    assert pod.receipt_address == "ARLINGTON ARLINGTON 700 Eden Rd 7-205"
    assert pod.expected_address == pod.receipt_address
    assert pod.signed_by == "Driver X"
    assert len(pod.photo_urls) == 2 and pod.number_of_photos == 2   # Deduplicadas
    assert pod.portal_meta["sign_distance"] == "12.5m" and pod.portal_meta["sign_id"] == "s101"
    assert pod.processing_status == ProcessingStatusEnum.PROCESSED


def test_run_pass_skips_unsigned_and_already_processed():
    api = FakeAPI()
    ext = ApiPODExtractor(api, images_dir=Path("/tmp/x"), downloader=_fake_downloader)
    got = []
    n = ext.run_pass([1888], "2026-09-29", processed={"GF101"}, on_record=got.append)
    # 07/10: intercalado (lista una ruta y procesa un bloque); sin resumen del portal, en el orden de la lista
    # 12/10: el orden entre repartidores sale de la proporción revisada; acá importa QUÉ se procesó
    assert sorted(p.tracking_number for p in got) == ["GF103", "GF201", "GF203"]
    assert n == 3 and "s101" not in api.sign_calls and len(ext.tracker.durations) == 3


def test_run_pass_marks_failed_and_continues():
    ext = ApiPODExtractor(FakeAPI(fail_sign={"s103"}), images_dir=Path("/tmp/x"), downloader=_fake_downloader)
    got = []
    ext.run_pass([1888], "2026-09-29", processed=set(), on_record=got.append)
    by = {p.tracking_number: p for p in got}
    assert by["GF103"].processing_status == ProcessingStatusEnum.FAILED
    assert by["GF201"].processing_status == ProcessingStatusEnum.PROCESSED


def test_run_pass_propagates_session_expired():
    api = FakeAPI()
    api.get_sign_info = MagicMock(side_effect=SessionExpiredError("vencida"))
    ext = ApiPODExtractor(api, images_dir=Path("/tmp/x"), downloader=_fake_downloader)
    with pytest.raises(SessionExpiredError):
        ext.run_pass([1888], "2026-09-29", processed=set(), on_record=lambda p: None)


def test_download_images_parallel_runs_concurrently_and_keeps_order(tmp_path):
    active, peak, lock = [0], [0], threading.Lock()

    def slow_fetch(url, dest):
        with lock:
            active[0] += 1
            peak[0] = max(peak[0], active[0])
        time.sleep(0.2)
        dest.write_bytes(url.encode())
        with lock:
            active[0] -= 1
        return dest

    urls = [f"{S3}/{c}.jpg" for c in "abcd"]
    t0 = time.monotonic()
    res = download_images_parallel(urls, tmp_path, workers=4, fetch=slow_fetch)
    elapsed = time.monotonic() - t0
    assert peak[0] == 4 and elapsed < 0.6                      # En paralelo, no 4 × 0,2 s
    assert [Path(p).name for p in res] == ["foto_1.jpg", "foto_2.jpg", "foto_3.jpg", "foto_4.jpg"]
    assert (tmp_path / "foto_3.jpg").read_text().endswith("c.jpg")


def test_download_rejects_non_allowlisted_hosts_and_tolerates_failures(tmp_path):
    def fetch(url, dest):
        if "b.jpg" in url:
            raise IOError("403")
        dest.write_bytes(b"x")
        return dest

    urls = [f"{S3}/a.jpg", f"{S3}/b.jpg", "https://evil.example.com/c.jpg"]
    res = download_images_parallel(urls, tmp_path, workers=3, fetch=fetch, sleep=lambda s: None)
    assert res[0] and res[1] is None and res[2] is None


# ---------------------------------------------------------------- modo continuo con API

def _patch_main(monkeypatch, tmp_path, api_fails=False):
    import main
    from storage.checkpoint_manager import CheckpointManager

    db = tmp_path / "c.db"
    monkeypatch.setattr(main, "CheckpointManager", lambda: CheckpointManager(db_path=db))
    monkeypatch.setattr(main.config, "THROUGHPUT_LOG_PATH", tmp_path / "t.jsonl")
    monkeypatch.setattr(main.config, "EXTRACTION_MODE", "api")
    monkeypatch.setattr(main.config, "BACKLOG_PATH", tmp_path / "faltantes.json")
    monkeypatch.setattr(main, "BrowserManager", lambda **kw: MagicMock())
    monkeypatch.setattr(main, "LoginManager", lambda bm: MagicMock())
    monkeypatch.setattr(main, "DashboardManager", lambda bm: MagicMock())
    monkeypatch.setattr(main, "AuditLogger", lambda **kw: MagicMock())
    from export.excel_exporter import PODExcelExporter
    monkeypatch.setattr(main, "PODExcelExporter", lambda: PODExcelExporter(output_dir=tmp_path))  # No tocar output/ real
    monkeypatch.setattr(main, "PortalAPI", lambda page: FakeAPI())
    monkeypatch.setattr(main, "PODValidator", lambda: MagicMock())

    from concurrent.futures import ThreadPoolExecutor
    from processing.pipeline import ScoringPipeline

    def thread_pipeline(validator, on_scored, **kw):
        def finalize(pod):
            pod.risk_score = 10.0  # score simulado
            on_scored(pod)
        pipe = ScoringPipeline(validator, finalize, executor=ThreadPoolExecutor(1), ocr_fn=lambda paths, address=None: [])
        pipe._finalize = lambda pod, photos: finalize(pod)
        return pipe

    monkeypatch.setattr(main, "ScoringPipeline", thread_pipeline)

    class Ext(ApiPODExtractor):
        def __init__(self, api, tracker=None, on_backlog=None):
            super().__init__(api, images_dir=tmp_path, tracker=tracker, downloader=_fake_downloader,
                             on_backlog=on_backlog)

        def run_pass(self, *a, **kw):
            if api_fails:
                raise RuntimeError("API cambió")
            return super().run_pass(*a, **kw)

    monkeypatch.setattr(main, "ApiPODExtractor", Ext)

    ui_calls = []

    class FakeScraper:
        def __init__(self, bm, throughput=None):
            pass

        def scrape_all_pods(self, preloaded_records, **kw):
            ui_calls.append(1)
            return list(preloaded_records) + [PODRecord(tracking_number="GFUI1")]

    monkeypatch.setattr(main, "PODScraper", FakeScraper)
    return main, db, ui_calls


def test_continuous_api_mode_checkpoints_each_pod_and_resumes(monkeypatch, tmp_path):
    main, db, ui_calls = _patch_main(monkeypatch, tmp_path)
    main.run_continuous_workflow(poll_interval=1, max_passes=1, sleep=lambda s: None)
    main.run_continuous_workflow(poll_interval=1, max_passes=1, sleep=lambda s: None)  # reinicio
    with sqlite3.connect(db) as conn:
        trks = sorted(r[0] for r in conn.execute("SELECT tracking_number FROM pod_checkpoints"))
    assert trks == ["GF101", "GF103", "GF201", "GF203"] and ui_calls == []


def test_continuous_falls_back_to_ui_when_api_breaks(monkeypatch, tmp_path):
    main, db, ui_calls = _patch_main(monkeypatch, tmp_path, api_fails=True)
    main.run_continuous_workflow(poll_interval=1, max_passes=1, sleep=lambda s: None)
    with sqlite3.connect(db) as conn:
        trks = [r[0] for r in conn.execute("SELECT tracking_number FROM pod_checkpoints")]
    assert ui_calls == [1] and trks == ["GFUI1"]


def test_continuous_rescores_pods_extracted_but_not_scored_before_a_crash(monkeypatch, tmp_path):
    main, db, _ = _patch_main(monkeypatch, tmp_path)
    from storage.checkpoint_manager import CheckpointManager
    import datetime
    ckpt = CheckpointManager(db_path=db)
    sid = ckpt.create_session(datetime.datetime.now().strftime("%Y-%m-%d"))
    ckpt.save_pod_checkpoint(sid, PODRecord(tracking_number="GF101", photo_paths=["x.jpg"],
                                            processing_status=ProcessingStatusEnum.PROCESSED))  # sin score
    main.run_continuous_workflow(poll_interval=1, max_passes=1, sleep=lambda s: None)
    with sqlite3.connect(db) as conn:
        rows = dict(conn.execute("SELECT tracking_number, risk_score FROM pod_checkpoints").fetchall())
    assert rows["GF101"] == 10.0                      # Se completó su score tras el "corte"
    assert all(v is not None for v in rows.values())  # Todos quedaron puntuados


def test_run_pass_by_blocks_rotates_drivers(monkeypatch):
    # 03/10: por bloques de N albaranes por repartidor, para que todos avancen parejo. 07/10: los bloques se
    # alternan dentro de la misma pasada (siempre el más atrasado) en vez de esperar a la pasada siguiente
    monkeypatch.setattr(config, "MAX_PER_DRIVER_PER_PASS", 1)
    ext = ApiPODExtractor(FakeAPI(), images_dir=Path("/tmp/x"), downloader=_fake_downloader)
    got = []
    ext.run_pass([1888], "2026-09-29", processed=set(), on_record=got.append)
    assert [p.tracking_number for p in got] == ["GF101", "GF201", "GF103", "GF203"] and not ext.capped


def test_resigned_pod_uses_latest_sign():
    # Caso real 04/10 (GFUS01075192499842): la lista conserva el signId del primer POD (15:17:28, 3 fotos) con la
    # hora del último (15:18:16, 4 fotos)
    class ResignAPI(FakeAPI):
        def latest_sign_id(self, waybill_no):
            return "nuevo"

        def get_sign_info(self, sign_id):
            info = super().get_sign_info(sign_id)
            info["signTime"] = "15:18:16 04/10/2026" if sign_id == "nuevo" else "15:17:28 04/10/2026"
            if sign_id == "nuevo":
                info["imageList"] = [f"{S3}/{c}.jpg" for c in "abcd"]
            return info

    ext = ApiPODExtractor(ResignAPI(), images_dir=Path("/tmp/x"), downloader=_fake_downloader)
    w = WaybillSummary(waybill_no="GF1", sign_id="viejo", driver_name="A", pod_time="10/277/2026 15:18:16")
    pod = ext.build_record({"driverName": "A"}, w, "2026-10-04")
    assert pod.portal_meta["sign_id"] == "nuevo" and len(pod.photo_urls) == 4


def test_status_signature_detects_resign_but_keeps_old_signatures():
    from automation.portal_api import same_status
    w = WaybillSummary(waybill_no="GF1", sign_id="s1", driver_name="A", order_status="3", delivery_status_code="205",
                       pod_time="10/277/2026 15:18:16")
    assert w.status_signature == "3|205|s1|15:18:16"
    assert same_status("3|205|s1", w.status_signature)              # Guardada antes del cambio: no se re-revisa
    assert not same_status("3|205|s1|15:17:28", w.status_signature)  # POD rehecho después de revisado


def test_tope_por_pasada_igual_cuenta_todos_los_entregados(monkeypatch):
    # 06/10: con el tope, el conteo de entregados de la ruta se cortaba (parecía que DFW-BAA estaba al día)
    monkeypatch.setattr(config, "MAX_PER_DRIVER_PER_PASS", 1)
    ext = ApiPODExtractor(FakeAPI(), images_dir=Path("/tmp/x"), downloader=_fake_downloader)
    routes = []
    ext.run_pass([1888], "2026-09-29", processed=set(), on_record=lambda p: None, max_records=2,
                 on_route=lambda st, courier, stats: routes.append(dict(stats)))
    # Cortada a los 2 albaranes, igual cuenta los 2 entregados (con POD) de cada ruta
    assert [r["with_pod"] for r in routes] == [2, 2] and ext.capped


def test_reparto_salta_lo_que_se_quedo_la_otra_corrida(monkeypatch):
    # 25/10: con claim_fn solo se revisa lo que el portal le reserva a esta corrida; el resto lo hace la otra
    monkeypatch.setattr(config, "MAX_PER_DRIVER_PER_PASS", 30)
    ext = ApiPODExtractor(FakeAPI(), images_dir=Path("/tmp/x"), downloader=_fake_downloader)
    calls = []

    def claim(trackings, done):
        calls.append((list(trackings), list(done)))
        return [t for t in trackings if t.endswith(("1", "3"))]   # La otra corrida se queda los pares

    ext.claim_fn = claim
    got = []
    ext.run_pass([1888], "2026-09-29", processed=set(), on_record=got.append)
    mine = [p.tracking_number for p in got]
    assert mine and all(t.endswith(("1", "3")) for t in mine)
    assert all(not t.endswith(("2", "4")) for t in mine)
    assert any(done for _, done in calls[1:]) or len(calls) == 1   # Avisa lo ya revisado en la siguiente petición


def test_reparto_sin_respuesta_del_portal_revisa_todo(monkeypatch):
    ext = ApiPODExtractor(FakeAPI(), images_dir=Path("/tmp/x"), downloader=_fake_downloader)

    def claim(trackings, done):
        raise RuntimeError("sin conexión")

    ext.claim_fn = claim
    got, base = [], []
    ext.run_pass([1888], "2026-09-29", processed=set(), on_record=got.append)
    ext2 = ApiPODExtractor(FakeAPI(), images_dir=Path("/tmp/x"), downloader=_fake_downloader)
    ext2.run_pass([1888], "2026-09-29", processed=set(), on_record=base.append)
    assert sorted(p.tracking_number for p in got) == sorted(p.tracking_number for p in base)


def test_prefetch_da_los_mismos_albaranes_en_el_mismo_orden(monkeypatch):
    # 25/10: con descarga en segundo plano el resultado es idéntico al de uno por uno
    monkeypatch.setattr(config, "MAX_PER_DRIVER_PER_PASS", 30)
    base, fast = [], []
    ApiPODExtractor(FakeAPI(), images_dir=Path("/tmp/x"), downloader=_fake_downloader).run_pass(
        [1888], "2026-09-29", processed=set(), on_record=base.append)
    ext = ApiPODExtractor(FakeAPI(), images_dir=Path("/tmp/x"), downloader=_fake_downloader)
    ext.prefetch = 3
    ext.run_pass([1888], "2026-09-29", processed=set(), on_record=fast.append)
    assert [p.tracking_number for p in fast] == [p.tracking_number for p in base] and fast
    assert [p.photo_paths for p in fast] == [p.photo_paths for p in base]


def test_prefetch_pide_el_detalle_solo_en_el_hilo_principal(monkeypatch):
    # El navegador (Playwright) no admite llamadas desde otros hilos: solo se descarga en segundo plano
    import threading
    monkeypatch.setattr(config, "MAX_PER_DRIVER_PER_PASS", 30)
    api = FakeAPI()
    threads = set()
    original = api.get_sign_info

    def spy(sign_id):
        threads.add(threading.current_thread().name)
        return original(sign_id)

    api.get_sign_info = spy
    ext = ApiPODExtractor(api, images_dir=Path("/tmp/x"), downloader=_fake_downloader)
    ext.prefetch = 3
    got = []
    ext.run_pass([1888], "2026-09-29", processed=set(), on_record=got.append)
    assert got and threads == {threading.main_thread().name}


def test_prefetch_respeta_max_records(monkeypatch):
    monkeypatch.setattr(config, "MAX_PER_DRIVER_PER_PASS", 30)
    ext = ApiPODExtractor(FakeAPI(), images_dir=Path("/tmp/x"), downloader=_fake_downloader)
    ext.prefetch = 3
    got = []
    n = ext.run_pass([1888], "2026-09-29", processed=set(), on_record=got.append, max_records=2)
    assert n == 2 and len(got) == 2 and ext.capped


def test_reparto_no_da_por_hecho_lo_que_fallo_por_la_red(monkeypatch):
    # 26/10: GFUS01074038390540 y otros salieron "Media 50 · Failed to fetch" y no se reintentaban: con el reparto se avisaba al portal
    # como "hecho" y ninguna corrida volvía a pedirlo. Un fallo de red no se da por revisado; los demás sí.
    monkeypatch.setattr(config, "MAX_PER_DRIVER_PER_PASS", 30)
    ext = ApiPODExtractor(FakeAPI(), images_dir=Path("/tmp/x"), downloader=_fake_downloader)
    real = ext._fetch_info

    def flaky(courier, w, date_iso):
        if w.waybill_no.endswith("1"):
            raise RuntimeError("/system/sign/getInfoBySignId: sin respuesta (TypeError: Failed to fetch)")
        return real(courier, w, date_iso)

    ext._fetch_info = flaky
    sent = []
    ext.claim_fn = lambda trackings, done: (sent.extend(done), list(trackings))[1]
    got = []
    ext.run_pass([1888], "2026-09-29", processed=set(), on_record=got.append)
    done = set(sent) | set(ext._claim_done)
    failed = [p.tracking_number for p in got if str(p.processing_status).endswith("FAILED")]
    ok = [p.tracking_number for p in got if not str(p.processing_status).endswith("FAILED")]
    assert failed and ok
    assert not done & set(failed)          # los que fallaron por la red quedan sin avisar (se vuelven a pedir)
    assert set(ok) <= done                 # los demás sí se avisan como hechos


def test_sin_portal_un_cambio_de_ciudad_ajeno_detiene_y_no_pelea_la_ciudad():
    """29/10: en modo sin portal, "sin permiso" = otra corrida cambió la ciudad de la sesión: no se vuelve a cambiar."""
    from automation.session_guard import SessionCoordinationError

    class Guard:
        offline, error = True, None

        def foreign_switch(self, detail):
            self.error = detail
            return True

    class OtherCityAPI(FakeAPI):
        current_station, switched = 297, []

        def get_sign_info(self, sign_id):
            raise RuntimeError("code=500 El usuario actual no tiene permiso para operar estos datos")

        def switch_station(self, station):
            self.switched.append(station)

    api = OtherCityAPI()
    api.session_guard = Guard()
    ext = ApiPODExtractor(api, images_dir=Path("/tmp/x"), downloader=_fake_downloader)
    with pytest.raises(SessionCoordinationError):
        ext._fetch_info_inner({"driverName": "A"}, WaybillSummary(waybill_no="GF1", sign_id="s1", driver_name="A"),
                              "2026-10-29")
    assert api.switched == []
