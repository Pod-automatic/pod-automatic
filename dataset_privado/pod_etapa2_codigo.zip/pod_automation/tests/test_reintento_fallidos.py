from models.pod import PODRecord, ProcessingStatusEnum
from storage.checkpoint_manager import CheckpointManager, is_connection_error


def _failed(trk, error):
    return PODRecord(tracking_number=trk, driver_name="X", processing_status=ProcessingStatusEnum.FAILED,
                     error_message=error, portal_meta={"portal_status": "Firmado"})


def test_fallo_de_conexion_se_reintenta_en_la_pasada_siguiente(tmp_path):
    m = CheckpointManager(db_path=tmp_path / "c.db")
    s = m.create_session("2026-10-06")
    m.save_pod_checkpoint(s, _failed("RED", "/system/sign/getInfoBySignId: sin respuesta (TypeError: Failed to fetch)"))
    m.save_pod_checkpoint(s, _failed("PERMISO", "code=500 El usuario actual no tiene permiso para operar estos datos"))
    ok = PODRecord(tracking_number="OK", driver_name="X", processing_status=ProcessingStatusEnum.PROCESSED)
    m.save_pod_checkpoint(s, ok)
    known = m.get_status_map(s)
    assert "RED" not in known and "PERMISO" in known and "OK" in known


def test_errores_de_conexion():
    assert is_connection_error("sin respuesta (TypeError: Failed to fetch)")
    assert is_connection_error("<urlopen error [Errno 11001] getaddrinfo failed>")
    assert not is_connection_error("El usuario actual no tiene permiso para operar estos datos (sin respuesta)")
    assert not is_connection_error(None)


def test_fotos_de_menos_por_corte_de_red_se_reintentan(tmp_path):
    # 22/10: GFUS01078769112322 se guardó con 1 de 5 fotos (getaddrinfo / tiempo agotado) y no se volvía a extraer
    m = CheckpointManager(db_path=tmp_path / "c.db")
    s = m.create_session("2026-10-22")
    red = PODRecord(tracking_number="RED", driver_name="X", processing_status=ProcessingStatusEnum.PROCESSED,
                    error_message="4 de 5 fotos no se pudieron descargar (<urlopen error [Errno 11001] getaddrinfo failed>)",
                    portal_meta={"portal_status": "Firmado", "driver_id": "7"})
    rota = PODRecord(tracking_number="ROTA", driver_name="X", processing_status=ProcessingStatusEnum.PROCESSED,
                     error_message="1 de 3 fotos no se pudieron descargar (HTTP 404)",
                     portal_meta={"portal_status": "Firmado", "driver_id": "7"})
    m.save_pod_checkpoint(s, red)
    m.save_pod_checkpoint(s, rota)
    known = m.get_status_map(s)
    assert "RED" not in known and "ROTA" in known      # Un 404 no se reintenta para siempre
    assert m.count_by_driver(s).get("7") == 1           # El que se reintenta no cuenta como revisado


def test_el_motivo_de_la_foto_fallida_queda_en_el_error(tmp_path):
    from automation.api_extractor import download_images_parallel
    errors = []
    def fetch(url, dest):
        raise OSError("<urlopen error [Errno 11001] getaddrinfo failed>")
    out = download_images_parallel(["https://x.amazonaws.com/a.jpg"], tmp_path, workers=1, fetch=fetch,
                                   sleep=lambda s: None, errors=errors)
    assert out == [None] and "getaddrinfo" in errors[0]
