from tools.benchmark_gpu_concurrency import summarize


def test_benchmark_throughput_counts_successes_over_total_wall_time():
    def result(wall,good):
        return {'label':'paddle','clients':2,'wall_s':wall,'peak_vram_mib':100,
                'requests':[{'ok':ok,'latency_s':1,'signature':'a'} for ok in good]}
    summary=summarize({'rounds':[result(2,[True,True,False]),result(8,[True,True,True])]})[0]
    assert summary['images_per_minute']==30
    assert summary['errors']==1 and summary['ok']==5


def test_output_comparison_excludes_unstable_reference_images():
    def row(signature): return {'ok':True,'latency_s':1,'signature':signature}
    def run(label,rows): return {'label':label,'clients':1,'wall_s':2,'requests':rows}
    report={'rounds':[run('ollama_parallel_1',[row('a'),row('b')]),
                      run('ollama_parallel_1',[row('a'),row('c')]),
                      run('ollama_parallel_2',[row('different'),row('b')])]}
    trial=summarize(report)[1]
    assert trial['compared_to_stable_ollama_baseline']==1
    assert trial['different_outputs']==1


def test_photo_batches_never_mix_deliveries():
    from pathlib import Path
    from tools.benchmark_gpu_concurrency import photo_batches
    paths=[Path('a/1.jpg'),Path('b/1.jpg'),Path('a/2.jpg'),Path('a/3.jpg')]
    groups=photo_batches(paths,2)
    assert all(len({p.parent for p in group})==1 for group in groups)
    assert groups[0]==[paths[0],paths[2]]
    assert sorted(str(p) for group in groups for p in group)==sorted(map(str,paths))


def test_photo_throughput_is_not_confused_with_request_throughput():
    result={'label':'two_photos','clients':1,'wall_s':4,
            'requests':[{'ok':True,'photos':2,'latency_s':2,'signature':'a'},
                        {'ok':True,'photos':2,'latency_s':2,'signature':'b'}]}
    summary=summarize({'rounds':[result]})[0]
    assert summary['images_per_minute']==60 and summary['requests_per_minute']==30
