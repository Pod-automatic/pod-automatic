"""
Pruebas Unitarias para la Fase 4: Motor de Validación Configurable (Rule Engine).

Verifica:
- Cero rechazos automáticos (sistema de triaje y soporte a la decisión humana).
- Clasificaciones: VALID / LIKELY VALID, REVIEW REQUIRED, POSSIBLE ISSUE, ERROR.
- Regla 1: Ausencia de fotografías -> REVIEW REQUIRED.
- Regla 2: Fotografía no analizable / corrupta -> ERROR o REVIEW REQUIRED.
- Regla 3: Información y fotos completas -> CONTINUAR / VALID.
- Regla 4: Fotografías duplicadas -> POSSIBLE DUPLICATE / POSSIBLE ISSUE.
- Regla 5: Fotografía extremadamente borrosa -> LOW IMAGE QUALITY / REVIEW REQUIRED.
- Regla 6: Evidencia insuficiente o incidencias -> REVIEW REQUIRED.
"""

from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter

from models.pod import (
    PODRecord,
    ValidationClassification,
    ImageQualityMetrics,
)
from processing.validator import PODValidator
from processing.rules import (
    MissingPhotoRule,
    UnreadableImageRule,
    BasicInfoCompletenessRule,
    DuplicatePhotoRule,
    ImageQualityRule,
)


def test_rule_missing_photos_gives_review_required():
    """Regla 1: Si no existen fotografías, clasifica como REVIEW REQUIRED (nunca rechazo automático)."""
    validator = PODValidator()
    pod = PODRecord(
        tracking_number="TRK-NO-PHOTO",
        driver_name="Juan Pérez",
        address="Calle Mayor 10, Madrid",
        number_of_photos=0,
        photo_paths=[],
    )

    result = validator.validate_pod(pod)

    assert result.classification == ValidationClassification.REVIEW_REQUIRED
    assert "NO PHOTO" in result.flags or any("FOTO_FALTANTE" in a for a in result.anomalies)


def test_rule_unreadable_image_gives_error(tmp_path):
    """Regla 2: Si el archivo de imagen está dañado o vacío, clasifica como ERROR o REVIEW REQUIRED."""
    corrupted_file = tmp_path / "corrupted.jpg"
    corrupted_file.write_bytes(b"")  # Archivo de 0 bytes

    validator = PODValidator()
    pod = PODRecord(
        tracking_number="TRK-CORRUPTED",
        driver_name="Juan Pérez",
        address="Calle Gran Vía 15, Madrid",
        photo_paths=[str(corrupted_file)],
        number_of_photos=1,
    )

    result = validator.validate_pod(pod)

    assert result.classification == ValidationClassification.ERROR
    assert "UNREADABLE IMAGE" in result.flags


def test_rule_complete_valid_delivery(tmp_path):
    """Regla 3: Si existen fotos suficientes y la información básica está completa, valida exitosamente."""
    sharp_img = Image.new("RGB", (200, 200), color="white")
    draw = ImageDraw.Draw(sharp_img)
    for x in range(0, 200, 20):
        for y in range(0, 200, 20):
            if (x + y) % 40 == 0:
                draw.rectangle([x, y, x + 20, y + 20], fill="black")
    sharp_path = tmp_path / "sharp_valid.jpg"
    sharp_img.save(sharp_path)

    validator = PODValidator()
    pod = PODRecord(
        tracking_number="TRK-PERFECT",
        driver_name="Alejandro Martínez",
        address="Calle Serrano 45, Madrid",
        photo_paths=[str(sharp_path)],
        number_of_photos=1,
    )

    result = validator.validate_pod(pod)

    assert result.classification in (ValidationClassification.VALID, ValidationClassification.LIKELY_VALID)
    assert len(result.anomalies) == 0


def test_rule_duplicate_photo_gives_possible_issue(tmp_path):
    """Regla 4: Si se detecta foto idéntica reutilizada, marca POSSIBLE DUPLICATE y POSSIBLE ISSUE."""
    img = Image.new("RGB", (100, 100), color=(150, 150, 150))
    dup_path = tmp_path / "shared_photo.jpg"
    img.save(dup_path)

    validator = PODValidator()

    # Paquete legítimo inicial
    pod1 = PODRecord(
        tracking_number="TRK-ORIGINAL",
        driver_name="Carlos Vega",
        address="Calle 1",
        photo_paths=[str(dup_path)],
    )
    validator.validate_pod(pod1)

    # Segundo paquete reutilizando la misma foto
    pod2 = PODRecord(
        tracking_number="TRK-REUSED",
        driver_name="Carlos Vega",
        address="Calle 2",
        photo_paths=[str(dup_path)],
    )
    result2 = validator.validate_pod(pod2)

    assert result2.classification == ValidationClassification.POSSIBLE_ISSUE
    assert "POSSIBLE DUPLICATE" in result2.flags


def test_rule_blurry_photo_gives_low_image_quality(tmp_path):
    """Regla 5: Si una imagen está extremadamente borrosa, marca LOW IMAGE QUALITY y REVIEW REQUIRED."""
    # Crear imagen completamente desenfocada
    sharp = Image.new("RGB", (200, 200), color="white")
    draw = ImageDraw.Draw(sharp)
    draw.rectangle([50, 50, 150, 150], fill="black")
    blurry = sharp.filter(ImageFilter.GaussianBlur(radius=15))
    blur_path = tmp_path / "blurry_photo.jpg"
    blurry.save(blur_path)

    validator = PODValidator()
    pod = PODRecord(
        tracking_number="TRK-BLURRY",
        driver_name="Luis Morales",
        address="Paseo de la Castellana 50, Madrid",
        photo_paths=[str(blur_path)],
        number_of_photos=1,
    )

    result = validator.validate_pod(pod)

    assert result.classification == ValidationClassification.REVIEW_REQUIRED
    assert "LOW IMAGE QUALITY" in result.flags


def test_rule_platform_incident_requires_review(tmp_path):
    """Regla 6: Si hay motivos de no conformidad de la plataforma, solicita REVIEW REQUIRED."""
    sharp = Image.new("RGB", (100, 100), color="white")
    draw = ImageDraw.Draw(sharp)
    for x in range(0, 100, 20):
        for y in range(0, 100, 20):
            if (x + y) % 40 == 0:
                draw.rectangle([x, y, x + 20, y + 20], fill="black")
    sharp_path = tmp_path / "ok.jpg"
    sharp.save(sharp_path)

    validator = PODValidator()
    pod = PODRecord(
        tracking_number="TRK-INCIDENT",
        driver_name="Javier Ramos",
        address="Calle Princesa 14, Madrid",
        photo_paths=[str(sharp_path)],
        non_compliance_reason="Cliente no localizado / entrega dudosa",
    )

    result = validator.validate_pod(pod)

    assert result.classification == ValidationClassification.REVIEW_REQUIRED
    assert "PLATFORM FLAGGED" in result.flags
