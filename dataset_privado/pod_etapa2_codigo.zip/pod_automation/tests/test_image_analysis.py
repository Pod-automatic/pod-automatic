"""
Pruebas Unitarias para ImageQualityAnalyzer (Computer Vision & Calidad de Imagen).
"""

import pytest
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter
import numpy as np

from processing.image_analysis import ImageQualityAnalyzer


@pytest.fixture
def temp_images_dir(tmp_path):
    """Crea un directorio temporal con imágenes sintéticas para pruebas."""
    images_dir = tmp_path / "test_imgs"
    images_dir.mkdir(parents=True, exist_ok=True)

    # 1. Imagen Nítida (Ajedrez con alto contraste y bordes definidos)
    sharp_img = Image.new("RGB", (200, 200), color="white")
    draw = ImageDraw.Draw(sharp_img)
    for x in range(0, 200, 20):
        for y in range(0, 200, 20):
            if (x + y) % 40 == 0:
                draw.rectangle([x, y, x + 20, y + 20], fill="black")
    sharp_path = images_dir / "sharp.jpg"
    sharp_img.save(sharp_path)

    # 2. Imagen Borrosa (Aplicación de filtro Gaussiano fuerte)
    blurry_img = sharp_img.filter(ImageFilter.GaussianBlur(radius=8))
    blurry_path = images_dir / "blurry.jpg"
    blurry_img.save(blurry_path)

    # 3. Imagen Oscura / Negra (Simulando cámara tapada o noche sin luz)
    dark_img = Image.new("RGB", (200, 200), color=(10, 10, 10))
    dark_path = images_dir / "dark.jpg"
    dark_img.save(dark_path)

    # 4. Imagen Sobreexpuesta / Quemada
    bright_img = Image.new("RGB", (200, 200), color=(250, 250, 250))
    bright_path = images_dir / "bright.jpg"
    bright_img.save(bright_path)

    # 5. Imagen Plana / Cámara tapada gris
    flat_img = Image.new("RGB", (200, 200), color=(128, 128, 128))
    flat_path = images_dir / "flat.jpg"
    flat_img.save(flat_path)

    return {
        "sharp": sharp_path,
        "blurry": blurry_path,
        "dark": dark_path,
        "bright": bright_path,
        "flat": flat_path,
    }


def test_blur_detection(temp_images_dir):
    """Verifica que la varianza del Laplaciano distinga nítidas de borrosas."""
    analyzer = ImageQualityAnalyzer(blur_threshold=100.0)

    metrics_sharp = analyzer.analyze_image(str(temp_images_dir["sharp"]))
    metrics_blurry = analyzer.analyze_image(str(temp_images_dir["blurry"]))

    assert metrics_sharp is not None
    assert metrics_blurry is not None

    # La imagen nítida debe tener una varianza de Laplaciano significativamente mayor
    assert metrics_sharp.blur_score > metrics_blurry.blur_score
    assert metrics_sharp.is_blurry is False
    assert metrics_blurry.is_blurry is True


def test_brightness_detection(temp_images_dir):
    """Verifica la detección de imágenes oscuras y sobreexpuestas."""
    analyzer = ImageQualityAnalyzer(min_brightness=30.0, max_brightness=230.0)

    metrics_dark = analyzer.analyze_image(str(temp_images_dir["dark"]))
    metrics_bright = analyzer.analyze_image(str(temp_images_dir["bright"]))

    assert metrics_dark.is_dark is True
    assert metrics_dark.is_overexposed is False

    assert metrics_bright.is_overexposed is True
    assert metrics_bright.is_dark is False


def test_flat_covered_detection(temp_images_dir):
    """Verifica la detección de lentes tapados o fondos planos con baja desviación estándar."""
    analyzer = ImageQualityAnalyzer()
    metrics_flat = analyzer.analyze_image(str(temp_images_dir["flat"]))

    assert metrics_flat.is_blank_or_covered is True
    assert metrics_flat.std_contrast < 2.0


def test_perceptual_hash_consistency(temp_images_dir):
    """Verifica la consistencia y unicidad del Perceptual Hash (dHash)."""
    analyzer = ImageQualityAnalyzer()
    m1 = analyzer.analyze_image(str(temp_images_dir["sharp"]))
    m2 = analyzer.analyze_image(str(temp_images_dir["sharp"]))
    m3 = analyzer.analyze_image(str(temp_images_dir["dark"]))

    # Misma imagen debe tener distancia de Hamming = 0
    dist_identical = ImageQualityAnalyzer.hamming_distance(m1.perceptual_hash, m2.perceptual_hash)
    assert dist_identical == 0

    # Imágenes diferentes deben tener distancia de Hamming apreciable
    dist_diff = ImageQualityAnalyzer.hamming_distance(m1.perceptual_hash, m3.perceptual_hash)
    assert dist_diff > 10
