"""
Configuración de Fixtures y PYTHONPATH para Pytest.
"""

import sys
from pathlib import Path

# Agregar la raíz del proyecto al PYTHONPATH
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import pytest


@pytest.fixture(autouse=True)
def _isolated_analysis_cache(tmp_path, monkeypatch):
    import config
    monkeypatch.setattr(config, "ANALYSIS_CACHE_PATH", tmp_path / "analysis_cache.db")
    monkeypatch.setattr(config, "RUNTIME_STATE_DIR", tmp_path)


@pytest.fixture(autouse=True)
def _no_real_ocr(request, monkeypatch):
    """
    Los tests no ejecutan el OCR real (lento, requiere modelos): devuelve fotos sin texto.
    Un test puede pedir el OCR real marcándose con @pytest.mark.real_ocr.
    """
    if request.node.get_closest_marker("real_ocr"):
        return
    from processing import pipeline
    from processing.ocr_address import PhotoOCR
    monkeypatch.setattr(pipeline, "ocr_photos", lambda paths, address=None: [PhotoOCR(path=str(p)) for p in paths])
    monkeypatch.setattr(pipeline, "strip_vision_numbers", lambda path, reader=None: [])   # 06/10: sin modelo real
    from processing import vision_llm
    monkeypatch.setattr(vision_llm, "package_room_confirmed", lambda path: False)   # 06/10: sin modelo real
    monkeypatch.setattr(vision_llm, "screenshot_address", lambda path: "")
    monkeypatch.setattr(vision_llm, "number_location", lambda path, number: "")
    from processing import scoring
    monkeypatch.setattr(scoring, "driver_of_tracking", lambda tracking: None)   # 11/10: sin leer la base real


@pytest.fixture(autouse=True)
def _sin_reparto_ni_portal_real(monkeypatch):
    """
    26/10: el .env de la PC activa el reparto (CLAIM_WORK=1) y trae la clave del portal real: los tests no deben depender de eso
    ni llamar al portal de verdad. Un test del reparto lo activa a mano con su propio claim_fn.
    """
    import config
    monkeypatch.setattr(config, "CLAIM_WORK", False)
    monkeypatch.setattr(config, "GPU_SEND_PHOTOS", False)
    monkeypatch.setattr(config, "PORTAL_SYNC_ENABLED", False)
    monkeypatch.setattr(config, 'GOFO_SESSION_GROUP', '')
    monkeypatch.setattr(config, 'CITY_DISPATCH_DB', '')
    monkeypatch.setattr(config, 'GPU_DISPATCH_DB', '')
    monkeypatch.setattr(config, 'ANALYSIS_POOL_DB', '')
    # 28/10: el .env de la PC reutiliza las listas de rutas y analiza en un hilo aparte; los tests usan los valores por defecto
    monkeypatch.setattr(config, 'ROUTE_LIST_CACHE_S', 0.0)
    monkeypatch.setattr(config, 'ASYNC_ANALYSIS', False)


def pytest_configure(config):
    config.addinivalue_line("markers", "real_ocr: usa el motor de OCR real")


@pytest.fixture(autouse=True)
def _isolated_drivers_config(tmp_path, monkeypatch):
    """Los tests nunca leen el drivers_config.json real del usuario."""
    import config
    monkeypatch.setattr(config, "DRIVERS_CONFIG_PATH", tmp_path / "drivers_config.json")
    monkeypatch.setattr(config, "BACKLOG_PATH", tmp_path / "faltantes.json")   # 07/10: no pisar el de la corrida real
    # 15/10: las pruebas de la corrida completa escribían "Driver A/B" en el panel de rutas y el control reales
    from storage import package_control, route_panel
    monkeypatch.setattr(route_panel, "PANEL_DB", tmp_path / "route_panel.db")
    monkeypatch.setattr(package_control, "CONTROL_DB", tmp_path / "package_control.db")
