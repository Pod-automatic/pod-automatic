"""
Verifica que todo `Selectors.X` referenciado en el código de automation/ exista.

Un atributo inexistente solo falla en tiempo de ejecución contra el portal real
(AttributeError), y los tests con DOM mock no lo detectan.
"""

import re
from pathlib import Path

from automation.selectors import Selectors, SelectorStrategy

AUTOMATION_DIR = Path(__file__).resolve().parent.parent / "automation"
REF_PATTERN = re.compile(r"\bSelectors\.([A-Z_][A-Z0-9_]*)")


def _referenced_names():
    names = {}
    for py_file in AUTOMATION_DIR.glob("*.py"):
        for name in REF_PATTERN.findall(py_file.read_text(encoding="utf-8")):
            names.setdefault(name, set()).add(py_file.name)
    return names


def test_all_referenced_selectors_exist():
    missing = {
        name: sorted(files)
        for name, files in _referenced_names().items()
        if not hasattr(Selectors, name)
    }
    assert not missing, f"Selectors referenciados pero no definidos: {missing}"


def test_referenced_selectors_are_strategies_with_candidates():
    for name in _referenced_names():
        strategy = getattr(Selectors, name)
        assert isinstance(strategy, SelectorStrategy), name
        assert strategy.selectors, f"{name} no tiene selectores candidatos"
