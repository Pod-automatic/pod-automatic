import json

import config
from models.pod import PODRecord
from models.priorities import category_for_payload
from export.portal_sync import pod_item, gpu_item, Outbox, PortalSync
from tests.test_portal_sync import FakeClient


def locker(priority='Alta'):
    return PODRecord(tracking_number='LOCKER0001', priority=priority, risk_score=80,
                     check_results=[{'check':'amazon_hub','score':100,'weight':.8,'applicable':True,'explanation':'Lockers de Amazon'}])


def test_categoria_de_legacy_y_serializacion_no_es_alta():
    p = locker()
    assert p.priority == 'Lockers' and p.to_dict()['priority'] == 'Lockers'
    assert PODRecord.from_dict(p.to_dict()).priority == 'Lockers'
    assert category_for_payload({'priority':'Alta','check_results':[{'check':'amazon_hub','applicable':False}]}) == 'Alta'
    assert category_for_payload({'priority':'Baja','hub':True}) == 'Lockers'


def test_pc_y_kaggle_envian_lockers_con_datos_y_fotos(tmp_path, monkeypatch):
    monkeypatch.setattr(config, 'PORTAL_GPU', False)
    p = locker()
    assert pod_item(p.to_dict(), '2026-10-27')['priority'] == 'Lockers'
    assert gpu_item(p.to_dict(), '2026-10-27')['hub'] is True
    client = FakeClient()
    sync = PortalSync(client, Outbox(tmp_path/'outbox.db'), card_maker=lambda *args:b'card')
    sync.enqueue_pod(p, '2026-10-27')
    sync.sync_once(pull=False)
    sent = next(iter(client.pods.values()))
    assert sent['priority'] == 'Lockers' and sent['cards']
    assert next(iter(client.analyses.values()))['priority'] == 'Lockers'


def test_pagina_local_cuenta_historial_antiguo_como_lockers(tmp_path, monkeypatch):
    import sqlite3
    from export import report_server
    db=tmp_path/'checkpoints.db'
    monkeypatch.setattr(report_server, 'CHECKPOINT_DB', db)
    with sqlite3.connect(db) as c:
        c.executescript('CREATE TABLE audit_sessions(session_id TEXT,query_date TEXT,started_at TEXT);'
                       'CREATE TABLE pod_checkpoints(session_id TEXT,tracking_number TEXT,driver_name TEXT,payload_json TEXT);')
        c.execute('INSERT INTO audit_sessions VALUES (?,?,?)', ('a','2026-10-27','2026-10-27'))
        payload=locker().to_dict(); payload['priority']='Alta'
        c.execute('INSERT INTO pod_checkpoints VALUES (?,?,?,?)',('a','LOCKER0001','Ana',json.dumps(payload)))
    assert report_server._latest_rows('2026-10-27')['LOCKER0001'][2] == 'Lockers'
