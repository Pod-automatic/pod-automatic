"""09/10: con repartidores en prioridad, 1 de cada PRIORITY_SHARE_EVERY bloques va al resto (no quedan parados)."""

import config
from automation.api_extractor import ApiPODExtractor


def _route(name, uid, pending):
    return {"station_id": 1888, "courier": {"driverName": name, "userId": uid}, "pending": [None] * pending}


def _pick(monkeypatch, every, n=8):
    monkeypatch.setattr(config, "PRIORITY_SHARE_EVERY", every)
    ex = ApiPODExtractor.__new__(ApiPODExtractor)
    ex.api = None
    ex.priority_drivers = {"272164"}
    routes = [_route("Aurelys", "272164", 50), _route("Otro", "999", 300)]
    return [ex._most_behind(routes)["courier"]["driverName"] for _ in range(n)]


def test_tres_de_cada_cuatro_bloques_a_la_prioridad(monkeypatch):
    assert _pick(monkeypatch, 4) == ["Aurelys", "Aurelys", "Aurelys", "Otro"] * 2


def test_sin_reparto_solo_prioridad(monkeypatch):
    assert _pick(monkeypatch, 0) == ["Aurelys"] * 8
