"""Paso 6: hoja 'Review Queue' (primera hoja, ordenada por riesgo, prioridad con color) y avance por repartidor."""

import openpyxl

from export.excel_exporter import PODExcelExporter
from models.pod import PODRecord
from processing.ocr_address import PhotoOCR
from processing.scoring import score_pod


def _pod(trk, photos, address="ALLEN ALLEN 1530 Broadmoor Dr", dist="10"):
    p = PODRecord(tracking_number=trk, receipt_address=address, address=address, billing_type="En la puerta/Patio",
                  driver_name="Driver Uno", stop_number="1064", photo_paths=[f"f{i}.jpg" for i in range(3)],
                  portal_meta={"sign_distance": dist})
    return score_pod(p, photos)


def test_review_queue_is_first_sheet_sorted_by_risk(tmp_path):
    label = PhotoOCR(path="l", is_label=True)
    pods = [
        _pod("BAJA", [PhotoOCR(path="d", numbers=["1530"]), label]),
        _pod("ALTA", [PhotoOCR(path="d", numbers=["1350"], vision_all=["1350"]), label]),  # no concuerda (OCR y visión)
        _pod("MEDIA", [PhotoOCR(path="d"), label]),                          # número no leído
    ]
    progress = [{"station_id": "1888", "driver_name": "Driver Uno", "is_new": 1, "reviewed": 3,
                 "delivered_in_portal": 5, "assigned_in_portal": 7, "needs_recheck": 0, "updated_at": "x"}]
    path = PODExcelExporter(output_dir=tmp_path).export(pods, "q.xlsx", route_progress=progress)
    wb = openpyxl.load_workbook(path)
    assert wb.sheetnames[:2] == ["Review Queue", "Avance por repartidor"]
    ws = wb["Review Queue"]
    headers = [c.value for c in ws[1]]
    rows = [dict(zip(headers, [c.value for c in r])) for r in ws.iter_rows(min_row=2)]
    assert [r["Tracking"] for r in rows] == ["ALTA", "MEDIA", "BAJA"]
    assert [r["Prioridad"] for r in rows] == ["Alta", "Media", "Baja"]
    assert "no concuerdan" in rows[0]["Motivo principal"]
    assert rows[0]["Score"] == 80 and rows[0]["Parada"] == "1064"
    assert ws.cell(row=2, column=headers.index("Prioridad") + 1).fill.start_color.rgb.endswith("F8D7DA")
    prog = wb["Avance por repartidor"]
    ph = [c.value for c in prog[1]]
    prow = dict(zip(ph, [c.value for c in prog[2]]))
    assert prow["Avance"] == "3 de 5" and prow["Nuevo"] == "SÍ"
    assert "POD Results" in wb.sheetnames and "Summary" in wb.sheetnames  # Hojas previas se mantienen
