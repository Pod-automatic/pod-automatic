from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import sqlite3
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

import config
from automation.activity import recent_activity
from automation.business_time import operation_day
from automation.browser import SessionExpiredError
from automation.work_claims import LeaseCoordinator
from models.pod import PODRecord
from storage.checkpoint_manager import CheckpointManager
from storage.closing_queue import ClosingQueue


def test_midnight_utc_does_not_close_venezuelan_workday(monkeypatch):
    monkeypatch.setattr(config,'OPERATION_TIMEZONE','America/Caracas')
    assert operation_day(datetime(2026,10,28,0,30,tzinfo=timezone.utc))=='2026-10-27'
    assert operation_day(datetime(2026,10,28,3,59,tzinfo=timezone.utc))=='2026-10-27'
    assert operation_day(datetime(2026,10,28,4,0,tzinfo=timezone.utc))=='2026-10-28'
    with pytest.raises(ValueError):
        operation_day(datetime(2026,10,28))


def log(path,entries):
    path.write_text('\n'.join(json.dumps(r) for r in entries)+'\n',encoding='utf-8')


def test_idle_does_not_reuse_old_median_or_count(tmp_path):
    now=datetime(2026,10,28,1,tzinfo=timezone.utc)
    path=tmp_path/'times.jsonl'
    log(path,[{'ts':(now-timedelta(minutes=40)).isoformat(),'tracking':'A','status':'ANALYZED','stage':'analisis','seconds':3.6}])
    result=recent_activity(path,now=now)
    assert result['completed_recent']==0 and result['actual_per_hour']==0
    assert result['median_seconds_recent'] is None and result['idle_seconds']==2400


def test_recent_counts_finished_analysis_and_separates_extraction(tmp_path):
    now=datetime(2026,10,28,1,tzinfo=timezone.utc)
    path=tmp_path/'times.jsonl'
    log(path,[{'ts':(now-timedelta(seconds=30)).isoformat(),'tracking':'A','status':'PROCESSED','seconds':1},
              {'ts':(now-timedelta(seconds=20)).isoformat(),'tracking':'A','status':'ANALYZED','stage':'analisis','seconds':6},
              {'ts':now.isoformat(),'tracking':'B','status':'PROCESSED','seconds':1},
              {'ts':(now+timedelta(hours=1)).isoformat(),'tracking':'FUTURE','status':'ANALYZED','stage':'analisis','seconds':2}])
    result=recent_activity(path,now=now)
    assert result['completed_recent']==1 and result['extracted_recent']==2
    assert result['actual_per_hour']==12 and result['median_seconds_recent']==6
    assert result['idle_seconds']==20 and result['completion_source']=='analisis'


def test_missing_and_broken_logs_are_tolerated(tmp_path):
    path=tmp_path/'missing.jsonl'
    assert recent_activity(path)['completed_recent']==0
    path.write_text('incomplete json\n{}\n',encoding='utf-8')
    assert recent_activity(path)['idle_seconds'] is None


def make_close(tmp_path,n=5):
    checkpoints=CheckpointManager(tmp_path/'checkpoints.db')
    sid=checkpoints.create_session('2026-10-27')
    for i in range(n):
        checkpoints.save_pod_checkpoint(sid,PODRecord(tracking_number=f'TEST-{i}',risk_score=0,priority='Baja',
            portal_meta={'sign_id':f'sign-{i}','whether_reported':2,'false_signature':3}))
    queue=ClosingQueue(checkpoints)
    queue.enqueue(sid,'2026-10-27')
    return checkpoints,sid,queue


def test_closing_batches_resume_after_restart_without_repeating(tmp_path):
    checkpoints,sid,queue=make_close(tmp_path)
    api=MagicMock();api.get_sign_info.return_value={'whetherReported':2,'falseSignature':3}
    assert queue.run_some(api,limit=2,budget_s=100)['remaining']==3
    first=[c.args[0] for c in api.get_sign_info.call_args_list]
    restarted=ClosingQueue(CheckpointManager(checkpoints.db_path))
    restarted.enqueue(sid,'2026-10-27')
    assert restarted.pending_count()==3
    restarted.run_some(api,limit=10,budget_s=100)
    assert api.get_sign_info.call_count==5
    assert len(set(c.args[0] for c in api.get_sign_info.call_args_list))==5
    assert restarted.ready_to_finish()==[{'session_id':sid,'day':'2026-10-27'}]
    restarted.finish(sid)
    assert restarted.ready_to_finish()==[]


def test_closing_respects_budget_between_requests(tmp_path,monkeypatch):
    import storage.closing_queue as module
    _,_,queue=make_close(tmp_path)
    clock=[0.0]
    monkeypatch.setattr(module,'time',SimpleNamespace(time=lambda:1000,monotonic=lambda:clock[0]))
    api=MagicMock()
    def slow(sign_id):
        clock[0]+=3
        return {}
    api.get_sign_info.side_effect=slow
    result=queue.run_some(api,limit=10,budget_s=2)
    assert result['attempted']==1 and result['remaining']==4


def test_closing_retains_failed_job_and_detects_late_false_flag(tmp_path,monkeypatch):
    import storage.closing_queue as module
    checkpoints,sid,queue=make_close(tmp_path,n=1)
    clock=[1000.0]
    monkeypatch.setattr(module,'time',SimpleNamespace(time=lambda:clock[0],monotonic=lambda:0))
    api=MagicMock();api.get_sign_info.side_effect=TimeoutError('network')
    assert queue.run_some(api)['remaining']==1
    api.get_sign_info.side_effect=None
    api.get_sign_info.return_value={'whetherReported':1,'falseSignature':4}
    assert queue.run_some(api)['attempted']==0
    clock[0]+=10
    assert queue.run_some(api)['flagged']==1
    assert checkpoints.get_review_queue(sid)[0].priority=='Alta'


def test_session_expiry_does_not_consume_closing_job(tmp_path):
    _,_,queue=make_close(tmp_path,n=1)
    api=MagicMock();api.get_sign_info.side_effect=SessionExpiredError('expired')
    with pytest.raises(SessionExpiredError):
        queue.run_some(api)
    assert queue.pending_count()==1


def test_changed_pod_is_requeued_before_looking_at_old_sign_id(tmp_path):
    checkpoints,sid,queue=make_close(tmp_path,n=1)
    pod=checkpoints.load_session_pods(sid)[0]
    pod.portal_meta['sign_id']='replacement'
    checkpoints.save_pod_checkpoint(sid,pod)
    api=MagicMock();api.get_sign_info.return_value={}
    queue.run_some(api)
    assert api.get_sign_info.call_count==0
    queue.run_some(api)
    api.get_sign_info.assert_called_once_with('replacement')


class ClaimServer:
    timeout=1
    def __init__(self):
        self.clock=0
        self.rows={}
        self.calls=[]
        self.fail=False
    def call(self,path,body):
        if self.fail:
            raise TimeoutError('portal unavailable')
        assert path=='claim.php'
        self.calls.append(body)
        for tracking in body['done']:
            self.rows[(body['date'],tracking)]={'worker':body['worker'],'done':True,'until':None}
        granted=[]
        for tracking in body['trackings']:
            key=(body['date'],tracking)
            row=self.rows.get(key)
            if not row or (not row['done'] and (row['worker']==body['worker'] or row['until']<=self.clock)):
                granted.append(tracking)
                self.rows[key]={'worker':body['worker'],'done':False,'until':self.clock+body['lease_s']}
        return {'granted':granted}


def coordinator(tmp_path,server,worker='pc',day='2026-10-28'):
    return LeaseCoordinator(server,worker,day,100,tmp_path/'claims.db')


def test_active_lease_is_renewed_and_only_expired_work_can_be_recovered(tmp_path):
    server=ClaimServer();pc=coordinator(tmp_path,server);gpu=coordinator(tmp_path,server,'gpu')
    assert pc.acquire(['TRACK-1'])==['TRACK-1']
    assert gpu.acquire(['TRACK-1'])==[]
    server.clock=90;pc.tick()
    server.clock=110
    assert gpu.acquire(['TRACK-1'])==[]
    server.clock=191
    assert gpu.acquire(['TRACK-1'])==['TRACK-1']


def test_confirmations_survive_portal_failure_and_process_restart(tmp_path):
    server=ClaimServer();pc=coordinator(tmp_path,server)
    pc.acquire(['TRACK-1'])
    pc.complete('TRACK-1')
    server.fail=True
    with pytest.raises(TimeoutError):
        pc.tick()
    assert pc.info()['done_to_confirm']==1
    server.fail=False
    restarted=coordinator(tmp_path,server)
    restarted.tick()
    assert restarted.info()['done_to_confirm']==0
    assert server.rows[('2026-10-28','TRACK-1')]['done']
    assert coordinator(tmp_path,server,'gpu').acquire(['TRACK-1'])==[]


def test_graceful_stop_shortens_only_own_unfinished_reservations(tmp_path):
    server=ClaimServer();pc=coordinator(tmp_path,server);gpu=coordinator(tmp_path,server,'gpu')
    pc.acquire(['TRACK-1']);gpu.acquire(['TRACK-2'])
    pc.close();pc.close()
    assert server.rows[('2026-10-28','TRACK-1')]['until']==30
    assert server.rows[('2026-10-28','TRACK-2')]['until']==100


def test_backlog_and_small_claims_separate_work_states(tmp_path,monkeypatch):
    from tests.test_cobertura_20261007 import TwoCitiesAPI,DFW
    from automation.api_extractor import ApiPODExtractor
    from automation.portal_api import WaybillSummary
    monkeypatch.setattr(config,'CLAIM_BATCH_SIZE',2)
    api=TwoCitiesAPI({DFW:{'Included':6,'Excluded':2}})
    original=api.iter_waybills
    def routes(*args,**kwargs):
        yield from original(*args,**kwargs)
        yield WaybillSummary(waybill_no='NO-POD',sign_id=None,driver_name='Included')
    api.iter_waybills=routes
    summaries=[];requests=[];records=[]
    extractor=ApiPODExtractor(api,images_dir=tmp_path,downloader=lambda *a:[],on_backlog=summaries.append)
    def claim(trackings,done):
        requests.append(list(trackings))
        return [t for t in trackings if t!='Included-0']
    extractor.claim_fn=claim
    extractor.defer_claim_done=True
    extractor.run_pass([DFW],'2026-10-28',set(),records.append,should_review=lambda c:c['driverName']!='Excluded')
    states=summaries[-1]['states']
    assert all(len(r)<=2 for r in requests)
    assert len(records)==5 and extractor._claim_done==[]
    assert states['not_granted']==1 and states['without_pod']==1
    assert states['excluded_estimated']==2 and states['available_listed']==0
    assert summaries[-1]['scope_stations']==['DFW-BAA']


def test_day_rollover_processes_new_work_before_pending_closure(tmp_path,monkeypatch):
    from tests.test_step4_politeness import _patch_continuous
    import main
    main,db=_patch_continuous(monkeypatch,tmp_path,[['OLD'],['NEW']])
    monkeypatch.setattr(config,'DAY_CARRY_OVER',False)   # 30/10: aquí se prueba el cierre al cambiar de día, sin seguir el anterior
    now=[datetime(2026,10,27,23,59,tzinfo=timezone(timedelta(hours=-4)))]
    monkeypatch.setattr(main,'operation_now',lambda:now[0])
    api=MagicMock();monkeypatch.setattr(main,'PortalAPI',lambda page:api)
    def next_day(seconds):
        with sqlite3.connect(db) as con:
            row=con.execute("SELECT payload_json FROM pod_checkpoints WHERE tracking_number='OLD'").fetchone()
            payload=json.loads(row[0]);payload['portal_meta']={'sign_id':'old-sign'}
            con.execute("UPDATE pod_checkpoints SET payload_json=? WHERE tracking_number='OLD'",(json.dumps(payload),))
        now[0]=datetime(2026,10,28,0,1,tzinfo=timezone(timedelta(hours=-4)))
    main.run_continuous_workflow(1,max_passes=2,sleep=next_day)
    with sqlite3.connect(db) as con:
        assert con.execute('SELECT COUNT(*) FROM pod_checkpoints').fetchone()[0]==2
        assert con.execute("SELECT COUNT(*) FROM closing_jobs WHERE status='pending'").fetchone()[0]==1
    api.get_sign_info.assert_not_called()


def test_prefetch_preserves_pass_deadline(tmp_path,monkeypatch):
    import automation.api_extractor as module
    from tests.test_cobertura_20261007 import TwoCitiesAPI,DFW
    from concurrent.futures import Future
    from models.pod import ProcessingStatusEnum
    clock=[0.0]
    monkeypatch.setattr(module,'time',SimpleNamespace(monotonic=lambda:clock[0]))
    monkeypatch.setattr(config,'PASS_REFRESH_MIN',1)
    monkeypatch.setattr(config,'MAX_PER_DRIVER_PER_PASS',2)
    monkeypatch.setattr(config,'ROUTES_PER_BLOCK',1)
    api=TwoCitiesAPI({DFW:{'A':4,'B':4}})
    extractor=module.ApiPODExtractor(api,images_dir=tmp_path,downloader=lambda *a:[])
    extractor.prefetch=3
    def process(courier,waybill,day,pool):
        clock[0]+=100
        future=Future()
        future.set_result(PODRecord(tracking_number=waybill.waybill_no,
                                   processing_status=ProcessingStatusEnum.PROCESSED))
        return future,clock[0]
    monkeypatch.setattr(extractor,'_process_async',process)
    records=[]
    extractor.run_pass([DFW],'2026-10-28',set(),records.append)
    assert len(records)==4 and extractor.capped
