"""07/10: informe semanal de precisión (marcas del usuario contra lo que puntuó la corrida)."""

import sqlite3
from datetime import date

import config
from models.pod import PODRecord
from storage.checkpoint_manager import CheckpointManager
from tools import precision_semanal as ps


def _pod(trk, prio, motivo="Número no leído / posible número lejano: revisar manualmente."):
    p = PODRecord(tracking_number=trk, risk_score={"Alta": 90, "Media": 40, "Baja": 5}[prio], priority=prio)
    p.check_results = [{"check": "numero_direccion", "score": 40, "weight": 2.0, "explanation": motivo,
                        "details": {"status": "not_visible"}, "applicable": True}]
    return p


def test_precision_escapados_y_comparacion_con_la_semana_anterior(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "STORAGE_DIR", tmp_path)
    monkeypatch.setattr(config, "CHECKPOINT_DB_PATH", tmp_path / "c.db")
    ckpt = CheckpointManager(db_path=tmp_path / "c.db")
    marcas = []
    # Semana anterior (29/09): 1 Alta real, 1 Media falsa
    s0 = ckpt.create_session("2026-09-29")
    for trk, prio, st in (("A0", "Alta", "reportado"), ("M0", "Media", "descartado")):
        ckpt.save_pod_checkpoint(s0, _pod(trk, prio))
        marcas.append((trk, "2026-09-29", st))
    # Esta semana (06/10): 2 Alta (1 real, 1 falsa), 2 Media reales, 1 Baja que era error (se escapó), 1 sin marcar
    s1 = ckpt.create_session("2026-10-06")
    for trk, prio, st in (("A1", "Alta", "reportado"), ("A2", "Alta", "descartado"), ("M1", "Media", "reportado"),
                          ("M2", "Media", "reportado"), ("B1", "Baja", "reportado"), ("B2", "Baja", None)):
        ckpt.save_pod_checkpoint(s1, _pod(trk, prio))
        if st:
            marcas.append((trk, "2026-10-06", st))
    with sqlite3.connect(tmp_path / "report_status.db") as c:
        c.execute("CREATE TABLE report_status (tracking_number TEXT PRIMARY KEY, query_date TEXT, status TEXT, updated_at TEXT)")
        c.executemany("INSERT INTO report_status VALUES (?, ?, ?, 'x')", marcas)

    esta, r, r_ant, tot = ps.build(date(2026, 10, 6), 7)
    assert r["revisados"] == 6 and r["alta"] == 2 and r["media"] == 2
    assert r["precision_alta"] == 50.0 and r["precision_media"] == 100.0
    assert r["escapados"] == 1 and tot["escapados"] == [("2026-10-06", "B1")]
    assert tot["motivos_falsas"] == {"numero_direccion:not_visible": 1}
    assert r_ant["precision_media"] == 0.0
    md = ps.render(date(2026, 10, 6), 7, esta, r, r_ant, tot)
    assert "Precisión **Media: 100.0 %** (▲100.0 mejor)" in md and "2026-10-06 · B1" in md
