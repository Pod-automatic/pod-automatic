"""30/10: detalle de cada albarán marcado para el portal (lecturas de cada foto), y su repuntuación en la PC."""
from models.pod import PODRecord
from export import portal_sync
from processing.ocr_address import PhotoOCR
from tools.detalle_portal import decode, rescore


def _pod():
    pod = PODRecord(tracking_number="GFUS01080165625218", receipt_address="GREENVILLE GREENVILLE 4899 County Road 2208",
                    driver_name="Mateo Sanchez", station="DFW02-BAA")
    pod.billing_type = "En la puerta/Patio"
    pod._photo_readings = [PhotoOCR(path="/kaggle/a.jpg", numbers=["4899"], number_conf={"4899": 99.0},
                                    text_regions=[{"box": [1, 2, 3, 4]}]),
                           PhotoOCR(path="/kaggle/b.jpg", numbers=["4901"], number_conf={"4901": 99.0})]
    return pod


def test_detalle_ida_y_vuelta_y_repuntuar():
    pod = _pod()
    blob = portal_sync.detail_blob(pod)
    detail = decode(blob)
    assert detail["v"] == 1 and detail["pod"]["tracking_number"] == pod.tracking_number
    assert [p["numbers"] for p in detail["photos"]] == [["4899"], ["4901"]]
    assert "text_regions" not in detail["photos"][0]          # lo pesado no viaja
    priority, score, reasons = rescore(detail)                  # casa vecina sin revisar: queda para revisar
    assert priority in ("Alta", "Media") and reasons


def test_detalle_solo_en_marcados():
    pod = _pod()
    assert "detail" in portal_sync.with_detail({"priority": "Media"}, pod)
    assert "detail" not in portal_sync.with_detail({"priority": "Baja"}, pod)
    pod._photo_readings = []
    assert "detail" not in portal_sync.with_detail({"priority": "Alta"}, pod)   # sin lecturas no se manda nada
