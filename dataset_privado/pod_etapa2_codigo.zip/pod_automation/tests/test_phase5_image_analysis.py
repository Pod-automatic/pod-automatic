"""
Pruebas Unitarias para la Fase 5: Análisis de Imágenes y Arquitectura de Proveedores CV.

Verifica:
1. Resolución y ratio de aspecto (detección de baja resolución < 640x480).
2. Tamaño de archivo en disco (detección de archivos vacíos / 0 bytes / truncados).
3. Detección de imágenes corruptas o headers dañados.
4. Brillo excesivamente bajo (imágenes oscuras / subexpuestas).
5. Brillo excesivamente alto (imágenes sobreexpuestas / flash excesivo).
6. Nitidez y detección de desenfoque mediante operador Laplaciano.
7. Detección de imágenes idénticas (SHA-256 idéntico y Hamming 0).
8. Detección de imágenes muy similares (Perceptual Hashing: dHash, pHash, aHash con imagehash).
9. Arquitectura abstracta extensible (intercambio polimórfico y stub multimodal).
10. Verificación de salvaguardas éticas (sin reconocimiento facial ni identificación de personas).
"""

from pathlib import Path
import pytest
from PIL import Image, ImageDraw, ImageFilter
import numpy as np

from config import IMAGE_ANALYSIS_CONFIG
from processing.providers.base import (
    BaseImageAnalysisProvider,
    ImageAnalysisResult,
    ImageSimilarityResult,
    ImageHashes,
)
from processing.providers.local_provider import LocalCVImageProvider
from processing.providers.multimodal_stub import MultimodalAIStubProvider
from processing.image_analysis import ImageAnalysisManager, ImageQualityAnalyzer


def create_sample_pattern(width: int, height: int) -> Image.Image:
    """Crea una imagen con cuadrícula y patrones de alto contraste para pruebas de nitidez y similitud."""
    img = Image.new("RGB", (width, height), color=(240, 240, 240))
    draw = ImageDraw.Draw(img)
    step = 40
    for x in range(0, width, step):
        for y in range(0, height, step):
            if (x // step + y // step) % 2 == 0:
                draw.rectangle([x, y, x + step, y + step], fill=(30, 30, 80))
            else:
                draw.rectangle([x, y, x + step, y + step], fill=(220, 180, 50))
    draw.line([0, 0, width, height], fill=(200, 0, 0), width=4)
    draw.line([0, height, width, 0], fill=(0, 180, 0), width=4)
    return img


def test_image_resolution_metrics(tmp_path):
    """Prueba 1: Medición de resolución, megapíxeles, aspect ratio y detección de baja resolución."""
    # Imagen de alta resolución: 800 x 600
    img_hi = create_sample_pattern(800, 600)
    path_hi = tmp_path / "high_res.jpg"
    img_hi.save(path_hi)

    # Imagen de baja resolución: 320 x 240 (menor a 640x480)
    img_low = create_sample_pattern(320, 240)
    path_low = tmp_path / "low_res.jpg"
    img_low.save(path_low)

    manager = ImageAnalysisManager()

    res_hi = manager.analyze_full(path_hi)
    assert res_hi.width == 800
    assert res_hi.height == 600
    assert res_hi.megapixels == 0.48
    assert res_hi.aspect_ratio == 1.33
    assert res_hi.is_low_resolution is False
    assert res_hi.is_corrupted is False

    res_low = manager.analyze_full(path_low)
    assert res_low.width == 320
    assert res_low.height == 240
    assert res_low.is_low_resolution is True


def test_image_file_size_and_empty_check(tmp_path):
    """Prueba 2: Medición de tamaño en bytes/KB y detección de archivos vacíos (0 bytes)."""
    # Archivo normal
    img = create_sample_pattern(640, 480)
    path_normal = tmp_path / "normal.jpg"
    img.save(path_normal)

    # Archivo vacío (0 bytes)
    path_empty = tmp_path / "empty.jpg"
    path_empty.write_bytes(b"")

    manager = ImageAnalysisManager()

    res_normal = manager.analyze_full(path_normal)
    assert res_normal.file_size_bytes > 0
    assert res_normal.file_size_kb > 0
    assert res_normal.is_corrupted is False

    res_empty = manager.analyze_full(path_empty)
    assert res_empty.file_size_bytes == 0
    assert res_empty.is_corrupted is True
    assert "0 bytes" in res_empty.error_detail


def test_corrupted_image_detection(tmp_path):
    """Prueba 3: Detección de archivos con datos inválidos o headers rotos."""
    path_corrupted = tmp_path / "broken.jpg"
    path_corrupted.write_bytes(b"\xff\xd8\xff\xe0\x00\x10JFIF\x00corrupted_bytes_here_invalid_stream")

    manager = ImageAnalysisManager()
    result = manager.analyze_full(path_corrupted)

    assert result.is_corrupted is True
    assert len(result.error_detail) > 0


def test_extremely_low_brightness_detection(tmp_path):
    """Prueba 4: Detección de fotos muy oscuras / subexpuestas (cámara en bolsillo / noche sin flash)."""
    dark_img = Image.new("RGB", (640, 480), color=(10, 10, 12))
    path_dark = tmp_path / "dark.jpg"
    dark_img.save(path_dark)

    manager = ImageAnalysisManager()
    result = manager.analyze_full(path_dark)

    assert result.mean_brightness < 25.0
    assert result.is_dark is True
    assert result.is_overexposed is False


def test_extremely_high_brightness_detection(tmp_path):
    """Prueba 5: Detección de fotos sobreexpuestas / quemadas por flash excesivo o luz solar directa."""
    bright_img = Image.new("RGB", (640, 480), color=(250, 250, 252))
    path_bright = tmp_path / "bright.jpg"
    bright_img.save(path_bright)

    manager = ImageAnalysisManager()
    result = manager.analyze_full(path_bright)

    assert result.mean_brightness > 235.0
    assert result.is_overexposed is True
    assert result.is_dark is False


def test_sharpness_and_blur_detection(tmp_path):
    """Prueba 6: Nitidez alta vs desenfoque severo por movimiento o foco incorrecto."""
    sharp_img = create_sample_pattern(640, 480)
    path_sharp = tmp_path / "sharp.jpg"
    sharp_img.save(path_sharp)

    # Imagen muy borrosa con desenfoque gaussiano
    blurry_img = sharp_img.filter(ImageFilter.GaussianBlur(radius=9))
    path_blurry = tmp_path / "blurry.jpg"
    blurry_img.save(path_blurry)

    manager = ImageAnalysisManager()
    res_sharp = manager.analyze_full(path_sharp)
    res_blurry = manager.analyze_full(path_blurry)

    assert res_sharp.blur_score > res_blurry.blur_score
    assert res_sharp.is_blurry is False
    assert res_blurry.is_blurry is True


def test_identical_images_detection(tmp_path):
    """Prueba 7: Detección de imágenes 100% idénticas (mismo archivo o copiado bit a bit)."""
    img = create_sample_pattern(640, 480)
    path1 = tmp_path / "photo_a.jpg"
    path2 = tmp_path / "photo_a_copy.jpg"
    img.save(path1)
    img.save(path2)

    manager = ImageAnalysisManager()
    comp = manager.compare_images(path1, path2)

    assert comp.is_identical is True
    assert comp.is_similar is True
    assert comp.dhash_distance == 0
    assert comp.phash_distance == 0
    assert comp.confidence_score == 1.0
    assert comp.similarity_type == "identical"


def test_highly_similar_images_detection(tmp_path):
    """Prueba 8: Detección de imágenes perceptualmente similares usando dHash / pHash con imagehash."""
    base_img = create_sample_pattern(640, 480)
    path_base = tmp_path / "base.jpg"
    base_img.save(path_base, quality=95)

    # Versión ligeramente comprimida con JPEG quality 70 (contenido visual prácticamente idéntico)
    path_compressed = tmp_path / "base_compressed.jpg"
    base_img.save(path_compressed, quality=70)

    # Imagen completamente distinta (círculo verde en fondo magenta)
    diff_img = Image.new("RGB", (640, 480), color=(200, 30, 200))
    d = ImageDraw.Draw(diff_img)
    d.ellipse([100, 100, 500, 400], fill=(0, 220, 0))
    path_diff = tmp_path / "different.jpg"
    diff_img.save(path_diff)

    manager = ImageAnalysisManager()

    # Comprobación de similitud
    comp_similar = manager.compare_images(path_base, path_compressed)
    assert comp_similar.is_similar is True
    assert comp_similar.min_dist <= 5 if hasattr(comp_similar, "min_dist") else comp_similar.dhash_distance <= 5

    # Comprobación de imagen distinta
    comp_diff = manager.compare_images(path_base, path_diff)
    assert comp_diff.is_similar is False
    assert comp_diff.is_identical is False
    assert comp_diff.similarity_type == "different"


def test_abstract_provider_swapping_and_multimodal_stub(tmp_path):
    """Prueba 9: Intercambio polimórfico de proveedores (Local vs Multimodal Stub)."""
    sample_img = create_sample_pattern(640, 480)
    path_sample = tmp_path / "sample.jpg"
    sample_img.save(path_sample)

    # 1. Instanciar con proveedor Local
    local_provider = LocalCVImageProvider()
    mgr_local = ImageAnalysisManager(provider=local_provider)
    res_local = mgr_local.analyze_full(path_sample)
    assert mgr_local.provider.provider_type == "local_heuristic"
    assert res_local.is_corrupted is False

    # 2. Instanciar con proveedor Multimodal Stub
    stub_provider = MultimodalAIStubProvider(model_name="gemini-2.0-flash")
    mgr_stub = ImageAnalysisManager(provider=stub_provider)
    res_stub = mgr_stub.analyze_full(path_sample)
    assert mgr_stub.provider.provider_type == "multimodal_ai"
    assert mgr_stub.provider.is_ai_powered is True
    assert "ai_provider_status" in res_stub.metadata
    assert res_stub.metadata["ai_model"] == "gemini-2.0-flash"


def test_privacy_and_no_facial_recognition_policy():
    """Prueba 10: Salvaguarda ética obligatoria (rechaza cualquier activación de reconocimiento facial)."""
    # 1. Asegurar que la configuración global tiene deshabilitado el reconocimiento facial
    assert IMAGE_ANALYSIS_CONFIG["ALLOW_FACIAL_RECOGNITION"] is False

    # 2. Intentar activar reconocimiento facial debe lanzar ValueError
    prohibited_config = dict(IMAGE_ANALYSIS_CONFIG)
    prohibited_config["ALLOW_FACIAL_RECOGNITION"] = True

    with pytest.raises(ValueError, match="El reconocimiento facial está estrictamente"):
        LocalCVImageProvider(config_dict=prohibited_config)

    with pytest.raises(ValueError, match="El reconocimiento facial está estrictamente"):
        MultimodalAIStubProvider(config_dict=prohibited_config)
