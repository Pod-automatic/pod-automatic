"""30/10: detalles de GOFO a la vez con freno automático, y visión con la otra GPU y gramática adaptable (solo Kaggle)."""
import io
import threading
import urllib.error
from pathlib import Path

import config
from automation.api_extractor import ApiPODExtractor
from automation.portal_api import PortalAPI, PortalAPIError
from processing import vision_llm
from tests.test_api_extractor import FakeAPI, _fake_downloader


class BatchAPI(FakeAPI):
    def __init__(self, fail_batch=None, **kw):
        super().__init__(**kw)
        self.batches = []
        self.fail_batch = fail_batch or set()

    def get_sign_infos(self, sign_ids, concurrency):
        self.batches.append((list(sign_ids), concurrency))
        out = {}
        for s in sign_ids:
            out[s] = PortalAPIError("HTTP 429") if s in self.fail_batch else FakeAPI.get_sign_info(self, s)
        self.sign_calls = [c for c in self.sign_calls if c not in sign_ids]   # Solo cuentan los pedidos de a uno
        return out


def _run(api, concurrency, monkeypatch):
    monkeypatch.setattr(config, "MAX_PER_DRIVER_PER_PASS", 30)
    ext = ApiPODExtractor(api, images_dir=Path("/tmp/x"), downloader=_fake_downloader)
    ext.detail_concurrency = concurrency
    got = []
    ext.run_pass([1888], "2026-09-29", processed=set(), on_record=got.append)
    return ext, got


def test_detalles_a_la_vez_dan_los_mismos_albaranes(monkeypatch):
    _, base = _run(FakeAPI(), 1, monkeypatch)
    api = BatchAPI()
    _, fast = _run(api, 4, monkeypatch)
    assert [p.tracking_number for p in fast] == [p.tracking_number for p in base] and fast
    assert [p.photo_urls for p in fast] == [p.photo_urls for p in base]
    assert api.batches and all(c == 4 for _, c in api.batches) and api.sign_calls == []


def test_con_uno_no_se_usa_el_lote(monkeypatch):
    api = BatchAPI()
    _run(api, 1, monkeypatch)
    assert api.batches == [] and api.sign_calls


def test_lote_con_fallas_se_pide_de_a_uno_y_frena(monkeypatch):
    api = BatchAPI(fail_batch={"s101"})
    ext, got = _run(api, 4, monkeypatch)
    assert "s101" in api.sign_calls                    # El que falló en el lote se pidió de nuevo de a uno
    assert {p.tracking_number for p in got} >= {"GF101", "GF103"}
    assert ext._brake_until > 0                         # Freno: lo que sigue va uno por uno


def test_lote_lento_frena(monkeypatch):
    monkeypatch.setattr(config, "GOFO_DETAIL_SLOW_S", -1)
    ext, _ = _run(BatchAPI(), 4, monkeypatch)
    assert ext._brake_until > 0


def test_get_sign_infos_una_llamada_y_una_pausa():
    import json

    class Page:
        def __init__(self):
            self.calls = []

        def evaluate(self, js, args):
            self.calls.append(args)
            return [{"status": 200, "url": u, "text": json.dumps({"code": 200, "data": {"id": u[-2:]}})}
                    if not u.endswith("bad") else {"status": 0, "url": u, "text": "", "error": "AbortError"}
                    for u in args["urls"]]

    sleeps = []
    api = PortalAPI(Page(), sleep=sleeps.append, request_delay_s=0.5)
    out = api.get_sign_infos(["s1", "s2", "bad"], 4)
    assert out["s1"] == {"id": "s1"} and out["s2"] == {"id": "s2"} and isinstance(out["bad"], PortalAPIError)
    assert len(api.page.calls) == 1 and api.page.calls[0]["concurrency"] == 4 and sleeps == [0.5]


# ---------------- visión ----------------

def _http_error(code=500, body=b'{"error":"model runner has unexpectedly stopped"}'):
    return urllib.error.HTTPError("http://x/api/generate", code, "err", {}, io.BytesIO(body))


def _shared(monkeypatch, tmp_path, answers):
    """Servicio compartido de dos GPU; answers[url] = lista de respuestas (excepción o texto) por consulta."""
    monkeypatch.setattr(config, "GPU_DISPATCH_DB", str(tmp_path / "slots.db"))
    monkeypatch.setattr(config, "OLLAMA_URLS", ["http://g0", "http://g1"])
    monkeypatch.setattr(config, "GPU_SLOTS_PER_URL", 1)
    calls = []

    class Resp:
        def __init__(self, text):
            self.text = text

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

        def read(self):
            import json
            return json.dumps({"response": self.text}).encode()

    def urlopen(req, timeout):
        base = req.full_url.rsplit("/api/", 1)[0]
        calls.append(base)
        nxt = answers[base].pop(0)
        if isinstance(nxt, Exception):
            raise nxt
        return Resp(nxt)

    monkeypatch.setattr(vision_llm.urllib.request, "urlopen", urlopen)
    return calls


def test_falla_http_se_repite_en_la_otra_gpu_sin_gastar_el_tope(monkeypatch, tmp_path, caplog):
    monkeypatch.setattr(config, "VISION_FAILOVER", True)
    good = '{"numbers": ["12"], "photo_type": "door"}'
    calls = _shared(monkeypatch, tmp_path, {"http://g0": [_http_error()], "http://g1": [good]})
    # El reparto elige el menos usado: forzar que la primera vaya a g0
    import sqlite3
    with sqlite3.connect(config.GPU_DISPATCH_DB) as db:
        db.execute('CREATE TABLE IF NOT EXISTS gpu_slots(url TEXT PRIMARY KEY,token TEXT,until REAL,last_used REAL)')
        db.execute("INSERT INTO gpu_slots VALUES ('http://g1',NULL,0,9e12)")
    vision_llm.reset_stats()
    data, _ = vision_llm._ask_json({"model": "m", "prompt": "p", "format": "json", "images": []}, 30)
    assert data == {"numbers": ["12"], "photo_type": "door"} and calls == ["http://g0", "http://g1"]
    assert vision_llm.STATS["llamadas_vision"] == 1 and vision_llm.STATS["otra_gpu"] == 1
    assert "model runner has unexpectedly stopped" in caplog.text   # El motivo del 500 queda en el log


def test_sin_failover_queda_como_antes(monkeypatch, tmp_path):
    monkeypatch.setattr(config, "VISION_FAILOVER", False)
    monkeypatch.setattr(config, "VISION_GRAMMAR_ADAPTIVE", False)
    calls = _shared(monkeypatch, tmp_path, {"http://g0": [_http_error(), _http_error()],
                                            "http://g1": [_http_error(), _http_error()]})
    vision_llm.reset_stats()
    data, _ = vision_llm._ask_json({"model": "m", "prompt": "p", "format": "json", "images": []}, 30)
    assert data is None and len(calls) == 2 and vision_llm.STATS["llamadas_vision"] == 2


def test_gramatica_que_falla_seguido_se_pausa(monkeypatch, tmp_path):
    monkeypatch.setattr(config, "VISION_FAILOVER", True)
    monkeypatch.setattr(config, "VISION_GRAMMAR_ADAPTIVE", True)
    monkeypatch.setattr(config, "VISION_GRAMMAR_FAILS", 2)
    monkeypatch.setattr(vision_llm, "_GRAMMAR", {"fallos": [], "sin_hasta": 0.0})
    good = '{"numbers": [], "photo_type": "other"}'
    sent = []

    def fake_generate(body, timeout):
        vision_llm._SERVICE["fallo"] = False   # Como el _generate real: vacío del modelo, no falla del servicio
        sent.append("format" in body)
        return "" if "format" in body else good

    monkeypatch.setattr(vision_llm, "_generate", fake_generate)
    body = {"model": "m", "prompt": "p", "format": "json", "images": []}
    for _ in range(2):
        assert vision_llm._ask_json(body, 30)[0] is not None
    assert sent == [True, False, True, False]
    sent.clear()
    assert vision_llm._ask_json(body, 30)[0] is not None
    assert sent == [False]                              # Pausada: una sola consulta, sin gramática


def test_recarga_omitida_no_espera_en_servicio_compartido(monkeypatch, tmp_path):
    monkeypatch.setattr(config, "GPU_DISPATCH_DB", str(tmp_path / "slots.db"))
    monkeypatch.setattr(config, "VISION_GRAMMAR_ADAPTIVE", False)
    monkeypatch.setattr(vision_llm, "_generate", lambda body, timeout: "")
    slept = []
    monkeypatch.setattr(vision_llm.time, "sleep", slept.append)
    assert vision_llm._ask_json({"model": "m", "prompt": "p", "format": "json"}, 30)[0] is None
    assert slept == []
