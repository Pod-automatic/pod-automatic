"""Reglas del 30/10: otro número sin revisar por el modelo de visión (tope de consultas) que no es otra puerta."""
from models.pod import PODRecord
from processing.ocr_address import PhotoOCR, unit_ranges
from processing.scoring import check_address_number

CAP = "tope de consultas/tiempo del modelo: revisar a mano"


def _status(address, *photos):
    pod = PODRecord(tracking_number="T1", receipt_address=address, driver_name="X", station="DFW02-BAA")
    pod.billing_type = "En la puerta/Patio"
    return check_address_number(pod, list(photos)).details["status"]


def test_numero_del_contenedor_no_es_otra_casa():
    # GFUS01080165625218 (29/10, Media descartado): buzón 4899 y "7274" en el contenedor de basura, sin revisar
    buzon = PhotoOCR(path="a", numbers=["4899"], number_conf={"4899": 99.0}, vision_error=CAP)
    reja = PhotoOCR(path="b", numbers=["7274"], number_conf={"7274": 99.0})
    assert _status("GREENVILLE GREENVILLE 4899 County Road 2208", buzon, reja) == "match"


def test_casa_vecina_sin_revisar_sigue_en_duda():
    # Misma acera y cerca (como los reales 1999/1997 y 3011/3009): sigue para revisar
    buzon = PhotoOCR(path="a", numbers=["4899"], number_conf={"4899": 99.0})
    otra = PhotoOCR(path="b", numbers=["4901"], number_conf={"4901": 99.0})
    assert _status("GREENVILLE GREENVILLE 4899 County Road 2208", buzon, otra) == "two_doors_unconfirmed"


def test_numero_esperado_dudoso_no_baja():
    # Si el número de la casa no se leyó claro, el otro número sigue en duda
    buzon = PhotoOCR(path="a", numbers=["4899"], number_conf={"4899": 40.0})
    reja = PhotoOCR(path="b", numbers=["7274"], number_conf={"7274": 99.0})
    assert _status("GREENVILLE GREENVILLE 4899 County Road 2208", buzon, reja) == "two_doors_unconfirmed"


def test_cartel_de_varios_pisos_no_es_otra_puerta():
    # GFUS01079554219779 (29/10, descartado): puerta 1202 y cartel "1 / 1101- / 1330" del edificio
    puerta = PhotoOCR(path="a", numbers=["1202"], number_conf={"1202": 99.0}, vision_error=CAP)
    cartel = PhotoOCR(path="b", text="1\n1101-\n1330", numbers=["1", "1101", "1330"],
                      number_conf={"1101": 99.0, "1330": 99.0})
    addr = "Greenville Greenville 8025 Monty Stratton Pkwy Apartment 1202"
    assert _status(addr, puerta, cartel) == "match"
    # Otra puerta suelta sin revisar en un apartamento sigue en duda (la regla de casas no aplica)
    otra = PhotoOCR(path="c", numbers=["1101"], number_conf={"1101": 99.0})
    assert _status(addr, puerta, otra) == "two_doors_unconfirmed"


def test_rangos_de_pisos_solo_si_se_piden():
    assert unit_ranges("1101-1330") == []
    assert unit_ranges("1101-1330", floors=True) == [(1101, 1330)]
    assert unit_ranges("1101-1830", floors=True) == []   # Más de 3 pisos: no es un cartel de unidades
    assert unit_ranges("972-396-5000 09/29/2026", floors=True) == []


def test_numero_en_contenedor_o_vehiculo_deja_de_contar():
    # Pregunta sin tope "¿dónde está el número?": un contenedor o un vehículo no es otra puerta; una puerta sí sigue
    from processing.pipeline import drop_numbers_on_packages
    addr = "GREENVILLE GREENVILLE 4899 County Road 2208"
    for where, kept in (("bin", []), ("vehicle", []), ("door", ["7274"]), ("other", ["7274"])):
        buzon = PhotoOCR(path="a", numbers=["4899"], number_conf={"4899": 40.0})
        reja = PhotoOCR(path="b", numbers=["7274"], number_conf={"7274": 99.0})
        drop_numbers_on_packages([buzon, reja], addr, asker=lambda path, n: where)
        assert reja.numbers == kept, where
