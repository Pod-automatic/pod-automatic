from main import BatteryWatch


def test_avisa_al_pasar_a_bateria_y_en_niveles_bajos_una_vez():
    estados = iter([(True, 90), (False, 80), (False, 60), (False, 29), (False, 28), (False, 14), (True, 15), (False, 50)])
    avisos = []
    w = BatteryWatch(reader=lambda: next(estados), warn=avisos.append)
    for _ in range(8):
        w.check()
    assert ["batería (80" in avisos[0], "29 %" in avisos[1], "14 %" in avisos[2],
            "Cargador conectado" in avisos[3], "batería (50" in avisos[4]] == [True] * 5
    assert len(avisos) == 5


def test_sin_bateria_no_avisa():
    avisos = []
    BatteryWatch(reader=lambda: None, warn=avisos.append).check()
    assert avisos == []
