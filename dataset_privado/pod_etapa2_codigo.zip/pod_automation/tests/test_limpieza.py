import sqlite3

from storage.checkpoint_manager import CheckpointManager
from storage.limpieza import apply_plan, build_plan, guide_trackings


def _add(conn, sid, day, trackings):
    conn.execute("INSERT INTO audit_sessions VALUES (?, ?, 'x', 'x', 'COMPLETED', 0, 0, NULL)", (sid, day))
    for t in trackings:
        conn.execute("INSERT INTO pod_checkpoints (session_id, tracking_number, query_date, payload_json, created_at) "
                     "VALUES (?, ?, ?, '{}', 'x')", (sid, t, day))
    conn.execute("INSERT INTO route_progress VALUES (?, 'S', 'D', 'n', 1, 1, 1, 'x')", (sid,))


def test_keeps_guide_cases_reference_and_current_day(tmp_path):
    db = tmp_path / "pod.db"
    CheckpointManager(db)
    conn = sqlite3.connect(db)
    _add(conn, "s1", "2026-10-01", ["GFUS0000000000001", "GFUS0000000000002"])   # día de referencia
    _add(conn, "s2", "2026-10-02", ["GFUS0000000000003", "GFUS0000000000004"])   # día pasado
    _add(conn, "s3", "2026-10-05", ["GFUS0000000000005"])                        # día en curso
    conn.commit()
    images = tmp_path / "pod_images"
    for day, trk in (("2026-10-01", "GFUS0000000000001"), ("2026-10-02", "GFUS0000000000003"),
                     ("2026-10-02", "GFUS0000000000004"), ("2026-10-05", "GFUS0000000000005")):
        (images / day / trk).mkdir(parents=True)
        (images / day / trk / "foto_1.jpg").write_bytes(b"x" * 10)
    (images / "demo_sample").mkdir()

    plan = build_plan(conn, today="2026-10-05", images_dir=images, reference_days=["2026-10-01"],
                      guide={"GFUS0000000000004"})
    assert plan.rows_by_day == {"2026-10-02": 1}
    assert plan.kept_rows_by_day == {"2026-10-02": 1}
    apply_plan(conn, plan)

    left = {r[0] for r in conn.execute("SELECT tracking_number FROM pod_checkpoints")}
    assert left == {"GFUS0000000000001", "GFUS0000000000002", "GFUS0000000000004", "GFUS0000000000005"}
    assert {r[0] for r in conn.execute("SELECT session_id FROM route_progress")} == {"s1", "s3"}
    assert conn.execute("SELECT COUNT(*) FROM audit_sessions").fetchone()[0] == 3
    assert not (images / "2026-10-02" / "GFUS0000000000003").exists()
    assert (images / "2026-10-02" / "GFUS0000000000004").exists()
    assert (images / "2026-10-01" / "GFUS0000000000001").exists()
    assert (images / "demo_sample").exists()
    conn.close()


def test_guide_trackings_reads_status_notes_and_cases(tmp_path):
    status = tmp_path / "report_status.db"
    with sqlite3.connect(status) as st:
        st.execute("CREATE TABLE report_status (tracking_number TEXT, query_date TEXT, status TEXT, updated_at TEXT)")
        st.execute("INSERT INTO report_status VALUES ('GFUS0000000000010', 'd', 'descartado', 'x')")
    out, tests = tmp_path / "output", tmp_path / "tests"
    out.mkdir()
    tests.mkdir()
    (out / "pendientes_20261004.md").write_text("1. **GFUS0000000000011** (Juan) y YT2640221437572356", encoding="utf-8")
    (tests / "casos_reales_20261001.json").write_text('{"casos": [{"tracking": "GFUS0000000000012"}]}', encoding="utf-8")
    assert guide_trackings(status, out, tests) == {"GFUS0000000000010", "GFUS0000000000011",
                                                   "GFUS0000000000012", "YT2640221437572356"}
