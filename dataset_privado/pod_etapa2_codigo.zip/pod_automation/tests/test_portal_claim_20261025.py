"""Reparto de trabajo con el portal (25/10): claim_granted respeta los límites de api/claim.php (100 albaranes, 200 hechos por pedido)."""
from export import portal_sync


class FakePortal:
    def __init__(self, deny=()):
        self.calls, self.deny = [], set(deny)

    def call(self, path, body=None, query=None):
        assert path == "claim.php"
        assert len(body["trackings"]) <= 100 and len(body["done"]) <= 200
        self.calls.append(body)
        return {"ok": True, "granted": [t for t in body["trackings"] if t not in self.deny]}


def test_un_pedido_normal():
    p = FakePortal(deny={"B"})
    assert portal_sync.claim_granted(p, "gpu", "2026-10-25", ["A", "B", "C"], ["X"], 600) == ["A", "C"]
    assert len(p.calls) == 1 and p.calls[0]["worker"] == "gpu" and p.calls[0]["done"] == ["X"] and p.calls[0]["lease_s"] == 600


def test_muchos_hechos_acumulados_se_mandan_aparte():
    p = FakePortal()
    done = ["D%04d" % i for i in range(450)]
    got = portal_sync.claim_granted(p, "pc", "2026-10-25", ["A", "B"], done, 600)
    assert got == ["A", "B"]
    sent = [t for c in p.calls for t in c["done"]]
    assert sent == done and all(len(c["done"]) <= 200 for c in p.calls)
    assert p.calls[-1]["trackings"] == ["A", "B"] and len(p.calls) == 3


def test_mas_de_100_albaranes_se_parten():
    p = FakePortal(deny={"T0150"})
    trk = ["T%04d" % i for i in range(250)]
    got = portal_sync.claim_granted(p, "pc", "2026-10-25", trk, ["X"], 600)
    assert len(got) == 249 and "T0150" not in got
    assert [len(c["trackings"]) for c in p.calls] == [100, 100, 50]
    assert p.calls[0]["done"] == ["X"] and p.calls[1]["done"] == [] and p.calls[2]["done"] == []


def test_solo_hechos_sin_albaranes():
    p = FakePortal()
    assert portal_sync.claim_granted(p, "pc", "2026-10-25", [], ["X", "X", "Y"], 600) == []
    assert len(p.calls) == 1 and p.calls[0]["done"] == ["X", "Y"]


def test_si_el_portal_falla_sube_la_excepcion():
    class Down:
        def call(self, *a, **k):
            raise portal_sync.PortalError("sin conexión")
    try:
        portal_sync.claim_granted(Down(), "pc", "2026-10-25", ["A"], [], 600)
        assert False
    except portal_sync.PortalError:
        pass
