from dataclasses import asdict
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from PIL import Image

from processing.first_read_experiment import ByteCache, build_detail, capture_ocr, numeric_regions, rank_photos, vision_read
from processing.ocr_address import PhotoOCR
from processing.vision_llm import VisionResult


class FirstReadTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.folder = Path(self.tmp.name)
        self.path = self.folder / 'photo.png'
        Image.new('RGB', (800, 600), 'white').save(self.path)
        self.record = {'reading': asdict(PhotoOCR(str(self.path))), 'width': 800, 'height': 600,
                       'sharpness': 20, 'regions': [{'box': [[50, 50], [120, 50], [120, 70], [50, 70]],
                                                   'text': '2905', 'confidence': .9}]}

    def test_detail_is_bounded_and_label_is_excluded(self):
        self.assertEqual(build_detail(self.path, self.record).size, (1024, 1024))
        self.record['reading']['is_label'] = True
        self.assertIsNone(build_detail(self.path, self.record))

    def test_capture_keeps_boxes_from_one_detection_and_reuses_them(self):
        cache = ByteCache(self.folder/'cache')
        detections = [([[50,50],[120,50],[120,70],[50,70]], '2905', .99)]
        with patch('processing.ocr_address.detect_label_cv', return_value=(False,None,'')), \
             patch('processing.ocr_address._readtext', return_value=(detections,600)) as detector, \
             patch.dict('processing.ocr_address._LAST_PADDLE_WIDTH', {'w':800}):
            first,hit1 = capture_ocr(self.path,cache)
            second,hit2 = capture_ocr(self.path,cache)
        self.assertEqual(detector.call_count,1)
        self.assertFalse(hit1)
        self.assertTrue(hit2)
        self.assertEqual(first['regions'],second['regions'])
        self.assertIn('2905',first['reading']['numbers'])

    def test_merging_new_reading_preserves_old_contradiction(self):
        from tools.probar_primera_lectura import merge_readings
        self.record['reading']['numbers']=['2903']
        response={'0':asdict(VisionResult(str(self.path),numbers=['2905'],photo_type='door'))}
        merged=merge_readings([self.record],response)
        self.assertEqual(merged[0].numbers,['2903','2905'])
        self.assertEqual(self.record['reading']['numbers'],['2903'])

    def test_cache_uses_bytes_and_options_not_filename(self):
        cache = ByteCache(self.folder/'cache')
        other = self.folder/'copy.png'
        other.write_bytes(self.path.read_bytes())
        self.assertEqual(cache.key(self.path, 'ocr', {}), cache.key(other, 'ocr', {}))
        self.assertNotEqual(cache.key(self.path, 'ocr', {'model': 'a'}), cache.key(self.path, 'ocr', {'model': 'b'}))
        other.write_bytes(b'changed')
        self.assertNotEqual(cache.key(self.path, 'ocr', {}), cache.key(other, 'ocr', {}))

    def test_success_reused_without_second_reader_call(self):
        cache = ByteCache(self.folder/'cache')
        calls = []
        def reader(path, **kwargs):
            calls.append(kwargs)
            return VisionResult(str(path), numbers=['2905'], photo_type='door')
        a, sa = vision_read(self.path, self.record, 'detail', cache, reader=reader)
        b, sb = vision_read(self.path, self.record, 'detail', cache, reader=reader)
        self.assertEqual(len(calls), 1)
        self.assertEqual(a.numbers, b.numbers)
        self.assertTrue(sb['cache_hit'])
        self.assertNotIn('2905', calls[0]['prompt'])
        self.assertEqual(calls[0]['image'].size, (1024, 1024))

    def test_error_is_not_cached(self):
        cache = ByteCache(self.folder/'cache')
        calls = []
        def reader(path, **kwargs):
            calls.append(path)
            return VisionResult(str(path), error='timeout')
        vision_read(self.path, self.record, 'normal', cache, reader=reader)
        vision_read(self.path, self.record, 'normal', cache, reader=reader)
        self.assertEqual(len(calls), 2)

    def test_ranking_excludes_labels_and_errors_but_keeps_all_other_photos(self):
        from copy import deepcopy
        no_text = deepcopy(self.record)
        no_text['regions'] = []
        label = deepcopy(self.record)
        label['reading']['is_label'] = True
        error = deepcopy(self.record)
        error['reading']['error'] = 'corrupt'
        self.assertEqual(rank_photos([no_text, self.record, label, error]), [1, 0])

    def test_group_vertical_digits(self):
        self.record['regions'] = [{'text': str(n), 'confidence': .9,
            'box': [[50, y], [60, y], [60, y+10], [50, y+10]]} for n,y in [(2,20),(9,40),(0,60),(5,80)]]
        self.assertEqual(numeric_regions(self.record)[0]['text'], '2905')
