from models.pod import PODRecord
from processing.ocr_address import PhotoOCR, match_numbers, parse_us_address
from processing.scoring import score_pod

# 25/10: dos falsas alarmas aprobadas por el usuario (output/falsas_alarmas_20261025.md).


def _pod(direccion):
    pod = PODRecord(tracking_number="T", receipt_address=direccion, driver_name="X", station="DFW02-BAA",
                    billing_type="En la puerta/Patio")
    pod.photo_paths = ["a.jpg", "l.jpg"]
    return pod


def _fotos(numeros, conf=90.0, vision=True):
    return [PhotoOCR(path="a.jpg", text=" ".join(numeros), numbers=list(numeros),
                     number_conf={n: conf for n in numeros}, vision_used=vision,
                     vision_all=list(numeros) if vision else [], photo_type="door"),
            PhotoOCR(path="l.jpg", is_label=True)]


# --- 1) "Apt N <calle>": la casa es el segundo número ---

def test_apt_antes_de_la_casa_la_casa_es_el_segundo_numero():
    a = parse_us_address("Richardson Richardson Apt 316 150 W Main St; Apt 316")
    assert a.house_number == "150"
    assert a.unit == "316"


def test_apt_antes_de_la_casa_sin_apt_final_toma_la_unidad_del_prefijo():
    a = parse_us_address("Richardson Apt 316 150 W Main St")
    assert (a.house_number, a.unit) == ("150", "316")


def test_apt_316_150_main_con_150_en_foto_no_es_alta():
    pod = _pod("Richardson Richardson Apt 316 150 W Main St; Apt 316")
    score_pod(pod, _fotos(["150"]))
    assert pod.priority != "Alta"
    num = next(c for c in pod.check_results if c["check"] == "numero_direccion")
    assert num["details"]["status"] == "partial"


def test_apt_316_150_main_con_unidad_visible_es_baja_en_numero():
    pod = _pod("Richardson Richardson Apt 316 150 W Main St; Apt 316")
    score_pod(pod, _fotos(["316"]))
    num = next(c for c in pod.check_results if c["check"] == "numero_direccion")
    assert num["details"]["status"] == "match"


def test_direccion_sin_apt_delante_no_cambia():
    a = parse_us_address("Dallas 316 Main St Apt 12")
    assert (a.house_number, a.unit) == ("316", "12")
    a = parse_us_address("Dallas 1400 Andrews Pkwy 205")
    assert (a.house_number, a.unit) == ("1400", "205")


def test_apt_con_codigo_postal_detras_no_se_reinterpreta():
    a = parse_us_address("Apt 12 75063 Main St")
    assert a.house_number != "75063"


def test_apartamento_otra_puerta_ajena_a_la_direccion_sigue_siendo_no_concuerda():
    # 4455 no aparece en la dirección: no es el edificio, es otra puerta
    a = parse_us_address("Richardson Apt 316 150 W Main St")
    m = match_numbers(a, _fotos(["4455"]))
    assert m.status == "mismatch"


def test_apartamento_numero_de_la_calle_en_foto_es_media_no_alta():
    # Regla (b): todo lo leído está escrito en la dirección del recibo (aquí "County Road 249" tras el edificio)
    a = parse_us_address("Plano 1200 Oak Ln Apt 316 Bldg 249")
    m = match_numbers(a, _fotos(["249"]))
    assert m.status != "mismatch"


# --- 2) número leído al revés ---

def test_numero_leido_al_reves_cuenta_como_coincidencia():
    pod = _pod("Arlington Arlington 4003 Windy Meadow Ct")
    fotos = _fotos(["520", "3004"])
    m = match_numbers(parse_us_address(pod.receipt_address), fotos)
    assert m.status == "match"


def test_numero_al_reves_4003_no_es_media():
    pod = _pod("Arlington Arlington 4003 Windy Meadow Ct")
    score_pod(pod, _fotos(["3004"]))
    num = next(c for c in pod.check_results if c["check"] == "numero_direccion")
    assert num["score"] == 0


def test_vecino_de_un_digito_distinto_sigue_siendo_problema():
    a = parse_us_address("Arlington 4003 Windy Meadow Ct")
    assert match_numbers(a, _fotos(["4005"])).status != "match"
    assert match_numbers(a, _fotos(["3005"])).status != "match"


def test_permutacion_que_no_es_el_reverso_no_es_match():
    a = parse_us_address("Arlington 4003 Windy Meadow Ct")
    assert match_numbers(a, _fotos(["3040"])).status != "match"
    assert match_numbers(a, _fotos(["0430"])).status != "match"


def test_palindromo_y_dos_digitos_no_usan_el_reverso():
    a = parse_us_address("Arlington 4004 Windy Meadow Ct")
    assert match_numbers(a, _fotos(["4004"])).status == "match"   # el propio
    a = parse_us_address("Arlington 45 Windy Meadow Ct")
    assert match_numbers(a, _fotos(["54"])).status != "match"
