"""07/10: copia de seguridad diaria de las bases (consistente aunque la corrida esté escribiendo) con rotación."""

import sqlite3
import zipfile
from datetime import datetime, timedelta

from tools.respaldo import respaldar


def test_respalda_las_bases_y_conserva_solo_los_ultimos_dias(tmp_path):
    storage, destino = tmp_path / "storage", tmp_path / "respaldos"
    storage.mkdir()
    with sqlite3.connect(storage / "report_status.db") as c:
        c.execute("CREATE TABLE report_status (tracking TEXT, status TEXT)")
        c.execute("INSERT INTO report_status VALUES ('GFUS1', 'reportado')")
    abierta = sqlite3.connect(storage / "report_status.db")   # La corrida tiene la base abierta
    abierta.execute("INSERT INTO report_status VALUES ('GFUS2', 'descartado')")  # Escritura sin confirmar
    hoy = datetime(2026, 10, 7)
    for i in range(4):
        respaldar(storage, destino, dias=3, hoy=hoy + timedelta(days=i))
    abierta.close()
    zips = sorted(p.name for p in destino.glob("respaldo_*.zip"))
    assert zips == ["respaldo_20261008.zip", "respaldo_20261009.zip", "respaldo_20261010.zip"]

    with zipfile.ZipFile(destino / "respaldo_20261010.zip") as zf:
        zf.extract("report_status.db", tmp_path / "x")
    with sqlite3.connect(tmp_path / "x" / "report_status.db") as c:
        assert c.execute("SELECT tracking, status FROM report_status").fetchall() == [("GFUS1", "reportado")]
