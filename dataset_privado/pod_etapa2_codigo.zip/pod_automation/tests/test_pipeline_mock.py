"""
Prueba de Integración Mock: Valida el flujo completo de Scraping en DOM simulado,
análisis de Computer Vision y exportación a Excel.
"""

from pathlib import Path
from playwright.sync_api import sync_playwright
import openpyxl

from automation.browser import BrowserManager
from automation.pod_scraper import PODScraper
from processing.validator import PODValidator
from export.excel_exporter import PODExcelExporter
from models.pod import VerdictEnum


MOCK_DASHBOARD_HTML = """
<!DOCTYPE html>
<html>
<head><title>Mock DSP Dashboard</title></head>
<body>
    <div id="dsp-dashboard">
        <h2>Dashboard DSP - Gofo Express</h2>
        <div class="user-avatar">Operador DSP</div>
        <input type="date" id="fecha-consulta" value="2026-09-12">
        <button class="btn-query">Consulta</button>

        <table>
            <thead>
                <tr>
                    <th>Tracking</th><th>Driver</th><th>Dirección</th>
                    <th>Estado</th><th>Fecha/Hora</th><th>Tipo</th><th>Acción</th>
                </tr>
            </thead>
            <tbody>
                <tr class="el-table__row">
                    <td><a class="tracking-number">GF100029384ES</a></td>
                    <td>Juan Gómez</td>
                    <td>Calle Serrano 12, Madrid</td>
                    <td>Entregado</td>
                    <td>2026-09-12 11:20:00</td>
                    <td>En mano</td>
                    <td><button class="btn-view-pod">Ver POD</button></td>
                </tr>
                <tr class="el-table__row">
                    <td><a class="tracking-number">GF100029385ES</a></td>
                    <td>Pedro Díaz</td>
                    <td>Av. de América 34, Madrid</td>
                    <td>Entregado</td>
                    <td>2026-09-12 12:45:00</td>
                    <td>Puerta</td>
                    <td><button class="btn-view-pod">Ver POD</button></td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>
"""


def test_mock_scraping_and_pipeline(tmp_path, monkeypatch):
    mock_html_path = tmp_path / "mock_dashboard.html"
    mock_html_path.write_text(MOCK_DASHBOARD_HTML, encoding="utf-8")

    def mock_start(self, use_saved_session=False):
        self.playwright = sync_playwright().start()
        self.browser = self.playwright.chromium.launch(headless=True)
        self.context = self.browser.new_context()
        self.page = self.context.new_page()
        return self.page

    monkeypatch.setattr(BrowserManager, "start", mock_start)
    bm = BrowserManager(headless=True)
    try:
        page = bm.start(use_saved_session=False)
        page.goto(mock_html_path.as_uri())

        scraper = PODScraper(bm)
        rows = scraper.get_table_rows()
        assert len(rows) == 2

        raw_pods = [scraper.extract_row_summary(r) for r in rows]
        assert raw_pods[0].albaran == "GF100029384ES"
        assert raw_pods[0].driver == "Juan Gómez"
        assert raw_pods[1].albaran == "GF100029385ES"
        assert raw_pods[1].driver == "Pedro Díaz"

        # Simular que al menos uno tiene firma
        raw_pods[0].tiene_firma = True

        # Validar con el motor
        validator = PODValidator()
        audited = validator.validate_batch(raw_pods)
        assert len(audited) == 2

        # Exportar a Excel
        exporter = PODExcelExporter(output_dir=tmp_path)
        excel_path = exporter.export(audited, filename="mock_output.xlsx")
        assert excel_path.exists()

        wb = openpyxl.load_workbook(excel_path)
        ws = wb["POD Results"]
        assert ws.max_row == 3
        wb.close()

    finally:
        bm.close()
