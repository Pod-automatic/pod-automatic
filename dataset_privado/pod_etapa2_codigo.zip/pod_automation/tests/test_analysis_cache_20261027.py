from dataclasses import asdict
import sqlite3

import pytest
import config
from processing.ocr_address import PhotoOCR
from storage.analysis_cache import cached_photo_reading,cached_photo_batch,ReadingCache

@pytest.fixture(autouse=True)
def isolated(monkeypatch,tmp_path):
    monkeypatch.setattr(config,'ANALYSIS_CACHE_ENABLED',True)
    monkeypatch.setattr(config,'ANALYSIS_CACHE_PATH',tmp_path/'cache.db')
    monkeypatch.setattr(config,'ANALYSIS_CACHE_EPOCH','test')
    monkeypatch.setattr(config,'ANALYSIS_CACHE_MAX_ENTRIES',100)


def test_photo_cache_persists_across_wrappers_and_rebinds_paths(tmp_path):
    first=tmp_path/'a.jpg'; second=tmp_path/'b.jpg'
    first.write_bytes(b'photo'); second.write_bytes(b'photo')
    calls=[]
    def compute(path,min_conf=None,max_side=None):
        calls.append(path)
        return PhotoOCR(str(path),text='door 1234',numbers=['1234'])
    result=cached_photo_reading(compute)(first)
    result.numbers.append('mutated')
    restarted=cached_photo_reading(compute)(second)
    assert calls==[first] and restarted.path==str(second) and restarted.numbers==['1234']


def test_same_path_same_size_modified_bytes_force_new_read(tmp_path):
    image=tmp_path/'a.jpg'; image.write_bytes(b'first')
    calls=[]
    @cached_photo_reading
    def compute(path,min_conf=None,max_side=None):
        calls.append(1); return PhotoOCR(str(path),text=image.read_text())
    assert compute(image).text=='first'
    image.write_bytes(b'other')
    assert compute(image).text=='other' and len(calls)==2


def test_model_options_epoch_address_and_photo_set_invalidate(tmp_path,monkeypatch):
    first=tmp_path/'a.jpg'; second=tmp_path/'b.jpg'
    first.write_bytes(b'first'); second.write_bytes(b'second')
    calls=[]
    @cached_photo_batch
    def compute(paths,expected_address=None):
        calls.append(1); return [PhotoOCR(str(p),text='read') for p in paths]
    compute([first],'123 Main St'); compute([first],'123 Main St')
    assert len(calls)==1
    compute([first],'124 Main St')
    compute([first,second],'124 Main St')
    monkeypatch.setattr(config,'VISION_MODEL','changed-model')
    compute([first,second],'124 Main St')
    monkeypatch.setattr(config,'OCR_MIN_CONFIDENCE',99)
    compute([first,second],'124 Main St')
    monkeypatch.setattr(config,'ANALYSIS_CACHE_EPOCH','updated-weights')
    compute([first,second],'124 Main St')
    monkeypatch.setattr(config,'FAR_TEXT_MAX_HEIGHT_RATIO',0.123)
    compute([first,second],'124 Main St')
    assert len(calls)==7


def test_errors_missing_files_and_disabled_cache_are_retried(tmp_path,monkeypatch):
    image=tmp_path/'a.jpg'; image.write_bytes(b'image')
    calls=[]
    @cached_photo_batch
    def failed(paths,expected_address=None):
        calls.append(1); return [PhotoOCR(str(p),vision_error='timeout') for p in paths]
    failed([image]); failed([image])
    assert len(calls)==2
    @cached_photo_reading
    def compute(path,min_conf=None,max_side=None):
        calls.append(1); return PhotoOCR(str(path))
    compute(tmp_path/'missing'); compute(tmp_path/'missing')
    monkeypatch.setattr(config,'ANALYSIS_CACHE_ENABLED',False)
    compute(image); compute(image)
    assert len(calls)==6


def test_corrupt_or_expired_cache_and_capacity_do_not_break_analysis(tmp_path,monkeypatch):
    cache=ReadingCache()
    monkeypatch.setattr(config,'ANALYSIS_CACHE_MAX_ENTRIES',2)
    for index in range(3): cache.put(str(index),{'read':index})
    assert cache.get('0') is None and cache.get('2')=={'read':2}
    with sqlite3.connect(config.ANALYSIS_CACHE_PATH) as conn:
        conn.execute("UPDATE readings SET payload='invalid JSON' WHERE cache_key='2'")
        conn.execute("UPDATE readings SET created=0 WHERE cache_key='1'")
    assert cache.get('2') is None and cache.get('1') is None


def test_ignored_secondary_model_failure_is_not_cached(tmp_path):
    from storage.analysis_cache import track_read_failures
    image=tmp_path/'image'; image.write_bytes(b'image')
    calls=[]
    @track_read_failures
    def secondary(): raise TimeoutError('segunda opinión')
    @cached_photo_batch
    def compute(paths,expected_address=None):
        calls.append(1)
        try: secondary()
        except TimeoutError: pass
        return [PhotoOCR(str(path)) for path in paths]
    compute([image]); compute([image])
    assert len(calls)==2


def test_snapshot_includes_committed_wal_and_never_overwrites(tmp_path):
    from tools.analysis_cache_snapshot import snapshot
    cache=ReadingCache(); cache.put('saved',{'text':'1234'})
    out=tmp_path/'backup.db'
    snapshot(config.ANALYSIS_CACHE_PATH,out)
    assert ReadingCache(out).get('saved')=={'text':'1234'}
    with pytest.raises(FileExistsError): snapshot(config.ANALYSIS_CACHE_PATH,out)
    with pytest.raises(ValueError): snapshot(config.ANALYSIS_CACHE_PATH,config.ANALYSIS_CACHE_PATH)
