import threading
from types import SimpleNamespace

import pytest
import config
from processing.analysis_queue import AnalysisQueue
from tests.test_api_extractor import FakeAPI, _fake_downloader
from automation.api_extractor import ApiPODExtractor


def test_analysis_overlaps_extraction_and_keeps_submission_order():
    entered = threading.Event()
    release = threading.Event()
    done = []

    class Pipeline:
        on_scored = staticmethod(lambda pod: done.append(pod.tracking_number))
        def submit(self, pod):
            entered.set()
            assert release.wait(3)
            self.on_scored(pod)
        def collect(self, block=False): pass
        def drain(self): pass
        def close(self): pass

    consumer = AnalysisQueue(Pipeline(), capacity=2)
    try:
        consumer.submit(SimpleNamespace(tracking_number='A'))
        assert entered.wait(3)
        # Extracción puede entregar B mientras la visión de A sigue ocupada.
        consumer.submit(SimpleNamespace(tracking_number='B'))
        consumer.submit(SimpleNamespace(tracking_number='A'))  # checkpoint precargado, aún en vuelo
        assert done == []
        release.set()
        consumer.drain()
        assert done == ['A', 'B']
    finally:
        release.set()
        consumer.close()


def test_queue_propagates_failure_instead_of_waiting_forever():
    class Pipeline:
        on_scored = staticmethod(lambda pod: None)
        def submit(self, pod): raise ValueError('failed consumer')
        def collect(self, block=False): pass
    consumer = AnalysisQueue(Pipeline())
    consumer.submit(SimpleNamespace(tracking_number='A'))
    consumer.thread.join(3)
    with pytest.raises(RuntimeError): consumer.drain()


def test_route_cache_refreshes_on_summary_change_expiry_and_day(tmp_path, monkeypatch):
    monkeypatch.setattr(config, 'ROUTE_LIST_CACHE_S', 180)
    monkeypatch.setattr(config, 'CITY_DISPATCH_DB', '')
    monkeypatch.setattr(config, 'GOFO_SESSION_GROUP', '')
    api = FakeAPI()
    real = api.iter_waybills
    calls = []
    def listed(*args, **kwargs):
        calls.append(args[0:2])
        yield from real(*args, **kwargs)
    api.iter_waybills = listed
    ext = ApiPODExtractor(api, images_dir=tmp_path, downloader=_fake_downloader)
    for _ in range(2): ext.run_pass([1888], '2026-10-28', set(), lambda p: None)
    assert len(calls) == 2  # Una consulta por conductor, no por pasada.
    api.list_couriers = lambda *a: [{'driverName':'Driver A', 'userId':1, 'podPieces':3}]
    ext.run_pass([1888], '2026-10-28', set(), lambda p: None)
    assert len(calls) == 3
    for entry in ext.route_lists.values(): entry['at'] -= 181
    ext.run_pass([1888], '2026-10-28', set(), lambda p: None)
    assert len(calls) == 4
    ext.run_pass([1888], '2026-10-29', set(), lambda p: None)
    assert len(calls) == 5


def test_empty_city_turn_is_bounded_without_marking_anything_done(tmp_path, monkeypatch):
    monkeypatch.setattr(config, 'CITY_DISPATCH_DB', str(tmp_path/'city.db'))
    monkeypatch.setattr(config, 'CITY_TURN_S', 1e-9)
    monkeypatch.setattr(config, 'ROUTES_PER_BLOCK', 1)
    api = FakeAPI()
    from automation.portal_api import WaybillSummary
    calls = []
    def unsigned(*args, **kwargs):
        calls.append(1)
        yield WaybillSummary(waybill_no='unsigned', sign_id=None, driver_name='Driver A')
    api.iter_waybills = unsigned
    ext = ApiPODExtractor(api, images_dir=tmp_path, downloader=_fake_downloader)
    processed = set()
    assert ext.run_pass([1888], '2026-10-28', processed, lambda p: pytest.fail('No POD')) == 0
    assert len(calls) == 1 and not processed


def test_portable_state_keeps_coordinates_and_cache_without_cookies(tmp_path):
    import sqlite3
    import zipfile
    from tools.kaggle_state import backup, restore
    root=tmp_path/'old';(root/'storage').mkdir(parents=True)
    with sqlite3.connect(root/'storage'/'analysis_cache.db') as db:
        db.execute('CREATE TABLE coordinates(lat REAL,lng REAL)')
        db.execute('INSERT INTO coordinates VALUES (32.7,-97.1)')
    (root/'storage'/'session_state.json').write_text('private')
    archive=backup(root,tmp_path/'pod_kaggle_estado.zip')
    with zipfile.ZipFile(archive) as z: assert z.namelist()==['storage/analysis_cache.db']
    target=tmp_path/'new';restore(target,archive)
    with sqlite3.connect(target/'storage'/'analysis_cache.db') as db:
        assert db.execute('SELECT * FROM coordinates').fetchone()==(32.7,-97.1)


def test_continuous_queue_finishes_checkpoints_and_resumes_without_duplicates(tmp_path, monkeypatch):
    import sqlite3
    from tests.test_api_extractor import _patch_main
    main,db,ui_calls=_patch_main(monkeypatch,tmp_path)
    monkeypatch.setattr(config,'ASYNC_ANALYSIS',True)
    monkeypatch.setattr(config,'ANALYSIS_QUEUE_SIZE',2)
    main.run_continuous_workflow(1,max_passes=2,sleep=lambda _:None)
    main.run_continuous_workflow(1,max_passes=1,sleep=lambda _:None)
    with sqlite3.connect(db) as con:
        rows=con.execute('SELECT tracking_number,risk_score FROM pod_checkpoints').fetchall()
    assert len(rows)==4 and all(score is not None for _,score in rows)
    assert not ui_calls
