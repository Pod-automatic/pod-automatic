"""Paso 5: cada CheckResult y la fórmula del score total (incluye 'OCR=100 y el resto en 0 da Alta')."""

import pytest

import config
from models.pod import PODRecord, ImageQualityMetrics, PriorityEnum, DuplicateStatusEnum
from processing.ocr_address import PhotoOCR, parse_us_address, match_numbers
from processing.scoring import (
    CheckResult, combine_scores, priority_for, score_pod, top_reasons,
    check_address_number, check_photo_count, check_label_photos, check_building_photos,
    check_duplicates, check_gps_distance, check_image_quality, check_platform_flag,
)

APT = "Allen Allen 505 E Exchange Pkwy Apt 6105 Gate code: 1500# DO NOT LEAVE AT OFFICE"
HOUSE = "ALLEN ALLEN 1530 Broadmoor Dr"


def door(*numbers, text=""):
    return PhotoOCR(path="door.jpg", numbers=list(numbers), text=text)


def label(trk=None):
    return PhotoOCR(path="label.jpg", is_label=True, label_tracking=trk, text="GOFO SHIP TO")


def pod(address=HOUSE, billing="En la puerta/Patio", photos=3, **kw):
    return PODRecord(tracking_number="GFUS01074122718596", receipt_address=address, address=address,
                     billing_type=billing, photo_paths=[f"f{i}.jpg" for i in range(photos)], **kw)


# ------------------------------------------------------------------ fórmula del total

def test_formula_ocr_100_rest_0_gives_alta():
    results = [CheckResult("numero_direccion", 100, 3.0, "no concuerda")] + [
        CheckResult(n, 0, w, "ok") for n, w in config.CHECK_WEIGHTS.items() if n != "numero_direccion"
    ]
    total = combine_scores(results)
    weighted = 100 * 3.0 / sum(config.CHECK_WEIGHTS.values())
    assert weighted < 30                              # El promedio solo lo diluiría a "Baja"
    assert total == pytest.approx(80.0)               # 0.8 × 100
    assert priority_for(total) == PriorityEnum.ALTA


def test_formula_uses_weighted_average_when_higher():
    results = [CheckResult("a", 50, 1, ""), CheckResult("b", 50, 1, ""), CheckResult("c", 50, 1, "")]
    assert combine_scores(results) == pytest.approx(50.0)  # promedio 50 > 0.8×50 = 40


def test_formula_ignores_non_applicable_and_force_report_gives_100():
    assert combine_scores([CheckResult("a", 100, 5, "", applicable=False), CheckResult("b", 0, 1, "")]) == 0
    assert combine_scores([CheckResult("a", 10, 1, "", force_report=True), CheckResult("b", 0, 9, "")]) == 100
    assert combine_scores([]) == 0


def test_factor_and_thresholds_are_configurable(monkeypatch):
    monkeypatch.setattr(config, "SCORE_MAX_WEIGHT_FACTOR", 0.5)
    assert combine_scores([CheckResult("a", 100, 1, ""), CheckResult("b", 0, 9, "")]) == pytest.approx(50.0)
    assert priority_for(60) == PriorityEnum.ALTA and priority_for(59.9) == PriorityEnum.MEDIA
    assert priority_for(30) == PriorityEnum.MEDIA and priority_for(29.9) == PriorityEnum.BAJA
    monkeypatch.setattr(config, "PRIORITY_HIGH_THRESHOLD", 90)
    assert priority_for(80) == PriorityEnum.MEDIA


def test_check_result_clamps_score():
    assert CheckResult("x", 150, 1, "").score == 100 and CheckResult("x", -5, 1, "").score == 0


# ------------------------------------------------------------------ dirección

@pytest.mark.parametrize("raw,house,unit", [
    ("MCKINNEY MCKINNEY 2201 South State Highway 5 31", "2201", "31"),
    ("ALLEN ALLEN 1530 Broadmoor Dr", "1530", None),
    ("Allen Allen 315 N greenville AVE 1123", "315", "1123"),
    (APT, "505", "6105"),
    ("ARLINGTON ARLINGTON 700 Eden Rd 7-205", "700", "7-205"),
    ("Allen Allen 1400 Andrews Pkwy Apartment 4111", "1400", "4111"),
    ("ALLEN ALLEN 1400 Andrews Pkwy 1045 Allen cortland station", "1400", "1045"),
])
def test_parse_us_address(raw, house, unit):
    a = parse_us_address(raw)
    assert (a.house_number, a.unit) == (house, unit)


def test_unit_with_dash_accepts_short_form():
    exp = parse_us_address("ARLINGTON ARLINGTON 700 Eden Rd 7-205").expected_numbers()
    assert exp["unit"] == {"7205", "205"}


# ------------------------------------------------------------------ número vs dirección (OCR)

def test_number_match_gives_0():
    r = check_address_number(pod(), [door("1530"), label()])
    assert r.score == 0 and not r.force_report


def test_number_mismatch_gives_100():
    # El caso del número pintado en la acera equivocada
    seen = door("6150"); seen.vision_all = ["6150"]   # El modelo de visión también lo lee
    r = check_address_number(pod(APT), [door("69"), seen, label()])
    assert r.score == 100 and r.details["status"] == "mismatch"
    # Regla 02/10: si solo lo lee el OCR (el modelo no lo confirma) va a revisión manual, no a Alta
    r = check_address_number(pod(APT), [door("69"), door("6150"), label()])
    assert r.score == config.WEAK_NUMBER_SCORE and r.details["status"] == "mismatch_unconfirmed"


def test_label_numbers_are_ignored():
    # La etiqueta trae la dirección: su número NO puede contar como "visible en la puerta"
    lbl = label(); lbl.numbers = ["1530"]
    r = check_address_number(pod(), [door(), lbl])
    assert r.details["status"] == "not_visible"


def test_number_not_read_goes_to_manual_review():
    r = check_address_number(pod(), [door(), door()])
    assert not r.force_report and r.score == config.FAR_NUMBERS_SCORE
    assert "no leído / posible número lejano" in r.explanation
    p = score_pod(pod(portal_meta={"sign_distance": "10"}), [door(), door(), label()])
    assert p.priority == "Media"


def test_number_not_visible_can_still_force_report(monkeypatch):
    monkeypatch.setattr(config, "NUMBER_NOT_VISIBLE_FORCES_REPORT", True)
    r = check_address_number(pod(), [door(), door()])
    assert r.force_report and r.score == 100


def test_apartment_with_only_building_number_goes_to_manual_review():
    r = check_address_number(pod(APT), [door("505"), door()])
    assert r.details["status"] == "partial" and not r.force_report
    assert "unidad no leído" in r.explanation


@pytest.mark.parametrize("read,address", [
    ("0355", "Dallas Dallas 355 Elm St"),          # cero a la izquierda
    ("1119", "Dallas Dallas 119 Elm St"),          # carácter de más al inicio
    ("13014", "Dallas Dallas 150 Elm St Apt 1301"),  # carácter de más al final
])
def test_ocr_artifacts_still_match(read, address):
    assert check_address_number(pod(address), [door(read)]).details["status"] == "match"


def test_missing_digit_is_incomplete_read_not_neighbor():
    # Regla 01/10: "552" de "1552", "360" de "3609" -> lectura incompleta (Media), no casa vecina
    clear = PhotoOCR(path="d", numbers=["121"], number_conf={"121": 99.0})
    r = check_address_number(pod("Dallas Dallas 1211 Elm St"), [clear])
    assert r.details["status"] == "partial_read" and r.score == config.WEAK_NUMBER_SCORE


def test_photo_with_street_name_is_treated_as_label():
    # Etiqueta no detectada por QR: trae la calle impresa y números de ruta/código postal
    undetected_label = PhotoOCR(path="l", numbers=["75052", "020", "082"],
                                text="GOFO 2825 Magna Carta Blvd Grand Prairie TX 75052 41 DFW.H DFW02 020")
    r = check_address_number(pod("Grand Prairie Grand Prairie 2825 Magna Carta Blvd"), [door(), undetected_label])
    assert r.details["status"] != "mismatch"


def test_building_sign_with_other_ranges_and_no_door_is_medium():
    # Regla 01/10: en apartamentos solo cuenta la unidad; un cartel de rangos sin la puerta va a revisar (Media)
    sign = PhotoOCR(path="b", numbers=["18"], text="18 4811.4818 | [821-1828L")
    r = check_address_number(pod("Grand Prairie Grand Prairie 2955 ALOUETTE DR APT 825"), [sign, door(), label()])
    assert r.details["status"] == "far_numbers" and r.score == config.WEAK_NUMBER_SCORE


def test_unit_on_door_wins_over_building_sign_ranges():
    # Casos reales 01/10 (N MacArthur 1413, Country Club 242): la puerta muestra la unidad, el cartel otros rangos
    sign = PhotoOCR(path="b", text="2401-2415")
    r = check_address_number(pod("Irving 2436 N Macarthur Blvd Apt 1413"), [sign, door("1413")])
    assert r.details["status"] == "match" and r.score == 0


def test_two_different_doors_is_high():
    # Caso real 01/10: puerta 2817 y puerta 4224 (leída "42241") para Apt 4224
    a = PhotoOCR(path="p1", numbers=["2817"], number_conf={"2817": 99.0}, vision_all=["2817"])
    b = PhotoOCR(path="p3", numbers=["42241"], number_conf={"42241": 90.0})
    r = check_address_number(pod("North Richland Hills 8500 Harwood Rd, Apt 4224"), [a, b])
    assert r.details["status"] == "two_doors" and r.score == 100
    # Sin confirmación del modelo de visión (02/10) -> Media
    a.vision_all = []
    r = check_address_number(pod("North Richland Hills 8500 Harwood Rd, Apt 4224"), [a, b])
    assert r.details["status"] == "two_doors_unconfirmed" and r.score == config.WEAK_NUMBER_SCORE


def test_zero_unit_ignored_and_plate_with_both_border_ones():
    r = check_address_number(pod("Terrell Terrell 201 Timber Ct Apt 000 315"), [door("315")])
    assert r.details["status"] == "match"
    r = check_address_number(pod("NRH 7036 Live Oak Drive"), [PhotoOCR(path="p", numbers=["170361"])])
    assert r.details["status"] == "match"


def test_slash_read_as_one_confirms_number():
    p = PhotoOCR(path="p", numbers=["7", "08"], alt_numbers=["7108"])
    r = check_address_number(pod("NRH 7108 Turner Ter"), [p])
    assert r.details["status"] == "match"


def test_note_before_number_and_leading_zero_unit():
    assert parse_us_address("NRH MAKE SURE TO DELIVER TO COURT NOT DRIVE 6513 MEADOW LAKES CT").house_number == "6513"
    r = check_address_number(pod("Dallas Dallas 1005 METKER ST  02"), [door("2")])
    assert r.details["status"] == "match"


def test_building_sign_containing_the_unit_is_fine():
    sign = PhotoOCR(path="b", numbers=["18"], text="18 1811-1818 1821-1828")
    r = check_address_number(pod("Grand Prairie Grand Prairie 2955 ALOUETTE DR APT 1825"), [sign, door("1825")])
    assert r.details["status"] == "match"


def test_dates_and_phones_are_not_unit_ranges():
    from processing.ocr_address import unit_ranges
    assert unit_ranges("972-396-5000 09/29/2026 2026-09-29") == []
    assert unit_ranges("1811-1818 1821 - 1828") == [(1811, 1818), (1821, 1828)]


def test_portal_false_pod_flag_forces_report_and_goes_first(tmp_path):
    from processing.scoring import queue_sort_key
    # Valores reales: sospechoso whetherReported=1 / falseSignature=4; normal 2 / 3
    flagged = score_pod(pod(portal_meta={"whether_reported": 1, "false_signature": 4, "sign_distance": "10"}),
                        [door("1530")])
    normal_bad = score_pod(pod(portal_meta={"whether_reported": 2, "false_signature": 3, "sign_distance": "10"}),
                           [door("1350")])
    assert flagged.priority == "Alta" and flagged.risk_score == 100
    assert "FALSO SOSPECHOSO" in top_reasons(flagged)[0]
    assert not any(r["check"] == "pod_falso_portal" and r["score"] for r in normal_bad.check_results)
    # Aunque el otro tenga Alta por número equivocado, el marcado por el portal va primero
    assert sorted([normal_bad, flagged], key=queue_sort_key)[0] is flagged
    from export.excel_exporter import PODExcelExporter
    import openpyxl
    path = PODExcelExporter(output_dir=tmp_path).export([normal_bad, flagged], "q.xlsx")
    ws = openpyxl.load_workbook(path)["Review Queue"]
    h = [c.value for c in ws[1]]
    assert ws.cell(row=2, column=h.index("Prioridad") + 1).value == "POD FALSO (portal)"


def test_one_digit_off_is_medium_risk():
    r = check_address_number(pod(APT), [door("6106")])
    assert r.details["status"] == "near_match" and r.score == config.WEAK_NUMBER_SCORE


def test_one_digit_off_read_clearly_is_neighbor_house():
    # Caso real (Yonaiker 29/09): dirección 4829, la foto muestra 4825 con confianza 0,97
    clear = PhotoOCR(path="door.jpg", numbers=["4825"], number_conf={"4825": 97.0}, vision_all=["4825"])
    r = check_address_number(pod("Grand Prairie Grand Prairie 4829 Magna Carta Blvd"), [clear, label()])
    assert r.details["status"] == "mismatch" and r.score == 100
    assert "vecina" in r.explanation
    p = score_pod(pod("Grand Prairie Grand Prairie 4829 Magna Carta Blvd", portal_meta={"sign_distance": "10"}),
                  [clear, label()])
    assert p.priority == "Alta"


def test_number_check_not_applicable_for_package_room_and_handover():
    assert not check_address_number(pod(APT, billing="Casillero para paquetes"), [door()]).applicable
    assert not check_address_number(pod(billing="Reunirse con el cliente/Miembro autorizado"), [door()]).applicable


def test_number_check_goes_to_manual_review_when_ocr_unavailable():
    r = check_address_number(pod(), [PhotoOCR(path="x", error="pytesseract no disponible")])
    assert r.applicable and r.score == config.FAR_NUMBERS_SCORE and r.details["status"] == "ocr_error"  # 04/10


# ------------------------------------------------------------------ resto de chequeos

@pytest.mark.parametrize("n,score,forced", [(0, 100, True), (2, 60, False), (3, 0, False), (5, 0, False), (6, 20, False)])
def test_photo_count(n, score, forced):
    r = check_photo_count(pod(photos=n))
    assert (r.score, r.force_report) == (score, forced)


def test_label_photos():
    p = pod()
    assert check_label_photos(p, [door(), label()]).score == 0
    assert check_label_photos(p, [label(), label(), door()]).score == 70
    # 25/10 (pedido del usuario): la etiqueta de otro paquete ya no es error
    assert check_label_photos(p, [label("GFUS09999999999999"), door()]).score == 0
    assert check_label_photos(p, [label(p.tracking_number), door()]).score == 0


def test_building_photos_rule_and_package_room_exception():
    assert not check_building_photos(pod(HOUSE), [door()]).applicable
    r = check_building_photos(pod(APT), [door("6105"), label()])
    assert not r.force_report and r.score == config.FAR_NUMBERS_SCORE   # 04/10: Media, no Alta
    assert check_building_photos(pod(APT), [door(), door(), label()]).score == 0
    assert not check_building_photos(pod(APT, billing="Casillero para paquetes"), [door()]).applicable
    assert not check_building_photos(pod(APT), [door(text="PACKAGE ROOM")]).applicable


def test_duplicates():
    assert check_duplicates(pod(duplicate_status=DuplicateStatusEnum.EXACT_DUPLICATE.value)).score == 100
    assert check_duplicates(pod(duplicate_status=DuplicateStatusEnum.POSSIBLE_VISUAL_DUPLICATE.value)).score == 80
    same = [ImageQualityMetrics(file_path="a", sha256="x"), ImageQualityMetrics(file_path="b", sha256="x")]
    assert check_duplicates(pod(image_metrics=same)).score == 70
    assert check_duplicates(pod()).score == 0


# Regla 01/10: menos de 800 m no cuenta; más de 800 m -> revisión (50 = Media)
@pytest.mark.parametrize("dist,score", [("12.49", 0), ("259", 0), ("799", 0), ("801", 50), ("1423.77", 50)])
def test_gps_distance(dist, score):
    assert check_gps_distance(pod(portal_meta={"sign_distance": dist})).score == score


def test_gps_not_applicable_without_data():
    assert not check_gps_distance(pod()).applicable


def test_image_quality_and_platform_flag():
    m = [ImageQualityMetrics(file_path="a", is_blurry=True), ImageQualityMetrics(file_path="b", is_blank_or_covered=True)]
    assert check_image_quality(pod(image_metrics=m)).score == 70
    assert check_platform_flag(pod(non_compliance_reason="Foto no clara")).score == 50
    assert check_platform_flag(pod()).score == 0


# ------------------------------------------------------------------ integración

def test_score_pod_sets_fields_and_reasons():
    seen = door("6150"); seen.vision_all = ["6150"]
    p = score_pod(pod(APT, portal_meta={"sign_distance": "12"}), [seen, door(), label()])
    assert p.risk_score >= 60 and p.priority == "Alta"
    assert len(p.check_results) == 12 and all("score" in r for r in p.check_results)
    assert "no concuerdan" in top_reasons(p)[0]


def test_clean_pod_is_low_priority():
    p = score_pod(pod(HOUSE, portal_meta={"sign_distance": "10"}), [door("1530"), door(), label()])
    assert p.risk_score == 0 and p.priority == "Baja"


def test_far_numbers_go_to_manual_review_not_forced():
    far_door = PhotoOCR(path="door.jpg", far_text=["61O5"])
    r = check_address_number(pod(APT), [far_door, door(), label()])
    assert r.details["status"] == "far_numbers"
    assert not r.force_report and r.score == config.WEAK_NUMBER_SCORE
    assert "lejanos" in r.explanation.lower()
    p = score_pod(pod(APT, portal_meta={"sign_distance": "10"}), [far_door, door(), label()])
    assert p.priority == "Media"


def test_far_text_in_label_photo_does_not_count():
    lbl = label(); lbl.far_text = ["1530"]
    assert check_address_number(pod(), [door(), lbl]).details["status"] == "not_visible"


def test_readable_match_wins_over_far_text():
    assert check_address_number(pod(), [door("1530"), PhotoOCR(path="x", far_text=["15"])]).score == 0


def test_duplicate_in_same_building_is_low_risk_other_address_is_max():
    same = pod(duplicate_status=DuplicateStatusEnum.EXACT_DUPLICATE.value, duplicate_matched_tracking="GF2",
               portal_meta={"duplicate_same_building": True})
    other = pod(duplicate_status=DuplicateStatusEnum.EXACT_DUPLICATE.value, duplicate_matched_tracking="GF3",
                portal_meta={"duplicate_same_building": False})
    assert check_duplicates(same).score == config.DUPLICATE_SAME_BUILDING_SCORE
    assert check_duplicates(other).score == 100


def test_validator_marks_same_building_duplicates(tmp_path):
    from PIL import Image
    from processing.validator import PODValidator, building_key
    assert building_key("Allen Allen 1400 Andrews Pkwy Apt 1027") == building_key("ALLEN ALLEN 1400 ANDREWS PARKWAY 3152")
    assert building_key("Allen Allen 1400 Andrews Pkwy") != building_key("Allen Allen 1530 Broadmoor Dr")
    img = tmp_path / "locker.jpg"
    Image.new("RGB", (800, 600), (120, 60, 30)).save(img)
    v = PODValidator(run_ocr=False)
    a = PODRecord(tracking_number="A", receipt_address="Allen Allen 1400 Andrews Pkwy Apt 1027", photo_paths=[str(img)])
    b = PODRecord(tracking_number="B", receipt_address="Allen Allen 1400 Andrews Pkwy Apt 3152", photo_paths=[str(img)])
    c = PODRecord(tracking_number="C", receipt_address="Allen Allen 1530 Broadmoor Dr", photo_paths=[str(img)])
    for p in (a, b, c):
        v.validate_pod(p, ocr_results=[])
    assert b.portal_meta["duplicate_same_building"] is True
    assert c.portal_meta["duplicate_same_building"] is False
    dup = lambda p: next(r for r in p.check_results if r["check"] == "fotos_duplicadas")["score"]
    assert dup(b) == config.DUPLICATE_SAME_BUILDING_SCORE and dup(c) == 100


def test_only_really_blurry_photos_count():
    soft = [ImageQualityMetrics(file_path="a", is_blurry=True, blur_score=86)]   # pared lisa, legible
    blurry = [ImageQualityMetrics(file_path="a", is_blurry=True, blur_score=10)]
    assert check_image_quality(pod(image_metrics=soft)).score == 0
    assert check_image_quality(pod(image_metrics=blurry)).score == 30


def test_short_numbers_cannot_contradict_a_longer_address():
    # "12", "14", "15" (fechas, carteles) no pueden ser la dirección 211 -> no leído, no "no concuerda"
    r = check_address_number(pod("Dallas Dallas 211 Elm St"), [door("12", "14", "15")])
    assert r.details["status"] != "mismatch"


def test_mismatch_read_only_by_vision_goes_to_manual_review():
    # Caso real 4808 Arabian Ct: el OCR no lee la placa chica y el modelo de visión lee "4000"
    only_vision = PhotoOCR(path="casa.jpg", numbers=["4000"], vision_numbers=["4000"], vision_used=True)
    r = check_address_number(pod("ARLINGTON ARLINGTON 4808 Arabian Ct"), [only_vision])
    # 02/10: "4000" por 4808 es la placa con dígitos borrosos leídos como 0 -> revisión manual (Media)
    assert r.score < 60 and r.details["status"] == "near_match"
    # Otro número que el OCR y el modelo leen igual sigue siendo riesgo máximo
    both = PhotoOCR(path="casa.jpg", numbers=["5123", "5123B"], vision_numbers=["5123B"], vision_used=True,
                    vision_all=["5123"])
    assert check_address_number(pod("ARLINGTON ARLINGTON 4808 Arabian Ct"), [both]).score == 100


def test_vision_failure_sends_to_medium_review():
    from processing.scoring import check_vision_failure
    ok = PhotoOCR(path="a.jpg", numbers=["5734"])
    bad = PhotoOCR(path="b.jpg", vision_error="ValueError: respuesta no JSON: ''")
    assert not check_vision_failure([ok]).applicable
    r = check_vision_failure([ok, bad])
    assert r.applicable and "#2" in r.explanation
    assert combine_scores([r]) >= config.PRIORITY_MEDIUM_THRESHOLD


def test_two_label_photos_ok_when_house_number_is_seen():
    labels = [PhotoOCR(path="e1.jpg", is_label=True), PhotoOCR(path="e2.jpg", is_label=True)]
    r = check_label_photos(pod(), labels, number_seen=True)
    assert r.score == 0
    assert check_label_photos(pod(), labels, number_seen=False).score == 70


def test_two_label_photos_ok_when_handed_to_customer():
    labels = [PhotoOCR(path="e1.jpg", is_label=True), PhotoOCR(path="e2.jpg", is_label=True)]
    r = check_label_photos(pod(billing="Reunirse con el cliente/Miembro autorizado"), labels)
    assert not r.applicable and r.score == 0


def test_label_of_another_package_is_not_an_error_anymore():
    # 25/10 (pedido del usuario): antes era riesgo máximo; son varios paquetes a la misma dirección
    other = [PhotoOCR(path="e1.jpg", is_label=True, label_tracking="GFUS99999999999999")]
    assert check_label_photos(pod(), other, number_seen=True).score == 0


def test_handover_to_a_person_is_omitted():
    p = pod(billing="Reunirse con el cliente/Miembro autorizado", photos=1,
            portal_meta={"sign_distance": "900"})
    score_pod(p, [PhotoOCR(path="a.jpg", numbers=["1"])])
    assert p.risk_score == 0 and p.priority == "Baja"
    assert p.check_results[-1]["check"] == "entrega_en_mano"


def test_handover_still_reported_when_portal_flags_false_pod():
    p = pod(billing="Reunirse con el cliente/Miembro autorizado", portal_meta={"whether_reported": "1"})
    score_pod(p, [])
    assert p.priority == "Alta"


def test_locker_delivery_is_omitted():
    p = pod(billing="Casillero para paquetes", portal_meta={"sign_distance": "214"})
    score_pod(p, [PhotoOCR(path="a.jpg", numbers=["1438"])])
    assert p.priority == "Baja" and p.check_results[-1]["check"] == "entrega_en_casillero"


def test_pickup_point_with_shared_table_photo_is_omitted():
    # Caso real GFUS01075337066121: "Punto de Recogida de Paquetes", misma foto de la mesa para varios albaranes
    p = pod(billing="Punto de Recogida de Paquetes", duplicate_status=DuplicateStatusEnum.EXACT_DUPLICATE.value,
            duplicate_matched_tracking="GFUS01074826132996")
    score_pod(p, [PhotoOCR(path="a.jpg")])
    assert p.priority == "Baja"


MAP_TEXT = ("12:21 The Gio Apartments Horario Abierto 10.00 18.00 Domingo Cerrado Detalles Telefono +1 (972) 460-8087 "
            "Sitio web thegioapts com Direccion 1800 E Spring Creek Pkwy Plano; TX 75074 Estados Unidos "
            "Mas en Foursquare Reportar un problema Anclar")


def test_map_screenshot_with_right_address_confirms_it():
    from processing.scoring import check_map_screenshot
    p = pod(address="Plano Plano 1800 E Springcreek Pkwy Apt 1133")
    r = check_map_screenshot(p, [PhotoOCR(path="mapa.jpg", text=MAP_TEXT)])
    assert r.score == 0 and r.details["status"] == "match"


def test_map_screenshot_with_other_address_is_max_risk():
    from processing.scoring import check_map_screenshot
    p = pod(address="Plano Plano 5000 K Ave Apt 3426")
    r = check_map_screenshot(p, [PhotoOCR(path="mapa.jpg", text=MAP_TEXT)])
    assert r.score == 100 and "1800 E Spring Creek" in r.explanation


def test_vision_failure_ignored_when_number_confirmed():
    p = pod(address="Plano Plano 1513 Lucas Ter")
    photos = [PhotoOCR(path="casa.jpg", numbers=["1513"], number_conf={"1513": 95.0}),
              PhotoOCR(path="etiqueta.jpg", vision_error="ValueError: respuesta no JSON: ''")]
    score_pod(p, photos)
    vf = [r for r in p.check_results if r["check"] == "vision_fallida"][0]
    assert not vf["applicable"]


@pytest.mark.parametrize("raw, street, unit", [
    ("Terrell Terrell 2637 County Road 249", "County Road 249", None),   # Caso real: portón de campo
    ("Kaufman 100 FM 1388", "FM 1388", None),
    ("Forney 123 CR 212", "CR 212", None),
    ("Mesquite 500 Highway 80 E", "Highway 80 E", None),
    ("Grand Prairie 6310 S State Highway 360 1438", "S State Highway 360", "1438"),
    ("Plano 5000 K Ave Apt 3426", "K Ave", "3426"),
    ("Dallas 123 Main St 4", "Main St", "4"),
    # Caso real 10/10: tras un nombre propio, el número que sigue a "Hwy" es el apartamento
    ("Garland 6864 N President George Bush Hwy 8403", "N President George Bush Hwy", "8403"),
    ("Rockwall 100 US Hwy 287", "US Hwy 287", None),
    ("Rowlett 100 N Hwy 66 12", "N Hwy 66", "12"),
])
def test_road_numbers_are_street_not_unit(raw, street, unit):
    a = parse_us_address(raw)
    assert (a.street, a.unit) == (street, unit)


def test_rural_gate_number_is_enough():
    p = pod(address="Terrell Terrell 2637 County Road 249")
    r = check_address_number(p, [PhotoOCR(path="porton.jpg", numbers=["2637"], number_conf={"2637": 95.0})])
    assert r.score == 0 and r.details["status"] == "match"


def test_building_key_ignores_spacing_and_suffix():
    from processing.validator import building_key
    assert building_key("Lucas Lucas 1104 Green Acres Lane") == building_key("Lucas 1104 Greenacres Ln")
    assert building_key("1400 Andrews Pkwy") == building_key("1400 ANDREWS PARKWAY")
    assert building_key("1104 Greenacres Ln") != building_key("1106 Greenacres Ln")


def test_mail_room_delivery_is_omitted():
    p = pod(billing="Sala de Correo", duplicate_status=DuplicateStatusEnum.POSSIBLE_VISUAL_DUPLICATE.value,
            portal_meta={"duplicate_same_building": True})
    score_pod(p, [PhotoOCR(path="a.jpg")])
    assert p.priority == "Baja"


def test_google_maps_screenshot_detected():
    from processing.map_screenshot import is_map_screenshot
    text = ("Merribrook Ln 10:15 Green Brook Dr Buscar aqui E Main St 904 Wandering Way Dr Allen, TX 75002 "
            "Edificio multiusos Como llegar Iniciar Guardar")
    assert is_map_screenshot(text)


def test_handoff_photo_detected_by_vision_is_omitted():
    from processing.pipeline import detect_handoff
    p = pod(portal_meta={"sign_distance": "765"})
    photos = [PhotoOCR(path="caja_en_mano.jpg"), PhotoOCR(path="entrega_en_mano.jpg")]   # 29/10: hacen falta 2 fotos distintas
    score_pod(p, photos)
    assert p.priority in ("Alta", "Media")
    assert detect_handoff(p, photos, asker=lambda path: True)
    score_pod(p, photos)
    assert p.priority == "Baja" and p.check_results[-1]["check"] == "entrega_en_mano"


def test_handoff_not_detected_keeps_priority():
    from processing.pipeline import detect_handoff
    p = pod(portal_meta={"sign_distance": "765"})
    score_pod(p, [PhotoOCR(path="porche.jpg")])
    assert not detect_handoff(p, [PhotoOCR(path="porche.jpg")], asker=lambda path: False)


@pytest.mark.parametrize("a, b", [
    ("Grand Prairie 2955 Alouette Dr Apartamento 727", "Grand Prairie 2955 Alouette Dr,Grand Prairie Clayton Apartment- unit 611"),
    ("GRAND PRAIRIE 2946 Alouette Dr Departamneto 615", "Grand Prairie 2946 Alouette Dr Apt 627 627"),
    ("Grand Prairie 2530 Sara Jane Pkwy Edificio 5 apto 511", "Grand Prairie 2530 SARA JANE PKWY Apt 1034"),
    ("Plano 1800 E Spring Creek Pkwy Apt 1133", "PLANO 1800 E Springcreek Pkwy 1322"),
])
def test_same_building_written_differently(a, b):
    from processing.validator import building_key
    assert building_key(a) == building_key(b)


def test_different_buildings_stay_different():
    from processing.validator import building_key
    assert building_key("Plano 5000 K Ave Apt 3426") != building_key("Plano 1800 E Spring Creek Pkwy Apt 1133")
    assert building_key("Dallas 2955 Alouette Dr") != building_key("Dallas 2946 Alouette Dr")


def test_label_of_sibling_package_same_address_is_ok():
    # Caso real: 4 paquetes a "400 Settlers Bnd" en una foto; la etiqueta es de otro paquete de la misma casa
    p = pod(address="MCKINNEY MCKINNEY 400 Settlers Bnd")
    lbl = [PhotoOCR(path="e.jpg", is_label=True, label_tracking="GFUS01075207777540")]
    r = check_label_photos(p, lbl, address_of=lambda t: "McKinney 400 Settlers Bnd")
    # 12/10: solo la etiqueta del otro paquete -> Media (50); con la de este paquete también a la vista -> normal
    assert r.score == 50 and r.details["misma_direccion"] == ["GFUS01075207777540"]
    both = lbl + [PhotoOCR(path="e2.jpg", is_label=True, label_tracking=p.tracking_number)]
    assert check_label_photos(p, both, number_seen=True, address_of=lambda t: "McKinney 400 Settlers Bnd").score == 0
    # 25/10 (pedido del usuario): la etiqueta de otro paquete ya no es error, sea cual sea la dirección registrada
    r2 = check_label_photos(p, lbl, address_of=lambda t: "McKinney 416 Blanton St")
    assert r2.score == 0 and r2.details["etiqueta_otro_paquete_ignorada"] == ["GFUS01075207777540"]
    r3 = check_label_photos(p, lbl, address_of=lambda t: None)
    assert r3.score == 0


def test_same_apartment_complex_by_gps():
    from processing.validator import same_apartment_complex
    a = (True, 32.6650, -97.1700)
    near = (True, 32.6660, -97.1705)      # ~120 m, otro apartamento del complejo
    far = (True, 32.6800, -97.1700)       # ~1.7 km
    house = (False, 32.6660, -97.1705)
    assert same_apartment_complex(a, near)
    assert not same_apartment_complex(a, far)
    assert not same_apartment_complex(a, house)   # En casas una foto repetida en otra dirección sigue siendo error


def test_phone_in_address_is_not_unit():
    a = parse_us_address("GARLAND 2005 Club Oaks Ct 214-226-8813")
    assert (a.house_number, a.unit) == ("2005", None)
    assert parse_us_address("Plano 100 Main St 9725551234").unit is None


def test_zip_code_read_in_photo_is_ignored():
    a = parse_us_address("Garland Garland 1905 W Walnut St APT B")
    m = match_numbers(a, [PhotoOCR(path="x.jpg", numbers=["75063"])])
    assert m.status != "mismatch"


def test_ocr_garbage_in_map_is_unknown_not_other_address():
    from processing.map_screenshot import screenshot_address_status
    text = "Buscar aqui Como llegar Iniciar Guardar Direccion 56 Ilil Estados Unidos"
    assert screenshot_address_status(text, "19850", "FM-986")[0] == "unknown"


def test_photo_handoff_cannot_hide_wrong_number():
    # Caso real: foto "3813", dirección TRLR 3824, falso "persona recibiendo" en otra foto
    p = pod(address="North Richland Hills 6520 Harmonson RD TRLR 3824", portal_meta={"handoff_photo": 2})
    score_pod(p, [PhotoOCR(path="trailer.jpg", numbers=["3813"], number_conf={"3813": 95.0}, vision_all=["3813"])])
    assert p.priority == "Alta" and not any(r["check"] == "entrega_en_mano" for r in p.check_results)


def test_billing_handoff_still_omitted():
    p = pod(billing="Reunirse con el cliente/Miembro autorizado")
    score_pod(p, [PhotoOCR(path="x.jpg", numbers=["9999"], number_conf={"9999": 95.0})])
    assert p.priority == "Baja"


def test_confirmed_photo_handoff_no_longer_hides_mismatch():
    p = pod(address="MCKINNEY 1414 S Tennessee St Trlr 7", portal_meta={"handoff_photo": 2, "handoff_confirmed": True})
    score_pod(p, [PhotoOCR(path="x.jpg", numbers=["72"], number_conf={"72": 95.0})])
    # Regla 02/10 (precisión primero): la entrega en mano vista en la foto no oculta un número que no concuerda
    assert p.priority in ("Alta", "Media")


def test_neighbor_door_in_another_photo_is_two_doors_but_same_plate_misread_is_not():
    # Puerta vecina 2607 en una foto y la correcta 2603 en otra -> dos puertas (Alta)
    a = PhotoOCR(path="p1", numbers=["2607"], number_conf={"2607": 99.0}, vision_all=["2607"])
    b = PhotoOCR(path="p2", numbers=["2603"], number_conf={"2603": 99.0})
    assert check_address_number(pod("Irving 2603 William Brewster Dr"), [a, b]).details["status"] == "two_doors"
    # Una sola placa leída "210" (OCR) y "218" (modelo) en la MISMA foto -> misma placa, no dos puertas
    c = PhotoOCR(path="p", numbers=["210", "218"], number_conf={"210": 94.0, "218": 70.0}, vision_numbers=["218"])
    assert check_address_number(pod("Arlington 218 E Embercrest Dr"), [c]).details["status"] == "match"


def test_amazon_hub_is_reported_not_omitted():
    p = pod(billing="Casillero para paquetes")
    score_pod(p, [PhotoOCR(path="hub.jpg", text="amazon hub locker select a size")])
    assert p.priority == "Lockers" and any(r["check"] == "amazon_hub" for r in p.check_results)


def test_locker_seen_in_photo_is_omitted_and_screens_skip_quality():
    p = pod(portal_meta={"sign_distance": "333"})
    score_pod(p, [PhotoOCR(path="k.jpg", text="Select a locker size Small Medium Large LuxerOne.com")])
    assert p.priority == "Baja" and p.check_results[-1]["check"] == "entrega_en_casillero"
    chat = "6:19 Hola 10:52:38 09/30/2026 306 10:53:21 09/30/2026 2430 finley Rd apt306 16:07:00 09/30/2026"
    q = pod(photos=1, image_metrics=[ImageQualityMetrics(file_path="f0.jpg", is_overexposed=True)])
    assert check_image_quality(q, [PhotoOCR(path="f0.jpg", text=chat)]).score == 0
    assert check_image_quality(q, [PhotoOCR(path="f0.jpg", text="porche")]).score > 0


def test_plate_with_street_name_is_not_a_label():
    plate = PhotoOCR(path="placa.jpg", text="22806 St Stafford", numbers=["22806"])
    r = check_address_number(pod("Irving Irving 2806 Stafford St"), [plate])
    assert r.details["status"] == "match"


def test_failed_extraction_is_not_no_photos():
    from models.pod import ProcessingStatusEnum
    p = pod(photos=0, processing_status=ProcessingStatusEnum.FAILED, error_message="sin permiso")
    score_pod(p, [])
    assert p.priority == "Media" and p.check_results[0]["check"] == "error_extraccion"


def test_neighbor_without_second_reader_is_medium():
    # Caso real 01/10: placa 3122 leída "5122" con 98 %, el modelo de visión falló en esa foto -> Media, no Alta
    p = PhotoOCR(path="placa", numbers=["5122"], number_conf={"5122": 98.0}, vision_error="ValueError")
    r = check_address_number(pod("Irving 3122 Chisholm Trail"), [p])
    assert r.score < 100 and r.details["status"] == "near_match"


def test_one_digit_other_photo_needs_strong_read_for_two_doors():
    a = PhotoOCR(path="p2", numbers=["306"], number_conf={"306": 100.0})
    b = PhotoOCR(path="p3", numbers=["106"], number_conf={"106": 70.0})
    r = check_address_number(pod("Irving 2410 finley Apt306"), [a, b])
    assert r.details["status"] == "match"


def test_range_sign_numbers_are_not_a_second_door():
    sign = PhotoOCR(path="cartel", text="1325-1333", numbers=["1325", "1333"], number_conf={"1325": 90.0, "1333": 90.0})
    r = check_address_number(pod("Irving 2426 N McArthr Blvd, Apt 1327"), [sign, door("1327")])
    assert r.details["status"] == "match"


def test_building_sign_listing_without_dashes_is_not_a_second_door():
    sign = PhotoOCR(path="cartel", numbers=["2426", "1325", "1333", "2325", "2333"],
                    number_conf={"1325": 83.0, "1333": 83.0, "2325": 64.0, "2333": 64.0})
    r = check_address_number(pod("Irving 2426 N McArthr Blvd, Apt 1327"), [sign, door("1327")])
    assert r.details["status"] == "match"


def test_confirmed_photo_handoff_never_hides_a_wrong_number():
    # Caso real 02/10: la mano del repartidor con la etiqueta se confirmó como "cliente" y ocultó el trailer 3813
    p = pod(address="North Richland Hills 6520 Harmonson RD TRLR 3824",
            portal_meta={"handoff_photo": 3, "handoff_confirmed": True})
    score_pod(p, [PhotoOCR(path="t.jpg", numbers=["3813"], number_conf={"3813": 95.0}, vision_all=["3813"])])
    assert p.priority == "Alta"


def test_label_photo_is_not_asked_for_handoff():
    from processing.pipeline import detect_handoff
    p = pod(address="North Richland Hills 6520 Harmonson RD TRLR 3824", portal_meta={})
    p.priority = "Media"
    asked = []
    label_in_hand = PhotoOCR(path="mano.jpg", text="OFO Fo Lopez 5520 Harmonson RD 826 North Richland Hills TX 76180")
    detect_handoff(p, [label_in_hand], asker=lambda path: asked.append(path) or True)
    assert asked == []


def test_photo_based_omission_does_not_hide_long_gps_distance():
    # Caso real 02/10: POD a 2.192 m (reportado por el usuario) oculto por un "casillero" deducido de la foto
    p = pod(portal_meta={"sign_distance": "2192"})
    score_pod(p, [PhotoOCR(path="k.jpg", text="Select a locker size LuxerOne.com")])
    assert p.priority in ("Alta", "Media")
    q = pod(billing="Casillero para paquetes", portal_meta={"sign_distance": "2192"})
    score_pod(q, [PhotoOCR(path="k.jpg")])
    assert q.priority == "Baja"   # Por facturación del portal se omite siempre


def test_confirmed_handoff_not_omitted_when_another_number_is_read():
    # Caso real 02/10: entrega en mano real, pero el buzón dice otro número ("715…" con dirección 3751)
    p = pod(address="Terrell Terrell 3751 County Road 321", portal_meta={"handoff_photo": 3, "handoff_confirmed": True})
    score_pod(p, [PhotoOCR(path="buzon.jpg", numbers=["715"], number_conf={"715": 60.0})])
    assert p.priority in ("Alta", "Media")
    q = pod(address="Terrell Terrell 3751 County Road 321", portal_meta={"handoff_photo": 3, "handoff_confirmed": True})
    score_pod(q, [PhotoOCR(path="porche.jpg")])
    assert q.priority == "Baja"   # Sin números que contradigan: entrega en mano, se omite


def test_zip_code_at_end_of_address_is_not_unit():
    a = parse_us_address("IRVING IRVING 1914 Cartwright St 75062")
    assert (a.house_number, a.unit) == ("1914", None)
    assert parse_us_address("Plano 100 Main St Apt 75").unit == "75"


def test_single_digit_unit_is_not_two_doors():
    # Caso real 02/10: "1005 METKER ST 02" (unidad 2) y un "1" suelto -> no son dos puertas
    a = PhotoOCR(path="p1", numbers=["2"], number_conf={"2": 99.0})
    b = PhotoOCR(path="p2", numbers=["1"], number_conf={"1": 99.0})
    r = check_address_number(pod("Dallas Dallas 1005 METKER ST  02"), [a, b])
    assert r.details["status"] == "match"


def test_house_number_read_upside_down_is_a_match():
    from processing.ocr_address import upside_down_of
    assert upside_down_of("919", "616") and upside_down_of("2169", "6917")
    assert not upside_down_of("916", "616")      # Un dígito distinto normal sigue siendo puerta vecina posible
    assert not upside_down_of("616", "616")
    # Casos reales 02/10: misma puerta en dos fotos, una leída de cabeza
    a = PhotoOCR(path="p1", numbers=["616"], number_conf={"616": 99.0})
    b = PhotoOCR(path="p2", numbers=["919"], number_conf={"919": 95.0})
    assert check_address_number(pod("Grand Prairie 616 WINDING FOREST CT"), [a, b]).details["status"] == "match"
    # 6917 pintado en el bordillo leído "2169"; el otro número de esa lectura invertida tampoco es otra puerta
    c = PhotoOCR(path="p2", numbers=["2169", "4763"], number_conf={"2169": 90.0, "4763": 80.0})
    r = check_address_number(pod("Garland 6917 clear springs PKWY"), [c])
    assert r.details["status"] == "match" and r.score == 0


def test_neighbor_door_still_detected_when_not_upside_down():
    a = PhotoOCR(path="p1", numbers=["2607"], number_conf={"2607": 99.0}, vision_all=["2607"])
    b = PhotoOCR(path="p2", numbers=["2603"], number_conf={"2603": 99.0})
    assert check_address_number(pod("Irving 2603 William Brewster Dr"), [a, b]).details["status"] == "two_doors"


def _door_status(address, *photos):
    return check_address_number(pod(address), list(photos)).details["status"]


def test_same_plate_misreads_are_not_a_second_door_20261002():
    from processing.ocr_address import misread_of_plate
    # Casos reales 02/10 (primer día con Paddle): la MISMA placa leída mal en otra foto
    for read, house in [("1000", "1800"), ("2100", "2109"), ("3600", "3629"), ("1880", "1808"), ("214", "412"),
                        ("9011", "1108"), ("461", "197"), ("4012", "2107"), ("2089", "6803"), ("000", "900")]:
        assert misread_of_plate(read, house), (read, house)
    for read, house in [("2607", "2603"), ("1231", "1221"), ("414", "412"), ("401", "403")]:
        assert not misread_of_plate(read, house), (read, house)
    ok = PhotoOCR(path="p2", numbers=["1800"], number_conf={"1800": 99.0})
    bad = PhotoOCR(path="p1", numbers=["1000"], number_conf={"1000": 99.0}, vision_all=["1000"])
    assert _door_status("RICHARDSON 1800 COLUMBIA DR", ok, bad) == "match"


def test_numbers_starting_with_zero_and_locker_screens_are_not_doors():
    ok = PhotoOCR(path="p2", numbers=["307"], number_conf={"307": 99.0})
    pumpkins = PhotoOCR(path="p1", numbers=["000"], number_conf={"000": 95.0}, vision_all=["000"])
    assert _door_status("Terrell 307 KNOLL PINES DR", ok, pumpkins) == "match"
    locker = PhotoOCR(path="p1", text="PARCEL PENDING 961723 select", numbers=["223"], number_conf={"223": 95.0},
                      vision_all=["223"])
    unit = PhotoOCR(path="p2", numbers=["605"], number_conf={"605": 99.0})
    assert _door_status("MCKINNEY 600 S Graves St Apt 605", locker, unit) == "match"


def test_two_doors_without_vision_confirmation_is_medium_and_handoff_still_omitted():
    ok = PhotoOCR(path="p2", numbers=["124"], number_conf={"124": 99.0})
    other = PhotoOCR(path="p1", numbers=["238"], number_conf={"238": 95.0})
    p = pod("ARLINGTON 4306 Matlock rd #124", portal_meta={"handoff_photo": 2, "handoff_confirmed": True})
    score_pod(p, [ok, other])
    assert p.priority == "Baja"   # Entrega en mano: el "238" que solo leyó el OCR no la bloquea (caso real 02/10)


def test_full_width_digits_and_car_plates():
    from processing.ocr_address import PLATE_RE, _numeric_tokens
    assert _numeric_tokens({"text": ["１０４"], "conf": [99]}, 50) == ["104"]
    assert _numeric_tokens({"text": ["TYG-5837"], "conf": [99]}, 50) == []
    assert _numeric_tokens({"text": ["APT 1605"], "conf": [99]}, 50) == ["1605"]


def test_package_room_photo_does_not_hide_two_confirmed_doors():
    # Caso real 01/10 (reportado): puertas 2817 y 4224 + una foto de la sala de correo
    a = PhotoOCR(path="p1", numbers=["2817"], number_conf={"2817": 99.0}, vision_all=["2817"], photo_type="door")
    b = PhotoOCR(path="p3", numbers=["4224"], number_conf={"4224": 99.0}, vision_all=["4224"], photo_type="door")
    room = PhotoOCR(path="p4", numbers=["1"], photo_type="package_room")
    p = pod("North Richland Hills 8500 Harwood Rd, Apt 4224")
    score_pod(p, [a, b, room])
    assert p.priority == "Alta"


def test_unparsed_identical_addresses_share_building_key():
    from processing.ocr_address import building_key
    # Caso real 02/10: dos paquetes a "15890Hwy80" con la misma foto -> misma casa, no "otra dirección"
    assert building_key("EDGEWOOD EDGEWOOD 15890Hwy80") == building_key("EDGEWOOD EDGEWOOD 15890Hwy80")
    assert building_key("EDGEWOOD EDGEWOOD 15890Hwy80") != building_key("EDGEWOOD EDGEWOOD 15900Hwy80")
    assert building_key("Arlington 1044 downing CT") != building_key("Arlington 1005 Royal Cir")


def test_number_invented_by_ocr_and_not_seen_by_vision_is_a_match():
    # Casos reales 02/10: 409 claro en el buzón y "540" en otra foto; el modelo revisó esa foto y no lo vio
    ok = PhotoOCR(path="p1", numbers=["409"], number_conf={"409": 99.0}, vision_all=["409"], vision_used=True)
    other = PhotoOCR(path="p2", numbers=["540"], number_conf={"540": 95.0}, vision_all=[], vision_used=True)
    assert _door_status("LUCAS 409 Hunt Drive", ok, other) == "match"
    # Si el modelo no pudo revisar esa foto, queda en duda (Media) solo si puede ser la casa vecina (30/10)
    other.vision_used = False
    assert _door_status("LUCAS 409 Hunt Drive", ok, other) == "match"
    other.numbers, other.number_conf = ["413"], {"413": 95.0}
    assert _door_status("LUCAS 409 Hunt Drive", ok, other) == "two_doors_unconfirmed"


def test_only_real_labels_count_as_label_photos():
    from processing.scoring import check_label_photos
    # Caso real 02/10: el modelo llamó "etiqueta" al cartel PRIVATE PROPERTY / al paquete en el piso
    sign = PhotoOCR(path="p1", text="PRIVATE PROPERTY NO TRESPASSING", is_label=True, vision_label=True)
    real = PhotoOCR(path="p4", is_label=True, label_tracking="GFUS01074122718596")   # la etiqueta de este paquete
    r = check_label_photos(pod("Lucas 275 Lost Valley Drive"), [sign, real, door(), door()])
    assert r.details["etiquetas"] == 1 and r.score == 0


def test_house_number_glued_to_street():
    assert parse_us_address("EDGEWOOD EDGEWOOD 15890Hwy80").house_number == "15890"
    assert parse_us_address("DALLAS 1500 100th St").house_number == "1500"


def test_county_road_and_t_as_one_20261002():
    from processing.ocr_address import _numeric_tokens
    a = parse_us_address("Terrell Terrell 11370 Co Rd 2316")
    assert a.house_number == "11370" and not a.unit          # "Co Rd 2316" es la carretera, no la unidad
    assert _numeric_tokens({"text": ["T1370"], "conf": [95]}, 50) == ["11370"]
    assert _door_status("Terrell Terrell 11370 Co Rd 2316", PhotoOCR(path="p", numbers=["11370"])) == "match"


def test_gofo_driver_app_screenshot_counts_as_map():
    from processing.map_screenshot import is_map_screenshot
    # Caso real 02/10: captura de la app de GOFO con la dirección de la parada
    text = ("3:46 5G 364 < POD 67 176 0 Agregar Pendiente Firmado Excepción paquete 109 107 58 105 103 Stonebriar Way "
            "Dirección incorrecta? 105 STONEBRIAR WAY, Terrell, Texas, 75160")
    assert is_map_screenshot(text)
    shot = PhotoOCR(path="p2", text=text, numbers=["105", "107", "109"])
    p = pod("Terrell Terrell 105 STONEBRIAR WAY")
    score_pod(p, [PhotoOCR(path="p1"), shot, label()])
    assert p.priority == "Baja"


def test_amazon_apartment_locker_screen_20261003():
    # Caso real 03/10: pantalla del Amazon Hub Apartment Locker sin la palabra "Amazon" + cartel "800" del complejo
    screen = PhotoOCR(path="p1", text="367 8 Lakeisha Stringfellow 367 Other resident 367 Help 123C 456 789 oC",
                      numbers=["367", "123C", "456", "789"], vision_all=["367"], photo_type="door")
    sign = PhotoOCR(path="p3", text="800", numbers=["800"], vision_all=["800"], photo_type="building")
    p = pod("IRVING IRVING 818 W Royal Ln 367")
    score_pod(p, [screen, sign, label()])
    assert p.priority == "Lockers" and "Lockers de Amazon" in top_reasons(p)[0]
    num = next(r for r in p.check_results if r["check"] == "numero_direccion")
    assert not num["applicable"] and num["score"] == 0


def test_amazon_hub_caption():
    from export.report_card import caption
    assert caption("Andri Balza", "DFW-BAA", ["A", "B"], amazon_hub=True) == (
        "Motivo: Pod Fake (Lockers de Amazon)\nDriver: Andri Balza\nCiudad: DFW - BAA\nTraking: A\nB")


def test_amazon_locker_size_screen_is_amazon_hub():
    from processing.scoring import is_amazon_hub
    screen = PhotoOCR(path="p1", text="Stringfellow Lakeisha Back Help Selec. avallable Medium 5 avallab Small 13 a EE")
    assert is_amazon_hub(pod("IRVING IRVING 818 W Royal Ln 367"), [screen])
    luxer = PhotoOCR(path="p1", text="LuxerOne Back Help Small 3 available Medium 2 available")
    assert not is_amazon_hub(pod("IRVING IRVING 818 W Royal Ln 367"), [luxer])


# ---------------------------------------------------------------------------- casos reales del 03/10 (DFW-BAA/DFW02)

def test_address_phone_extension_and_building_20261003():
    a = parse_us_address("SOUTHLAKE SOUTHLAKE 1108 TEALWOOD CT +1 210-728-4548 ext. 56399")
    assert a.house_number == "1108" and not a.unit
    a = parse_us_address("PLANO PLANO 4701 14th St 4305, Building 4")
    assert a.house_number == "4701" and a.unit == "4305"


def test_unit_with_letter_20261003():
    addr = "Plano Plano 1334 Sherrye Dr Apt 34B"
    for read in (["1334B"], ["34B"]):
        assert _door_status(addr, PhotoOCR(path="p", numbers=["1334"], unit_letters=read)) == "match"
    assert _door_status(addr, PhotoOCR(path="p", numbers=["1334"], unit_letters=["1334C"])) in (
        "mismatch", "mismatch_unconfirmed")


def test_two_mailboxes_in_same_photo_and_apartment_door_rule():
    both = PhotoOCR(path="p", numbers=["3529", "3525"], number_conf={"3529": 99, "3525": 99},
                    vision_all=["3529", "3525"])
    assert _door_status("PLANO PLANO 3525 Twin Lakes Way", both) == "match"
    door = PhotoOCR(path="p3", numbers=["7210"], number_conf={"7210": 99}, photo_type="door")
    other = PhotoOCR(path="p1", numbers=["7103"], number_conf={"7103": 99}, photo_type="building")
    assert _door_status("Grand Prairie 2250 Sara Jane Pkwy Apt 7210", door, other) == "match"


def test_cursive_seven_read_as_one_is_not_high():
    from processing.ocr_address import misread_of_plate
    assert misread_of_plate("2111", "2717") and not misread_of_plate("2111", "2713")
    p = pod("GARLAND GARLAND 2717 Pinewood Drive")
    score_pod(p, [PhotoOCR(path="p", numbers=["2111"], number_conf={"2111": 99}, vision_all=["2111"]), label()])
    assert p.priority != "Alta"


def test_dark_photo_with_matching_number_and_mail_piece():
    from models.pod import ImageQualityMetrics
    p = pod("PLANO PLANO 4701 14th St Apt 7204")
    p.image_metrics = [ImageQualityMetrics(file_path="d.jpg", is_dark=True)]
    score_pod(p, [PhotoOCR(path="d.jpg", numbers=["7204"]), label()])
    assert p.priority == "Baja"
    mail = PhotoOCR(path="m.jpg", is_label=True,
                    text="ECRWSS**C-081 DIANNA HENDERSON OR CURRENT RESIDENT 3514 COTILLION DR PLANO TX 75074-4349")
    r = check_address_number(pod("Plano Plano 3514 Cotillion Dr Casa"), [PhotoOCR(path="x"), mail])
    assert r.details["status"] == "match"


def test_map_screenshot_with_farm_road_and_pmb_mailbox_store():
    from processing.map_screenshot import screenshot_address_status
    t = "3570 FM 859, Edgewood, TX 7511 3570 FM 859 Visitados recientemente 3570 FM 859 Edgewood, TX 75117"
    assert screenshot_address_status(t, "3570", "FM 859")[0] == "match"
    from processing.scoring import is_locker_delivery
    assert is_locker_delivery(pod("GRAPEVINE 1527 W STATE HIGHWAY 114 STE 500 PMB 138"), [])


def test_apartment_door_rule_waits_for_vision_before_matching():
    # 04/10: sin el modelo de visión todavía, la regla de edificios no puede dar "concuerda" (el modelo debe revisar)
    a = PhotoOCR(path="f1", numbers=["2817"], number_conf={"2817": 99.0}, photo_type="door")
    b = PhotoOCR(path="f3", numbers=["4224"], number_conf={"4224": 99.0}, photo_type="door")
    st = _door_status("North Richland Hills 8500 Harwood Rd, Apt 4224", a, b)
    assert st != "match"


def test_reception_counter_photo_is_asked_and_omitted():
    # 04/10: foto que SOLO el modelo llamó "etiqueta" (paquete en el mostrador) se pregunta; la recepción se omite
    from processing.pipeline import detect_handoff
    counter = PhotoOCR(path="mostrador.jpg", is_label=True, vision_label=True, text="440 DD2")
    counter2 = PhotoOCR(path="mostrador2.jpg", is_label=True, vision_label=True, text="440 DD2")   # 29/10: 2 fotos distintas
    p = pod("NORTH RICHLAND HILLS 6350 Winter Park Dr Apt. 341")
    p.priority = "Alta"
    asked = []
    assert detect_handoff(p, [PhotoOCR(path="edificio.jpg"), counter, counter2], asker=lambda path: False,
                          reception_asker=lambda path: asked.append(path) or path.startswith("mostrador"))
    assert "mostrador.jpg" in asked and p.portal_meta.get("handoff_reception")
    real = PhotoOCR(path="etiqueta.jpg", is_label=True, label_tracking="GFUS01075571240196")
    p2 = pod("NORTH RICHLAND HILLS 6350 Winter Park Dr Apt. 341"); p2.priority = "Alta"
    assert not detect_handoff(p2, [real], asker=lambda path: True, reception_asker=lambda path: True)


def test_reception_question_never_for_a_house_door():
    # 04/10: el modelo dijo "recepción" ante la puerta de una casa (error real reportado, 4009 Westwind Dr)
    from processing.pipeline import detect_handoff
    p = pod("Arlington Arlington 4009 Westwind Dr"); p.priority = "Media"
    door_photo = PhotoOCR(path="puerta.jpg", photo_type="door", text="FRIENDS")
    assert not detect_handoff(p, [door_photo], asker=lambda path: False, reception_asker=lambda path: True)


def test_suite_with_slash_and_zip_in_map_screenshot_20261004():
    assert _door_status("BEDFORD BEDFORD 2248 Central Dr Ste107/502", PhotoOCR(path="p", numbers=["107"])) == "match"
    from processing.map_screenshot import screenshot_address
    assert screenshot_address("Terrell, TX 75160 Edificio multiusos Guardar") is None


def test_city_inside_street_name_is_same_building():
    # Caso real 04/10: la misma foto en dos albaranes de la misma casa escrita de dos formas
    from processing.ocr_address import building_key, same_building_key
    a, b = building_key("Euless Euless 1516 North Main Street"), building_key("Euless Euless 1516 N Euless Main St")
    assert same_building_key(a, b)
    assert not same_building_key(a, building_key("Euless 1518 N Euless Main St"))
    assert not same_building_key(building_key("Dallas 2955 Alouette Dr"), building_key("Dallas 2955 Oak Dr"))


def test_false_signature_2_is_not_portal_flag():
    # Caso real 04/10: falseSignature=2 sin etiqueta roja en el portal (foto correcta, 740 Summerfield Dr)
    from processing.scoring import is_portal_flagged_false_pod, portal_info_is_false_pod
    assert not is_portal_flagged_false_pod(pod(portal_meta={"whether_reported": 2, "false_signature": 2}))
    assert is_portal_flagged_false_pod(pod(portal_meta={"whether_reported": 2, "false_signature": 4}))
    assert not portal_info_is_false_pod({"whetherReported": 2, "falseSignature": 2})


def test_apple_maps_screenshot_is_recognized():
    # Caso real 04/10 (GFUS01075583870337): captura de Apple Maps con muy pocas palabras de botones
    from processing.map_screenshot import is_map_screenshot, screenshot_address_status
    t = ("9:31 5G 74 21o ICA 26 ROLL BROOK ST SPRING CREEK DR SPRINGST HOLLOW RIDGE DR SPRING CREEK DR 1506 Spring St "
         "CHAPARRAL RD RD WOODHEIGHTS CT LENT OAK LN 1506 Spring St Address")
    assert is_map_screenshot(t)
    assert screenshot_address_status(t, "1506", "Spring St")[0] == "match"
    assert not is_map_screenshot("SHIP TO JOHN SMITH 1506 SPRING ST ALLEN TX 75002 USPS TRACKING")


def test_amazon_hub_is_not_omitted_as_reception_handoff():
    # Caso real 04/10 (GFUS01075643430153): la pantalla del Amazon Hub en el lobby se tomó como recepción
    from processing.scoring import score_pod
    from processing.ocr_address import PhotoOCR
    p = pod(address="GRAND PRAIRIE 2650 S Forum Dr Apt # 10102",
            portal_meta={"handoff_photo": 1, "handoff_confirmed": True, "handoff_reception": True})
    hub = PhotoOCR(path="hub.jpg", text="10102 Ronald Tennyson 10102 Otherresident Exit Need help7 1-888-283-0577",
                   numbers=["10102"])
    score_pod(p, [hub])
    assert p.priority == "Lockers" and any(r["check"] == "amazon_hub" and r["score"] > 0 for r in p.check_results)


def test_second_loose_unit_number_is_accepted():
    # Caso real 09/10: "Apt 1102 5203" y la puerta dice 5203 -> concuerda (el código postal no cuenta)
    a = parse_us_address("Kennedale 3100 Joplin Rd Apt 1102 5203")
    assert a.unit == "1102" and a.expected_numbers()["unit"] == {"1102", "5203"}
    assert parse_us_address("Dallas 100 Main St Apt 4 75201").expected_numbers()["unit"] == {"4"}
    p = pod(address="Kennedale 3100 Joplin Rd Apt 1102 5203")
    r = check_address_number(p, [PhotoOCR(path="puerta.jpg", numbers=["5203"], number_conf={"5203": 95.0})])
    assert r.details["status"] == "match"



def test_confirmed_handoff_not_omitted_when_vision_reads_other_number():
    # 10/10: 3 errores reales (2315 Everton Dr, 1104 Brevito Dr, 1006 Inwood Dr) con una "entrega en mano" confirmada
    # por error; un número que solo leyó el modelo ("123", "100") es lo que los mantiene en revisión
    p = pod(address="Grand Prairie Grand Prairie 1104 Brevito Dr", portal_meta={"handoff_photo": 2, "handoff_confirmed": True})
    score_pod(p, [PhotoOCR(path="f2.jpg", numbers=["123"], vision_numbers=["123"], number_conf={"123": 60.0})])
    assert p.priority in ("Alta", "Media")
