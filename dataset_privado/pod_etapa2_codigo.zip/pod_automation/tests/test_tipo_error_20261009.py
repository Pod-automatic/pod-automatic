"""09/10: filtro "Tipo de error" de la página local (motivo principal, en palabras)."""

from export.report_server import error_type


def _num(status, score=100):
    return {"check": "numero_direccion", "score": score, "weight": 1, "applicable": True, "details": {"status": status}}


def test_numero_se_separa_por_resultado():
    assert error_type([_num("mismatch")]) == "Número no concuerda"
    assert error_type([_num("not_visible", 40)]) == "Número no se ve"
    assert error_type([_num("near_match", 40)]) == "Número parecido (lectura dudosa)"
    assert error_type([_num("far_numbers", 30)]) == "Edificio sin número de unidad"


def test_gana_el_motivo_que_mas_pesa():
    res = [_num("not_visible", 30), {"check": "fotos_duplicadas", "score": 90, "weight": 1, "applicable": True}]
    assert error_type(res) == "Fotos duplicadas"
    forced = {"check": "pod_falso_portal", "score": 10, "weight": 1, "applicable": True, "force_report": True}
    assert error_type(res + [forced]) == "POD falso (portal)"


def test_sin_motivo():
    assert error_type([]) == "Otro"
