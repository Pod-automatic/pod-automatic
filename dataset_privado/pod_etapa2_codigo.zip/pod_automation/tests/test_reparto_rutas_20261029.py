"""29/10 (pedido del usuario): reparto mejorado entre PC, Kaggle Luis y Kaggle Tracking.

1. Cada corrida empieza en otro punto de cada ruta (ROUTE_START_FRACTION).
2. Lista de hechos del dia (claims_done) y varios candidatos por pedido ("max"): lo de otra corrida se salta sin pedirlo.
3. Reparto por repartidor (route_claim): cada ruta la lista y revisa una sola corrida a la vez.
"""
import time

import pytest

import config
from automation.api_extractor import ApiPODExtractor, WaybillSummary
from automation.work_claims import LeaseCoordinator
from export import portal_sync
from export.portal_sync import PortalError
from tests.test_api_extractor import FakeAPI, _fake_downloader


class Routes(FakeAPI):
    """Tres repartidores con 10 albaranes con POD cada uno."""
    def list_couriers(self, station_id, date_iso):
        return [{"driverName": f"Driver {n}", "userId": n} for n in (1, 2, 3)]

    def iter_waybills(self, station_id, date_iso, courier, page_size=50):
        n = courier["userId"]
        for i in range(1, 11):
            yield WaybillSummary(waybill_no=f"GF{n}{i:02d}", sign_id=f"s{n}{i:02d}", driver_name=courier["driverName"])


@pytest.fixture(autouse=True)
def setup(monkeypatch):
    monkeypatch.setattr(config, 'GOFO_SESSION_GROUP', '')
    monkeypatch.setattr(config, 'CITY_DISPATCH_DB', '')
    monkeypatch.setattr(config, 'ROUTES_PER_BLOCK', 1)
    monkeypatch.setattr(config, 'ROUTE_LIST_CACHE_S', 0)
    monkeypatch.setattr(config, 'CLAIM_BATCH_SIZE', 5)
    monkeypatch.setattr(config, 'ROUTE_START_FRACTION', 0.0)


def run(tmp_path, **attrs):
    api = Routes(); real = api.iter_waybills; events = []
    api.iter_waybills = lambda *a, **k: (events.append(('lista', a[2]['userId'])), (yield from real(*a, **k)))[1]
    ext = ApiPODExtractor(api, images_dir=tmp_path, downloader=_fake_downloader)
    for k, v in attrs.items():
        setattr(ext, k, v)
    done = []
    ext.run_pass([1888], '2026-10-29', set(), lambda p: (done.append(p.tracking_number), events.append(('revisa', p.tracking_number))))
    return events, done, ext


def test_cada_corrida_empieza_en_otro_punto_de_la_ruta(tmp_path, monkeypatch):
    _, done, _ = run(tmp_path)
    assert done[0] == 'GF101'
    monkeypatch.setattr(config, 'ROUTE_START_FRACTION', 0.67)
    _, done, _ = run(tmp_path)
    assert done[0] == 'GF107' and len(done) == 30          # empieza a dos tercios y da la vuelta: no se pierde ninguno


def test_lo_hecho_por_otra_corrida_se_salta_sin_pedirlo(tmp_path):
    asked = []
    def claim(trackings, done):
        asked.extend(trackings)
        return list(trackings)
    hechos = {f'GF1{i:02d}' for i in range(1, 9)}
    _, done, ext = run(tmp_path, claim_fn=claim, done_elsewhere=hechos)
    assert not hechos & set(asked) and not hechos & set(done)
    assert {'GF109', 'GF110'} <= set(done)
    assert ext._taken['1'] == hechos                         # cuentan como vistos para elegir repartidor


def test_varios_candidatos_en_un_pedido(tmp_path):
    calls = []
    hechos_por_otra = {f'GF1{i:02d}' for i in range(1, 9)} | {f'GF2{i:02d}' for i in range(1, 9)}
    def claim_some(trackings, done, n):
        calls.append(list(trackings))
        free = [t for t in trackings if t not in hechos_por_otra]
        return free[:n], [t for t in trackings if t in hechos_por_otra]
    _, done, ext = run(tmp_path, claim_fn=lambda t, d: list(t), claim_some_fn=claim_some)
    assert set(done) == {'GF109', 'GF110', 'GF209', 'GF210'} | {f'GF3{i:02d}' for i in range(1, 11)}
    assert len(calls) <= 6                                   # antes: un pedido por cada bloque de 5 negados
    assert ext._states['not_granted'] >= {'GF101', 'GF208'}


def test_si_falla_el_pedido_nuevo_se_usa_el_anterior(tmp_path):
    def claim_some(trackings, done, n):
        raise PortalError('caido')
    _, done, _ = run(tmp_path, claim_fn=lambda t, d: list(t), claim_some_fn=claim_some)
    assert len(done) == 30


def test_cada_ruta_la_revisa_una_sola_corrida(tmp_path):
    asked, released = [], []
    def route_claim(station, drivers, n):
        asked.append((station, list(drivers)))
        return ([d for d in drivers if d != '2'][:n], ['2'] if '2' in drivers else [])
    events, done, ext = run(tmp_path, claim_fn=lambda t, d: list(t), route_claim_fn=route_claim,
                            route_release_fn=lambda station, driver: released.append(driver))
    assert ('lista', 2) not in events                        # la tiene otra corrida: ni se lista
    assert not any(t.startswith('GF2') for t in done) and len(done) == 20
    assert asked[0][0] == 'DFW02-BAA' and ext._states['route_held'] == {'2'}
    assert set(released) == {'1', '3'}                       # terminadas: se sueltan enseguida


def test_pocas_rutas_a_la_vez(tmp_path, monkeypatch):
    monkeypatch.setattr(config, 'ROUTE_HOLD_MAX', 1)
    monkeypatch.setattr(config, 'MAX_PER_DRIVER_PER_PASS', 5)
    events, done, _ = run(tmp_path, claim_fn=lambda t, d: list(t),
                          route_claim_fn=lambda s, drivers, n: (list(drivers)[:n], []),
                          route_release_fn=lambda s, d: None)
    # Con una ruta a la vez, la 1 se termina antes de listar la 2
    assert events.index(('revisa', 'GF110')) < events.index(('lista', 2)) and len(done) == 30


def test_sin_portal_de_rutas_sigue_como_antes(tmp_path):
    def route_claim(station, drivers, n):
        raise PortalError('sin route_claim.php')
    events, done, _ = run(tmp_path, claim_fn=lambda t, d: list(t), route_claim_fn=route_claim,
                          route_release_fn=lambda s, d: None)
    assert [e for e in events if e[0] == 'lista'] == [('lista', 1), ('lista', 2), ('lista', 3)] and len(done) == 30


# ------------------------------------------------------------------ coordinador y cliente
class Client:
    timeout = 5

    def __init__(self, new=True):
        self.new = new; self.bodies = []; self.routes = {}

    def call(self, path, body):
        self.bodies.append((path, dict(body)))
        if path == 'claims_done.php':
            if not self.new:
                raise PortalError('HTTP 404')
            return {'ok': True, 'trackings': ['GF1', 'GF2'] if not body['after'] else [], 'more': not body['after']}
        if path == 'claim.php':
            wanted = body.get('trackings') or []
            if 'max' in body and self.new:
                return {'ok': True, 'granted': wanted[1:1 + body['max']], 'taken': wanted[:1]}
            return {'ok': True, 'granted': wanted}
        if path == 'route_claim.php':
            if body['release_all']:
                self.routes.clear()
                return {'ok': True, 'granted': [], 'held': []}
            for d in body['release']:
                self.routes.pop(d, None)
            granted = [d for d in body['drivers'] if self.routes.get(d, body['worker']) == body['worker']][:body['max']]
            for d in granted:
                self.routes[d] = body['worker']
            return {'ok': True, 'granted': granted, 'held': [d for d in body['drivers'] if d not in granted]}
        raise AssertionError(path)


def test_coordinador_detecta_el_portal_nuevo(tmp_path):
    coord = LeaseCoordinator(Client(), 'gpu_tracking', '2026-10-29', 600, tmp_path / 'c.db')
    assert coord.done_set() == {'GF1', 'GF2'}
    assert coord.acquire_some(['A1', 'B2', 'C3'], max_n=1) == (['B2'], ['A1'])
    old = LeaseCoordinator(Client(new=False), 'gpu_tracking', '2026-10-29', 600, tmp_path / 'd.db')
    assert old.done_set() is None                           # portal anterior: reparto de siempre (nunca se manda "max")
    assert not any(p == 'claim.php' for p, _ in old.client.bodies)


def test_portal_anterior_con_max_no_se_toma_como_valido():
    with pytest.raises(PortalError):
        portal_sync.claim_some(Client(new=False), 'pc', '2026-10-29', ['A1', 'B2'], [], 1)


def test_rutas_se_reservan_renuevan_y_sueltan(tmp_path, monkeypatch):
    client = Client()
    coord = LeaseCoordinator(client, 'pc', '2026-10-29', 600, tmp_path / 'c.db')
    client.routes['9'] = 'gpu_luis'
    assert coord.routes('DFW-BAA', ['9', '5'], 1) == (['5'], ['9'])
    monkeypatch.setattr(config, 'ROUTE_LEASE_S', 3)
    coord.routes_held[('DFW-BAA', '5')] = time.monotonic() - 2
    coord._renew_routes()
    assert client.bodies[-1][1]['drivers'] == ['5']          # renovada antes de vencer
    coord.release_routes()
    assert client.bodies[-1][1]['release_all'] and not coord.routes_held and not client.routes.get('5')
