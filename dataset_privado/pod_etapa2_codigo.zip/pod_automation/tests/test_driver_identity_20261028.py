from export.report_server import driver_key, whatsapp_messages


def test_identity_uses_id_and_company_before_name():
    base={'driver':'Ana','driver_id':'1','station':'DFW-AAA'}
    assert driver_key(base)==driver_key({**base,'driver':'Ana Actualizada','station':'DFW02-AAA'})
    assert driver_key(base)!=driver_key({**base,'driver_id':'2'})
    assert driver_key(base)!=driver_key({**base,'station':'DFW-BBB'})
    assert driver_key(base)!=driver_key({**base,'driver_id':''})
    assert driver_key({'driver':'Ana','station':'DFW-AAA'})!=driver_key({'driver':'Ana','station':'DFW02-AAA'})


def test_whatsapp_lockers_separate_homonyms_and_join_same_id(monkeypatch,tmp_path):
    from export import report_server, whatsapp_sender
    monkeypatch.setattr(report_server,'WHATSAPP_OUT',tmp_path)
    monkeypatch.setattr(whatsapp_sender,'group_for_station',lambda station:'Grupo simulado')
    evidence=tmp_path/'evidence.png'; evidence.write_bytes(b'fake')
    reports=[{'driver':'Ana','driver_id':'1','station':'DFW-AAA','hub':True},
             {'driver':'Ana','driver_id':'2','station':'DFW-AAA','hub':True},
             {'driver':'Ana Actualizada','driver_id':'1','station':'DFW02-AAA','hub':True},
             {'driver':'Desconocido','station':'DFW-AAA','hub':True},
             {'driver':'Desconocido','station':'DFW-AAA','hub':True}]
    items=[{'tracking':str(i),'portal_evidence':True,'portal_card':str(evidence),'report':report} for i,report in enumerate(reports)]
    result=whatsapp_messages('2026-10-28',items)['Grupo simulado']
    assert [message['trackings'] for message in result]==[['0','2'],['1'],['3'],['4']]
