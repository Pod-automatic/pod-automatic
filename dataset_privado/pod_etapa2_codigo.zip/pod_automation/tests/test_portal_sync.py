import base64

import pytest

from export import portal_sync
from export.portal_sync import Outbox, PortalError, PortalSync, card_jpeg, main_detection, pod_item
from models.pod import PODRecord


class FakeClient:
    """Portal simulado: guarda lo recibido y responde como la API real."""

    def __init__(self):
        self.pods = {}
        self.analyses = {}
        self.snapshots = []
        self.statuses = []
        self.changes = []
        self.down = False
        self.reject = set()

    def call(self, path, body=None, query=None):
        if self.down:
            raise PortalError("sin conexión con el portal (prueba)")
        if path == "analysis.php":
            self.snapshots = body.get("snapshots", [])
            for it in body["items"]:
                self.analyses[(it["worker"], it["model"], it["date"], it["tracking"])] = it
            return {"ok": True, "accepted": list(range(len(body["items"]))), "errors": []}
        if path == "ingest.php":
            errors = []
            for i, it in enumerate(body["items"]):
                if it["tracking"] in self.reject:
                    errors.append({"index": i, "tracking": it["tracking"], "error": "tracking inválido"})
                elif it["priority"] == "Baja":
                    self.pods.pop((it["tracking"], it["date"]), None)
                else:
                    self.pods[(it["tracking"], it["date"])] = it
            return {"ok": not errors, "saved": len(body["items"]) - len(errors), "errors": errors}
        if path == "status.php":
            self.statuses.extend(body["items"])
            return {"ok": True, "missing": [i["tracking"] for i in body["items"] if (i["tracking"], i["date"]) not in self.pods]}
        if path == "changes.php":
            since = (query or {}).get("since", "")
            items = [c for c in self.changes if c["changed_at"] >= since]
            return {"ok": True, "items": items, "cursor": items[-1]["changed_at"] if items else since}
        raise AssertionError(path)


def make_pod(tracking="GFUS0000000000001", priority="Alta", score=80.0, checks=None):
    pod = PODRecord(tracking_number=tracking, driver_name="  Tony   Hernandez ", station="DFW02-BAA",
                    receipt_address="2650 S Forum Dr")
    pod.priority = priority
    pod.risk_score = score
    pod.portal_meta = {"driver_id": 77}
    pod.check_results = checks if checks is not None else [
        {"check": "calidad_imagen", "score": 50, "weight": 1.0, "explanation": "Foto oscura", "applicable": True},
        {"check": "numero_direccion", "score": 100, "weight": 2.0, "explanation": "Número distinto", "applicable": True},
    ]
    return pod


@pytest.fixture
def env(tmp_path):
    client = FakeClient()
    written = []
    sync = PortalSync(client, Outbox(tmp_path / "outbox.db"), status_writer=lambda d, t, s: written.append((d, t, s)),
                      card_maker=lambda payload, i: b"\xff\xd8\xffJPG" + str(i).encode(), pull_interval=0,
                      photo_maker=lambda path: b"\xff\xd8\xffFOTO")
    # Este test de sincronización no debe leer los datos reales de rutas/control de la PC.
    sync.push_panel = lambda: False
    sync.push_control = lambda: False
    return sync, client, written


def test_alta_se_envia_con_datos_y_tarjeta(env):
    sync, client, _ = env
    sync.enqueue_pod(make_pod(), "2026-10-05")
    assert sync.sync_once()["albaranes"] == 1
    it = client.pods[("GFUS0000000000001", "2026-10-05")]
    assert it["driver"] == "Tony Hernandez" and it["station"] == "DFW02-BAA" and it["driver_id"] == "77"
    assert it["address"] == "2650 S Forum Dr" and it["priority"] == "Alta" and it["score"] == 80.0
    assert it["detection"] == "numero_direccion"                    # la que más pesa
    assert it["reasons"][0] == "Número distinto"
    assert [base64.b64decode(c) for c in it["cards"]] == [b"\xff\xd8\xffJPG0"]   # sin fotos en disco: una tarjeta
    assert sync.outbox.counts() == {"enviados": 1}


def test_baja_solo_va_al_historial_y_baja_despues_de_alta_se_retira(env):
    sync, client, _ = env
    sync.enqueue_pod(make_pod("GFUS0000000000002", "Baja", 10), "2026-10-05")
    sync.enqueue_pod(make_pod(score=None), "2026-10-05")     # sin score todavía
    assert sync.outbox.counts() == {"analysis": 1, "enviados": 0}
    sync.enqueue_pod(make_pod(), "2026-10-05")
    sync.sync_once()
    sync.enqueue_pod(make_pod(priority="Baja", score=10), "2026-10-05")   # re-calificado
    sync.sync_once()
    assert client.pods == {}
    assert sync.outbox.counts() == {"enviados": 0}


def test_sin_conexion_queda_en_bandeja_y_sale_despues(env):
    sync, client, _ = env
    client.down = True
    sync.enqueue_pod(make_pod(), "2026-10-05")
    with pytest.raises(PortalError):
        sync.sync_once()
    assert sync.outbox.counts()["pod"] == 1
    client.down = False
    sync.sync_once()
    assert ("GFUS0000000000001", "2026-10-05") in client.pods
    assert "pod" not in sync.outbox.counts()


def test_version_nueva_pisa_a_la_pendiente(env):
    sync, client, _ = env
    sync.enqueue_pod(make_pod(score=60), "2026-10-05")
    sync.enqueue_pod(make_pod(score=95), "2026-10-05")
    sync.sync_once()
    assert client.pods[("GFUS0000000000001", "2026-10-05")]["score"] == 95


def test_rechazo_del_portal_se_reintenta_y_luego_se_descarta(env, monkeypatch):
    sync, client, _ = env
    client.reject.add("GFUS0000000000001")
    sync.enqueue_pod(make_pod(), "2026-10-05")
    for _ in range(portal_sync.MAX_ATTEMPTS):
        with sync.outbox._conn() as c:
            c.execute("UPDATE outbox SET next_try = 0")   # sin esperar la pausa entre reintentos
        sync.sync_once()
    assert sync.outbox.counts() == {"enviados": 0}


def test_marcas_locales_van_al_portal_y_las_de_la_web_vuelven(env):
    sync, client, written = env
    sync.enqueue_pod(make_pod(), "2026-10-05")
    sync.enqueue_status("2026-10-05", "GFUS0000000000001", "reportado")
    sync.sync_once()
    assert client.statuses == [{"date": "2026-10-05", "tracking": "GFUS0000000000001", "status": "reportado"}]
    assert "status" not in sync.outbox.counts()
    client.changes = [{"tracking": "GFUS0000000000009", "date": "2026-10-04", "status": "descartado",
                       "error_type": None, "changed_at": "2026-10-05 10:00:00"}]
    sync.sync_once()
    assert written == [("2026-10-04", "GFUS0000000000009", "descartado")]
    assert sync.outbox.get_state("pull_cursor") == "2026-10-05 10:00:00"


def test_main_detection_prioriza_force_report():
    checks = [{"check": "amazon_hub", "score": 100, "weight": 2.0},
              {"check": "numero_direccion", "score": 10, "weight": 1.0, "force_report": True},
              {"check": "distancia_gps", "score": 0, "weight": 5.0}]
    assert main_detection(checks) == "numero_direccion"
    assert main_detection([]) is None


def test_pod_item_baja_solo_lleva_lo_minimo():
    assert pod_item({"tracking_number": "GFUS1", "priority": "Baja"}, "2026-10-05") == \
        {"date": "2026-10-05", "tracking": "GFUS1", "priority": "Baja"}


def test_card_jpeg_es_jpg_y_respeta_el_ancho(monkeypatch):
    monkeypatch.setattr(portal_sync.config, "PORTAL_CARD_MAX_WIDTH", 600)
    data = card_jpeg(make_pod().to_dict())
    from PIL import Image
    import io
    img = Image.open(io.BytesIO(data))
    assert img.format == "JPEG" and img.width == 600


def test_marca_local_se_encola_si_el_portal_esta_configurado(tmp_path, monkeypatch):
    monkeypatch.setattr(portal_sync.config, "PORTAL_SYNC_ENABLED", True)
    monkeypatch.setattr(portal_sync.config, "PORTAL_OUTBOX_PATH", tmp_path / "o.db")
    portal_sync.notify_status("2026-10-05", "GFUS1", "descartado")
    assert Outbox(tmp_path / "o.db").counts()["status"] == 1


def test_hilo_en_segundo_plano_envia_y_se_detiene(env):
    import time
    sync, client, _ = env
    sync.start()
    sync.enqueue_pod(make_pod(), "2026-10-05")
    for _ in range(100):
        if client.pods:
            break
        time.sleep(0.05)
    sync.stop(timeout=5)
    assert ("GFUS0000000000001", "2026-10-05") in client.pods
    assert not sync._thread.is_alive()


def test_una_tarjeta_por_foto_hasta_seis(env, tmp_path):
    sync, client, _ = env
    fotos = []
    for i in range(8):
        f = tmp_path / f"foto_{i}.jpg"
        f.write_bytes(b"x")
        fotos.append(str(f))
    pod = make_pod()
    pod.photo_paths = fotos[:3] + [str(tmp_path / "no_existe.jpg")]
    sync.enqueue_pod(pod, "2026-10-05")
    sync.sync_once()
    cards = client.pods[("GFUS0000000000001", "2026-10-05")]["cards"]
    assert [base64.b64decode(c)[-1:] for c in cards] == [b"0", b"1", b"2"]   # solo las fotos que existen
    pod2 = make_pod("GFUS0000000000002")
    pod2.photo_paths = fotos
    sync.enqueue_pod(pod2, "2026-10-05")
    sync.sync_once()
    assert len(client.pods[("GFUS0000000000002", "2026-10-05")]["cards"]) == 6


def test_manda_las_fotos_originales_para_el_zoom(env, tmp_path):
    from PIL import Image
    sync, client, _ = env
    sync.photo_maker = portal_sync.photo_jpeg
    fotos = []
    for i, size in enumerate([(4000, 3000), (800, 600)]):
        f = tmp_path / f"orig_{i}.jpg"
        Image.new("RGB", size, "gray").save(f)
        fotos.append(str(f))
    pod = make_pod()
    pod.photo_paths = fotos
    sync.enqueue_pod(pod, "2026-10-05")
    sync.sync_once()
    it = client.pods[("GFUS0000000000001", "2026-10-05")]
    import io
    sizes = [Image.open(io.BytesIO(base64.b64decode(p))).size for p in it["photos"]]
    assert sizes == [(1600, 1200), (800, 600)]          # se achica solo la grande, sin agrandar la chica
    assert len(it["cards"]) == 2


def test_envio_demasiado_grande_baja_a_uno_y_luego_sin_originales(env):
    sync, client, _ = env
    real = client.call
    state = {"limit": 1}

    def call(path, body=None, query=None):
        if path == "ingest.php":
            big = len(body["items"]) > state["limit"] or any("photos" in it for it in body["items"])
            if big:
                raise PortalError("HTTP 413: Request Entity Too Large")
        return real(path, body, query)
    client.call = call
    for t in ("GFUS0000000000001", "GFUS0000000000002"):
        pod = make_pod(t)
        pod.photo_paths = []
        sync.enqueue_pod(pod, "2026-10-05")
    sync.sync_once()
    assert sync.batch == 1
    sync.sync_once()
    assert set(client.pods) == {("GFUS0000000000001", "2026-10-05"), ("GFUS0000000000002", "2026-10-05")}
    assert all("photos" not in it for it in client.pods.values())


def test_analysis_instance_lleva_la_corrida(monkeypatch):
    """29/10: gpu_luis y gpu_tracking comparten máquina en Kaggle; Comparar GPU las separa por la corrida."""
    import socket
    import config
    from export import portal_sync
    monkeypatch.setattr(config, 'CLAIM_WORKER', 'gpu_tracking')
    monkeypatch.setattr(socket, 'gethostname', lambda: 'x' * 100)
    instance = portal_sync.analysis_instance()
    assert instance.endswith(':gpu_tracking') and len(instance) <= 80
    monkeypatch.setattr(config, 'CLAIM_WORKER', 'pc')
    monkeypatch.setattr(socket, 'gethostname', lambda: 'DESKTOP-1')
    assert portal_sync.analysis_instance() == 'DESKTOP-1:pc'
