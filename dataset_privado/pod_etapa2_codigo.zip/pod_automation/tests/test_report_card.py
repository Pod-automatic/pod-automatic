from export.report_card import caption, render_card, station_label, city_code, company_code


def test_iah_and_iah02_remain_distinct_with_baa_company():
    assert city_code('IAH02-BAA') == 'IAH02'
    assert city_code('IAH-BAA') == 'IAH'
    assert company_code('IAH02-BAA') == 'BAA'
    assert 'Ciudad: IAH02 - BAA\n' in caption('X', 'IAH02-BAA', ['A'])
    assert 'Ciudad: IAH - BAA\n' in caption('X', 'IAH-BAA', ['A'])


def test_station_label_matches_group_format():
    assert station_label("DFW02-BAA") == "DFW02 - BAA"
    assert station_label("DFW-BAA") == "DFW - BAA"


def test_caption_one_and_many_trackings():
    assert caption("Hanna  Mariam", "DFW02-BAA", ["GFUS1"]) == (
        "Motivo: Pod Fake\nDriver: Hanna Mariam\nCiudad: DFW02 - BAA\nTraking: GFUS1")
    assert caption("X", "DFW-BAA", ["A", "B"]).endswith("Traking: A\nB")


def test_render_card_without_photos_is_png():
    png = render_card({"tracking_number": "GFUS1", "station": "DFW02-BAA", "photo_paths": []})
    assert png[:8] == b"\x89PNG\r\n\x1a\n"
