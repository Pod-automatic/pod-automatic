"""07/10: latido de la corrida al portal, para que avise por correo si se cae o se traba."""

from export.portal_sync import PortalError, PortalSync


class FakeClient:
    def __init__(self, fail=False):
        self.calls, self.fail = [], fail

    def call(self, path, body=None, query=None):
        if self.fail:
            raise PortalError("HTTP 404")   # Portal todavía sin heartbeat.php
        self.calls.append((path, body))
        return {"ok": True}


def _sync(client):
    return PortalSync(client, outbox=None)


def test_sin_datos_de_la_corrida_no_envia_latido():
    client = FakeClient()
    assert not _sync(client).send_heartbeat() and client.calls == []


def test_latido_lleva_avance_y_faltantes():
    client = FakeClient()
    sync = _sync(client)
    sync.heartbeat_info = lambda: {"day": "2026-10-07", "reviewed_today": 812, "last_reviewed_at": "2026-10-07 14:03:11",
                                   "backlog": {"total": 120, "per_hour": 450}}
    assert sync.send_heartbeat()
    path, body = client.calls[0]
    assert path == "heartbeat.php" and body["state"] == "running" and body["reviewed_today"] == 812
    assert body["backlog"]["total"] == 120 and body["host"] and body["sent_at"].startswith("20")


def test_portal_sin_endpoint_no_rompe_la_corrida():
    sync = _sync(FakeClient(fail=True))
    sync.heartbeat_info = lambda: {"day": "2026-10-07"}
    assert sync.send_heartbeat() is False


def test_al_detener_avisa_que_fue_a_proposito():
    client = FakeClient()
    sync = _sync(client)
    sync.heartbeat_info = lambda: {"day": "2026-10-07"}
    sync.stop(timeout=0)
    assert client.calls[-1][1]["state"] == "stopped"
