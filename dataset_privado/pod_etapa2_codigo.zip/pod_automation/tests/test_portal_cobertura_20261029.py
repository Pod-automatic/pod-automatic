"""29/10: cobertura del portal. Cualquier corrida (PC o Kaggle) manda cada 10 min los repartidores de TODAS las ciudades de GOFO
(list_couriers no cambia la ciudad activa) a api/coverage.php, que reemplaza solo las ciudades recibidas."""
import config
from export import portal_sync
from export.portal_sync import Outbox, PortalSync, PortalError, coverage_body

COURIER = {"siteName": "IAH-BAA", "userId": 264084, "driverName": "Jaider  Esneider ", "checkOutPieces": 244,
           "podPieces": 215, "deliveringPieces": 3}


class Client:
    def __init__(self, fail=False):
        self.calls, self.fail = [], fail

    def call(self, path, body=None, query=None):
        if self.fail:
            raise PortalError("sin conexión")
        self.calls.append((path, body))
        return {"ok": True}


def test_cuerpo_de_cobertura():
    body = coverage_body("2026-10-29", {"IAH-BAA": [COURIER, {"driverName": "Sin id"}], "DFW-BAA": []}, "gpu_luis")
    assert body["date"] == "2026-10-29" and body["worker"] == "gpu_luis"
    iah = next(s for s in body["stations"] if s["station"] == "IAH-BAA")
    assert iah["couriers"] == [{"user_id": "264084", "driver": "Jaider Esneider", "checkout": 244, "pod": 215, "delivering": 3}]
    # Una ciudad sin repartidores también se manda: así el portal sabe que hoy tiene 0
    assert {"station": "DFW-BAA", "couriers": []} in body["stations"]


def test_se_envia_en_el_hilo_y_tambien_en_modo_gpu(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "PORTAL_GPU", True)
    monkeypatch.setattr(config, "CLAIM_WORKER", "gpu_tracking")
    client = Client()
    sync = PortalSync(client, Outbox(tmp_path / "o.db"))
    sync.queue_coverage("2026-10-29", {"IAH-BAA": [COURIER]})
    sync.sync_once(pull=False)
    paths = [p for p, _ in client.calls]
    assert paths.count("coverage.php") == 1
    body = dict(client.calls)["coverage.php"]
    assert body["worker"] == "gpu_tracking" and body["stations"][0]["station"] == "IAH-BAA"
    sync.sync_once(pull=False)                    # Ya se mandó: no se repite
    assert [p for p, _ in client.calls].count("coverage.php") == 1


def test_portal_caido_conserva_lo_ultimo(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "PORTAL_GPU", False)
    sync = PortalSync(Client(fail=True), Outbox(tmp_path / "o.db"))
    sync.queue_coverage("2026-10-29", {"IAH-BAA": [COURIER]})
    assert sync.push_coverage() is False          # Nunca lanza: la corrida sigue
    sync.queue_coverage("2026-10-29", {"IAH-BAA": [dict(COURIER, podPieces=216)]})
    sync.client = Client()
    assert sync.push_coverage() is True
    assert sync.client.calls[0][1]["stations"][0]["couriers"][0]["pod"] == 216   # Solo el más nuevo
    assert sync.push_coverage() is False          # Nada pendiente


def test_lectura_de_las_ciudades_cada_10_min(monkeypatch):
    monkeypatch.setattr(config, "GOFO_STATION_NAMES", {1: "DFW-BAA", 2: "IAH-BAA", 3: "ORD-BAA"})
    asked, queued = [], []

    class Api:
        def list_couriers(self, station_id, date_iso):
            asked.append(station_id)
            if station_id == 3:
                raise RuntimeError("timeout")   # Una ciudad que falla no frena a las demás
            return [COURIER]

    class Sync:
        def queue_coverage(self, day, stations):
            queued.append((day, stations))

    state, clock = {}, [1000.0]
    monkeypatch.setattr(portal_sync.time, "monotonic", lambda: clock[0])
    assert portal_sync.coverage_tick(Api(), Sync(), "2026-10-29", state)
    assert asked == [1, 2, 3] and set(queued[0][1]) == {"DFW-BAA", "IAH-BAA"}
    clock[0] += 300
    assert not portal_sync.coverage_tick(Api(), Sync(), "2026-10-29", state)    # Antes de 10 min no vuelve a leer
    clock[0] += 301
    assert portal_sync.coverage_tick(Api(), Sync(), "2026-10-29", state)
    assert not portal_sync.coverage_tick(Api(), None, "2026-10-29", {})          # Sin portal no lee nada
