import json
import sqlite3
import zipfile
from pathlib import Path

from tools.kaggle_diagnostico import parse_gpu_csv, sample, append_sample, build_bundle, summarize_log_text


def make_worker(root, name):
    base = Path(root) / 'storage' / 'multi' / 'workers' / name
    (base / 'logs').mkdir(parents=True)
    (base / 'logs' / 'run_20261028.log').write_text(
        '2026-10-29 02:40:15 [WARNING] Ollama devolvio HTTP 500\n'
        '2026-10-29 02:40:17 [WARNING] VisionCapped: tope de 5 consultas\n'
        '2026-10-29 02:40:18 [WARNING] VisionCapped: tope de 5 consultas\n'
        '2026-10-29 02:40:19 [INFO] Albaran X procesado en 1.0s\n', encoding='utf-8')
    (base / 'throughput.jsonl').write_text('{"seconds": 1.2, "status": "PROCESSED"}\n', encoding='utf-8')
    db = sqlite3.connect(base / 'pod_checkpoints.db')
    db.execute('CREATE TABLE pod_checkpoints(tracking_number TEXT)')
    db.execute("INSERT INTO pod_checkpoints VALUES ('GFUS1')")
    db.commit(); db.close()
    (base / 'pod_images' / '2026-10-28' / 'T1').mkdir(parents=True)
    (base / 'pod_images' / '2026-10-28' / 'T1' / 'foto_1.jpg').write_bytes(b'x' * 1000)
    return base


def test_parse_gpu_csv_reads_utilization_and_memory():
    rows = parse_gpu_csv('0, 24, 6643, 15360\n1, 100, 14469, 15360\n')
    assert rows == [{'gpu': 0, 'util_pct': 24, 'mem_used_mib': 6643, 'mem_total_mib': 15360, 'mem_free_mib': 8717},
                    {'gpu': 1, 'util_pct': 100, 'mem_used_mib': 14469, 'mem_total_mib': 15360, 'mem_free_mib': 891}]
    assert parse_gpu_csv('') == [] and parse_gpu_csv('basura') == []


def test_log_summary_counts_known_problems():
    counts = summarize_log_text(Path_text := ('HTTP 500\nVisionCapped\nVisionCapped\nrespuesta no JSON\nSesion vencida\n'
                                              'Modelo mayor no disponible\nse omite recarga global\n'))
    assert counts == {'http_500': 1, 'vision_capped': 2, 'respuesta_no_json': 1, 'sesion_vencida': 1,
                      'modelo_mayor_no_disponible': 1, 'recarga_global_omitida': 1}


def test_sample_never_raises_when_tools_are_missing(tmp_path):
    def broken(*a, **k): raise FileNotFoundError('nvidia-smi')
    row = sample(tmp_path, ['gpu_luis'], runner=broken, activity=lambda worker: {'completed_recent': 3})
    assert row['gpus'] == [] and row['workers']['gpu_luis'] == {'completed_recent': 3} and 'time_utc' in row


def test_append_sample_writes_one_json_line_each(tmp_path):
    path = tmp_path / 'diag' / 'metricas.jsonl'
    append_sample(path, {'a': 1}); append_sample(path, {'a': 2})
    assert [json.loads(line) for line in path.read_text().splitlines()] == [{'a': 1}, {'a': 2}]


def test_bundle_has_logs_and_db_but_no_credentials_or_photos(tmp_path):
    root = tmp_path / 'pod'; working = tmp_path / 'working'; working.mkdir()
    make_worker(root, 'gpu_luis'); make_worker(root, 'gpu_tracking')
    sessions = root / 'storage' / 'sessions'; sessions.mkdir(parents=True)
    (sessions / 'luis.json').write_text('{"cookies": [{"value": "SECRETO"}]}')
    (root / 'storage' / 'session_state.json').write_text('{"cookies": []}')
    (root / '.env').write_text('PORTAL_API_KEY=SECRETO')
    (working / 'multiciudad.log').write_text('supervisor ok\n')
    (working / 'diagnostico').mkdir(); (working / 'diagnostico' / 'metricas.jsonl').write_text('{"a":1}\n')
    out = build_bundle(root, working, working / 'diagnostico_kaggle.zip')
    names = zipfile.ZipFile(out).namelist()
    assert 'resumen.json' in names and 'multiciudad.log' in names and 'metricas.jsonl' in names
    assert 'workers/gpu_luis/logs/run_20261028.log' in names
    assert 'workers/gpu_tracking/throughput.jsonl' in names
    assert 'workers/gpu_luis/pod_checkpoints.db' in names
    assert not [n for n in names if 'luis.json' in n.split('/')[-1] and 'workers' not in n]
    assert not [n for n in names if n.endswith(('.jpg', '.png', 'session_state.json', '.env'))]
    blob = b''.join(zipfile.ZipFile(out).read(n) for n in names)
    assert b'SECRETO' not in blob
    summary = json.loads(zipfile.ZipFile(out).read('resumen.json'))
    assert summary['workers']['gpu_luis']['http_500'] == 1 and summary['workers']['gpu_luis']['vision_capped'] == 2
    assert not (working / 'diagnostico_kaggle.tmp').exists()


def test_bundle_truncates_huge_logs_keeping_the_end(tmp_path):
    root = tmp_path / 'pod'; working = tmp_path / 'working'; working.mkdir()
    base = make_worker(root, 'gpu_luis')
    (base / 'logs' / 'run_20261028.log').write_text('INICIO\n' + 'x' * 5000 + '\nFINAL\n', encoding='utf-8')
    out = build_bundle(root, working, working / 'd.zip', max_log_bytes=1000)
    text = zipfile.ZipFile(out).read('workers/gpu_luis/logs/run_20261028.log').decode()
    assert 'FINAL' in text and 'INICIO' not in text and len(text) < 1500
