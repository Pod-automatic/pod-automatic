"""La simulacion nunca debe tratar datos GPS invalidos u otras alertas como evidencia favorable."""
from copy import deepcopy
import unittest

from tools.probar_gps_ambiguo import candidate


class GPSExperimentTests(unittest.TestCase):
    def setUp(self):
        self.data = {'portal_meta': {'sign_distance': '4', 'pod_lat': '32.9', 'pod_lng': '-96.6'},
                     'check_results': [
                         {'check': 'numero_direccion', 'score': 40,
                          'details': {'status': 'near_match', 'unidad': None}},
                         {'check': 'fotos_edificio', 'score': 0, 'applicable': False,
                          'explanation': 'No es apartamento.'}]}

    def test_close_ambiguous_house(self):
        self.assertTrue(candidate(self.data, 5))
        self.assertFalse(candidate(self.data, 3))

    def test_invalid_gps(self):
        for key, value in [('sign_distance', x) for x in (None, '', 'nan', 'inf', '-1')] + [
                ('pod_lat', None), ('pod_lat', '91'), ('pod_lng', '-181')]:
            data = deepcopy(self.data)
            data['portal_meta'][key] = value
            self.assertFalse(candidate(data, 5), (key, value))

    def test_other_number_or_apartment(self):
        for status in ('mismatch', 'neighbor_digit', 'not_visible'):
            data = deepcopy(self.data)
            data['check_results'][0]['details']['status'] = status
            self.assertFalse(candidate(data, 5))
        self.data['check_results'][0]['details']['unidad'] = '101'
        self.assertFalse(candidate(self.data, 5))

    def test_vision_failure_only_in_explicit_aggressive_variant(self):
        self.data['check_results'].append({'check': 'vision_fallida', 'score': 50})
        self.assertFalse(candidate(self.data, 5))
        self.assertTrue(candidate(self.data, 5, True))

    def test_other_alerts_and_forced_report_block_both_variants(self):
        for check in ({'check': 'fotos_duplicadas', 'score': 50},
                      {'check': 'pod_falso_portal', 'score': 0, 'force_report': True}):
            data = deepcopy(self.data)
            data['check_results'].append(check)
            self.assertFalse(candidate(data, 5, True))

    def test_no_mutation(self):
        before = deepcopy(self.data)
        candidate(self.data, 5, True)
        self.assertEqual(self.data, before)
