"""Verificación cruzada (26/10): una corrida analiza lo que marcó la otra y manda su resultado al portal."""

from pathlib import Path

import config
from automation.api_extractor import ApiPODExtractor
from automation.verifier import CrossVerifier
from export.portal_sync import Outbox, PortalError, PortalSync
from tests.test_api_extractor import FakeAPI, _fake_downloader


class VerifyAPI(FakeAPI):
    def __init__(self, signs=None):
        super().__init__()
        self.signs = signs if signs is not None else {"GFX1": "sX1", "GFX2": "sX2"}
        self.asked = []

    def latest_sign_id(self, tracking):
        self.asked.append(tracking)
        return self.signs.get(tracking)


class FakePipeline:
    def __init__(self):
        self.pods = []

    def submit(self, pod):
        self.pods.append(pod)


def _item(tracking, **extra):
    return {"date": "2026-10-26", "tracking": tracking, "driver": "Ana Perez", "driver_id": "77", "station": "DFW02-BAA",
            "sign_distance": "12.5", "pod_lat": "32.7", "pod_lng": "-97.1", "flagged_by": "gpu", **extra}


def _extractor(api):
    return ApiPODExtractor(api, images_dir=Path("/tmp/x"), downloader=_fake_downloader)


def test_verifica_lo_que_pide_el_portal_y_lo_manda_al_analisis():
    api, pipe = VerifyAPI(), FakePipeline()
    v = CrossVerifier(lambda n: [_item("GFX1"), _item("GFX2")], interval_s=0, batch=5)
    assert v.run_some(_extractor(api), pipe, "2026-10-26") == 2
    assert [p.tracking_number for p in pipe.pods] == ["GFX1", "GFX2"]
    p = pipe.pods[0]
    assert p.portal_meta["verify_of"] == "gpu" and p.portal_meta["verify_day"] == "2026-10-26"
    assert p.portal_meta["sign_distance"] == "12.5"       # La distancia GPS del original viaja con la petición
    assert api.sign_calls == ["sX1", "sX2"]               # Pidió el detalle del POD más reciente de cada uno


def test_respeta_el_intervalo_y_el_tope_por_vez():
    api, pipe = VerifyAPI(), FakePipeline()
    now = [100.0]
    asked = []

    def fetch(n):
        asked.append(n)
        return [_item("GFX1"), _item("GFX2")]

    v = CrossVerifier(fetch, interval_s=30, batch=1, clock=lambda: now[0])
    ext = _extractor(api)
    assert v.run_some(ext, pipe, "2026-10-26") == 1       # Tope: 1 aunque el portal mande 2
    assert v.run_some(ext, pipe, "2026-10-26") == 0       # Aún no pasan 30 s
    assert asked == [1]
    now[0] += 31
    assert v.run_some(ext, pipe, "2026-10-26") == 1 and asked == [1, 1]


def test_si_el_portal_no_responde_no_pasa_nada():
    def boom(n):
        raise PortalError("sin conexión")

    v = CrossVerifier(boom, interval_s=0)
    assert v.run_some(_extractor(VerifyAPI()), FakePipeline(), "2026-10-26") == 0


def test_sin_pod_en_gofo_se_avisa_y_se_sigue_con_el_siguiente():
    errors = []
    api, pipe = VerifyAPI({"GFX2": "sX2"}), FakePipeline()
    v = CrossVerifier(lambda n: [_item("GFX1"), _item("GFX2")], lambda it, msg: errors.append((it["tracking"], msg)),
                      interval_s=0)
    assert v.run_some(_extractor(api), pipe, "2026-10-26") == 1
    assert errors == [("GFX1", "sin POD en GOFO")] and [p.tracking_number for p in pipe.pods] == ["GFX2"]


def test_un_albaran_que_falla_no_frena_a_los_demas():
    errors = []
    api, pipe = VerifyAPI(), FakePipeline()
    calls = []
    orig = api.latest_sign_id

    def flaky(tracking):
        calls.append(tracking)
        if tracking == "GFX1":
            raise RuntimeError("GOFO caído")
        return orig(tracking)

    api.latest_sign_id = flaky
    v = CrossVerifier(lambda n: [_item("GFX1"), _item("GFX2")], lambda it, msg: errors.append(it["tracking"]), interval_s=0)
    assert v.run_some(_extractor(api), pipe, "2026-10-26") == 1
    assert errors == ["GFX1"] and [p.tracking_number for p in pipe.pods] == ["GFX2"]


def test_el_extractor_llama_a_verify_fn_entre_bloques(monkeypatch):
    monkeypatch.setattr(config, "MAX_PER_DRIVER_PER_PASS", 1)
    ext = _extractor(FakeAPI())
    calls = []
    ext.verify_fn = lambda: calls.append(1)
    ext.run_pass([1888], "2026-09-29", processed=set(), on_record=lambda p: None)
    assert len(calls) >= 2


def test_un_fallo_de_verify_fn_no_frena_la_extraccion():
    ext = _extractor(FakeAPI())
    got = []

    def boom():
        raise RuntimeError("fallo")

    ext.verify_fn = boom
    ext.run_pass([1888], "2026-09-29", processed=set(), on_record=got.append)
    assert len(got) == 4


def test_el_resultado_llega_al_portal_sin_fotos(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "VERIFY_WORK", True)
    monkeypatch.setattr(config, "CLAIM_WORKER", "gpu")
    sent = []

    class Client:
        def call(self, path, body=None, query=None):
            sent.append((path, body))
            return {"ok": True, "errors": []}

    sync = PortalSync(Client(), Outbox(tmp_path / "o.db"), status_writer=lambda *a: None)
    from tests.test_portal_sync import make_pod
    pod = make_pod("GFX1", priority="Baja", score=0.0)
    pod.portal_meta["verify_of"] = "pc"
    pod.portal_meta["verify_day"] = "2026-10-26"
    sync.enqueue_verify(pod, "2026-10-26")
    assert sync.push_verify() == 1
    path, body = sent[-1]
    assert path == "verify.php" and body["action"] == "result" and body["worker"] == "gpu"
    it = body["items"][0]
    assert it["tracking"] == "GFX1" and it["priority"] == "Baja" and it["date"] == "2026-10-26"
    assert it["verify_of"] == "pc" and "photos" not in it and "cards" not in it
    assert sync.push_verify() == 0                         # Ya se mandó: no se repite


def test_si_el_portal_esta_caido_el_resultado_se_reintenta(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "VERIFY_WORK", True)

    class Down:
        def call(self, path, body=None, query=None):
            raise PortalError("sin conexión")

    sync = PortalSync(Down(), Outbox(tmp_path / "o.db"), status_writer=lambda *a: None)
    from tests.test_portal_sync import make_pod
    pod = make_pod("GFX9", priority="Alta")
    pod.portal_meta["verify_of"] = "pc"
    sync.enqueue_verify(pod, "2026-10-26")
    try:
        sync.push_verify()
    except PortalError:
        pass
    assert sync.outbox.due("verify", 10)[0]["tracking"] == "GFX9"     # Sigue en la bandeja


def test_apagada_por_defecto():
    assert config.VERIFY_WORK is False or config.VERIFY_WORK is True   # Existe y es booleano
