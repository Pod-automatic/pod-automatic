import pytest
from export.portal_sync import PortalSync, Outbox, pod_processed_at


def test_pages_are_consumed_without_skipping_equal_timestamp(tmp_path):
    calls=[]
    class Client:
        def call(self,path,body=None,query=None):
            calls.append(query)
            page=len(calls)
            return {'items':[{'tracking':str(page),'date':'2026-10-28','status':'descartado'}],
                    'cursor':f'v2:{page}','has_more':page<3}
    written=[]
    sync=PortalSync(Client(),Outbox(tmp_path/'outbox.db'),status_writer=lambda *args:written.append(args))
    assert sync.pull_changes()==3
    assert calls==[None,{'since':'v2:1'},{'since':'v2:2'}]
    assert sync.outbox.get_state('pull_cursor')=='v2:3'
    assert [row[1] for row in written]==['1','2','3']


def test_failed_write_keeps_cursor_for_replay(tmp_path):
    class Client:
        def call(self,*args,**kwargs):
            return {'items':[{'tracking':'A','date':'2026-10-28','status':'reportado'}],'cursor':'v2:9'}
    def fail(*args): raise OSError('Prueba: disco no disponible')
    box=Outbox(tmp_path/'outbox.db'); box.set_state('pull_cursor','v2:8')
    with pytest.raises(OSError): PortalSync(Client(),box,status_writer=fail).pull_changes()
    assert box.get_state('pull_cursor')=='v2:8'


def test_recovered_checkpoint_keeps_original_time():
    saved={'portal_meta':{'analysis_processed_at':1234567890000000}}
    assert pod_processed_at(saved,False)==1234567890000000
    assert pod_processed_at({'pod_review_date':'2026-10-01 10:00:00'},False)<pod_processed_at({})
    assert pod_processed_at({},False) is None
