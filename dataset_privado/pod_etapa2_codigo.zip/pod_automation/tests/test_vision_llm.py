from processing import vision_llm


def _fake(responses, calls, unloads, monkeypatch):
    def gen(body, timeout):
        calls.append("format" in body)
        return responses.pop(0)
    monkeypatch.setattr(vision_llm, "_generate", gen)
    monkeypatch.setattr(vision_llm, "_unload_model", lambda m: unloads.append(m))
    monkeypatch.setattr(vision_llm.time, "sleep", lambda s: None)


def test_fallo_de_gramatica_reintenta_sin_format_y_sin_recargar(monkeypatch):
    calls, unloads = [], []
    _fake(["", 'Here: ```json\n{"numbers": ["3229"], "photo_type": "door"}\n```'], calls, unloads, monkeypatch)
    data, _ = vision_llm._ask_json({"model": "m", "format": "json"}, 5)
    assert data == {"numbers": ["3229"], "photo_type": "door"}
    assert calls == [True, False]
    assert unloads == []


def test_recarga_solo_si_tambien_falla_sin_gramatica(monkeypatch):
    calls, unloads = [], []
    _fake(["", "", '{"person_receiving": true}'], calls, unloads, monkeypatch)
    data, _ = vision_llm._ask_json({"model": "m", "format": "json"}, 5, attempts=3)
    assert data == {"person_receiving": True}
    assert unloads == ["m"]


def test_primer_intento_bueno_no_reintenta(monkeypatch):
    calls, unloads = [], []
    _fake(['{"numbers": [], "photo_type": "label"}'], calls, unloads, monkeypatch)
    data, _ = vision_llm._ask_json({"model": "m", "format": "json"}, 5)
    assert data["photo_type"] == "label" and calls == [True] and unloads == []


def test_generate_deja_el_modelo_cargado_y_contexto_chico(monkeypatch):
    sent = []
    monkeypatch.setattr(vision_llm, "_post_generate", lambda body, timeout: sent.append(body) or "{}")
    vision_llm.reset_stats()
    vision_llm._generate({"model": "m", "options": {"temperature": 0}}, 5)
    assert sent[0]["keep_alive"] == -1
    assert sent[0]["options"] == {"temperature": 0, "num_ctx": vision_llm.config.VISION_NUM_CTX}
    assert vision_llm.STATS["llamadas_vision"] == 1


def test_formato_de_tiempos_por_etapa():
    from processing.pipeline import format_stages
    line = format_stages("GF1", 30.0, {"ocr": 1.2, "vision": 20.0, "confirmacion": 5.0, "entrega_mano": 3.8,
                                       "llamadas_vision": 4, "segundos_vision": 24.5, "sin_gramatica": 1,
                                       "recargas": 0})
    assert line == ("Tiempos GF1: total 30.0s | ocr 1.2s | vision 20.0s | confirmacion 5.0s | entrega_mano 3.8s"
                    " | 4 llamadas a visión (24.5s) | 1 reintentos sin gramática")
