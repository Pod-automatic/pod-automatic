"""
Paso 3: campos nuevos del albarán (firmante, facturación, dirección de recibo, roles de foto,
score de riesgo, prioridad, resultados de chequeos) en to_dict(), from_dict() y SQLite.
"""

import json
import sqlite3

from models.pod import PODRecord, ImageQualityMetrics, PhotoRole, PriorityEnum
from storage.checkpoint_manager import CheckpointManager


def _full_pod(tracking="GF1001", risk=72.5, priority=PriorityEnum.ALTA):
    return PODRecord(
        tracking_number=tracking,
        station="DFW02",
        address="1234 Elm St APT 5B, Dallas, TX 75201",
        receipt_address="1234 Elm St Apt 5B, Dallas, TX 75201",
        signed_by="J. Smith",
        billing_type="Residential",
        photo_paths=["a.jpg", "b.jpg"],
        photo_roles={PhotoRole.DOOR_UNIT.value: "a.jpg", PhotoRole.LABEL.value: "b.jpg"},
        image_metrics=[ImageQualityMetrics(file_path="a.jpg", width=640, height=480, blur_score=150.0)],
        risk_score=risk,
        priority=priority,
        check_results=[{"check": "address_ocr", "score": 90.0, "weight": 3.0, "explanation": "Número 1243 != 1234"}],
    )


def test_to_dict_includes_all_new_fields():
    d = _full_pod().to_dict()
    assert d["signed_by"] == "J. Smith"
    assert d["billing_type"] == "Residential"
    assert d["receipt_address"] == "1234 Elm St Apt 5B, Dallas, TX 75201"
    assert d["photo_roles"] == {"door_unit": "a.jpg", "label": "b.jpg"}
    assert d["risk_score"] == 72.5
    assert d["priority"] == "Alta"  # Enum serializado como texto
    assert d["check_results"][0]["check"] == "address_ocr"
    assert d["image_metrics"][0]["file_path"] == "a.jpg"
    assert d["image_metrics"][0]["blur_score"] == 150.0
    json.dumps(d)  # Todo el dict debe ser serializable a JSON


def test_to_dict_from_dict_roundtrip():
    original = _full_pod()
    restored = PODRecord.from_dict(json.loads(json.dumps(original.to_dict())))
    assert restored.to_dict() == original.to_dict()
    assert isinstance(restored.image_metrics[0], ImageQualityMetrics)


def test_new_fields_default_values_and_expected_address():
    pod = PODRecord(tracking_number="X1", address="500 Main St, Fort Worth, TX")
    d = pod.to_dict()
    assert d["signed_by"] is None and d["billing_type"] is None and d["receipt_address"] is None
    assert d["photo_roles"] == {} and d["check_results"] == [] and d["image_metrics"] == []
    assert d["risk_score"] is None and d["priority"] is None
    assert pod.expected_address == "500 Main St, Fort Worth, TX"
    pod.receipt_address = "501 Main St, Fort Worth, TX"
    assert pod.expected_address == "501 Main St, Fort Worth, TX"


def test_checkpoint_persists_risk_columns_and_review_queue_order(tmp_path):
    ckpt = CheckpointManager(db_path=tmp_path / "c.db")
    sid = ckpt.create_session("2026-09-29")
    ckpt.save_pod_checkpoint(sid, _full_pod("LOW", 10.0, PriorityEnum.BAJA))
    ckpt.save_pod_checkpoint(sid, _full_pod("HIGH", 88.0, PriorityEnum.ALTA))
    ckpt.save_pod_checkpoint(sid, _full_pod("MID", 45.0, PriorityEnum.MEDIA))
    ckpt.save_pod_checkpoint(sid, _full_pod("NONE", None, None))

    queue = ckpt.get_review_queue(sid)
    assert [p.tracking_number for p in queue] == ["HIGH", "MID", "LOW", "NONE"]
    assert queue[0].signed_by == "J. Smith" and queue[0].priority == "Alta"

    with sqlite3.connect(tmp_path / "c.db") as conn:
        row = conn.execute("SELECT risk_score, priority FROM pod_checkpoints WHERE tracking_number='MID'").fetchone()
    assert row == (45.0, "Media")


def test_existing_db_without_risk_columns_is_migrated(tmp_path):
    db = tmp_path / "old.db"
    with sqlite3.connect(db) as conn:
        conn.execute("""CREATE TABLE pod_checkpoints (
            session_id TEXT NOT NULL, tracking_number TEXT NOT NULL, query_date TEXT NOT NULL,
            stop_number TEXT, driver_name TEXT, processing_status TEXT, validation_result TEXT,
            confidence_score REAL, payload_json TEXT NOT NULL, created_at TEXT NOT NULL,
            PRIMARY KEY (session_id, tracking_number))""")
    CheckpointManager(db_path=db)
    with sqlite3.connect(db) as conn:
        cols = {r[1] for r in conn.execute("PRAGMA table_info(pod_checkpoints)")}
    assert {"risk_score", "priority"} <= cols
