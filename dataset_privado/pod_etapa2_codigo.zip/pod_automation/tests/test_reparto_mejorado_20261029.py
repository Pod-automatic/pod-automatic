"""29/10: reparto mejorado entre corridas (PC, Kaggle Luis, Kaggle Tracking).

- Cada corrida empieza en otro punto de cada ruta (ROUTE_START_FRACTION).
- Varios candidatos por pedido: el portal concede los primeros libres y avisa cuales tiene o hizo otra corrida.
- Lista de lo revisado hoy por todas las corridas: se salta sin pedirlo.
- Reparto por repartidor (apagado por defecto): una ruta la lista una sola corrida.
"""
import pytest

import config
from automation.api_extractor import ApiPODExtractor, WaybillSummary
from automation.work_claims import LeaseCoordinator
from export.portal_sync import PortalError, claim_some
from tests.test_api_extractor import FakeAPI, _fake_downloader


class Routes(FakeAPI):
    """Dos rutas de 10 albaranes con POD."""
    def list_couriers(self, station_id, date_iso):
        return [{"driverName": "Driver A", "userId": 1, "podPieces": 10},
                {"driverName": "Driver B", "userId": 2, "podPieces": 10}]

    def iter_waybills(self, station_id, date_iso, courier, page_size=50):
        n = courier["userId"]
        for i in range(1, 11):
            yield WaybillSummary(waybill_no=f"GF{n}{i:02d}", sign_id=f"s{n}{i:02d}", driver_name=courier["driverName"])


@pytest.fixture(autouse=True)
def setup(monkeypatch):
    monkeypatch.setattr(config, 'GOFO_SESSION_GROUP', '')
    monkeypatch.setattr(config, 'CITY_DISPATCH_DB', '')
    monkeypatch.setattr(config, 'ROUTES_PER_BLOCK', 1)
    monkeypatch.setattr(config, 'ROUTE_LIST_CACHE_S', 0)
    monkeypatch.setattr(config, 'CLAIM_BATCH_SIZE', 5)
    monkeypatch.setattr(config, 'MAX_PER_DRIVER_PER_PASS', 30)
    monkeypatch.setattr(config, 'ROUTE_START_FRACTION', 0.0)
    monkeypatch.setattr(config, 'EXTRACT_PREFETCH', 0)


def run(tmp_path, **attrs):
    ext = ApiPODExtractor(Routes(), images_dir=tmp_path, downloader=_fake_downloader)
    ext.prefetch = 0
    done = []
    ext._process = lambda courier, w, d: (done.append(w.waybill_no), ext.build_record(courier, w, d))[1]
    for k, v in attrs.items():
        setattr(ext, k, v)
    ext.run_pass([1888], '2026-10-29', set(), lambda p: None)
    return done, ext


def test_cada_corrida_empieza_en_otro_punto_de_la_ruta(tmp_path, monkeypatch):
    monkeypatch.setattr(config, 'ROUTE_START_FRACTION', 0.67)
    done, _ = run(tmp_path, claim_fn=lambda t, d: list(t))
    assert done[:4] == ['GF107', 'GF108', 'GF109', 'GF110'] and done[4] == 'GF101'
    assert sorted(done) == sorted(f'GF{n}{i:02d}' for n in (1, 2) for i in range(1, 11))   # nada se pierde


def test_varios_candidatos_en_un_pedido_y_lo_ajeno_sale_de_la_ruta(tmp_path):
    calls = []
    other = {f'GF1{i:02d}' for i in range(1, 9)}     # las 8 primeras de A las tiene/hizo otra corrida

    def some(cands, done, n):
        calls.append((list(cands), n))
        free = [t for t in cands if t not in other]
        return free[:n], [t for t in cands if t in other]

    done, ext = run(tmp_path, claim_fn=lambda t, d: list(t), claim_some_fn=some)
    assert len(calls[0][0]) == 10 and calls[0][1] == 5          # toda la ruta como candidatos, 5 a la vez
    assert [t for t in done if t.startswith('GF1')] == ['GF109', 'GF110']
    assert ext._taken['1'] == other                             # cuentan como vistos para elegir repartidor
    assert not any(t in other for c, _ in calls[1:] for t in c)  # no se vuelven a pedir


def test_portal_caido_usa_el_pedido_anterior(tmp_path):
    def some(cands, done, n):
        raise PortalError('sin conexión con el portal')
    done, _ = run(tmp_path, claim_fn=lambda t, d: list(t), claim_some_fn=some)
    assert len(done) == 20


def test_lo_revisado_hoy_por_otra_corrida_no_se_pide(tmp_path):
    asked = []
    elsewhere = {f'GF2{i:02d}' for i in range(1, 11)}
    done, ext = run(tmp_path, claim_fn=lambda t, d: (asked.extend(t), list(t))[1], done_elsewhere=elsewhere)
    assert not any(t.startswith('GF2') for t in done + asked)
    assert ext._taken['2'] == elsewhere


class Client:
    def __init__(self, answers):
        self.answers = answers; self.calls = []

    def call(self, path, body):
        self.calls.append((path, body))
        answer = self.answers[path]
        if isinstance(answer, Exception):
            raise answer
        return answer(body) if callable(answer) else answer


def test_portal_anterior_sin_lista_de_hechos_sigue_como_antes(tmp_path):
    client = Client({'claims_done.php': PortalError('HTTP 404: Not Found')})
    coord = LeaseCoordinator(client, 'gpu_tracking', '2026-10-29', 600, tmp_path / 'c.db')
    assert coord.done_set() is None and coord.v2 is False
    assert coord.done_set() is None and len(client.calls) == 1   # no se insiste en cada pasada


def test_lista_de_hechos_por_paginas_y_en_cache(tmp_path, monkeypatch):
    pages = {'': {'trackings': ['GF1', 'GF2'], 'more': True}, 'GF2': {'trackings': ['GF3'], 'more': False}}
    client = Client({'claims_done.php': lambda body: pages[body['after']]})
    coord = LeaseCoordinator(client, 'gpu_tracking', '2026-10-29', 600, tmp_path / 'c.db')
    assert coord.done_set() == {'GF1', 'GF2', 'GF3'} and coord.v2
    coord.done_set()
    assert len(client.calls) == 2                                  # en cache CLAIMS_DONE_REFRESH_S


def test_claim_some_exige_el_portal_nuevo():
    with pytest.raises(PortalError):
        claim_some(Client({'claim.php': {'ok': True, 'granted': ['GF1']}}), 'pc', '2026-10-29', ['GF1'], [], 5)
    client = Client({'claim.php': {'ok': True, 'granted': ['GF2'], 'taken': ['GF1']}})
    assert claim_some(client, 'pc', '2026-10-29', ['GF1', 'GF2', 'GF3'], [], 1) == (['GF2'], ['GF1'])
    assert client.calls[0][1]['max'] == 1


def test_reparto_por_repartidor_salta_las_rutas_de_otra_corrida(tmp_path):
    released = []

    def routes(station, drivers, n):
        assert station == 'DFW02-BAA'
        held = [d for d in drivers if d == '1']
        return [d for d in drivers if d not in held][:n], held

    done, ext = run(tmp_path, claim_fn=lambda t, d: list(t), route_claim_fn=routes,
                    route_release_fn=lambda station, driver: released.append(driver))
    assert done and all(t.startswith('GF2') for t in done)        # la ruta de A la tiene otra corrida: ni se lista
    assert '1' in ext._states['route_held'] and released == ['2']  # B terminada: se suelta enseguida


def test_reparto_por_repartidor_apagado_por_defecto():
    from pathlib import Path
    assert 'os.getenv("ROUTE_CLAIMS", "0")' in Path(config.__file__).read_text(encoding='utf-8')
