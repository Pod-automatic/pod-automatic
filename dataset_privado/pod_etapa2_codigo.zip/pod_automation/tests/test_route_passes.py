"""
Rutas a medio terminar: la clave de "ya procesado" es el tracking, las paradas llegan fuera de
orden, cada pasada revisa solo la diferencia, y un cambio de estado posterior se vuelve a revisar.
Usa el extractor y la base de checkpoints reales, con la misma conexión que main.api_pass.
"""

from pathlib import Path

import pytest

from automation.api_extractor import ApiPODExtractor
from automation.portal_api import WaybillSummary
from storage.checkpoint_manager import CheckpointManager

DELIVERED = ("5", "208")   # (orderStatus, waybillDeliveryStatus) observados en el portal para entregado
ANULADO = ("9", "299")     # Estado ficticio de anulación para el test


class RouteAPI:
    """Portal simulado con una ruta de 5 paradas cuyos estados cambian entre pasadas."""

    def __init__(self):
        # Paradas con números reales de distinto formato y en orden arbitrario
        self.route = {
            "GF-A": {"stop": "1064", "status": None},
            "GF-B": {"stop": "STOP-S9", "status": None},
            "GF-C": {"stop": "1021", "status": None},
            "GF-D": {"stop": "1067", "status": None},
            "GF-E": {"stop": "1030", "status": None},
        }
        self.sign_calls = []

    def deliver(self, trk):
        self.route[trk]["status"] = DELIVERED

    def set_status(self, trk, status, keep_pod=True):
        self.route[trk]["status"] = status
        self.route[trk]["keep_pod"] = keep_pod

    def list_couriers(self, station_id, date_iso):
        return [{"driverName": "Driver Uno", "userId": 447984, "checkOutPieces": 5}]

    def iter_waybills(self, station_id, date_iso, courier, page_size=50):
        # El portal no garantiza orden: se devuelven en orden "mezclado"
        for trk in ["GF-D", "GF-A", "GF-E", "GF-B", "GF-C"]:
            info = self.route[trk]
            st = info["status"]
            has_pod = st is not None and (st == DELIVERED or info.get("keep_pod", False))
            yield WaybillSummary(
                waybill_no=trk, sign_id=f"sign-{trk}" if has_pod else None, driver_name=courier["driverName"],
                stop_index=info["stop"], order_status=(st or ("1", "100"))[0],
                delivery_status_code=(st or ("1", "100"))[1],
            )

    def get_sign_info(self, sign_id):
        self.sign_calls.append(sign_id)
        return {"courierName": "Driver Uno", "delivery": "DFW02-BAA", "signTypeName": "En la puerta/Patio",
                "toAddress": "ALLEN ALLEN 1530 Broadmoor Dr", "imageList": []}


def run_pass(ext, ckpt, sid, processed_log):
    """Misma conexión que main.api_pass (mapa de estados + callbacks)."""
    def on_record(pod):
        pod.risk_score, pod.priority = 0.0, "Baja"   # score simulado (el OCR se prueba aparte)
        ckpt.save_pod_checkpoint(sid, pod)
        processed_log.append(pod.tracking_number)

    status_map = ckpt.get_status_map(sid)
    return ext.run_pass(
        [1888], "2026-09-30", status_map, on_record,
        on_status_change=lambda trk, old, new: ckpt.mark_status_change(sid, trk, old, new),
        on_route=lambda st, courier, stats: ckpt.save_route_snapshot(sid, st, courier, stats),
    )


@pytest.fixture
def env(tmp_path):
    api = RouteAPI()
    ckpt = CheckpointManager(db_path=tmp_path / "c.db")
    sid = ckpt.create_session("2026-09-30")
    ext = ApiPODExtractor(api, images_dir=Path(tmp_path), downloader=lambda urls, d: [])
    return api, ckpt, sid, ext


def test_second_pass_processes_only_the_two_new_stops(env):
    api, ckpt, sid, ext = env

    # Pasada 1: el conductor entregó 3 de 5, fuera de orden (1067, 1021, STOP-S9)
    for trk in ("GF-D", "GF-C", "GF-B"):
        api.deliver(trk)
    log1 = []
    assert run_pass(ext, ckpt, sid, log1) == 3
    assert sorted(log1) == ["GF-B", "GF-C", "GF-D"]

    # Pasada 2: terminó la ruta (las 5 entregadas)
    api.deliver("GF-A")
    api.deliver("GF-E")
    api.sign_calls.clear()
    log2 = []
    assert run_pass(ext, ckpt, sid, log2) == 2
    assert sorted(log2) == ["GF-A", "GF-E"]                        # Solo las 2 nuevas
    assert sorted(api.sign_calls) == ["sign-GF-A", "sign-GF-E"]    # Ni una llamada extra al portal

    # Las paradas quedan guardadas como dato (no como clave)
    stops = {p.tracking_number: p.stop_number for p in ckpt.load_session_pods(sid)}
    assert stops == {"GF-A": "1064", "GF-B": "STOP-S9", "GF-C": "1021", "GF-D": "1067", "GF-E": "1030"}

    # Pasada 3 sin cambios: nada que procesar
    assert run_pass(ext, ckpt, sid, []) == 0


def test_route_is_not_closed_while_driver_is_still_delivering(env):
    api, ckpt, sid, ext = env
    api.deliver("GF-A")
    run_pass(ext, ckpt, sid, [])
    prog = ckpt.get_route_progress(sid)[0]
    assert (prog["reviewed"], prog["delivered_in_portal"], prog["assigned_in_portal"]) == (1, 1, 5)
    assert ckpt.get_latest_incomplete_session("2026-09-30")["session_id"] == sid  # Sigue abierta

    for trk in ("GF-B", "GF-C", "GF-D"):
        api.deliver(trk)
    run_pass(ext, ckpt, sid, [])
    prog = ckpt.get_route_progress(sid)[0]
    assert (prog["reviewed"], prog["delivered_in_portal"]) == (4, 4)   # "revisadas 4 de 4 entregadas (5 asignadas)"


def test_status_change_after_review_is_flagged_for_recheck(env):
    api, ckpt, sid, ext = env
    for trk in ("GF-A", "GF-B"):
        api.deliver(trk)
    run_pass(ext, ckpt, sid, [])

    # Después de revisado, GF-A pasa a "Anulado" y pierde el POD
    api.set_status("GF-A", ANULADO, keep_pod=False)
    api.sign_calls.clear()
    log = []
    run_pass(ext, ckpt, sid, log)
    assert log == [] and api.sign_calls == []          # Sin POD: se marca, no se re-extrae

    pod = {p.tracking_number: p for p in ckpt.load_session_pods(sid)}["GF-A"]
    assert pod.portal_meta["status_change"]["to"].startswith("9|299")
    assert pod.priority == "Alta" and pod.risk_score == 100      # Se toma como error
    assert next(c for c in pod.check_results if c["check"] == "cambio_estado")["force_report"]
    assert any(c["check"] == "cambio_estado" for c in pod.check_results)
    assert ckpt.get_route_progress(sid)[0]["needs_recheck"] == 1
    assert {p.tracking_number for p in ckpt.get_review_queue(sid)[:1]} == {"GF-A"}  # Primero en la cola

    # Si en otra pasada vuelve a cambiar pero CON POD nuevo (POD rehecho): se re-extrae y se re-puntúa
    api.set_status("GF-A", ("5", "209"), keep_pod=True)
    log = []
    run_pass(ext, ckpt, sid, log)
    assert log == ["GF-A"] and api.sign_calls == ["sign-GF-A"]


def test_old_rows_without_status_are_not_reprocessed(env):
    """Filas guardadas antes de existir la firma de estado: se respetan como ya procesadas."""
    api, ckpt, sid, ext = env
    from models.pod import PODRecord
    ckpt.save_pod_checkpoint(sid, PODRecord(tracking_number="GF-A"))  # sin portal_status
    api.deliver("GF-A")
    log = []
    run_pass(ext, ckpt, sid, log)
    assert log == []
