"""
Paso 2: sesión persistente. Un servidor HTTP local simula el portal: responde el dashboard
si llega la cookie 'sid=good' y redirige a /login en caso contrario.
"""

import json
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

import pytest

from automation.browser import BrowserManager, SessionExpiredError, session_file_has_cookies
from automation.login import LoginManager, looks_logged_out

PORTAL_HITS = []


class FakePortal(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_GET(self):
        cookie = self.headers.get("Cookie", "")
        PORTAL_HITS.append((self.path, cookie))
        if self.path.startswith("/login"):
            self._send(200, "<html><body>Login page</body></html>")
        elif "sid=good" in cookie:
            self._send(200, "<html><body><div id='dsp-dashboard'>Dashboard</div></body></html>")
        else:
            self.send_response(302)
            self.send_header("Location", "/login")
            self.end_headers()

    def _send(self, code, body):
        self.send_response(code)
        self.send_header("Content-Type", "text/html")
        self.end_headers()
        self.wfile.write(body.encode())


@pytest.fixture
def portal():
    PORTAL_HITS.clear()
    server = HTTPServer(("127.0.0.1", 0), FakePortal)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    yield f"http://127.0.0.1:{server.server_port}/dashboard"
    server.shutdown()


def _write_state(path, cookie_value):
    path.write_text(json.dumps({
        "cookies": [{
            "name": "sid", "value": cookie_value, "domain": "127.0.0.1", "path": "/",
            "expires": -1, "httpOnly": False, "secure": False, "sameSite": "Lax",
        }],
        "origins": [],
    }), encoding="utf-8")


def test_looks_logged_out_url_rules():
    portal_url = "https://dms.gofoexpress.com/gofo-report/report/reportCenter/siteDashboardUs"
    assert looks_logged_out("https://accounts.google.com/o/oauth2/auth", portal_url)
    assert looks_logged_out("https://dms.gofoexpress.com/login?redirect=x", portal_url)
    assert looks_logged_out("about:blank", portal_url)
    assert looks_logged_out("https://otro-sitio.com/dashboard", portal_url)
    assert not looks_logged_out(portal_url, portal_url)


def test_session_file_has_cookies(tmp_path):
    missing = tmp_path / "nope.json"
    empty = tmp_path / "empty.json"
    empty.write_text('{"cookies": [], "origins": []}')
    ok = tmp_path / "ok.json"
    _write_state(ok, "good")
    assert not session_file_has_cookies(missing)
    assert not session_file_has_cookies(empty)
    assert session_file_has_cookies(ok)


def test_start_without_saved_session_stops_with_clear_message(tmp_path, monkeypatch):
    monkeypatch.setattr("automation.browser.SESSION_FILE", tmp_path / "missing.json")
    bm = BrowserManager(headless=True)
    with pytest.raises(SessionExpiredError, match="main.py login"):
        bm.start()
    assert bm.page is None


def test_headless_run_reuses_saved_session_without_cdp(tmp_path, monkeypatch, portal):
    state = tmp_path / "session.json"
    _write_state(state, "good")
    monkeypatch.setattr("automation.browser.SESSION_FILE", state)

    bm = BrowserManager(headless=True)
    try:
        bm.start()
        LoginManager(bm).require_valid_session(portal)
        assert bm.session_valid is True
        assert "Dashboard" in bm.page.content()
        assert any("sid=good" in cookie for _, cookie in PORTAL_HITS)
    finally:
        bm.close()


def test_expired_session_stops_and_never_logs_in(tmp_path, monkeypatch, portal):
    state = tmp_path / "session.json"
    _write_state(state, "expired")
    monkeypatch.setattr("automation.browser.SESSION_FILE", state)
    before = state.read_text(encoding="utf-8")

    bm = BrowserManager(headless=True)
    try:
        bm.start()
        with pytest.raises(SessionExpiredError, match="main.py login"):
            LoginManager(bm).require_valid_session(portal)
        assert bm.session_valid is False
    finally:
        bm.close()

    # La sesión vencida no debe sobrescribir el archivo guardado
    assert state.read_text(encoding="utf-8") == before


def test_find_profile_dir_for_email(tmp_path):
    from automation.login import find_profile_dir_for_email
    (tmp_path / "Local State").write_text(json.dumps({"profile": {"info_cache": {
        "Default": {"user_name": "Luis@Gmail.com"},
        "Profile 3": {"user_name": "otra@gmail.com"},
    }}}), encoding="utf-8")
    assert find_profile_dir_for_email(tmp_path, "luis@gmail.com") == "Default"
    assert find_profile_dir_for_email(tmp_path, "otra@gmail.com") == "Profile 3"
    assert find_profile_dir_for_email(tmp_path, "nadie@gmail.com") is None
    assert find_profile_dir_for_email(tmp_path / "no-existe", "x@y.com") is None


def test_copy_profile_essentials_excludes_passwords_and_cache(tmp_path):
    from automation.login import copy_profile_essentials
    src, dest = tmp_path / "src", tmp_path / "dest"
    prof = src / "Default"
    (prof / "Network").mkdir(parents=True)
    (prof / "Network" / "Cookies").write_text("cookies")
    (prof / "Local Storage").mkdir()
    (prof / "Local Storage" / "a").write_text("ls")
    (prof / "Preferences").write_text("{}")
    (prof / "Login Data").write_text("SECRET")
    (prof / "Cache").mkdir()
    (prof / "Cache" / "big").write_text("x")
    (src / "Local State").write_text("{}")

    # Restos de una copia anterior que referencian extensiones inexistentes
    (dest / "Default").mkdir(parents=True)
    (dest / "Default" / "Secure Preferences").write_text("{}")

    copy_profile_essentials(src, "Default", dest)
    assert not (dest / "Default" / "Secure Preferences").exists()

    assert (dest / "Local State").exists()
    assert (dest / "Default" / "Network" / "Cookies").read_text() == "cookies"
    assert (dest / "Default" / "Local Storage" / "a").exists()
    assert not (dest / "Default" / "Preferences").exists()
    assert not (dest / "Default" / "Login Data").exists()
    assert not (dest / "Default" / "Cache").exists()
