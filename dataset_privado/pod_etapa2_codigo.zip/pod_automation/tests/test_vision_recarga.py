import socket
import urllib.error

import pytest

from processing import vision_llm


def test_dos_consultas_cortadas_seguidas_recargan_el_modelo(monkeypatch):
    descargas = []
    monkeypatch.setattr(vision_llm, "_unload_model", lambda m: descargas.append(m))
    monkeypatch.setattr(vision_llm.urllib.request, "urlopen", lambda req, timeout: (_ for _ in ()).throw(socket.timeout("timed out")))
    vision_llm._TIMEOUTS["seguidos"] = 0
    for _ in range(2):
        with pytest.raises(socket.timeout):
            vision_llm._post_generate({"model": "qwen2.5vl:3b"}, 1)
    assert descargas == ["qwen2.5vl:3b"]


def test_otro_error_de_red_no_recarga(monkeypatch):
    descargas = []
    monkeypatch.setattr(vision_llm, "_unload_model", lambda m: descargas.append(m))
    monkeypatch.setattr(vision_llm.urllib.request, "urlopen",
                        lambda req, timeout: (_ for _ in ()).throw(urllib.error.URLError(ConnectionRefusedError())))
    vision_llm._TIMEOUTS["seguidos"] = 0
    for _ in range(3):
        with pytest.raises(urllib.error.URLError):
            vision_llm._post_generate({"model": "m"}, 1)
    assert descargas == []
