"""
Pruebas Unitarias Integrales para las Fases 6 a 13.

Verifica:
1. Fase 6: Detección de duplicados (Exact Duplicate, Possible Visual Duplicate, Unique, registro de fotos comparadas).
2. Fase 7: Logging profesional en storage/logs/ y sanitización estricta de credenciales.
3. Fase 8: Persistencia atómica de checkpoints en SQLite (storage/pod_checkpoints.db) y reanudación de lotes.
4. Fase 9: Parámetros centralizados de configuración y modo READ-ONLY.
5. Fase 10: Interfaz CLI y renderizado de tarjeta en tiempo real por POD.
6. Fase 11: Capa de selectores con placeholders configurables (SELECTORS).
7. Fase 12: Generación de informe resumen de inspección sin acciones destructivas.
8. Fase 13: Política de seguridad y sólo lectura (READ_ONLY_MODE = True).
"""

from pathlib import Path
import json
import sqlite3
import pytest
from datetime import datetime
from PIL import Image

import config
from models.pod import PODRecord, DuplicateStatusEnum, ProcessingStatusEnum
from processing.duplicate_detection import DuplicateImageDetector, DuplicateCheckResult
from automation.audit_logger import AuditLogger, sanitize_message
from storage.checkpoint_manager import CheckpointManager
from automation.selectors import (
    SELECTORS,
    get_selector,
    is_selector_configured,
    get_unconfigured_selectors,
    validate_configured_selectors,
)
from automation.inspector import PlatformInspector
from main import display_live_pod_card, parse_cli_args


def test_phase6_duplicate_detection_taxonomies(tmp_path):
    """Fase 6: Clasificación estricta (Exact Duplicate, Possible Visual Duplicate, Unique) y registro de comparaciones."""
    detector = DuplicateImageDetector(max_hamming_distance=4)

    # 1. Registrar primera imagen legítima
    res1 = detector.register_and_check(
        tracking="TRK-100",
        driver="Driver A",
        file_path="/photos/photo1.jpg",
        dhash="0000ffff0000ffff",
        sha256="sha256_original_hash",
        phash="1111222233334444",
    )
    assert res1.classification == DuplicateStatusEnum.UNIQUE.value
    assert res1.is_duplicate is False

    # 2. Misma imagen para otro albarán (Exact Duplicate por SHA-256)
    res_exact = detector.register_and_check(
        tracking="TRK-200",
        driver="Driver B",
        file_path="/photos/photo2.jpg",
        dhash="0000ffff0000ffff",
        sha256="sha256_original_hash",
        phash="1111222233334444",
    )
    assert res_exact.classification == DuplicateStatusEnum.EXACT_DUPLICATE.value
    assert res_exact.is_duplicate is True
    assert res_exact.matched_tracking == "TRK-100"
    # Verificar que guardó información de la comparación
    assert len(res_exact.comparisons_log) == 1
    assert res_exact.comparisons_log[0]["compared_tracking"] == "TRK-100"

    # 3. Imagen perceptual similar (2 bits cambiados en dHash) -> Possible Visual Duplicate
    res_visual = detector.register_and_check(
        tracking="TRK-300",
        driver="Driver C",
        file_path="/photos/photo3.jpg",
        dhash="0000ffff0000fffc",  # 2 bits de distancia
        sha256="different_sha",
        phash="1111222233334444",
    )
    assert res_visual.classification in (DuplicateStatusEnum.EXACT_DUPLICATE.value, DuplicateStatusEnum.POSSIBLE_VISUAL_DUPLICATE.value)
    assert res_visual.is_duplicate is True
    assert len(res_visual.comparisons_log) >= 1

    # 4. Desempaquetado como tupla (is_dup, reason)
    is_dup, reason = res_visual
    assert is_dup is True
    assert reason is not None


def test_phase7_audit_logger_and_sanitization(tmp_path):
    """Fase 7: Creación de logs estructurados y sanitización de credenciales."""
    test_log = tmp_path / "test_audit.log"
    logger = AuditLogger(session_id="test_session", log_filename=str(test_log))

    logger.start_pod(1, 10, "TRK-999")
    logger.log_retry(1, "TRK-999", 1, 3, "Timeout esperando modal")
    logger.end_pod(1, 10, "TRK-999", 2, "PROCESSED", "VALID", "Conforme")

    # Sanitización de credenciales
    secret_text = "Usuario logueado con password='MiSuperPassword123' y token='xyz-token-abc'"
    sanitized = sanitize_message(secret_text)
    assert "MiSuperPassword123" not in sanitized
    assert "PROTECTED_CREDENTIAL" in sanitized

    # Verificar que el log existe y tiene contenido
    assert test_log.exists()
    content = test_log.read_text(encoding="utf-8")
    assert "TRK-999" in content
    assert "REINTENTO" in content


def test_phase8_sqlite_checkpoint_and_resumption(tmp_path):
    """Fase 8: Persistencia atómica de checkpoints y reanudación sin duplicados."""
    db_file = tmp_path / "checkpoints_test.db"
    manager = CheckpointManager(db_path=db_file)

    session_id = manager.create_session("2026-09-12", total_detected=1000)
    assert session_id.startswith("session_")

    # Guardar primer lote de 2 PODs
    pod1 = PODRecord(tracking_number="TRK-001", stop_number="1", driver_name="Driver 1")
    pod2 = PODRecord(tracking_number="TRK-002", stop_number="2", driver_name="Driver 2")

    manager.save_pod_checkpoint(session_id, pod1)
    manager.save_pod_checkpoint(session_id, pod2)

    # Verificar sesión incompleta
    active_session = manager.get_latest_incomplete_session("2026-09-12")
    assert active_session is not None
    assert active_session["total_processed"] == 2
    assert active_session["last_processed_tracking"] == "TRK-002"

    # Verificar que trackings procesados se reconocen para evitar duplicados
    processed_set = manager.get_processed_trackings(session_id)
    assert "TRK-001" in processed_set
    assert "TRK-002" in processed_set
    assert "TRK-003" not in processed_set

    # Reanudar y cargar PODs previos
    loaded = manager.load_session_pods(session_id)
    assert len(loaded) == 2
    assert loaded[0].tracking_number == "TRK-001"

    # Marcar completada
    manager.mark_session_completed(session_id)
    assert manager.get_latest_incomplete_session("2026-09-12") is None


def test_phase9_and_13_configuration_and_readonly_policy():
    """Fases 9 y 13: Validación de parámetros centralizados y modo de sólo lectura."""
    assert config.HEADLESS is False or config.HEADLESS is True
    assert isinstance(config.SLOW_MO, int)
    assert config.DEFAULT_TIMEOUT >= 10000
    assert config.MAX_RETRIES == 3
    assert config.READ_ONLY_MODE is True
    assert config.DATE_FORMAT == "MM/DD/YYYY"


def test_phase11_selectors_layer_and_placeholders():
    """Fase 11: Diccionario formal SELECTORS con placeholders y helpers de resolución."""
    required_keys = [
        "date_input",
        "search_button",
        "pod_list",
        "pod_card",
        "tracking_number",
        "pod_modal",
        "pod_images",
        "close_modal",
    ]
    for key in required_keys:
        assert key in SELECTORS

    status_dict = validate_configured_selectors()
    assert len(status_dict) == len(SELECTORS)

    # Helper de resolución segura
    resolved = get_selector("date_input", fallback_heuristic="input[type='date']")
    assert resolved == "input[type='date']" or resolved == SELECTORS["date_input"]


def test_phase12_inspection_markdown_generation(tmp_path):
    """Fase 12: Generación del informe de inspección para facilitar completar selectors.py."""
    inspector = PlatformInspector()
    sample_data = {
        "inputs": [
            {"tag": "input", "type": "date", "name": "query_date", "id": "date-picker", "placeholder": "Seleccionar fecha", "data_testid": "date-input", "aria_label": "", "class_name": ""}
        ],
        "buttons": [
            {"text": "Consulta", "id": "btn-search", "data_testid": "btn-query", "aria_label": "Consultar", "class_name": "btn-primary"}
        ],
        "tables": [],
        "modals": [],
    }
    summary_md = inspector._generate_markdown_summary(sample_data, tmp_path)
    assert "Informe de Inspección" in summary_md
    assert "[data-testid=\"date-input\"]" in summary_md
    assert "[data-testid=\"btn-query\"]" in summary_md
    assert "automation/selectors.py" in summary_md


def test_phase10_live_pod_card_rendering():
    """Fase 10: Renderizado sin errores de la tarjeta de estado en vivo."""
    pod = PODRecord(
        tracking_number="GFUS01071720782912",
        driver_name="Test Driver",
        number_of_photos=3,
        processing_status=ProcessingStatusEnum.PROCESSING,
    )
    # Debe ejecutarse sin lanzar excepciones
    display_live_pod_card(143, 8057, pod)
