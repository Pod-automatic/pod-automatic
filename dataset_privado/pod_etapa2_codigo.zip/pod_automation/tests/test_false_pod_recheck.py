"""Control de cierre del día: marca de "POD falso sospechoso" puesta por el portal después de revisado."""

from unittest.mock import MagicMock

from models.pod import PODRecord
from storage.checkpoint_manager import CheckpointManager


def test_recheck_marks_late_false_pod_flags_and_puts_them_first(tmp_path, monkeypatch):
    import main
    monkeypatch.setattr(main, "PODExcelExporter", MagicMock())
    ckpt = CheckpointManager(db_path=tmp_path / "c.db")
    sid = ckpt.create_session("2026-09-29")
    for trk, score, prio in (("OK1", 0.0, "Baja"), ("BAD", 10.0, "Baja"), ("HIGH", 80.0, "Alta")):
        ckpt.save_pod_checkpoint(sid, PODRecord(
            tracking_number=trk, risk_score=score, priority=prio,
            portal_meta={"sign_id": f"s-{trk}", "whether_reported": 2, "false_signature": 3}))

    api = MagicMock()
    api.get_sign_info.side_effect = lambda sign_id: (
        {"whetherReported": 1, "falseSignature": 4} if sign_id == "s-BAD" else {"whetherReported": 2, "falseSignature": 3})

    assert main.recheck_false_pod_flags(ckpt, sid, api) == 1
    assert api.get_sign_info.call_count == 3
    queue = ckpt.get_review_queue(sid)
    assert queue[0].tracking_number == "BAD"                   # Arriba de todo, incluso sobre el Alta previo
    assert queue[0].priority == "Alta" and queue[0].risk_score == 100
    assert queue[0].check_results[0]["check"] == "pod_falso_portal" and queue[0].check_results[0]["force_report"]

    # Una segunda pasada no vuelve a consultar los ya marcados
    api.get_sign_info.reset_mock()
    main.recheck_false_pod_flags(ckpt, sid, api)
    assert api.get_sign_info.call_count == 2
