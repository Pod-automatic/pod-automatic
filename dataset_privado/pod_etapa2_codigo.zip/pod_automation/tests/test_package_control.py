"""15/10: control de paquetes (doble escaneo, devoluciones, perdidos) con historiales reales de GOFO."""
from datetime import date, datetime

from processing import package_control as pc
from storage import package_control as store


def item(tracking, blocks):
    """Respuesta de track/private/list: bloques por día (del más nuevo al más viejo), eventos del más nuevo al más viejo."""
    return {"waybill": {"waybillNo": tracking},
            "list": [{"operationTime": day, "trackList": [
                {"order_no": tracking, "operationTime": t, "operation_move": code, "create_by_name": by,
                 "location": loc, "es_context": text} for t, code, by, loc, text in evs]} for day, evs in blocks]}


# Caso real: Pedro falla el 13/10, la estación lo recibe el 14/10 a las 07:46 y vuelve a salir el 15/10
PEDRO = item("GFUS01076272516740", [
    ("Jueves, 15/10/2026", [("08:11:20", "208", "Pedro Jose Pena Diaz", "DFW-BAA", "out for delivery"),
                            ("06:04:53", "500", "Sandra Lizeth Cruz ramos", "DFW-BAA", "Sorting Scan")]),
    ("Miércoles, 14/10/2026", [("10:28:07", "3218", "DFW01_OPS02", "DFW01", "Site Redelivery"),
                               ("07:46:36", "209", "Bryant Zhu", "DFW01", "Returned to station DFW01")]),
    ("Martes, 13/10/2026", [("10:26:36", "206", "Pedro Jose Pena Diaz", "DFW-BAA",
                             "**Delivery failed, type : Bad Address, description : -."),
                            ("07:22:53", "208", "Pedro Jose Pena Diaz", "DFW-BAA", "out for delivery"),
                            ("06:12:30", "500", "Juan Manuel Contessi Lobos", "DFW-BAA", "Sorting Scan")]),
])
# Caso real: Román lo escanea y sale; Luis Osuna lo escanea DESPUÉS de que Román salió
ROMAN = item("GFUS01077313363714", [
    ("Jueves, 15/10/2026", [("13:34:37", "205", "Román Quintero", "DFW02-BAA", "Delivered"),
                            ("07:50:40", "500", "Luis e Osuna diaz", "DFW02-BAA", "Sorting Scan"),
                            ("07:10:59", "208", "Román Quintero", "DFW02-BAA", "out for delivery"),
                            ("06:26:46", "500", "Román  Quintero", "DFW02-BAA", "Sorting Scan"),
                            ("06:04:55", "500", "Darwin J Chirinos Medina", "DFW02-BAA", "Sorting Scan")]),
])


def test_lee_el_historial_en_orden():
    t = pc.parse_track(PEDRO)
    assert t.tracking == "GFUS01076272516740"
    assert [e.code for e in t.events] == ["500", "208", "206", "209", "3218", "500", "208"]
    assert t.events[0].when == datetime(2026, 10, 13, 6, 12, 30)
    assert pc.parse_block_date("Jueves, 15/10/2026") == date(2026, 10, 15)
    assert pc.parse_block_date("10/15/2026") == date(2026, 10, 15)   # Si algún día llega como mes/día


def test_doble_escaneo():
    roman = pc.scan_checks(pc.parse_track(ROMAN), date(2026, 10, 15))
    assert len(roman) == 1
    r = roman[0]
    # Lo escaneó él, pero Luis Osuna lo escaneó después: queda a nombre de Luis (regla del último escaneo)
    assert (r["driver"], r["verdict"], r["after_by"]) == ("Román Quintero", "otro_despues", "Luis e Osuna diaz")
    assert r["scanned_by"] == "Darwin J Chirinos Medina, Luis e Osuna diaz"
    # Caso real 15/10: confirma la ruta 07:10:59 y escanea el paquete 07:15:15 mientras carga -> cumple
    cargando = pc.parse_track(item("GFUS-CARGA", [("Jueves, 15/10/2026", [
        ("13:43:43", "205", "Román Quintero", "DFW02-BAA", "Delivered"),
        ("07:15:15", "500", "Román Quintero", "DFW02-BAA", "Sorting Scan"),
        ("07:10:59", "208", "Román Quintero", "DFW02-BAA", "out"),
        ("06:49:20", "500", "Carlos Armando Urbina Saavedra", "DFW02-BAA", "Sorting Scan")])]))
    [c] = pc.scan_checks(cargando, date(2026, 10, 15))
    assert (c["verdict"], c["own_scan"]) == ("ok", "2026-10-15 07:15:15")
    # Un escaneo de otro DESPUÉS de la entrega ya no cuenta
    entregado = pc.parse_track(item("GFUS-POST", [("Jueves, 15/10/2026", [
        ("15:00:00", "500", "Otro", "DFW02-BAA", "Sorting Scan"),
        ("13:00:00", "205", "Ana", "DFW02-BAA", "Delivered"),
        ("07:00:00", "208", "Ana", "DFW02-BAA", "out"),
        ("06:00:00", "500", "Ana", "DFW02-BAA", "Sorting Scan")])]))
    assert pc.scan_checks(entregado, date(2026, 10, 15))[0]["verdict"] == "ok"
    pedro = pc.parse_track(PEDRO)
    # 13/10: solo lo escaneó Juan Manuel; Pedro salió sin escanearlo
    [p13] = pc.scan_checks(pedro, date(2026, 10, 13))
    assert (p13["verdict"], p13["scanned_by"], p13["own_scan"]) == ("otro", "Juan Manuel Contessi Lobos", None)
    [p15] = pc.scan_checks(pedro, date(2026, 10, 15))
    assert p15["verdict"] == "otro"
    assert pc.scan_checks(pedro, date(2026, 10, 14)) == []   # Ese día no salió a reparto


def test_sin_escaneo_de_clasificacion():
    t = pc.parse_track(item("X1", [("Jueves, 15/10/2026", [("05:00:00", "208", "Ana", "DFW-BAA", "out")])]))
    assert pc.scan_checks(t, date(2026, 10, 15))[0]["verdict"] == "sin_escaneo"


def test_devolucion_a_tiempo_y_vencida():
    pedro = pc.parse_track(PEDRO)
    [r] = pc.return_checks(pedro, now=datetime(2026, 10, 15, 12, 0))
    assert (r["kind"], r["driver"], r["issue"], r["outcome"]) == ("fallido", "Pedro Jose Pena Diaz", "Bad Address", "a_tiempo")
    assert r["resolved_by"] == "Bryant Zhu" and r["hours"] == 21.3
    # Mismo fallo sin escaneo de devolución
    t = pc.parse_track(item("X2", [("Martes, 13/10/2026", [
        ("10:26:36", "206", "Pedro", "DFW-BAA", "**Delivery failed, type : No Access, description : -."),
        ("07:22:53", "208", "Pedro", "DFW-BAA", "out")])]))
    # Plazo: devolver el mismo día; la estación lo escanea a la mañana siguiente (hasta las 13 h)
    [r] = pc.return_checks(t, now=datetime(2026, 10, 14, 9, 0))
    assert (r["outcome"], r["deadline"]) == ("pendiente", "2026-10-14 13:00:00")
    assert pc.return_checks(t, now=datetime(2026, 10, 14, 13, 1))[0]["outcome"] == "vencido"
    # Escaneado de devolución la tarde del día siguiente: ya pasó el plazo
    tarde = pc.parse_track(item("X2b", [("Miércoles, 14/10/2026", [("14:10:00", "209", "Staff", "DFW01", "Returned")]),
                                        ("Martes, 13/10/2026", [("10:26:36", "206", "Pedro", "DFW-BAA", "type : No Access,")])]))
    assert pc.return_checks(tarde, now=datetime(2026, 10, 15))[0]["outcome"] == "tarde"


def test_devuelto_tarde_y_retenido():
    tarde = pc.parse_track(item("X3", [
        ("Jueves, 15/10/2026", [("09:00:00", "209", "Staff", "DFW01", "Returned")]),
        ("Martes, 13/10/2026", [("10:00:00", "206", "Ana", "DFW-BAA", "type : Business Closed,")])]))
    assert pc.return_checks(tarde, now=datetime(2026, 10, 15, 10))[0]["outcome"] == "tarde"
    # Lo guardó y lo volvió a sacar al día siguiente sin pasar por la estación
    retenido = pc.parse_track(item("X4", [
        ("Miércoles, 14/10/2026", [("07:00:00", "208", "Ana", "DFW-BAA", "out"),
                                   ("06:30:00", "500", "Ana", "DFW-BAA", "Sorting Scan")]),
        ("Martes, 13/10/2026", [("10:00:00", "206", "Ana", "DFW-BAA", "type : Business Closed,")])]))
    assert pc.return_checks(retenido, now=datetime(2026, 10, 14, 12))[0]["outcome"] == "salio_sin_devolver"


def test_salida_sin_entrega_ni_fallo():
    t = pc.parse_track(item("X5", [("Martes, 13/10/2026", [("07:00:00", "208", "Ana", "DFW-BAA", "out"),
                                                           ("06:00:00", "500", "Ana", "DFW-BAA", "Sorting Scan")])]))
    assert pc.return_checks(t, now=datetime(2026, 10, 13, 22)) == []   # El día todavía no cerró
    [r] = pc.return_checks(t, now=datetime(2026, 10, 14, 8))
    assert (r["kind"], r["outcome"], r["driver"]) == ("sin_estado", "pendiente", "Ana")
    # Entregado el mismo día: nada que devolver
    ok = pc.parse_track(ROMAN)
    assert pc.return_checks(ok, now=datetime(2026, 10, 16)) == []


def test_perdido_con_ultimo_escaneo():
    t = pc.parse_track(item("X6", [
        ("Miércoles, 14/10/2026", [("11:00:00", "700", "GOFO", "DFW01", "Suspected lost at site")]),
        ("Martes, 13/10/2026", [("10:00:00", "206", "Ana", "DFW-BAA", "type : No Access,"),
                                ("07:00:00", "208", "Ana", "DFW-BAA", "out"),
                                ("06:00:00", "500", "Luis", "DFW-BAA", "Sorting Scan")])]))
    [l] = pc.lost_checks(t)
    assert (l["label"], l["last_scan_by"], l["last_scan_code"], l["last_out_by"]) == ("Sospecha de pérdida", "Ana", "206", "Ana")
    assert pc.return_checks(t, now=datetime(2026, 10, 15))[0]["outcome"] == "perdido"
    assert not pc.is_settled(t, datetime(2026, 10, 15))
    assert pc.is_settled(pc.parse_track(ROMAN), datetime(2026, 10, 15, 14))


def test_solo_nuestras_estaciones():
    # Caso real 15/10: el historial trae fallos de otros DSP (DFW02-MEL) antes de llegar a nuestra ruta
    t = pc.parse_track(item("GFUS01075080759040", [
        ("Jueves, 15/10/2026", [("07:00:00", "208", "Ana", "DFW02-BAA", "out"),
                                ("06:00:00", "500", "Ana", "DFW02-BAA", "Sorting Scan")]),
        ("Sábado, 03/10/2026", [("18:34:47", "206", "Richard Sepulveda", "DFW02-MEL", "type : No Access,"),
                                ("08:00:00", "208", "Richard Sepulveda", "DFW02-MEL", "out")])]))
    res = pc.analyze([t], [date(2026, 10, 15)], datetime(2026, 10, 15, 12), stations=["DFW02-BAA", "DFW-BAA"])
    assert res["returns"] == []
    assert [s["driver"] for s in res["scans"]] == ["Ana"]
    assert len(pc.analyze([t], [date(2026, 10, 15)], datetime(2026, 10, 15, 12))["returns"]) == 1   # Sin filtro


def test_guarda_y_lee_la_base(tmp_path):
    db = tmp_path / "control.db"
    tracks = [pc.parse_track(PEDRO), pc.parse_track(ROMAN)]
    now = datetime(2026, 10, 15, 14)
    store.save_tracks(tracks, {t.tracking: pc.is_settled(t, now) for t in tracks}, path=db)
    again = {t.tracking: t for t in store.load_tracks(["GFUS01076272516740", "GFUS01077313363714"], path=db)}
    assert [e.code for e in again["GFUS01076272516740"].events] == ["500", "208", "206", "209", "3218", "500", "208"]
    assert again["GFUS01076272516740"].events[2].text.startswith("**Delivery failed")   # El texto del fallo se guarda
    assert store.settled_trackings(path=db) == {"GFUS01077313363714"}
    res = pc.analyze(tracks, [date(2026, 10, 14), date(2026, 10, 15)], now)
    store.save_results(res, path=db)
    store.save_results(res, path=db)   # Repetir no duplica
    data = store.load("2026-10-15", path=db)
    assert sorted(s["driver"] for s in data["scans"]) == ["Pedro Jose Pena Diaz", "Román Quintero"]
    assert store.load("2026-10-13", path=db)["returns"][0]["outcome"] == "a_tiempo"


def test_la_corrida_guarda_la_ruta_completa(tmp_path):
    from automation.portal_api import WaybillSummary
    db = tmp_path / "control.db"
    ws = [WaybillSummary("A1", "sig", "Ana", delivery_status_code="205"),
          WaybillSummary("A2", None, "Ana", delivery_status_code="206")]
    store.save_route("2026-10-15", "DFW-BAA", {"userId": 7, "driverName": "Ana  Rodriguez"}, ws, path=db)
    roster = store.roster_trackings(["2026-10-15"], path=db)
    assert set(roster) == {"A1", "A2"}
    assert roster["A2"]["driver"] == "Ana Rodriguez" and roster["A2"]["status"] == "206"
