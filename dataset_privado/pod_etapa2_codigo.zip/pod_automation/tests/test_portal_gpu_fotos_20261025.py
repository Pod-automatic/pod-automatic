"""GPU con reparto (25/10): la corrida de GPU manda también las fotos originales de los Alta/Media (si GPU_SEND_PHOTOS)."""
import base64

import config
from export.portal_sync import Outbox, PortalSync
from tests.test_portal_sync import make_pod


class FakeGpuPortal:
    def __init__(self):
        self.items = []

    def call(self, path, body=None, query=None):
        if path == "analysis.php":
            return {"ok": True, "accepted": list(range(len(body["items"]))), "errors": []}
        assert path == "ingest_gpu.php"
        self.items.extend(body["items"])
        return {"ok": True, "saved": len(body["items"]), "errors": []}


def _sync(tmp_path, monkeypatch, photos):
    monkeypatch.setattr(config, "PORTAL_GPU", True)
    monkeypatch.setattr(config, "GPU_SEND_PHOTOS", photos)
    client = FakeGpuPortal()
    sync = PortalSync(client, Outbox(tmp_path / "o.db"), card_maker=lambda payload, i: b"\xff\xd8\xffCARD", pull_interval=0,
                      photo_maker=lambda path: b"\xff\xd8\xffFOTO")
    pod = make_pod()
    pods_dir = tmp_path / "fotos"
    pods_dir.mkdir()
    paths = []
    for i in range(3):
        f = pods_dir / ("p%d.jpg" % i)
        f.write_bytes(b"x")
        paths.append(str(f))
    pod.photo_paths = paths
    sync.enqueue_pod(pod, "2026-10-25")
    sync.enqueue_pod(make_pod("GFUS0000000000009", "Baja", 5), "2026-10-25")
    sync.sync_once()
    return {i["tracking"]: i for i in client.items}


def test_con_gpu_send_photos_manda_las_fotos_de_alta_y_media(tmp_path, monkeypatch):
    got = _sync(tmp_path, monkeypatch, True)
    alta = got["GFUS0000000000001"]
    assert [base64.b64decode(x) for x in alta["photos"]] == [b"\xff\xd8\xffFOTO"] * 3 and len(alta["cards"]) == 3
    assert "photos" not in got["GFUS0000000000009"] and "cards" not in got["GFUS0000000000009"]    # Baja: ni tarjetas ni fotos


def test_sin_gpu_send_photos_solo_tarjetas_como_antes(tmp_path, monkeypatch):
    got = _sync(tmp_path, monkeypatch, False)
    assert "photos" not in got["GFUS0000000000001"] and len(got["GFUS0000000000001"]["cards"]) == 3
