import sqlite3

import config
from generate_demo_dataset import generate_demo_dataset


def test_el_demo_no_escribe_en_la_base_real(tmp_path, monkeypatch):
    real = tmp_path / "real.db"
    monkeypatch.setattr(config, "STORAGE_DIR", tmp_path)
    monkeypatch.setattr(config, "CHECKPOINT_DB_PATH", real)
    monkeypatch.setattr(config, "OUTPUT_DIR", tmp_path)
    import storage.checkpoint_manager as cm
    monkeypatch.setattr(cm, "CHECKPOINT_DB_PATH", real)
    generate_demo_dataset()
    demo = tmp_path / "demo" / "pod_checkpoints_demo.db"
    assert demo.exists()
    with sqlite3.connect(demo) as c:
        assert c.execute("SELECT COUNT(*) FROM pod_checkpoints").fetchone()[0] == 8
    assert not real.exists() or sqlite3.connect(real).execute(
        "SELECT name FROM sqlite_master WHERE name='pod_checkpoints'").fetchone() is None
