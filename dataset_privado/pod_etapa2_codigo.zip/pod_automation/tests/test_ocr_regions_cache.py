from dataclasses import asdict
import pickle

from PIL import Image

import config
from processing import ocr_address
from processing.ocr_address import PhotoOCR, ocr_photo


def test_paddle_coordinates_cached_with_one_detection_and_rebound_path(tmp_path, monkeypatch):
    monkeypatch.setattr(config, 'ANALYSIS_CACHE_ENABLED', True)
    monkeypatch.setattr(config, 'OCR_ENGINE', 'paddle')
    monkeypatch.setattr(ocr_address, 'detect_label_cv', lambda path: (False, None, ''))
    first=tmp_path/'first.png'; second=tmp_path/'same_bytes.png'
    Image.new('RGB',(800,600),'white').save(first)
    second.write_bytes(first.read_bytes())
    calls=[]
    def detector(path, upscale=1):
        calls.append(str(path))
        ocr_address._LAST_PADDLE_WIDTH['w']=400
        return [([[10,20],[80,20],[80,40],[10,40]],'2905',.99)],300
    monkeypatch.setattr(ocr_address, '_paddle_readtext', detector)
    first_read=ocr_photo(first)
    expected=asdict(first_read)
    assert first_read.ocr_size==[400,300]
    assert first_read.text_regions[0]['box']==[[10.,20.],[80.,20.],[80.,40.],[10.,40.]]
    first_read.text_regions[0]['box'][0][0]=999
    next_read=ocr_photo(second)
    assert calls==[str(first)]
    assert asdict(next_read)==dict(expected,path=str(second))
    assert next_read.numbers==['2905']


def test_tesseract_keeps_existing_rotation_passes_and_their_boxes(tmp_path, monkeypatch):
    monkeypatch.setattr(config,'ANALYSIS_CACHE_ENABLED',False)
    monkeypatch.setattr(config,'OCR_ENGINE','tesseract')
    monkeypatch.setattr(ocr_address,'HAS_TESSERACT',True)
    monkeypatch.setattr(ocr_address,'detect_label_cv',lambda p:(False,None,''))
    image=tmp_path/'source.png'; Image.new('RGB',(100,60),'white').save(image)
    calls=[]
    def detector(*args,**kwargs):
        calls.append(1)
        return {'text':['2905'],'conf':['99'],'left':[10],'top':[15],'width':[30],'height':[12]}
    monkeypatch.setattr(ocr_address.pytesseract,'image_to_data',detector)
    reading=ocr_photo(image)
    assert not reading.error
    assert len(calls)==2
    assert reading.ocr_size==[100,60]
    assert [r['rotation'] for r in reading.text_regions]==[0,180]
    assert reading.text_regions[0]['box']==[[10,15],[40,15],[40,27],[10,27]]
    assert reading.numbers==['2905']


def test_decoded_label_still_skips_detector(tmp_path, monkeypatch):
    monkeypatch.setattr(config,'OCR_ENGINE','paddle')
    monkeypatch.setattr(ocr_address,'detect_label_cv',lambda p:(True,'GFUS123','qr_decodificado'))
    def detector(*args,**kwargs):
        raise AssertionError('Una etiqueta decodificada no necesita OCR')
    monkeypatch.setattr(ocr_address,'_readtext',detector)
    reading=ocr_photo(tmp_path/'label.jpg')
    assert reading.is_label and not reading.error
    assert reading.text_regions==[] and reading.ocr_size==[]


def test_old_pickled_reading_restores_new_metadata_defaults():
    old=PhotoOCR('old.jpg',numbers=['2905'])
    del old.text_regions
    del old.ocr_size
    restored=pickle.loads(pickle.dumps(old))
    assert asdict(restored)['text_regions']==[]
    assert restored.ocr_size==[] and restored.numbers==['2905']


def test_coordinates_do_not_change_address_check():
    from models.pod import PODRecord
    from processing.scoring import check_address_number
    pod=PODRecord(tracking_number='TEST',address='Garland Garland 2905 Pegasus Dr')
    plain=PhotoOCR('door.jpg',numbers=['2905'])
    with_regions=PhotoOCR('door.jpg',numbers=['2905'],ocr_size=[800,600],
                          text_regions=[{'box':[[1,1],[10,1],[10,5],[1,5]],'text':'2905','confidence':.99,'rotation':0}])
    assert check_address_number(pod,[plain]).to_dict()==check_address_number(pod,[with_regions]).to_dict()
