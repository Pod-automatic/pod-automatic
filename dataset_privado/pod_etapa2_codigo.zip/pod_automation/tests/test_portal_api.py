"""Cliente de la API interna del portal: lista blanca, sesión vencida, reintentos y paginación (mocks)."""

import json
from unittest.mock import MagicMock

import pytest

from automation.browser import SessionExpiredError
from automation.portal_api import PortalAPI, PortalAPIError, EP_WAYBILLS, EP_SIGN_INFO


def _resp(payload, status=200, url="https://dms.gofoexpress.com/prod-api/x"):
    return {"status": status, "url": url, "text": json.dumps(payload)}


def _api(responses):
    page = MagicMock()
    page.evaluate.side_effect = list(responses)
    sleeps = []
    return PortalAPI(page, sleep=sleeps.append, request_delay_s=1.0), page, sleeps


def test_rejects_endpoints_outside_allowlist():
    api, page, _ = _api([])
    with pytest.raises(ValueError, match="no permitido"):
        api._call("POST", "/dbu_report/common/magic/privacy/waybillNoData/decode", {})
    page.evaluate.assert_not_called()


@pytest.mark.parametrize("resp", [
    _resp({}, status=401),
    _resp({"code": 401, "msg": "token expirado"}),
    _resp({}, url="https://dms.gofoexpress.com/login"),
])
def test_session_expired_is_detected_and_not_retried(resp):
    api, page, sleeps = _api([resp])
    with pytest.raises(SessionExpiredError, match="main.py login"):
        api.get_sign_info("abc")
    assert page.evaluate.call_count == 1 and sleeps == []


def test_api_error_is_retried_with_backoff_then_succeeds():
    api, page, sleeps = _api([
        _resp({"code": 500003}),
        _resp({"code": 200, "data": {"imageList": ["https://s3/x.jpg"]}}),
    ])
    assert api.get_sign_info("abc")["imageList"] == ["https://s3/x.jpg"]
    assert page.evaluate.call_count == 2
    assert 1.0 <= sleeps[0] <= 2.0      # backoff del reintento
    assert sleeps[-1] == 1.0            # pausa de cortesía tras la llamada


def test_api_error_exhausts_retries():
    api, _, _ = _api([_resp({"code": 500003})] * 3)
    with pytest.raises(PortalAPIError, match="500003"):
        api.get_sign_info("abc")


def test_iter_waybills_paginates_until_total():
    def page_of(n, start, total):
        return _resp({"code": 200, "data": {"total": total, "records": [
            {"waybillNo": f"GF{start + i}", "signId": f"s{start + i}", "podImgUrlList": ["u"]} for i in range(n)
        ]}})

    api, page, _ = _api([page_of(2, 0, 5), page_of(2, 2, 5), page_of(1, 4, 5)])
    items = list(api.iter_waybills(1888, "2026-09-29", {"driverName": "X", "userId": 1}, page_size=2))
    assert [w.waybill_no for w in items] == ["GF0", "GF1", "GF2", "GF3", "GF4"]
    bodies = [c.args[1]["body"] for c in page.evaluate.call_args_list]
    assert [b["pageNum"] for b in bodies] == [1, 2, 3]
    assert all(c.args[1]["url"].endswith(EP_WAYBILLS) for c in page.evaluate.call_args_list)


def test_sign_info_uses_get_with_sign_id():
    api, page, _ = _api([_resp({"code": 200, "data": {"toAddress": "700 Eden Rd 7-205"}})])
    assert api.get_sign_info("abc123")["toAddress"] == "700 Eden Rd 7-205"
    arg = page.evaluate.call_args.args[1]
    assert arg["method"] == "GET" and arg["url"].endswith(EP_SIGN_INFO + "?signId=abc123")


def test_hung_request_times_out_and_is_retried():
    api, page, sleeps = _api([
        {"status": 0, "url": "x", "text": "", "error": "AbortError"},
        _resp({"code": 200, "data": {"ok": 1}}),
    ])
    assert api.get_sign_info("abc") == {"ok": 1}
    assert page.evaluate.call_count == 2
    assert "timeoutMs" in page.evaluate.call_args.args[1]
