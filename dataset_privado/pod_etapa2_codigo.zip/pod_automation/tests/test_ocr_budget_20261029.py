import time

import pytest
import config
from processing import ocr_address, pipeline, vision_llm
from processing.ocr_address import PhotoOCR


pytestmark = pytest.mark.real_ocr   # ver conftest: prueba ocr_photos de verdad, con el lector falso


@pytest.fixture(autouse=True)
def isolated(monkeypatch, tmp_path):
    monkeypatch.setattr(config, 'ANALYSIS_CACHE_ENABLED', False)
    monkeypatch.setattr(config, 'VISION_ENABLED', True)


def _fake_reader(seconds, calls):
    def read(path, *a, **k):
        calls.append(path)
        time.sleep(seconds)
        return PhotoOCR(str(path), text='door 1234', numbers=['1234'])
    return read


def _spy_stages(monkeypatch):
    seen = {'vision': 0, 'confirm': 0}
    monkeypatch.setattr(pipeline, 'add_vision_opinion', lambda p, a: seen.__setitem__('vision', seen['vision'] + 1) or p)
    monkeypatch.setattr(pipeline, 'confirm_doubtful_number', lambda p, a: seen.__setitem__('confirm', seen['confirm'] + 1) or p)
    monkeypatch.setattr(pipeline, 'drop_numbers_on_packages', lambda p, a: p)
    return seen


def test_budget_exceeded_skips_remaining_photos_and_model_and_goes_to_manual_review(monkeypatch):
    calls = []
    monkeypatch.setattr(config, 'OCR_POD_BUDGET_S', 0.05)
    monkeypatch.setattr(pipeline, 'ocr_photo', _fake_reader(0.08, calls))
    seen = _spy_stages(monkeypatch)
    photos = pipeline.ocr_photos(['a.jpg', 'b.jpg', 'c.jpg'], '1234 Main St')
    assert calls == ['a.jpg']                       # las demás fotos no se leen
    assert [bool(p.error) for p in photos] == [False, True, True]
    assert seen == {'vision': 0, 'confirm': 0}      # sin consultas al modelo
    assert pipeline.LAST_STAGES['tope_ocr'] == 1
    assert photos[0].vision_error                   # check vision_fallida = Media, nunca Baja
    assert ocr_address.OCR_DEADLINE['t'] == 0.0     # el límite no queda armado para el siguiente albarán


def test_within_budget_behaves_as_before(monkeypatch):
    calls = []
    monkeypatch.setattr(config, 'OCR_POD_BUDGET_S', 30)
    monkeypatch.setattr(pipeline, 'ocr_photo', _fake_reader(0, calls))
    seen = _spy_stages(monkeypatch)
    photos = pipeline.ocr_photos(['a.jpg', 'b.jpg'], '1234 Main St')
    assert calls == ['a.jpg', 'b.jpg'] and not any(p.error or p.vision_error for p in photos)
    assert seen == {'vision': 1, 'confirm': 1} and 'tope_ocr' not in pipeline.LAST_STAGES


def test_budget_zero_means_no_cap(monkeypatch):
    calls = []
    monkeypatch.setattr(config, 'OCR_POD_BUDGET_S', 0)
    monkeypatch.setattr(pipeline, 'ocr_photo', _fake_reader(0.02, calls))
    _spy_stages(monkeypatch)
    photos = pipeline.ocr_photos(['a.jpg', 'b.jpg'], '1234 Main St')
    assert len(calls) == 2 and 'tope_ocr' not in pipeline.LAST_STAGES and not any(p.error for p in photos)


def test_paddle_wait_never_exceeds_remaining_budget_but_keeps_a_floor(monkeypatch):
    assert ocr_address._paddle_timeout() == 120.0
    ocr_address.OCR_DEADLINE['t'] = time.perf_counter() + 30
    try:
        assert 25 < ocr_address._paddle_timeout() <= 30
        ocr_address.OCR_DEADLINE['t'] = time.perf_counter() - 5
        assert ocr_address._paddle_timeout() == 10.0   # ya pasado: piso de 10 s
    finally:
        ocr_address.OCR_DEADLINE['t'] = 0.0


def test_ocr_cap_blocks_handoff_and_package_room_reclassification(monkeypatch):
    """Caso real 28/10 GFUS01080190783105: tras el tope, el modelo lo reclasificó como entrega en mano (Baja)."""
    from models.pod import PODRecord
    monkeypatch.setattr(config, 'VISION_ENABLED', True)
    pod = PODRecord(tracking_number='X', priority='Media')
    capped = [PhotoOCR('a.jpg', vision_error=pipeline.OCR_CAP_MSG), PhotoOCR('b.jpg', error='tope de tiempo del OCR')]
    asked = []
    asker = lambda *a, **k: asked.append(1) or 'person_handing'
    assert pipeline.detect_handoff(pod, capped, asker=asker) is False
    assert pipeline.detect_package_room(pod, capped, asker=asker) is False
    assert asked == []   # ni siquiera se consulta al modelo


def _capture_post(monkeypatch):
    seen = []
    monkeypatch.setattr(vision_llm, '_post_generate', lambda body, timeout, wait=None: seen.append((timeout, dict(body))) or '{}')
    monkeypatch.setattr(vision_llm, '_watch_speed', lambda *a: None)
    return seen


def test_inflight_vision_call_is_bounded_by_remaining_pod_budget(monkeypatch):
    monkeypatch.setattr(config, 'VISION_POD_BUDGET_S', 35)
    monkeypatch.setattr(config, 'VISION_MIN_CALL_S', 10)
    monkeypatch.setattr(config, 'VISION_MAX_CALLS_PER_POD', 0)
    seen = _capture_post(monkeypatch)
    vision_llm.reset_stats(); vision_llm.start_capped()
    try:
        vision_llm._CAP['desde'] = time.perf_counter() - 20        # quedan ~15 s del tope de 35 s
        vision_llm._generate({'model': 'm', 'prompt': 'p'}, 60)
        vision_llm._CAP['desde'] = time.perf_counter() - 30        # quedan ~5 s: se aplica el piso de 10 s
        vision_llm._generate({'model': 'm', 'prompt': 'p'}, 60)
        vision_llm._CAP['desde'] = time.perf_counter() - 1         # sobra tiempo: el valor normal no cambia
        vision_llm._generate({'model': 'm', 'prompt': 'p'}, 12)
        vision_llm._CAP['desde'] = time.perf_counter() - 30
        vision_llm._generate({'model': 'm', 'prompt': 'p', '_sin_tope': True}, 60)   # exentas del tope: sin recorte
    finally:
        vision_llm.stop_capped()
    t = [x[0] for x in seen]
    assert 13 < t[0] <= 15 and t[1] == 10 and t[2] == 12 and t[3] == 60
    assert seen[0][1].get('_recortado') and seen[1][1].get('_recortado')
    assert not seen[2][1].get('_recortado') and not seen[3][1].get('_recortado')


def test_budget_trimmed_timeout_does_not_count_toward_model_reload(monkeypatch):
    import urllib.request
    monkeypatch.setattr(config, 'GPU_DISPATCH_DB', '')
    monkeypatch.setattr(urllib.request, 'urlopen', lambda *a, **k: (_ for _ in ()).throw(TimeoutError('t')))
    unloaded = []
    monkeypatch.setattr(vision_llm, '_unload_model', lambda *a, **k: unloaded.append(1))
    vision_llm._TIMEOUTS['seguidos'] = 0
    for _ in range(4):
        with pytest.raises(TimeoutError):
            vision_llm._post_generate_at({'model': 'm', '_recortado': True}, 1)
    assert unloaded == [] and vision_llm._TIMEOUTS['seguidos'] == 0
    for _ in range(2):
        with pytest.raises(TimeoutError):
            vision_llm._post_generate_at({'model': 'm'}, 1)   # un corte real sigue recargando el modelo
    assert unloaded == [1]


def test_stage_deadline_bounds_and_stops_calls_without_touching_other_stages(monkeypatch):
    monkeypatch.setattr(config, 'VISION_MIN_CALL_S', 10)
    seen = _capture_post(monkeypatch)
    vision_llm.set_deadline(30)
    try:
        vision_llm._generate({'model': 'm', 'prompt': 'p'}, 60)
        assert 25 < seen[0][0] <= 30 and seen[0][1].get('_recortado')
        vision_llm._DEADLINE['t'] = time.perf_counter() - 1        # etapa vencida: no se consulta más
        with pytest.raises(vision_llm.VisionCapped):
            vision_llm._generate({'model': 'm', 'prompt': 'p'}, 60)
    finally:
        vision_llm.clear_deadline()
    assert len(seen) == 1
    vision_llm._generate({'model': 'm', 'prompt': 'p'}, 60)       # sin límite de etapa: igual que antes
    assert seen[1][0] == 60 and not seen[1][1].get('_recortado')


def test_detect_handoff_arms_and_clears_the_stage_deadline(monkeypatch):
    from models.pod import PODRecord
    monkeypatch.setattr(config, 'HANDOFF_BUDGET_S', 20)
    states = []
    pod = PODRecord(tracking_number='X', priority='Media', expected_address='1234 Main St')
    photo = PhotoOCR('a.jpg')
    def asker(path):
        states.append(vision_llm._DEADLINE['t'])
        raise RuntimeError('modelo no disponible')
    with pytest.raises(RuntimeError):
        pipeline.detect_handoff(pod, [photo], asker=asker, reception_asker=lambda p: False)
    assert states and states[0] > time.perf_counter()    # armado durante la etapa
    assert vision_llm._DEADLINE['t'] == 0.0              # y desarmado al salir, aunque falle


def test_trimmed_call_keeps_the_original_wait_for_a_gpu_slot(monkeypatch):
    """Regresión 29/10: acortar la consulta no debe acortar la espera en la cola de GPU (Kaggle: 'Servicios GPU ocupados')."""
    from contextlib import contextmanager
    import automation.gpu_dispatch as gd
    waits = []
    @contextmanager
    def fake_slot(path, urls, timeout, capacity=1):
        waits.append(timeout); yield urls[0]
    monkeypatch.setattr(gd, 'gpu_slot', fake_slot)
    monkeypatch.setattr(config, 'GPU_DISPATCH_DB', 'x.db')
    monkeypatch.setattr(config, 'VISION_POD_BUDGET_S', 35)
    monkeypatch.setattr(config, 'VISION_MIN_CALL_S', 10)
    monkeypatch.setattr(config, 'VISION_MAX_CALLS_PER_POD', 0)
    http = []
    monkeypatch.setattr(vision_llm, '_post_generate_at', lambda body, timeout, selected=None: http.append(timeout) or '{}')
    monkeypatch.setattr(vision_llm, '_watch_speed', lambda *a: None)
    vision_llm.reset_stats(); vision_llm.start_capped()
    try:
        vision_llm._CAP['desde'] = time.perf_counter() - 30      # quedan ~5 s: la consulta se acota a 10 s
        vision_llm._generate({'model': 'm', 'prompt': 'p'}, 60)
    finally:
        vision_llm.stop_capped()
    assert waits == [60] and http == [10]


# ---- 29/10: oficinas de paquetes en apartamentos (6903 / 6919 State Highway 161) ----

def _room_photo(path='a.jpg', kind='package_room', numbers=('104',)):
    return PhotoOCR(path, text='boxes', numbers=list(numbers), photo_type=kind)


def test_apartment_sala_photo_is_not_reread_but_house_sala_photo_still_is(monkeypatch):
    reread = []
    def rereader(path):
        reread.append(path); return []
    flat = [_room_photo('sala.jpg'), PhotoOCR('puerta.jpg', text='x', numbers=['999'], photo_type='door')]
    pipeline.confirm_doubtful_number(flat, '6903 State Highway 161 Apt 104', rereader=rereader)
    assert 'sala.jpg' not in reread
    reread.clear()
    house = [_room_photo('sala.jpg', numbers=('6904',)), PhotoOCR('puerta.jpg', text='x', numbers=['999'], photo_type='door')]
    pipeline.confirm_doubtful_number(house, '6903 State Highway 161', rereader=rereader)
    assert 'sala.jpg' in reread          # en casas todo sigue igual: ahí estaban los errores reales


def _run_capped(monkeypatch, photos, address):
    monkeypatch.setattr(config, 'OCR_POD_BUDGET_S', 0)
    monkeypatch.setattr(pipeline, 'ocr_photo', lambda p: next(x for x in photos if x.path == p))
    monkeypatch.setattr(pipeline, 'add_vision_opinion', lambda p, a: p)
    monkeypatch.setattr(pipeline, 'confirm_doubtful_number', lambda p, a: p)
    monkeypatch.setattr(pipeline, 'drop_numbers_on_packages', lambda p, a: p)
    monkeypatch.setattr(vision_llm, 'stop_capped', lambda: True)    # se alcanzó el tope de consultas/tiempo del modelo
    return pipeline.ocr_photos([p.path for p in photos], address)


def test_model_cap_does_not_flag_the_sala_photo_of_an_apartment(monkeypatch):
    photos = _run_capped(monkeypatch, [_room_photo('sala.jpg')], '6903 State Highway 161 Apt 104')
    assert not any(p.vision_error for p in photos)


def test_model_cap_still_flags_a_house_and_an_apartment_without_sala_photo(monkeypatch):
    house = _run_capped(monkeypatch, [_room_photo('sala.jpg')], '6903 State Highway 161')
    assert house[0].vision_error                       # casa: se conserva la red de seguridad
    mixed = _run_capped(monkeypatch, [_room_photo('sala.jpg'), PhotoOCR('puerta.jpg', text='x', photo_type='door')],
                        '6903 State Highway 161 Apt 104')
    flat_no_sala = _run_capped(monkeypatch, [PhotoOCR('puerta.jpg', text='x', photo_type='door')], '6903 State Highway 161 Apt 104')
    assert flat_no_sala[0].vision_error                # apartamento SIN foto de sala: se conserva la red de seguridad
    assert not mixed[0].vision_error and not mixed[1].vision_error   # sala con unidad: el número no se exige, sin marca


def test_sala_apartment_rule_can_be_switched_off(monkeypatch):
    monkeypatch.setattr(config, 'SALA_APARTMENT_NO_CAP', False)
    original_confirm = pipeline.confirm_doubtful_number
    flat = _run_capped(monkeypatch, [_room_photo('sala.jpg')], '6903 State Highway 161 Apt 104')
    assert flat[0].vision_error                        # apagada: vuelve a marcarse como antes
    reread = []
    original_confirm([_room_photo('sala.jpg', numbers=('105',)), PhotoOCR('p.jpg', text='x', numbers=['999'], photo_type='door')],
                                     '6903 State Highway 161 Apt 104', rereader=lambda p: reread.append(p) or [])
    assert 'sala.jpg' in reread
