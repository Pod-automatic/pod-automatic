"""Regla del 12/10: un "casillero" que solo dice el modelo de visión no tapa una foto que el modelo no pudo leer."""
from models.pod import PODRecord
from processing.ocr_address import PhotoOCR
from processing.scoring import score_pod


def _pod(tmp_path, billing="En la puerta/Patio", locker_text=""):
    paths = []
    for i in (1, 2):
        p = tmp_path / f"foto_{i}.jpg"
        p.write_bytes(f"foto-{i}".encode())
        paths.append(str(p))
    pod = PODRecord(tracking_number="GFUS01077341470593", receipt_address="ARLINGTON ARLINGTON 327 MESQUITE HILL DR",
                    driver_name="X", station="DFW02-BAA")
    pod.billing_type = billing
    pod.photo_paths = paths
    photos = [PhotoOCR(path=paths[0], text=locker_text, photo_type="locker"),
              PhotoOCR(path=paths[1], vision_error="VisionCapped: tope de 5 consultas al modelo en este albarán")]
    return pod, photos


def test_casillero_solo_del_modelo_con_foto_sin_leer_no_se_omite(tmp_path):
    # Caso real 10/10 (327 Mesquite Hill Dr, reportado): la etiqueta se fotografió dentro del carro
    pod, photos = _pod(tmp_path)
    score_pod(pod, photos)
    assert pod.priority == "Media"
    assert not any(r["check"] == "entrega_en_casillero" for r in pod.check_results)


def test_casillero_por_facturacion_se_sigue_omitiendo(tmp_path):
    pod, photos = _pod(tmp_path, billing="Casillero")
    score_pod(pod, photos)
    assert any(r["check"] == "entrega_en_casillero" for r in pod.check_results)
    assert pod.priority == "Baja"


def test_solo_etiqueta_de_otro_paquete_misma_casa_va_a_media():
    # Casos reales 09/10 reportados (1509 Meadow View Dr, 1940 Winding Ridge Trl): mismo repartidor, misma casa
    from processing.scoring import check_label_photos
    pod = PODRecord(tracking_number="GFUS01076491058945", receipt_address="RICHARDSON RICHARDSON 1509 Meadow View Dr",
                    driver_name="Ana", station="DFW02-BAA")
    lbl = [PhotoOCR(path="e.jpg", is_label=True, label_tracking="GFUS01076532840333", text="GOFO SHIP TO 1509 Meadow View Dr")]
    r = check_label_photos(pod, lbl, number_seen=True, address_of=lambda t: "Richardson 1509 Meadow View Dr",
                           driver_of=lambda t: "Ana")
    assert r.score == 50 and "no la de este" in r.explanation


def test_excluidos_solo_del_dia_vencen_solos():
    from automation.drivers import day_exclusions
    data = {"_excluir_solo_hoy": {"fecha": "2026-10-12", "ids": ["15779", "264084"]}}
    assert day_exclusions(data, "2026-10-12") == ["15779", "264084"]
    assert day_exclusions(data, "2026-10-13") == []
    assert day_exclusions({}, "2026-10-12") == []


def _status(address, *photos):
    from processing.scoring import check_address_number
    pod = PODRecord(tracking_number="T1", receipt_address=address, driver_name="X", station="DFW02-BAA")
    pod.billing_type = "En la puerta/Patio"
    return check_address_number(pod, list(photos)).details["status"]


def test_casa_vecina_alta_solo_si_difiere_el_ultimo_digito():
    # Casos 11/10 descartados: placas decorativas 2903 leída 2913, 6932 leída 5932 -> Media (near_match), no Alta
    leer = lambda n: PhotoOCR(path="p", numbers=[n], number_conf={n: 99.0}, vision_numbers=[n], vision_all=[n],
                              vision_used=True)
    assert _status("Garland Garland 2903 Pegasus Dr", leer("2913")) in ("near_match", "neighbor_digit")
    assert _status("FORT WORTH FORT WORTH 6932 Derbyshire Dr", leer("5932")) in ("near_match", "neighbor_digit")
    # Casa de al lado (reportados: 3704/3708, 1506/1508): sigue en Alta
    assert _status("Dallas Dallas 3704 Elm St", leer("3708")) == "mismatch"


def test_numero_escrito_en_la_etiqueta_no_es_otra_puerta():
    # 605 S Holiday Dr (11/10, descartado): el buzón dice 605 y "673" es el marcador sobre la etiqueta de GOFO
    buzon = PhotoOCR(path="a", numbers=["605"], number_conf={"605": 99.0}, vision_used=True, vision_numbers=["605"])
    caja = PhotoOCR(path="b", text="673 GOFO SHIP TO 605 S HOLIDAY DR 41 DFW.H DFW02", numbers=["673"],
                    number_conf={"673": 99.0})
    assert _status("Grand Prairie Grand Prairie 605 S Holiday Dr", buzon, caja) == "match"
    # El número de una casa vecina en una foto sin etiqueta sí queda en duda. 30/10: un número que no puede ser la casa
    # de al lado ("673") ya no (test_reglas_20261030)
    puerta = PhotoOCR(path="c", numbers=["611"], number_conf={"611": 99.0})
    assert _status("Grand Prairie Grand Prairie 605 S Holiday Dr", buzon, puerta) == "two_doors_unconfirmed"


def test_digito_no_final_sigue_protegido_contra_omision():
    from processing.scoring import HARD_NUMBER_PROBLEMS
    assert "neighbor_digit" in HARD_NUMBER_PROBLEMS


def test_tope_de_tiempo_del_modelo(monkeypatch):
    import config
    from processing import vision_llm
    monkeypatch.setattr(config, "VISION_POD_BUDGET_S", 0.01)
    monkeypatch.setattr(vision_llm, "_post_generate", lambda body, timeout: "ok")
    vision_llm.reset_stats()
    vision_llm.start_capped()
    import time
    time.sleep(0.05)
    try:
        vision_llm._generate({"model": "x", "prompt": "p"}, 5)
        raised = False
    except vision_llm.VisionCapped:
        raised = True
    assert raised and vision_llm.stop_capped()


def test_tope_de_tiempo_de_entrega_en_mano_no_omite(tmp_path, monkeypatch):
    import config, time
    from processing.pipeline import detect_handoff
    monkeypatch.setattr(config, "HANDOFF_BUDGET_S", 0.01)
    monkeypatch.setattr(config, "VISION_ENABLED", True)
    pod, photos = _pod(tmp_path)
    pod.priority = "Media"
    photos = [PhotoOCR(path=p) for p in pod.photo_paths]
    slow = lambda path: (time.sleep(0.05), False)[1]
    assert detect_handoff(pod, photos, asker=slow, reception_asker=slow) is False
    assert pod.portal_meta.get("handoff_tope")


def test_va_primero_el_menos_revisado_en_proporcion():
    # 12/10: "que vaya viendo a todos": 10 pendientes de 10 entregados (0 %) va antes que 50 de 200 (75 % revisado)
    from automation.api_extractor import ApiPODExtractor
    ex = ApiPODExtractor.__new__(ApiPODExtractor)
    ex.priority_drivers = set()
    ex.api = type("A", (), {"current_station": 1888})()
    grande = {"station_id": 1888, "courier": {"driverName": "Grande", "podPieces": 200}, "pending": [None] * 50}
    nuevo = {"station_id": 1888, "courier": {"driverName": "Nuevo", "podPieces": 10}, "pending": [None] * 10}
    assert ex._most_behind([grande, nuevo])["courier"]["driverName"] == "Nuevo"


def test_de_30_en_30_nadie_repite_hasta_que_todos_tengan_su_bloque(monkeypatch):
    # 12/10: Morelis recibió un 2.º bloque mientras otros seguían en 0
    import config
    from pathlib import Path
    from automation.api_extractor import ApiPODExtractor
    from tests.test_cobertura_20261007 import TwoCitiesAPI, DFW, DFW02, _drivers
    monkeypatch.setattr(config, "MAX_PER_DRIVER_PER_PASS", 2)
    monkeypatch.setattr(config, "ROUTES_PER_BLOCK", 1)
    api = TwoCitiesAPI({DFW: {"Grande": 10, "B": 4}, DFW02: {"C": 4, "D": 4}})
    got = []
    ApiPODExtractor(api, images_dir=Path("/tmp/x"), downloader=lambda u, d: []).run_pass(
        [DFW, DFW02], "2026-10-12", set(), on_record=got.append)
    first_round = _drivers(got)[:8]
    assert sorted(set(first_round)) == ["B", "C", "D", "Grande"]       # Los 4 tuvieron su bloque antes del 2.º
    assert all(first_round.count(d) == 2 for d in ("B", "C", "D", "Grande"))


def test_mismo_lugar_aunque_la_direccion_venga_escrita_distinto():
    # 12/10: 3 albaranes de Jesús Silva Pérez con las mismas fotos salieron como 3 reportes de WhatsApp
    from export.report_server import place_key
    a = place_key("PLANO PLANO 1500 Precision Dr STE 110 PW 1301")
    assert a == place_key("Plano Plano 1500 Precision Dr.  STE 110 SFW-2002T") == \
        place_key("Plano Plano 1500 Precision Drive STE 110 PKB6212")
    assert a != place_key("Plano Plano 1500 Precision Dr STE 120")   # Otra unidad: otro lugar


def test_calcomania_en_la_foto_de_la_etiqueta_no_es_otra_puerta():
    # 2665 Forest Trail Dr (12/10, Alta falso): la casa dice 2665; el "3526" está en una calcomanía sobre el paquete,
    # en la foto de la etiqueta de GOFO, y el modelo también lo leyó
    casa = PhotoOCR(path="a", numbers=["2665"], number_conf={"2665": 99.0}, vision_used=True, vision_all=["2665"])
    etiqueta = PhotoOCR(path="b", text="3526 GOFO SHIP TO 2665 FOREST TRAIL DR 41 DFW.H DFW02", numbers=["3526"],
                        number_conf={"3526": 99.0}, vision_used=True, vision_all=["3526"])
    assert _status("Grand Prairie Grand Prairie 2665 FOREST TRAIL DR", casa, etiqueta) == "match"
    # Si el otro número está en la foto de OTRA puerta (sin etiqueta), siguen siendo dos puertas
    puerta = PhotoOCR(path="c", numbers=["3526"], number_conf={"3526": 99.0}, vision_used=True, vision_all=["3526"])
    assert _status("Grand Prairie Grand Prairie 2665 FOREST TRAIL DR", casa, puerta) == "two_doors"


def test_gps_lejano_con_el_numero_visible_no_suma():
    # 12/10 Colleyville (Suhana Martínez): 28 Media por GPS a 1,6-4,4 km, todas descartadas; el número se veía
    from processing.scoring import check_gps_distance
    pod = PODRecord(tracking_number="T1", receipt_address="Colleyville Colleyville 2003 Kyle court", driver_name="X",
                    station="DFW-BAA")
    pod.portal_meta["sign_distance"] = "3262"
    assert check_gps_distance(pod, number_match=True).score == 0
    assert check_gps_distance(pod).score > 0          # Sin el número a la vista sigue sumando (caso real 01/10, 2.192 m)
