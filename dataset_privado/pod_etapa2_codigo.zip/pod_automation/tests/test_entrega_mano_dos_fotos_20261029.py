"""29/10: la entrega en mano exige HANDOFF_MIN_PHOTOS fotos distintas (antes bastaba una).

Motivo (tools/probar_entrega_mano.py, 62 albaranes con marca válida): con una foto, el modelo de 3B tomaba por "persona recibiendo" la
mano del repartidor con la etiqueta, su reflejo en un vidrio o un paquete solo, y omitía 7 de 12 errores reales; con dos fotos, 0 de 12.
"""
import pytest
import config
from models.pod import PODRecord
from processing.ocr_address import PhotoOCR
from processing.pipeline import detect_handoff


def _pod(address="1234 Main St"):
    return PODRecord(tracking_number="T", priority="Media", receipt_address=address, address=address)


def _photos(*names):
    return [PhotoOCR(path=n) for n in names]


def test_default_requires_two_photos():
    assert config.HANDOFF_MIN_PHOTOS == 2


def test_una_sola_foto_que_confirma_no_alcanza():
    pod = _pod()
    # solo la foto 2 es "persona recibiendo" (p. ej. el reflejo del repartidor en el vidrio)
    assert detect_handoff(pod, _photos("a.jpg", "b.jpg", "c.jpg"), asker=lambda p: p == "b.jpg") is False
    assert "handoff_confirmed" not in pod.portal_meta and "handoff_photo" not in pod.portal_meta


def test_dos_fotos_distintas_si_alcanzan_y_se_anotan():
    pod = _pod()
    assert detect_handoff(pod, _photos("a.jpg", "b.jpg", "c.jpg"), asker=lambda p: p in ("b.jpg", "c.jpg")) is True
    assert pod.portal_meta["handoff_photo"] == 2 and pod.portal_meta["handoff_photos"] == [2, 3]
    assert pod.portal_meta["handoff_confirmed"] is True


def test_la_misma_foto_no_cuenta_dos_veces():
    pod = _pod()
    asked = []
    assert detect_handoff(pod, _photos("a.jpg"), asker=lambda p: asked.append(p) or True) is False
    assert asked == ["a.jpg"]


def test_un_albaran_con_una_sola_foto_candidata_nunca_se_omite():
    # la foto de la etiqueta real no se pregunta, así que queda una sola candidata: no hay segunda confirmación posible
    label = PhotoOCR(path="etiqueta.jpg", is_label=True, label_tracking="GFUS01075571240196")
    assert detect_handoff(_pod(), [label, PhotoOCR(path="a.jpg")], asker=lambda p: True) is False


def test_recepcion_y_persona_cuentan_como_fotos_distintas():
    pod = _pod("6350 Winter Park Dr Apt 341")
    photos = [PhotoOCR(path="a.jpg", photo_type="building"), PhotoOCR(path="b.jpg", photo_type="building")]
    assert detect_handoff(pod, photos, asker=lambda p: p == "a.jpg", reception_asker=lambda p: p == "b.jpg") is True
    assert pod.portal_meta["handoff_photos"] == [1, 2]
    assert not pod.portal_meta.get("handoff_reception")   # la primera confirmación fue por persona


def test_con_un_minimo_de_uno_vuelve_al_comportamiento_anterior(monkeypatch):
    monkeypatch.setattr(config, "HANDOFF_MIN_PHOTOS", 1)
    pod = _pod()
    assert detect_handoff(pod, _photos("a.jpg", "b.jpg"), asker=lambda p: p == "b.jpg") is True
    assert pod.portal_meta["handoff_photo"] == 2 and "handoff_photos" not in pod.portal_meta


def test_el_tope_de_tiempo_de_la_etapa_deja_el_albaran_como_estaba(monkeypatch):
    # si no alcanza el tiempo para la segunda foto, no se omite: Alta/Media se conserva
    import time
    monkeypatch.setattr(config, "HANDOFF_BUDGET_S", 0.05)
    pod = _pod()
    def slow(p):
        time.sleep(0.08); return True
    assert detect_handoff(pod, _photos("a.jpg", "b.jpg"), asker=slow) is False
    assert pod.portal_meta.get("handoff_tope") is True
