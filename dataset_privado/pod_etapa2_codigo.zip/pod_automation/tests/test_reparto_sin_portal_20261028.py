"""28/10: con el portal caído, el reparto no espera en cada bloque: tras un fallo se revisa todo sin preguntar."""
import time

import config
from automation import work_claims
from automation.work_claims import LeaseCoordinator


class _Down:
    timeout = 10

    def __init__(self):
        self.calls = 0

    def call(self, path, body=None, query=None):
        self.calls += 1
        raise TimeoutError('portal sin respuesta')


def test_after_one_failure_claims_pause_without_calling_the_portal(tmp_path, monkeypatch):
    monkeypatch.setattr(config, 'CLAIM_BACKOFF_S', 120)
    client = _Down()
    coord = LeaseCoordinator(client, 'pc', '2026-10-28', 600, tmp_path / 'c.db')
    for _ in range(5):
        try:
            coord.acquire(['A', 'B'])
        except Exception:
            pass
    assert client.calls == 1
    coord.tick()   # la renovación tampoco insiste
    assert client.calls == 1


def test_claims_retry_the_portal_after_the_pause(tmp_path, monkeypatch):
    monkeypatch.setattr(config, 'CLAIM_BACKOFF_S', 120)
    client = _Down()
    coord = LeaseCoordinator(client, 'pc', '2026-10-28', 600, tmp_path / 'c.db')
    try:
        coord.acquire(['A'])
    except Exception:
        pass
    coord.down_until = time.monotonic() - 1
    try:
        coord.acquire(['A'])
    except Exception:
        pass
    assert client.calls == 2


def test_extractor_reviews_everything_while_claims_are_paused(tmp_path, monkeypatch):
    from automation.api_extractor import ApiPODExtractor
    monkeypatch.setattr(config, 'CLAIM_BACKOFF_S', 120)
    coord = LeaseCoordinator(_Down(), 'pc', '2026-10-28', 600, tmp_path / 'c.db')
    ext = ApiPODExtractor(object())
    ext.claim_fn = coord.acquire
    ext._claim_done = []
    started = time.monotonic()
    assert ext._claim(['A', 'B']) == {'A', 'B'}
    assert ext._claim(['C']) == {'C'}
    assert time.monotonic() - started < 2
