"""30/10: el registro de cada corrida se manda al portal (Auditoría > Registro); PC y Luis solo en DFW02; 8 detalles a la vez."""
import io
import logging
from pathlib import Path

import pytest

import config
from export import portal_log
from export.portal_log import PortalLog, _Handler, _Tee, scrub


class FakeClient:
    def __init__(self, fail=None):
        self.calls, self.fail = [], fail

    def call(self, path, body):
        if self.fail:
            raise self.fail
        self.calls.append((path, body))
        return {"ok": True}


class Clock:
    def __init__(self):
        self.t = 1_800_000_000.0

    def __call__(self):
        return self.t


def _log(client, **kw):
    kw.setdefault("every_s", 20)
    kw.setdefault("max_per_min", 300)
    return PortalLog(client, "gpu_luis", "kag:gpu_luis", clock=kw.pop("clock", Clock()), **kw)


def test_tacha_claves_tokens_y_cookies():
    out = scrub("X-Api-Key: abc123 token=eyJhbGci cookie='SESS=99' Authorization: Bearer zzz password=hola \x1b[31mrojo\x1b[0m")
    for secret in ("abc123", "eyJhbGci", "SESS=99", "zzz", "hola"):
        assert secret not in out
    assert "rojo" in out and "\x1b" not in out
    assert scrub("Albarán GFUS01234567 revisado") == "Albarán GFUS01234567 revisado"


def test_envia_en_lotes_y_reintenta_si_el_portal_falla():
    client = FakeClient(fail=RuntimeError("sin conexión con el portal"))
    log = _log(client)
    log.add("INFO", "uno\ndos\n\n")
    assert log.flush() == 0 and len(log.queue) == 2      # Portal caído: las líneas esperan
    client.fail = None
    assert log.flush() == 2
    path, body = client.calls[0]
    assert path == "run_log.php" and body["worker"] == "gpu_luis" and body["instance"] == "kag:gpu_luis"
    assert [l["msg"] for l in body["lines"]] == ["uno", "dos"] and body["lines"][0]["s"] < body["lines"][1]["s"]
    log.max_per_min = 10 ** 6
    for i in range(portal_log.BATCH + 5):
        log.add("INFO", f"l{i}")
    assert log.flush() == portal_log.BATCH + 5 and len(client.calls) == 3


def test_portal_sin_actualizar_no_insiste():
    clock = Clock()
    client = FakeClient(fail=RuntimeError("HTTP 404: Not Found"))
    log = _log(client, clock=clock)
    log.add("INFO", "hola")
    log.flush()
    client.fail = None
    assert log.flush() == 0            # Pausa de 10 min
    clock.t += 601
    assert log.flush() == 1


def test_tope_por_minuto_deja_pasar_avisos_y_cuenta_lo_omitido():
    clock = Clock()
    client = FakeClient()
    log = _log(client, clock=clock, max_per_min=3)
    for i in range(5):
        log.add("INFO", f"info {i}")
    log.add("WARNING", "Detalles a la vez: 8 de 8 fallaron")
    log.flush()
    msgs = [l["msg"] for l in client.calls[0][1]["lines"]]
    assert msgs[:3] == ["info 0", "info 1", "info 2"] and "Detalles a la vez: 8 de 8 fallaron" in msgs
    assert any(m.startswith("(registro) 2 líneas no se enviaron") for m in msgs)


def test_copia_pantalla_y_logging_sin_cambiar_la_salida():
    log = _log(FakeClient())
    out = io.StringIO()
    tee = _Tee(out, log, "INFO")
    tee.write("Pasada 3: ")
    tee.write("12 albaranes\nsigue")
    assert out.getvalue() == "Pasada 3: 12 albaranes\nsigue"
    assert [l["msg"] for l in log.queue] == ["Pasada 3: 12 albaranes"]
    logger = logging.getLogger("PODAutomation.PruebaRegistro")
    handler = _Handler(log)
    logger.addHandler(handler)
    try:
        logger.warning("Ollama HTTP 500")
        logger.debug("no va")
    finally:
        logger.removeHandler(handler)
    assert log.queue[-1]["lvl"] == "WARNING" and log.queue[-1]["msg"].endswith("Ollama HTTP 500")
    assert all("no va" not in l["msg"] for l in log.queue)


def test_sin_portal_o_apagado_no_se_instala(monkeypatch):
    monkeypatch.setattr(portal_log, "_installed", None)
    monkeypatch.setattr(config, "PORTAL_SYNC_ENABLED", False)
    assert portal_log.install() is None
    monkeypatch.setattr(config, "PORTAL_SYNC_ENABLED", True)
    monkeypatch.setattr(config, "PORTAL_LOG", False)
    assert portal_log.install() is None


def test_kaggle_luis_solo_dfw02_y_8_detalles_a_la_vez(tmp_path):
    from tools import run_kaggle_multi as multi
    assert multi.LUIS_STATIONS == "DFW02-BAA"
    for worker, shared_session in (("gpu_luis", True), ("gpu_tracking", False)):
        env = multi.worker_env({}, worker, tmp_path / "c.json", tmp_path, shared_session)
        assert env["GOFO_DETAIL_CONCURRENCY"] == "8" and env["CLAIM_BATCH_SIZE"] == "16"
    assert "PORTAL_LOG" not in env or env["PORTAL_LOG"] != "0"   # Registro en el portal también en Kaggle


def test_pc_solo_dfw02_y_8_detalles_a_la_vez():
    env = Path(config.PROJECT_ROOT / ".env")
    if not env.exists():
        pytest.skip("sin .env de la PC")
    values = dict(l.split("=", 1) for l in env.read_text(encoding="utf-8").splitlines() if "=" in l and not l.startswith("#"))
    assert values.get("GOFO_STATION_IDS") == "1888"
    assert values.get("GOFO_DETAIL_CONCURRENCY") == "8" and values.get("CLAIM_BATCH_SIZE") == "16"
