"""10/10: tope de consultas al modelo de visión por albarán y vigilante de Ollama."""
import pytest

import config
from processing import pipeline, vision_llm
from processing.ocr_address import PhotoOCR


def test_cap_raises_after_limit(monkeypatch):
    monkeypatch.setattr(config, "VISION_MAX_CALLS_PER_POD", 2)
    monkeypatch.setattr(vision_llm, "_post_generate", lambda body, timeout: "{}")
    monkeypatch.setattr(vision_llm, "_watch_speed", lambda s, m: None)
    vision_llm.reset_stats()
    vision_llm.start_capped()
    vision_llm._generate({"model": "m"}, 1)
    vision_llm._generate({"model": "m"}, 1)
    with pytest.raises(vision_llm.VisionCapped):
        vision_llm._generate({"model": "m"}, 1)
    assert vision_llm.stop_capped() is True
    vision_llm._generate({"model": "m"}, 1)   # Fuera de la lectura del número (entrega en mano) no hay tope


@pytest.mark.real_ocr   # Usa ocr_photos de verdad (el OCR de cada foto se reemplaza abajo)
def test_capped_pod_goes_to_manual_review(monkeypatch):
    # Al llegar al tope sin resolver, una foto queda con vision_error -> check vision_fallida (Media, nunca Baja)
    monkeypatch.setattr(config, "VISION_MAX_CALLS_PER_POD", 1)
    monkeypatch.setattr(config, "VISION_ENABLED", True)
    monkeypatch.setattr(pipeline, "ocr_photo", lambda p: PhotoOCR(path=p))

    def greedy(photos, address):
        for _ in range(3):
            try:
                vision_llm._generate({"model": "m"}, 1)
            except vision_llm.VisionCapped:
                pass
        return photos
    monkeypatch.setattr(vision_llm, "_post_generate", lambda body, timeout: "{}")
    monkeypatch.setattr(vision_llm, "_watch_speed", lambda s, m: None)
    monkeypatch.setattr(pipeline, "add_vision_opinion", greedy)
    monkeypatch.setattr(pipeline, "confirm_doubtful_number", lambda photos, a: photos)
    monkeypatch.setattr(pipeline, "drop_numbers_on_packages", lambda photos, a: photos)
    photos = pipeline.ocr_photos(["a.jpg", "b.jpg"], "Dallas 100 Main St")
    assert "tope" in photos[0].vision_error
    assert pipeline.LAST_STAGES.get("tope_vision") == 1


def test_watchdog_reloads_when_median_is_slow(monkeypatch):
    unloaded = []
    monkeypatch.setattr(vision_llm, "_unload_model", lambda m: unloaded.append(m))
    monkeypatch.setattr(config, "VISION_SLOW_WINDOW", 4)
    monkeypatch.setattr(config, "VISION_SLOW_MEDIAN_S", 15)
    vision_llm._RECENT.clear()
    for s in (3, 4, 40, 5):
        vision_llm._watch_speed(s, "m")   # Una consulta lenta suelta no recarga
    assert unloaded == []
    for s in (30, 50, 40, 60):
        vision_llm._watch_speed(s, "m")
    assert unloaded == ["m"]
