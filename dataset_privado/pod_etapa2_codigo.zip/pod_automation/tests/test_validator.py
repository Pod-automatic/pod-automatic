"""
Pruebas Unitarias para el Validador de PODs y Reglas de Negocio.
"""

from models.pod import PODRecord, VerdictEnum, AnomalyCode
from processing.validator import PODValidator


def test_validator_clean_pod():
    """Un POD con foto válida y sin incidencias debe ser clasificado como VÁLIDO."""
    validator = PODValidator()
    pod = PODRecord(
        albaran="TRK-100",
        driver="Driver Test",
        direccion="Calle Mayor 45, Piso 2, Madrid",
        estado_entrega="Entregado",
        fecha_hora="2026-09-12 14:30:00",
        tipo_entrega="En mano",
        fotos_urls=["http://portal/foto1.jpg"],
    )

    result = validator.validate_pod(pod)

    assert result.veredicto == VerdictEnum.VALIDO
    assert result.puntaje_calidad >= 75.0
    assert len(result.anomalias) == 0


def test_validator_missing_photo_and_signature():
    """Un POD sin foto ni firma debe ser clasificado como SOSPECHOSO."""
    validator = PODValidator()
    pod = PODRecord(
        albaran="TRK-200",
        driver="Driver Test",
        direccion="Av. Diagonal 123",
        fotos_urls=[],
        fotos_locales=[],
        tiene_firma=False,
    )

    result = validator.validate_pod(pod)

    assert result.veredicto == VerdictEnum.REQUIERE_REVISION
    assert result.classification.value == "REVIEW REQUIRED"
    assert any(AnomalyCode.FOTO_FALTANTE.value in a for a in result.anomalias)


def test_validator_platform_incident_requires_review():
    """Un POD con foto pero con reporte de incumplimiento de la plataforma debe requerir revisión."""
    validator = PODValidator()
    pod = PODRecord(
        albaran="TRK-300",
        driver="Driver Test",
        direccion="Paseo de la Castellana 80",
        fotos_urls=["http://portal/foto.jpg"],
        razon_incumplimiento="Paquete entregado a vecino no autorizado",
    )

    result = validator.validate_pod(pod)

    assert result.veredicto == VerdictEnum.REQUIERE_REVISION
    assert any(AnomalyCode.INCUMPLIMIENTO_PLATAFORMA.value in a for a in result.anomalias)
