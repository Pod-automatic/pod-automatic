"""
Pruebas Unitarias para DuplicateImageDetector (Detección de Fraude por Reutilización de Fotos).
"""

from processing.duplicate_detection import DuplicateImageDetector


def test_duplicate_detector_exact_and_perceptual():
    detector = DuplicateImageDetector(max_hamming_distance=4)

    # 1. Registrar primera imagen legítima para el paquete TRK-001
    is_dup, reason = detector.register_and_check(
        tracking="TRK-001",
        driver="Juan Pérez",
        file_path="/storage/pod_images/2026-09-12/TRK-001/foto_1.jpg",
        dhash="ffff0000ffff0000",
        sha256="abc123exacthash",
    )
    assert is_dup is False
    assert reason is None

    # 2. Misma imagen para el mismo paquete (segunda foto del mismo envío) -> No es fraude
    is_dup_same, _ = detector.register_and_check(
        tracking="TRK-001",
        driver="Juan Pérez",
        file_path="/storage/pod_images/2026-09-12/TRK-001/foto_2.jpg",
        dhash="ffff0000ffff0000",
        sha256="abc123exacthash",
    )
    assert is_dup_same is False

    # 3. Misma foto reutilizada en OTRO paquete TRK-002 por el mismo repartidor -> FRAUDE DETECTADO
    is_dup_cross, reason_cross = detector.register_and_check(
        tracking="TRK-002",
        driver="Juan Pérez",
        file_path="/storage/pod_images/2026-09-12/TRK-002/foto_1.jpg",
        dhash="ffff0000ffff0000",
        sha256="abc123exacthash",
    )
    assert is_dup_cross is True
    assert "FOTO IDÉNTICA (SHA-256)" in reason_cross
    assert "TRK-001" in reason_cross

    # 4. Foto ligeramente diferente (solo 2 bits cambiados en dHash) en paquete TRK-003 -> DUPLICADO PERCEPTUAL
    # ffff0000ffff0000 vs ffff0000ffff0003 (solo 2 bits de diferencia en el último nibble)
    is_dup_perceptual, reason_p = detector.register_and_check(
        tracking="TRK-003",
        driver="Carlos Gómez",
        file_path="/storage/pod_images/2026-09-12/TRK-003/foto_1.jpg",
        dhash="ffff0000ffff0003",
        sha256="different_sha_due_to_compression",
    )
    assert is_dup_perceptual is True
    assert "FOTO PERCEPTUALMENTE DUPLICADA" in reason_p

    # 5. Foto completamente distinta -> Legítima
    is_dup_legit, reason_legit = detector.register_and_check(
        tracking="TRK-004",
        driver="Ana Ruiz",
        file_path="/storage/pod_images/2026-09-12/TRK-004/foto_1.jpg",
        dhash="0000ffff0000ffff",
        sha256="completely_different_sha",
    )
    assert is_dup_legit is False
    assert reason_legit is None
