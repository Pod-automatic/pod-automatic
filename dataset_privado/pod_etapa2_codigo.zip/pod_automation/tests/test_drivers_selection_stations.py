import json

from automation.drivers import DriverSelection


def _sel(tmp_path, **kw):
    p = tmp_path / "drivers.json"
    p.write_text(json.dumps({"excluir": ["260419"], "catalogo": []}), encoding="utf-8")
    return DriverSelection(path=p, **kw)


def test_station_filter_and_exclusions(tmp_path):
    sel = _sel(tmp_path, stations=["DFW02-BAA"])
    assert sel.should_review({"driverName": "Hanna", "userId": 373336, "siteName": "DFW02-BAA"})
    assert not sel.should_review({"driverName": "Carla Colina", "userId": 267748, "siteName": "DFW-BAA"})
    assert not sel.should_review({"driverName": "Henry", "userId": 260419, "siteName": "DFW02-BAA"})


def test_no_station_filter_reviews_all_stations(tmp_path):
    assert _sel(tmp_path).should_review({"driverName": "Carla", "userId": 1, "siteName": "DFW-BAA"})


def test_skip_drivers_only_for_this_run(tmp_path):
    sel = _sel(tmp_path, stations=["DFW02-BAA"], skip=["274587", "Jesús D Portillo Taborda"])
    assert not sel.should_review({"driverName": "Yonaiker", "userId": 274587, "siteName": "DFW02-BAA"})
    assert not sel.should_review({"driverName": "Jesús D  Portillo Taborda", "userId": 1, "siteName": "DFW02-BAA"})
    assert sel.should_review({"driverName": "Hanna", "userId": 373336, "siteName": "DFW02-BAA"})


def test_extra_driver_from_other_station(tmp_path):
    sel = _sel(tmp_path, stations=["DFW02-BAA"], extra=["362972"])
    assert sel.should_review({"driverName": "Pedro Jose Pena Diaz", "userId": 362972, "siteName": "DFW-BAA"})
    assert not sel.should_review({"driverName": "Carla Colina", "userId": 267748, "siteName": "DFW-BAA"})


def test_extractor_switches_city_before_each_station():
    from automation.api_extractor import ApiPODExtractor

    class FakeAPI:
        def __init__(self):
            self.current_station, self.switches = None, []
        def list_couriers(self, sid, date):
            return [{"driverName": "A", "userId": sid, "siteName": "X"}] if sid != 999 else []
        def switch_station(self, sid):
            self.switches.append(sid); self.current_station = sid
        def iter_waybills(self, sid, date, courier, page_size=50):
            assert self.current_station == sid, "abrió albaranes sin cambiar de ciudad"
            return iter([])

    api = FakeAPI()
    ApiPODExtractor(api).run_pass([1888, 297, 999], "2026-10-01", set(), on_record=lambda p: None)
    assert api.switches == [1888, 297]          # 999 no tiene repartidores que revisar: no se cambia


def test_station_filter_uses_city_where_route_is_listed_today(tmp_path):
    # 03/10: los repartidores se cambian entre DFW-BAA y DFW02-BAA; cuenta la ciudad donde aparece la ruta hoy
    from automation.drivers import DriverSelection
    sel = DriverSelection(path=tmp_path / "x.json", stations=["DFW02-BAA"])
    maria = {"driverName": "Maria de los angeles Martinez gonzalez", "userId": "1", "siteName": "DFW-BAA"}
    assert sel.should_review(dict(maria, _listed_station="DFW02-BAA"))
    assert not sel.should_review(dict(maria, _listed_station="DFW-BAA"))
    assert not sel.should_review(maria)          # Sin saber la lista: su ciudad de registro
