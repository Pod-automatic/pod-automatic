"""
Pruebas Unitarias para la Fase 2: Modelo PODRecord y Almacenamiento PODMemoryStorage.
"""

from pathlib import Path
from datetime import datetime
import openpyxl

from models.pod import (
    PODRecord,
    PODMemoryStorage,
    ProcessingStatusEnum,
    VerdictEnum,
    AnomalyCode,
)
from export.excel_exporter import PODExcelExporter


def test_pod_record_all_phase2_fields():
    """Valida la presencia y consistencia de todos los campos solicitados en la Fase 2."""
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    pod = PODRecord(
        tracking_number="GF10098231ES",
        stop_number="42",
        driver_name="Carlos Martínez",
        station="DFW02",
        address="Calle Gran Vía 28, Madrid",
        delivery_status="Entregado",
        delivery_datetime="2026-09-12 14:15:30",
        signature_datetime="2026-09-12 14:15:28",
        delivery_type="En mano",
        reviewer="Inspector DSP 01",
        pod_review_date=now_str,
        abnormal_status=False,
        non_compliance_reason=None,
        number_of_photos=2,
        photo_paths=["/storage/photo1.jpg", "/storage/photo2.jpg"],
        processing_status=ProcessingStatusEnum.PROCESSED,
        error_message=None,
    )

    # 1. Verificación de atributos directos
    assert pod.tracking_number == "GF10098231ES"
    assert pod.stop_number == "42"
    assert pod.driver_name == "Carlos Martínez"
    assert pod.station == "DFW02"
    assert pod.address == "Calle Gran Vía 28, Madrid"
    assert pod.delivery_status == "Entregado"
    assert pod.delivery_datetime == "2026-09-12 14:15:30"
    assert pod.signature_datetime == "2026-09-12 14:15:28"
    assert pod.delivery_type == "En mano"
    assert pod.reviewer == "Inspector DSP 01"
    assert pod.pod_review_date == now_str
    assert pod.abnormal_status is False
    assert pod.non_compliance_reason is None
    assert pod.number_of_photos == 2
    assert len(pod.photo_paths) == 2
    assert pod.processing_status == ProcessingStatusEnum.PROCESSED
    assert pod.error_message is None

    # 2. Verificación de retrocompatibilidad
    assert pod.albaran == "GF10098231ES"
    assert pod.driver == "Carlos Martínez"
    assert pod.direccion == "Calle Gran Vía 28, Madrid"
    assert pod.fotos_locales == ["/storage/photo1.jpg", "/storage/photo2.jpg"]

    # 3. Modificación por alias
    pod.albaran = "GF99999999ES"
    assert pod.tracking_number == "GF99999999ES"


def test_pod_record_abnormal_behavior():
    """Verifica que al registrar anomalías o incumplimientos se active abnormal_status."""
    pod = PODRecord(tracking_number="GF001")
    assert pod.abnormal_status is False

    pod.add_anomaly(AnomalyCode.FOTO_BORROSA, "Desenfoque alto", penalty=30.0)
    assert pod.abnormal_status is True
    assert pod.quality_score == 70.0


def test_pod_memory_storage_operations():
    """Valida la funcionalidad de indexación, consulta y filtrado de PODMemoryStorage."""
    storage = PODMemoryStorage()
    assert storage.count() == 0

    pod1 = PODRecord(
        tracking_number="GF100",
        driver_name="Driver 1",
        processing_status=ProcessingStatusEnum.PROCESSED,
    )
    pod2 = PODRecord(
        tracking_number="GF200",
        driver_name="Driver 2",
        processing_status=ProcessingStatusEnum.FAILED,
        error_message="Timeout abriendo modal",
    )

    storage.add(pod1)
    storage.add(pod2)

    assert storage.count() == 2
    assert storage.get("GF100") == pod1
    assert storage.get("GF200") == pod2
    assert storage.get("NONEXISTENT") is None

    # Filtros por estado
    successful = storage.get_successful()
    failed = storage.get_failed()
    assert len(successful) == 1
    assert successful[0].tracking_number == "GF100"
    assert len(failed) == 1
    assert failed[0].tracking_number == "GF200"

    # Serialización a dict
    dict_list = storage.to_dict_list()
    assert len(dict_list) == 2
    assert dict_list[0]["tracking_number"] == "GF100"
    assert dict_list[1]["error_message"] == "Timeout abriendo modal"

    # Limpieza
    storage.clear()
    assert storage.count() == 0


def test_excel_export_from_memory_storage(tmp_path):
    """Verifica que el exportador Excel acepte PODMemoryStorage y renderice los campos de Fase 2."""
    storage = PODMemoryStorage()
    pod = PODRecord(
        tracking_number="GF300",
        stop_number="15",
        driver_name="Marcos Alonso",
        station="MAD01",
        address="Paseo de la Castellana 100",
        delivery_status="Entregado",
        delivery_datetime="2026-09-12 16:00:00",
        signature_datetime="2026-09-12 15:59:45",
        delivery_type="Puerta",
        reviewer="Operador 02",
        abnormal_status=True,
        non_compliance_reason="Foto borrosa reportada",
        photo_paths=["/tmp/photo.jpg"],
        processing_status=ProcessingStatusEnum.PROCESSED,
        verdict=VerdictEnum.REQUIERE_REVISION,
    )
    storage.add(pod)

    exporter = PODExcelExporter(output_dir=tmp_path)
    excel_file = exporter.export(storage, filename="fase2_report.xlsx")

    assert excel_file.exists()
    wb = openpyxl.load_workbook(excel_file)
    assert "POD Results" in wb.sheetnames
    assert "Summary" in wb.sheetnames

    ws = wb["POD Results"]

    # Verificar encabezados clave
    headers = [cell.value for cell in ws[1]]
    assert "Tracking" in headers
    assert "Stop" in headers
    assert "Station" in headers
    assert "Photos Count" in headers
    assert "Validation Result" in headers

    # Verificar valores en fila 2
    assert ws.cell(row=2, column=1).value == "GF300"
    assert ws.cell(row=2, column=2).value == "15"
    assert ws.cell(row=2, column=4).value == "MAD01"
    assert ws.cell(row=2, column=9).value == 1     # Photos Count
    assert ws.cell(row=2, column=15).value == "REVIEW REQUIRED"  # Validation Result

    wb.close()
