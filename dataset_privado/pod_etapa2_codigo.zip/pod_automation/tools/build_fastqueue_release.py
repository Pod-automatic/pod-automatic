"""Notebook con código integrado, sin claves, cookies, bases ni fotos."""
import base64
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))


def main():
    subprocess.run([sys.executable,'deploy/kaggle/empaquetar_etapa2.py','--solo-codigo'],cwd=ROOT,check=True)
    out=ROOT/'output'
    notebook=json.loads((out/'pod_multiciudad_20261028.ipynb').read_text(encoding='utf-8'))
    code=base64.b64encode((out/'pod_etapa2_codigo.zip').read_bytes()).decode('ascii')
    overlay="with zipfile.ZipFile(io.BytesIO(base64.b64decode("+repr(code)+"))) as release: release.extractall(W)"
    source=''.join(notebook['cells'][1]['source'])
    assert '# RELEASE_CODE_OVERLAY' in source
    notebook['cells'][1]['source']=source.replace('# RELEASE_CODE_OVERLAY',overlay).splitlines(keepends=True)
    path=out/'pod_multiciudad_cola_20261028.ipynb'
    path.write_text(json.dumps(notebook,ensure_ascii=False,indent=1),encoding='utf-8')
    print('Notebook con codigo integrado (sin secretos):',path)


if __name__=='__main__': main()
