"""Respaldo portable de caché, coordenadas, checkpoints y fotos; excluye credenciales."""
from pathlib import Path
import sqlite3
import tempfile
import zipfile

DATABASES = {'analysis_cache.db', 'pod_checkpoints.db', 'portal_outbox.db',
             'package_control.db', 'route_panel.db', 'report_status.db'}


def allowed(relative):
    parts = relative.parts
    if not parts or relative.is_absolute() or '..' in parts or parts[0] != 'storage':
        return False
    return relative.name in DATABASES or ('pod_images' in parts and relative.suffix.lower() in {'.jpg','.jpeg','.png','.webp'})


def backup(root, destination):
    root, destination = Path(root), Path(destination)
    pending = destination.with_suffix('.tmp')
    with tempfile.TemporaryDirectory() as folder, zipfile.ZipFile(pending,'w',zipfile.ZIP_DEFLATED) as archive:
        for source in (root/'storage').rglob('*'):
            relative = source.relative_to(root)
            if not source.is_file() or not allowed(relative): continue
            if source.name in DATABASES:
                snapshot = Path(folder)/'snapshot.db'
                src = sqlite3.connect(f'file:{source.as_posix()}?mode=ro',uri=True)
                dst = sqlite3.connect(snapshot)
                try: src.backup(dst)
                finally:
                    dst.close()
                    src.close()
                archive.write(snapshot, relative.as_posix())
                snapshot.unlink()
            else:
                archive.write(source, relative.as_posix())
    pending.replace(destination)
    return destination


def restore(root, source):
    root = Path(root)
    with zipfile.ZipFile(source) as archive:
        names = archive.namelist()
        if any(not allowed(Path(name)) for name in names):
            raise ValueError('El respaldo contiene archivos fuera del estado permitido.')
        for name in names:
            target = root/name
            if target.exists(): continue
            target.parent.mkdir(parents=True,exist_ok=True)
            with archive.open(name) as src, target.open('wb') as dst:
                import shutil
                shutil.copyfileobj(src,dst)
