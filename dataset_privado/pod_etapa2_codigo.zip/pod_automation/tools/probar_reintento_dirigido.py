"""Piloto reproducible: cola de reintentos + lectura dirigida, aislado de produccion."""
import argparse
from collections import Counter
from copy import deepcopy
import json
import os
from pathlib import Path
import pickle
import random
import sqlite3
import statistics
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
OUT = ROOT / 'output' / 'piloto_reintento_dirigido_20261027'


def ro(name):
    return sqlite3.connect((ROOT / 'storage' / name).as_uri() + '?mode=ro', uri=True, timeout=30)


def prepare():
    OUT.mkdir(parents=True, exist_ok=True)
    with ro('report_status.db') as con:
        marks = {(d, t): status for d, t, status in con.execute(
            "SELECT query_date,tracking_number,status FROM report_status WHERE status IN ('reportado','descartado') AND " + __import__('config').REPORT_STATUS_TRUSTED_SQL)}
    cache = pickle.loads((ROOT / 'output' / 'cache_lecturas_20261005_antes.pkl').read_bytes())
    selected = []
    randomizer = random.Random(20261027)
    for status, size in [('reportado', 5), ('descartado', 11)]:
        group = [t for t in sorted(cache) if marks.get(('2026-10-05', t)) == status]
        randomizer.shuffle(group)
        selected += [('2026-10-05', t, 'lecturas_guardadas') for t in group[:size]]
    payloads = {}
    failures = {'reportado': [], 'descartado': []}
    seen = set()
    with ro('pod_checkpoints.db') as con:
        sessions = con.execute('SELECT session_id,query_date FROM audit_sessions ORDER BY started_at DESC,session_id DESC').fetchall()
        for sid, day in sessions:
            wanted = [t for d, t in marks if d == day]
            if not wanted:
                continue
            for offset in range(0, len(wanted), 400):
                batch = wanted[offset:offset+400]
                sql = 'SELECT tracking_number,payload_json FROM pod_checkpoints WHERE session_id=? AND tracking_number IN (' + ','.join('?' for _ in batch) + ')'
                for trk, raw in con.execute(sql, [sid] + batch):
                    key = (day, trk)
                    if key in seen:
                        continue
                    seen.add(key)
                    data = json.loads(raw)
                    if key in {(d, t) for d, t, source in selected}:
                        payloads[key] = data
                    status = marks[key]
                    failure = any(r.get('check') == 'vision_fallida' and r.get('applicable', True) and r.get('score', 0) > 0 for r in data.get('check_results', []))
                    if (failure and len(failures[status]) < 4 and day >= '2026-10-20'
                            and data.get('photo_paths') and all(Path(p).exists() for p in data['photo_paths'])):
                        failures[status].append(key)
                        payloads[key] = data
            if len(failures['reportado']) == len(failures['descartado']) == 4 and len(payloads) >= len(selected) + 8:
                break
    for status, keys in failures.items():
        selected += [(d, t, 'fallo_vision_reciente') for d, t in keys]
    manifest = []
    from dataclasses import asdict
    for day, trk, source in selected:
        data = payloads.get((day, trk))
        if not data:
            continue
        record = {'fecha': day, 'tracking': trk, 'marca': marks[(day, trk)], 'grupo': source, 'pod': data}
        if source == 'lecturas_guardadas':
            record['photos'] = [asdict(p) for p in cache[trk]['photos']]
        manifest.append(record)
    (OUT / 'muestra.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    return manifest


def child(index, budget):
    import config
    # No escribir lecturas de esta prueba en la cache compartida de produccion.
    config.ANALYSIS_CACHE_ENABLED = False
    from models.pod import PODRecord
    from processing.ocr_address import PhotoOCR, ocr_photo
    from processing.retry_experiment import retry_photos
    from processing.scoring import CheckResult, check_address_number, check_vision_failure, combine_scores, priority_for
    sample = json.loads((OUT / 'muestra.json').read_text(encoding='utf-8'))[index]
    pod = PODRecord.from_dict(sample['pod'])
    start = time.monotonic()
    if 'photos' in sample:
        photos = [PhotoOCR(**p) for p in sample['photos']]
    else:
        photos = [ocr_photo(p) for p in pod.photo_paths]
        failed = next(r for r in pod.check_results if r.get('check') == 'vision_fallida')
        for number in (failed.get('details') or {}).get('fotos', []):
            if 0 < number <= len(photos):
                photos[number-1].vision_error = 'fallo historico: reconstruccion con OCR actual'
    setup = time.monotonic() - start

    def projected(readings):
        # Mantener alertas ajenas al numero exactamente como estaban guardadas.
        number = check_address_number(pod, deepcopy(readings))
        matched = (number.details or {}).get('status') == 'match'
        vision = check_vision_failure([] if matched else readings)
        checks = [CheckResult(**r) for r in pod.check_results if r.get('check') not in ('numero_direccion', 'vision_fallida')]
        checks += [number, vision]
        score = combine_scores(checks)
        return {'prioridad': priority_for(score).value, 'score': score,
                'numero': number.to_dict(), 'vision': vision.to_dict()}

    before = projected(photos)
    retried, stats = retry_photos(photos, budget=budget)
    after = projected(retried)
    result = {k: sample[k] for k in ('fecha', 'tracking', 'marca', 'grupo')}
    result.update({'historico': {'prioridad': pod.priority, 'score': pod.risk_score},
                   'antes': before, 'despues': after, 'reintento': stats,
                   'preparacion_s': round(setup, 2)})
    (OUT / f'caso_{index:03}.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')


def summary(manifest):
    rows = []
    for index in range(len(manifest)):
        path = OUT / f'caso_{index:03}.json'
        if path.exists():
            rows.append(json.loads(path.read_text(encoding='utf-8')))
    good = [r for r in rows if 'error' not in r]
    flagged = lambda r, phase: r[phase]['prioridad'] in ('Alta', 'Media')
    counts = {'muestra': len(manifest), 'terminados': len(good), 'errores_ejecucion': len(rows)-len(good),
              'grupos': dict(Counter(r['grupo'] for r in good)),
              'descartados': sum(r['marca'] == 'descartado' for r in good),
              'reportados': sum(r['marca'] == 'reportado' for r in good),
              'falsas_resueltas_por_reintento': sum(r['marca'] == 'descartado' and flagged(r, 'antes') and not flagged(r, 'despues') for r in good),
              'reportados_que_se_perderian_por_reintento': sum(r['marca'] == 'reportado' and flagged(r, 'antes') and not flagged(r, 'despues') for r in good),
              'reportados_en_baja_antes': sum(r['marca'] == 'reportado' and not flagged(r, 'antes') for r in good),
              'descartados_en_baja_antes': sum(r['marca'] == 'descartado' and not flagged(r, 'antes') for r in good),
              'falsas_que_siguen_en_revision': sum(r['marca'] == 'descartado' and flagged(r, 'despues') for r in good),
              'numeros_confirmados_nuevos': sum(r['antes']['numero']['details'].get('status') != 'match' and r['despues']['numero']['details'].get('status') == 'match' for r in good),
              'consultas_completas_exitosas': sum(e.get('lectura_completa') is not None for r in good for e in r['reintento']['eventos']),
              'consultas_completas_fallidas': sum(e.get('lectura_completa') is None for r in good for e in r['reintento']['eventos']),
              'recortes_leidos': sum(isinstance(e.get('recorte'), list) for r in good for e in r['reintento']['eventos']),
              'fallos_recorte': sum(bool(e.get('error_recorte')) or isinstance(e.get('recorte'), str) for r in good for e in r['reintento']['eventos']),
              'fallos_foto_antes': sum(r['reintento']['fallos_antes'] for r in good),
              'fallos_foto_despues': sum(r['reintento']['fallos_despues'] for r in good),
              'segundos_reintento': round(sum(r['reintento']['segundos'] for r in good), 2),
              'segundos_preparacion': round(sum(r['preparacion_s'] for r in good), 2)}
    if good:
        times = [r['reintento']['segundos'] for r in good]
        counts.update({'promedio_reintento_s': round(statistics.mean(times), 2),
                       'mediana_reintento_s': round(statistics.median(times), 2),
                       'maximo_reintento_s': max(times)})
    (OUT / 'resumen.json').write_text(json.dumps(counts, ensure_ascii=False, indent=2), encoding='utf-8')
    lines = ['# Piloto: reintento automatico y lectura dirigida', '',
             'Experimento aislado. Mantiene las alertas independientes guardadas y compara solo los chequeos de numero y fallo de vision. No modifica estados ni prioridades de produccion.', '',
             'La muestra incluye lecturas antiguas reutilizadas y fallos recientes reconstruidos con OCR actual. La comparacion antes/despues usa las mismas lecturas iniciales. El historico se informa por separado. Muestra exploratoria seleccionada, sin estimacion de reduccion global.', '',
             '```json', json.dumps(counts, ensure_ascii=False, indent=2), '```', '',
             '| Tracking | Marca | Grupo | Antes | Despues | Segundos extra |', '|---|---|---|---|---|---:|']
    for r in good:
        lines.append(f"| {r['tracking']} | {r['marca']} | {r['grupo']} | {r['antes']['prioridad']} | {r['despues']['prioridad']} | {r['reintento']['segundos']} |")
    if len(rows) == len(manifest):
        lines += ['', '## Interpretacion', '',
                  f"El reintento elimino {counts['falsas_resueltas_por_reintento']} falsas alarmas adicionales. "
                  f"Habia {counts['descartados_en_baja_antes']} descartados que ya quedaban en Baja antes del reintento; no se atribuyen como mejora. "
                  f"Reportados que perderian la revision por este cambio: {counts['reportados_que_se_perderian_por_reintento']}.", '',
                  'Recuperar una lectura fallida no implica confirmar la direccion. Los fallos se reconstruyeron con OCR actual; '
                  'no se reprodujo la carga de GPU ni el fallo tecnico original. Los tiempos excluyen arranque de servicios, '
                  'preparacion de OCR y puntuacion; no equivalen al tiempo total de una corrida. '
                  'No se puede extrapolar el resultado de esta muestra al objetivo de 1-3%. '
                  'El prototipo sigue desconectado de la corrida habitual.']
    (OUT / 'informe.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    return counts


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--child', type=int)
    ap.add_argument('--budget', type=float, default=25)
    args = ap.parse_args()
    if args.child is not None:
        child(args.child, args.budget)
        return
    manifest = json.loads((OUT / 'muestra.json').read_text(encoding='utf-8')) if (OUT / 'muestra.json').exists() else prepare()
    for index, record in enumerate(manifest):
        target = OUT / f'caso_{index:03}.json'
        if target.exists():
            continue
        try:
            result = subprocess.run([sys.executable, str(Path(__file__).resolve()), '--child', str(index), '--budget', str(args.budget)],
                                    cwd=ROOT, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=120)
            if result.returncode:
                raise RuntimeError(result.stderr[-1200:])
        except Exception as error:
            target.write_text(json.dumps({'tracking': record['tracking'], 'error': str(error)}), encoding='utf-8')
        print(f"[{index+1}/{len(manifest)}] {record['tracking']} " + json.dumps(summary(manifest), ensure_ascii=False), flush=True)
    print(json.dumps(summary(manifest), ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
