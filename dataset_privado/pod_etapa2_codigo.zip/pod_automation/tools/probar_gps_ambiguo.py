"""Experimento offline: GPS cercano frente a numero ambiguo. No cambia la corrida ni las bases.

Usa chequeos historicos guardados (no vuelve a ejecutar OCR ni consulta mapas).
Compara variantes y umbrales; una marca pendiente o ausente nunca cuenta como acierto.
"""
import argparse
from collections import Counter
import json
import math
from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parents[1]


def finite(value):
    try:
        result = float(value)
        return result if math.isfinite(result) else None
    except (TypeError, ValueError):
        return None


def candidate(data, limit, allow_vision_failure=False):
    """Solo casas, lectura near_match, GPS valido y ninguna otra alerta independiente."""
    checks = data.get('check_results') or []
    number = next((r for r in checks if r.get('check') == 'numero_direccion'), {})
    details = number.get('details') or {}
    if not number.get('applicable', True) or details.get('status') != 'near_match' or details.get('unidad'):
        return False
    # Exigir que el chequeo de edificio identifique expresamente una casa.
    building = next((r for r in checks if r.get('check') == 'fotos_edificio'), {})
    if building.get('explanation') != 'No es apartamento.':
        return False
    meta = data.get('portal_meta') or {}
    dist, lat, lng = [finite(meta.get(k)) for k in ('sign_distance', 'pod_lat', 'pod_lng')]
    if dist is None or not 0 <= dist <= limit or lat is None or lng is None:
        return False
    if not -90 <= lat <= 90 or not -180 <= lng <= 180 or (lat == 0 and lng == 0):
        return False
    ignored = {'numero_direccion'}
    if allow_vision_failure:
        ignored.add('vision_fallida')
    for check in checks:
        if check.get('applicable', True):
            if check.get('force_report'):
                return False
            if check.get('check') not in ignored and float(check.get('score', 0)) > 0:
                return False
    return True


def ro(path):
    return sqlite3.connect(path.resolve().as_uri() + '?mode=ro', uri=True, timeout=30)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path, default=ROOT / 'output' / 'prueba_gps_ambiguo_20261027.json')
    args = ap.parse_args()
    with ro(ROOT / 'storage' / 'report_status.db') as con:
        truth = {(day, trk): status for day, trk, status in con.execute(
            'SELECT query_date,tracking_number,status FROM report_status WHERE ' + __import__('config').REPORT_STATUS_TRUSTED_SQL) if status in ('reportado', 'descartado')}
    for path in sorted((ROOT / 'tests').glob('casos_reales_*.json')):
        stamp = path.stem.rsplit('_', 1)[1]
        day = f'{stamp[:4]}-{stamp[4:6]}-{stamp[6:]}'
        for case in json.loads(path.read_text(encoding='utf-8-sig')).get('casos', []):
            truth[(day, case['tracking'])] = 'descartado' if case['esperado'] == 'ok' else 'reportado'
    latest = {}
    with ro(ROOT / 'storage' / 'pod_checkpoints.db') as con:
        # Incluir Baja para que una reevaluacion posterior no deje una Media antigua como vigente.
        sessions = con.execute('SELECT session_id,query_date FROM audit_sessions ORDER BY started_at').fetchall()
        for session, day in sessions:
            for trk, priority, payload in con.execute('''
                SELECT tracking_number,priority,
                       CASE WHEN priority IN ('Alta','Media') THEN payload_json ELSE NULL END
                FROM pod_checkpoints WHERE session_id=?''', (session,)):
                key = (day, trk)
                if priority in ('Alta', 'Media'):
                    latest[key] = json.loads(payload)
                else:
                    latest.pop(key, None)
    variants = []
    for allow in (False, True):
        for limit in (5, 10, 15, 20, 30):
            counts = Counter()
            cases = []
            for (day, trk), data in latest.items():
                if not candidate(data, limit, allow):
                    continue
                status = truth.get((day, trk), 'sin_revisar')
                counts[status] += 1
                num = next(r for r in data['check_results'] if r['check'] == 'numero_direccion')
                cases.append({'fecha': day, 'tracking': trk, 'marca': status,
                              'distancia': finite(data['portal_meta']['sign_distance']),
                              'direccion': data.get('receipt_address') or data.get('address'),
                              'motivo': num.get('explanation')})
            variants.append({'max_metros': limit, 'ignora_fallo_vision': allow,
                             'candidatos': len(cases), 'marcas': dict(counts), 'casos': cases})
    result = {'metodo': 'Simulacion con chequeos historicos; sin OCR nuevo ni consulta cartografica. '
              'Reportado/descartado son decisiones humanas registradas; fixtures explicados tienen precedencia. '
              'No demuestra que un punto GPS pertenezca a una parcela. No cambia prioridades guardadas.',
              'revisiones_vigentes': len(latest),
              'fechas': sorted({day for day, _ in latest}), 'variantes': variants}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    lines = ['# Prueba de GPS para numeros ambiguos', '', result['metodo'], '',
             f'Revisiones vigentes examinadas: {len(latest)}.', '',
             '| Maximo (m) | Quita fallo de vision | Candidatos | Descartados | Reportados | Sin revisar |',
             '|---:|:---:|---:|---:|---:|---:|']
    for variant in variants:
        print(json.dumps({k: v for k, v in variant.items() if k != 'casos'}, ensure_ascii=False))
        marks = variant['marcas']
        lines.append(f"| {variant['max_metros']} | {'Si' if variant['ignora_fallo_vision'] else 'No'} | "
                     f"{variant['candidatos']} | {marks.get('descartado', 0)} | "
                     f"{marks.get('reportado', 0)} | {marks.get('sin_revisar', 0)} |")
    lines += ['', 'Candidatos: revisiones que hipoteticamente pasarian a Baja al quitar los motivos indicados. '
              'Descartados: falsas alarmas segun las marcas. Reportados: errores confirmados que se ocultarian. '
              'Sin revisar: resultado desconocido; no se cuenta como mejora.', '',
              'Los umbrales son exploratorios. El historial usa diferentes versiones de las reglas. '
              'No hay validacion independiente de parcelas ni precision GPS. '
              'No activar una variante solo porque no aparezcan errores en una muestra pequena.', '']
    args.out.with_suffix('.md').write_text('\n'.join(lines), encoding='utf-8')
    print(args.out)


if __name__ == '__main__':
    main()
