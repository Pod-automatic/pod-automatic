"""Diagnostico de una corrida de Kaggle: una muestra cada minuto y un ZIP descargable (Output > diagnostico_kaggle.zip).

28/10: la corrida nocturna solo dejaba el visor de logs (retrasado y lleno de barras de descarga). Aqui se guardan, sin
credenciales ni fotos, los logs de cada sesion, el ritmo, la GPU/CPU/RAM por minuto y las bases de resultados para analizar
la corrida despues y decidir optimizaciones. Solo se incluyen archivos de una lista permitida."""
import json
import re
import sqlite3
import subprocess
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path

WORKERS = ('gpu_luis', 'gpu_tracking')
PATTERNS = {
    'http_500': r'HTTP 500',
    'vision_capped': r'VisionCapped',
    'respuesta_no_json': r'respuesta no JSON',
    'sesion_vencida': r'[Ss]esi[oó]n vencida',
    'modelo_mayor_no_disponible': r'Modelo mayor no disponible',
    'recarga_global_omitida': r'se omite recarga global',
}


def parse_gpu_csv(text):
    rows = []
    for line in (text or '').splitlines():
        parts = [part.strip() for part in line.split(',')]
        if len(parts) != 4: continue
        try:
            index, util, used, total = (int(part) for part in parts)
        except ValueError:
            continue
        rows.append({'gpu': index, 'util_pct': util, 'mem_used_mib': used, 'mem_total_mib': total,
                     'mem_free_mib': total - used})
    return rows


def summarize_log_text(text):
    counts = {name: len(re.findall(pattern, text)) for name, pattern in PATTERNS.items()}
    return {name: n for name, n in counts.items() if n}


def default_activity(root, worker):
    root = Path(root)
    try:
        import os
        env = dict(os.environ, STORAGE_DIR=str(root / 'storage' / 'multi' / 'workers' / worker))
        done = subprocess.run([str(root / 'venv' / 'bin' / 'python'), 'tools/activity_report.py', '--json'], cwd=root,
                              env=env, capture_output=True, text=True, timeout=30)
        return json.loads(done.stdout)
    except Exception as error:
        return {'error': type(error).__name__}


def _slot_busy(path):
    """Cupos ocupados ahora en una cola SQLite compartida: {url_base: (ocupados, total)}. Nunca lanza."""
    import time as _time
    out = {}
    try:
        con = sqlite3.connect(f'file:{Path(path).as_posix()}?mode=ro', uri=True, timeout=0.5)
        try:
            now = _time.time()
            for key, until in con.execute('SELECT url, until FROM gpu_slots'):
                base = key.split('#')[0]
                busy, total = out.get(base, (0, 0))
                out[base] = (busy + (1 if until and until > now else 0), total + 1)
        finally:
            con.close()
    except Exception:
        pass
    return out


def _burst(root, runner, burst, gap):
    """Lecturas cortas (burst x gap s) de GPU, CPU por nucleo, procesos y ocupacion de las colas: una foto instantanea por
    minuto engana (28/10: la GPU parecia ociosa o saturada segun el instante)."""
    import os
    import time as _time
    gpu_readings, cpu_cores, busy_samples = [], [], {'vision': [], 'analysis': []}
    procs, top = {}, {}
    try:
        import psutil
        for proc in psutil.process_iter(['name']):
            try: proc.cpu_percent(None); procs[proc.pid] = proc
            except Exception: pass
    except Exception:
        psutil = None
    shared = Path(root) / 'storage' / 'multi'
    for _ in range(max(1, burst)):
        try:
            rows = parse_gpu_csv(runner(['nvidia-smi', '--query-gpu=index,utilization.gpu,memory.used,memory.total',
                                         '--format=csv,noheader,nounits'], capture_output=True, text=True, timeout=10).stdout)
            if rows: gpu_readings.append(rows)
        except Exception:
            pass
        for kind, name in (('vision', 'gpu_slots.db'), ('analysis', 'analysis_pool.db')):
            if (shared / name).exists():
                busy_samples[kind].append(_slot_busy(shared / name))
        if psutil is not None:
            try: cpu_cores.append(psutil.cpu_percent(interval=gap, percpu=True))
            except Exception: _time.sleep(gap)
        else:
            _time.sleep(gap)
    if psutil is not None:
        for pid, proc in procs.items():
            try:
                pct = proc.cpu_percent(None)
                if pct and proc.name() not in ('System Idle Process',):
                    top[proc.name()] = round(top.get(proc.name(), 0) + pct, 1)
            except Exception: pass
    result = {'gpus': [], 'cpu': {}, 'top': dict(sorted(top.items(), key=lambda kv: -kv[1])[:5]), 'occupancy': {}}
    if gpu_readings:
        last = gpu_readings[-1]
        for item in last:
            utils = [r['util_pct'] for reading in gpu_readings for r in reading if r['gpu'] == item['gpu']]
            result['gpus'].append(dict(item, util_pct=round(sum(utils) / len(utils)), util_max_pct=max(utils)))
    if cpu_cores:
        cores = list(zip(*cpu_cores))
        means = [sum(c) / len(c) for c in cores]
        result['cpu'] = {'logicas': len(means), 'cpu_pct': round(sum(means) / len(means), 1),
                         'nucleos_calientes': sum(1 for m in means if m >= 90), 'nucleo_max_pct': round(max(means), 1)}
    for kind, snaps in busy_samples.items():
        if not snaps: continue
        agg = {}
        for snap in snaps:
            for base, (busy, total) in snap.items():
                b, t, n = agg.get(base, (0, 0, 0)); agg[base] = (b + busy, total, n + 1)
        result['occupancy'][kind] = {base: {'ocupado_pct': round(100 * b / (t * n), 1) if t and n else None, 'cupos': t}
                                     for base, (b, t, n) in agg.items()}
    return result


def sample(root, workers=WORKERS, runner=subprocess.run, activity=None, burst=8, gap=0.25):
    """Una fila de metricas. Nunca lanza: si una herramienta falta, ese campo queda vacio."""
    activity = activity or (lambda worker: default_activity(root, worker))
    row = {'time_utc': datetime.now(timezone.utc).isoformat(timespec='seconds'), 'gpus': [], 'cpu': {},
           'models': {}, 'workers': {}}
    try:
        measured = _burst(root, runner, burst, gap)
        row['gpus'] = measured['gpus']
        row['cpu'] = measured['cpu']
        row['top'] = measured['top']
        row['occupancy'] = measured['occupancy']
    except Exception:
        pass
    try:
        import psutil
        row['cpu'] = dict({'logicas': psutil.cpu_count(), 'ram_pct': psutil.virtual_memory().percent}, **row['cpu'])
        row['cpu'].setdefault('cpu_pct', psutil.cpu_percent(interval=0.2))
    except Exception:
        pass
    for gpu in (0, 1):
        try:
            import os
            out = runner(['ollama', 'ps'], env=dict(os.environ, OLLAMA_HOST=f'127.0.0.1:{11434 + gpu}'),
                         capture_output=True, text=True, timeout=10).stdout
            row['models'][str(gpu)] = [line.split()[0] for line in out.splitlines()[1:] if line.strip()]
        except Exception:
            pass
    for worker in workers:
        try:
            row['workers'][worker] = activity(worker)
        except Exception as error:
            row['workers'][worker] = {'error': type(error).__name__}
    return row


def append_sample(path, row):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a', encoding='utf-8') as handle:
        handle.write(json.dumps(row, ensure_ascii=False) + '\n')


def _tail(path, limit):
    size = Path(path).stat().st_size
    with open(path, 'rb') as handle:
        if size > limit: handle.seek(size - limit)
        return handle.read()


def _gpu_summary(metrics_path):
    peaks = {}
    if not Path(metrics_path).exists(): return peaks
    for line in Path(metrics_path).read_text(encoding='utf-8', errors='replace').splitlines():
        try: row = json.loads(line)
        except ValueError: continue
        for gpu in row.get('gpus', []):
            item = peaks.setdefault(str(gpu['gpu']), {'mem_used_max_mib': 0, 'util_sum': 0, 'n': 0})
            item['mem_used_max_mib'] = max(item['mem_used_max_mib'], gpu['mem_used_mib'])
            item['util_sum'] += gpu['util_pct']; item['n'] += 1
    return {gpu: {'mem_used_max_mib': item['mem_used_max_mib'], 'util_media_pct': round(item['util_sum'] / item['n'], 1)}
            for gpu, item in peaks.items() if item['n']}


def build_bundle(root, working, destination, max_log_bytes=20_000_000):
    """ZIP atomico con logs, ritmo y resultados. Lista permitida: nada de cookies, claves ni fotos."""
    root, working, destination = Path(root), Path(working), Path(destination)
    pending = destination.with_suffix('.tmp')
    summary = {'generado_utc': datetime.now(timezone.utc).isoformat(timespec='seconds'), 'workers': {}}
    with tempfile.TemporaryDirectory() as folder, zipfile.ZipFile(pending, 'w', zipfile.ZIP_DEFLATED) as archive:
        def add_tail(source, name):
            archive.writestr(name, _tail(source, max_log_bytes))
        workers_dir = root / 'storage' / 'multi' / 'workers'
        for worker_dir in sorted(p for p in workers_dir.glob('*') if p.is_dir()) if workers_dir.exists() else []:
            counts = {}
            for log in sorted((worker_dir / 'logs').glob('*.log')):
                add_tail(log, f'workers/{worker_dir.name}/logs/{log.name}')
                for key, n in summarize_log_text(_tail(log, max_log_bytes).decode('utf-8', 'replace')).items():
                    counts[key] = counts.get(key, 0) + n
            for jsonl in sorted(worker_dir.glob('*.jsonl')):
                add_tail(jsonl, f'workers/{worker_dir.name}/{jsonl.name}')
            for state in sorted(worker_dir.glob('runtime_*.json')):
                archive.write(state, f'workers/{worker_dir.name}/{state.name}')
            database = worker_dir / 'pod_checkpoints.db'
            if database.exists():
                snapshot = Path(folder) / f'{worker_dir.name}.db'
                src = sqlite3.connect(f'file:{database.as_posix()}?mode=ro', uri=True)
                dst = sqlite3.connect(snapshot)
                try: src.backup(dst)
                finally:
                    dst.close(); src.close()
                archive.write(snapshot, f'workers/{worker_dir.name}/pod_checkpoints.db')
            summary['workers'][worker_dir.name] = counts
        for name in ['multiciudad.log'] + [f'ollama{g}_multi.log' for g in (0, 1)] + [f'paddle{g}_multi.log' for g in (0, 1)]:
            if (working / name).exists(): add_tail(working / name, name)
        metrics = working / 'diagnostico' / 'metricas.jsonl'
        if metrics.exists():
            add_tail(metrics, 'metricas.jsonl')
        supervisor = root / 'storage' / 'multi' / 'supervisor.json'
        if supervisor.exists(): archive.write(supervisor, 'supervisor.json')
        summary['gpus'] = _gpu_summary(metrics)
        archive.writestr('resumen.json', json.dumps(summary, ensure_ascii=False, indent=1))
    pending.replace(destination)
    return destination
