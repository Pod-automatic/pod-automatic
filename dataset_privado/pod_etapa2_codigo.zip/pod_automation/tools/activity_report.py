"""Resumen temporal real para la PC y el monitor de Kaggle."""
import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import config
from automation.activity import recent_activity


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--window',type=int,default=300)
    parser.add_argument('--json',action='store_true')
    args=parser.parse_args()
    activity=recent_activity(config.THROUGHPUT_LOG_PATH,args.window)
    states=[]
    for path in config.RUNTIME_STATE_DIR.glob('runtime_*.json'):
        try:
            states.append(json.loads(path.read_text(encoding='utf-8')))
        except (OSError,ValueError):
            continue
    activity['runtime']=max(states,key=lambda row:row.get('updated_at','')) if states else None
    print(json.dumps(activity,ensure_ascii=False) if args.json else
          f"Ultimos {args.window//60} min: {activity['completed_recent']} analizados, "
          f"{activity['actual_per_hour']}/h; sin completar: {activity['idle_seconds']} s; "
          f"mediana reciente: {activity['median_seconds_recent']} s.")


if __name__=='__main__':
    main()
