"""
Dónde está el cuello de botella de una corrida de Kaggle (29/10/2026): GPU, CPU, análisis o falta de trabajo.

Usa las muestras de tools/kaggle_diagnostico.py (una por minuto, con ráfagas de GPU/CPU y la ocupación de la cola de visión y
de los cuatro procesos de análisis) y el ritmo de extracción y análisis de cada sesión. Solo lee; no toca la corrida.

  En vivo: la celda 6 del notebook lo imprime cada 10 minutos (informe_cuello).
  Después:  python tools/cuello_kaggle.py diagnostico_kaggle.zip [--ventana 30]
            python tools/cuello_kaggle.py metricas.jsonl [--ventana 30]
El veredicto es una heurística: indica qué recurso está saturado, no sustituye mirar los números.
"""
import argparse
import io
import json
import sys
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

SATURADO = 85.0     # % de uso desde el que un recurso se considera el límite
OCIOSO = 50.0       # % de ocupación del análisis por debajo del cual falta trabajo


def _parse_ts(value):
    try:
        ts = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
    except ValueError:
        return None
    return ts if ts.tzinfo else ts.replace(tzinfo=timezone.utc)


def _mean(values):
    values = [v for v in values if v is not None]
    return round(sum(values) / len(values), 1) if values else None


def evaluate(rows, throughput=None, ventana_min=10, end=None):
    """rows: muestras de metricas.jsonl. throughput: filas de throughput.jsonl de los procesos ({'ts','status'})."""
    rows = [r for r in rows if _parse_ts(r.get('time_utc'))]
    if not rows:
        return {'veredicto': 'sin_datos', 'texto': 'Sin muestras: no hay datos para decidir.'}
    end = end or _parse_ts(rows[-1]['time_utc'])
    start = end - timedelta(minutes=ventana_min)
    win = [r for r in rows if start <= _parse_ts(r['time_utc']) <= end]
    out = {'muestras': len(win), 'ventana_min': ventana_min}

    gpus = {}
    for r in win:
        for g in r.get('gpus') or []:
            item = gpus.setdefault(g['gpu'], {'util': [], 'mem': [], 'tot': g.get('mem_total_mib')})
            item['util'].append(g['util_pct']); item['mem'].append(g['mem_used_mib'])
    out['gpu'] = {str(i): {'util_media_pct': _mean(v['util']), 'util_max_pct': max(v['util']),
                           'memoria_max_pct': round(100 * max(v['mem']) / v['tot']) if v['tot'] else None}
                  for i, v in gpus.items()}
    cpu = [r.get('cpu') or {} for r in win]
    out['cpu'] = {'cpu_media_pct': _mean([c.get('cpu_pct') for c in cpu]),
                  'nucleo_max_media_pct': _mean([c.get('nucleo_max_pct') for c in cpu]),
                  'nucleos_calientes_max': max([c.get('nucleos_calientes') or 0 for c in cpu] or [0]),
                  'logicas': next((c['logicas'] for c in cpu if c.get('logicas')), None),
                  'ram_max_pct': max([c.get('ram_pct') or 0 for c in cpu] or [0])}
    top = {}
    for r in win:
        for name, pct in (r.get('top') or {}).items():
            top.setdefault(name, []).append(pct)
    out['procesos_top'] = dict(sorted(((n, _mean(v)) for n, v in top.items()), key=lambda kv: -kv[1])[:5])

    def occupancy(kind):
        per = {}
        for r in win:
            for base, v in ((r.get('occupancy') or {}).get(kind) or {}).items():
                per.setdefault(base, []).append(v.get('ocupado_pct'))
        return {base: _mean(v) for base, v in per.items()}
    out['vision_ocupacion_pct'] = occupancy('vision')
    out['analisis_ocupacion_pct'] = occupancy('analysis')

    if throughput:
        done = [t for t in throughput if (_parse_ts(t.get('ts')) or end) >= start and (_parse_ts(t.get('ts')) or end) <= end]
        extracted = sum(1 for t in done if t.get('status') == 'PROCESSED')
        analyzed = sum(1 for t in done if t.get('status') == 'ANALYZED')
        horas = ventana_min / 60
        out['ritmo_por_hora'] = {'extraidos': round(extracted / horas), 'analizados': round(analyzed / horas)}

    gpu_hot = [i for i, g in out['gpu'].items() if (g['util_media_pct'] or 0) >= SATURADO]
    slots_hot = [b for b, v in out['vision_ocupacion_pct'].items() if (v or 0) >= SATURADO]
    cpu_hot = ((out['cpu']['cpu_media_pct'] or 0) >= SATURADO
               or (out['cpu']['logicas'] and out['cpu']['nucleos_calientes_max'] >= max(2, out['cpu']['logicas'] - 1)))
    analysis = _mean(list(out['analisis_ocupacion_pct'].values()))
    out['analisis_ocupado_pct'] = analysis
    if cpu_hot:
        out['veredicto'] = 'cpu'
        out['texto'] = ('CPU: es el límite. Los procesos de análisis, el navegador y los servicios se disputan los '
                        f'{out["cpu"]["logicas"]} núcleos. Más GPU no ayuda; hay que bajar carga de CPU o usar otra máquina.')
    elif gpu_hot or slots_hot:
        out['veredicto'] = 'gpu'
        out['texto'] = ('GPU / cola de visión: está saturada. Más consultas simultáneas o una GPU más grande sí aumentarían el ritmo.')
    elif analysis is not None and analysis >= SATURADO:
        out['veredicto'] = 'analisis_espera'
        out['texto'] = ('Análisis: los 4 procesos están ocupados casi todo el tiempo, pero ni la GPU ni la CPU están saturadas. '
                        'Esperan algo externo (Paddle, red o portal) o cada albarán se atasca en una etapa lenta.')
    elif analysis is not None and analysis < OCIOSO:
        out['veredicto'] = 'sin_trabajo'
        out['texto'] = (f'Falta trabajo: el análisis está ocupado solo el {analysis:.0f} % del tiempo. El límite está antes: extracción, '
                        'turnos de la sesión de GOFO, reservas del portal o descargas.')
    elif analysis is None:
        out['veredicto'] = 'sin_datos_de_colas'
        out['texto'] = 'No hay datos de ocupación de las colas; con GPU y CPU no saturadas, el límite no es esa máquina.'
    else:
        out['veredicto'] = 'mixto'
        out['texto'] = 'Sin un recurso saturado: el análisis está a ratos ocupado y a ratos esperando trabajo.'
    return out


def format_report(result):
    if result.get('veredicto') == 'sin_datos':
        return 'Cuello de botella: ' + result['texto']
    g = ', '.join(f'GPU{i} {v["util_media_pct"]}% (máx {v["util_max_pct"]}%, memoria {v["memoria_max_pct"]}%)'
                  for i, v in result['gpu'].items()) or 'sin datos de GPU'
    c = result['cpu']
    lines = [f'=== Cuello de botella (últimos {result["ventana_min"]} min, {result["muestras"]} muestras) ===',
             f'VEREDICTO: {result["texto"]}',
             f'  {g}',
             f'  CPU {c["cpu_media_pct"]}% de {c["logicas"]} núcleos (núcleo más cargado {c["nucleo_max_media_pct"]}%, '
             f'hasta {c["nucleos_calientes_max"]} núcleos ≥90%), RAM máx {c["ram_max_pct"]}%',
             f'  Cola de visión ocupada: {result["vision_ocupacion_pct"] or "sin datos"} | análisis ocupado: '
             f'{result["analisis_ocupacion_pct"] or "sin datos"}',
             f'  Procesos que más CPU usan: {result["procesos_top"] or "sin datos"}']
    if 'ritmo_por_hora' in result:
        r = result['ritmo_por_hora']
        lines.append(f'  Ritmo: {r["extraidos"]} extraídos/h y {r["analizados"]} analizados/h')
    return '\n'.join(lines)


def _read_jsonl(text):
    out = []
    for line in text.splitlines():
        try: out.append(json.loads(line))
        except ValueError: pass
    return out


def informe_cuello(metrics_path, root, ventana_min=10):
    """En vivo, desde la celda 6: lee las muestras y el ritmo de cada sesión."""
    rows = _read_jsonl(Path(metrics_path).read_text(encoding='utf-8', errors='replace')) if Path(metrics_path).exists() else []
    throughput = []
    for path in sorted((Path(root) / 'storage' / 'multi' / 'workers').glob('*/throughput.jsonl')):
        size = path.stat().st_size
        with open(path, 'rb') as handle:
            if size > 400_000: handle.seek(size - 400_000)
            throughput += _read_jsonl(handle.read().decode('utf-8', errors='replace'))
    return format_report(evaluate(rows, throughput, ventana_min))


def evaluate_bundle(source, ventana_min=30):
    """source: diagnostico_kaggle.zip o metricas.jsonl."""
    source = Path(source)
    throughput = []
    if source.suffix == '.zip':
        with zipfile.ZipFile(source) as archive:
            rows = _read_jsonl(archive.read('metricas.jsonl').decode('utf-8', errors='replace')) if 'metricas.jsonl' in archive.namelist() else []
            for name in archive.namelist():
                if name.endswith('throughput.jsonl'):
                    throughput += _read_jsonl(archive.read(name).decode('utf-8', errors='replace'))
    else:
        rows = _read_jsonl(source.read_text(encoding='utf-8', errors='replace'))
    return evaluate(rows, throughput, ventana_min)


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('fuente', help='diagnostico_kaggle.zip o metricas.jsonl')
    ap.add_argument('--ventana', type=int, default=30, help='minutos finales a analizar (30)')
    args = ap.parse_args()
    sys.stdout.reconfigure(encoding='utf-8')
    print(format_report(evaluate_bundle(args.fuente, args.ventana)))
