"""Notebook privado reproducible para medir 3B/7B en T4 sin credenciales ni consultas a GOFO."""
import base64
import io
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parents[1]


def main():
    code=io.BytesIO()
    with zipfile.ZipFile(code,'w',zipfile.ZIP_DEFLATED) as z:
        for folder in ('automation','processing','models','storage','export'):
            for path in (ROOT/folder).glob('*.py'):
                z.write(path,path.relative_to(ROOT).as_posix())
        z.write(ROOT/'config.py','config.py')
        for name in ('benchmark_gpu_concurrency.py','benchmark_address_policies.py','paddle_ocr_server.py'):
            z.write(ROOT/'tools'/name,'tools/'+name)
        z.writestr('tools/__init__.py','')
    encoded=base64.b64encode(code.getvalue()).decode()
    cells=[]
    def markdown(text): cells.append({'cell_type':'markdown','metadata':{},'source':text.splitlines(keepends=True)})
    def python(text):
        compile(text,'benchmark cell','exec')
        cells.append({'cell_type':'code','metadata':{},'execution_count':None,'outputs':[],'source':text.splitlines(keepends=True)})
    markdown('# POD: comparacion real 3B / 7B y concurrencia\n\nNotebook PRIVADO. Adjuntar como Input la salida del notebook56802cff4f (ya esta en Kaggle). '
             'No usa cookies ni claves, no consulta GOFO ni envia albaranes al portal. Activar GPU T4 x2 e Internet. '
             'Comparar tiempos de lectura y del numero de direccion; no confundirlos con una auditoria completa. '
             'Sin etiquetas humanas, mas coincidencias no prueban mayor exactitud.\n')
    python("""import os,sys,json,subprocess,base64,io,zipfile
from pathlib import Path
ROOT=Path('/kaggle/working/pod_benchmark')
ROOT.mkdir(exist_ok=True)
"""+f"zipfile.ZipFile(io.BytesIO(base64.b64decode({encoded!r}))).extractall(ROOT)\n"+"""os.chdir(ROOT)
os.environ.update(STORAGE_DIR=str(ROOT/'storage_benchmark'),ANALYSIS_CACHE_ENABLED='false',
                 GOFO_SESSION_GROUP='',CLAIM_WORK='',PORTAL_URL='',PORTAL_API_KEY='',
                 OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1')
print(subprocess.run(['nvidia-smi','--query-gpu=name,memory.total','--format=csv,noheader'],capture_output=True,text=True,check=True).stdout)
gpus=subprocess.run(['nvidia-smi','--query-gpu=index','--format=csv,noheader'],capture_output=True,text=True,check=True).stdout.splitlines()
assert len(gpus)>=2,'Esta matriz requiere las dos T4; no medir 7B parcialmente en CPU.'
""")
    python("""import sqlite3,random
databases=list(Path('/kaggle/input').rglob('pod_checkpoints.db'))
assert databases,'Adjuntar la salida privada de la corrida anterior como Input.'
db=databases[0];images=db.parent/'pod_images'
assert images.exists(),'La salida debe incluir las fotos originales.'
def actual_path(value):
    text=str(value).replace('\\\\','/')
    suffix=text.split('/pod_images/',1)[-1]
    candidate=images/suffix
    return candidate if candidate.is_file() else None
cases=[]
with sqlite3.connect('file:'+db.as_posix()+'?mode=ro',uri=True) as con:
    for predicate in ('risk_score>=40','risk_score<40'):
        rows=con.execute('SELECT payload_json FROM pod_checkpoints WHERE '+predicate+' ORDER BY created_at DESC LIMIT 100').fetchall()
        added=0
        for row in rows:
            pod=json.loads(row[0]);paths=[actual_path(p) for p in pod.get('photo_paths',[])]
            paths=[str(p) for p in paths if p]
            if not paths or not pod.get('address'): continue
            cases.append({'id':str(len(cases)),'address':pod['address'],'paths':paths})
            added+=1
            if added>=3: break
assert cases,'No se encontraron entregas con fotos accesibles.'
(ROOT/'cases.json').write_text(json.dumps(cases),encoding='utf-8')
(ROOT/'manifest.json').write_text(json.dumps([p for c in cases for p in c['paths']]),encoding='utf-8')
print('Muestra privada:',len(cases),'entregas,',sum(len(c['paths']) for c in cases),'fotos. No son etiquetas humanas.')
""")
    python("""import urllib.request
subprocess.run([sys.executable,'-m','venv','--system-site-packages','bench_env'],check=True)
PY=str(ROOT/'bench_env/bin/python')
subprocess.run([PY,'-m','pip','-q','install','psutil','pillow','numpy','opencv-python-headless','pydantic','python-dotenv','pytesseract','imagehash','rich','tzdata'],check=True)
old=list(Path('/kaggle/input').rglob('venv_paddle/bin/python'))
PADDLE_PY=None
for candidate in old:
    probe=subprocess.run([str(candidate),'-c','import paddle,paddleocr; assert paddle.is_compiled_with_cuda()'],capture_output=True)
    if probe.returncode==0:
        PADDLE_PY=str(candidate);break
if not PADDLE_PY:
    subprocess.run([sys.executable,'-m','venv','paddle_env'],check=True)
    PADDLE_PY=str(ROOT/'paddle_env/bin/python')
    subprocess.run([PADDLE_PY,'-m','pip','-q','install','paddlepaddle-gpu==3.3.1','-i','https://www.paddlepaddle.org.cn/packages/stable/cu126/'],check=True)
    subprocess.run([PADDLE_PY,'-m','pip','-q','install','paddleocr==3.7.0','paddlex==3.7.2','numpy==2.3.5','opencv-contrib-python==4.10.0.84','pillow==12.1.0','psutil'],check=True)
if subprocess.run(['sh','-c','command -v ollama'],capture_output=True).returncode:
    subprocess.run('curl -fsSL https://ollama.com/install.sh | sh',shell=True,check=True)
print('Entornos listos. La carga y descarga inicial de modelos se excluye de las mediciones.')
""")
    python("""import time
sys.path.insert(0,str(ROOT))
from tools.benchmark_gpu_concurrency import service
import psutil
cpus=psutil.Process().cpu_affinity()[:4]
psutil.Process().cpu_affinity(cpus)
base=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PADDLE_MAX_RAM_MB='10000')
bootstrap=dict(base,OLLAMA_HOST='127.0.0.1:11543',CUDA_VISIBLE_DEVICES='0')
with service(['ollama','serve'],bootstrap,'http://127.0.0.1:11543/api/tags',ROOT/'bootstrap.log',cpus):
    for model in ('qwen2.5vl:3b','qwen2.5vl:7b'):
        subprocess.run(['ollama','pull',model],env=bootstrap,check=True)
results=ROOT/'results';results.mkdir(exist_ok=True)
def command(model,gpu,batch=1):
    return [PY,'tools/benchmark_gpu_concurrency.py','--manifest',str(ROOT/'manifest.json'),
            '--engines','pipeline','--model',model,'--gpu',str(gpu),'--paddle-python',PADDLE_PY,
            '--photo-batch-size',str(batch),'--require-full-gpu']
for model,gpu in (('qwen2.5vl:3b',0),('qwen2.5vl:7b',1)):
    for batch in (1,2):
        target=results/(model.replace(':','_')+f'_batch{batch}')
        subprocess.run(command(model,gpu,batch)+['--output',str(target)],env=base,check=True)
print('Matriz individual completada. Revisar errores y size_vram antes de comparar.')
""")
    python("""from contextlib import ExitStack
from tools.benchmark_gpu_concurrency import http_json
services_base=dict(base,OLLAMA_MAX_LOADED_MODELS='1',OLLAMA_CONTEXT_LENGTH='2048',OLLAMA_FLASH_ATTENTION='1',OLLAMA_KEEP_ALIVE='-1')
with ExitStack() as stack:
    for gpu,port,model,parallel in ((0,11544,'qwen2.5vl:3b',2),(1,11545,'qwen2.5vl:7b',1)):
        envg=dict(services_base,CUDA_VISIBLE_DEVICES=str(gpu),OLLAMA_HOST=f'127.0.0.1:{port}',OLLAMA_NUM_PARALLEL=str(parallel))
        stack.enter_context(service(['ollama','serve'],envg,f'http://127.0.0.1:{port}/api/tags',ROOT/f'policy_ollama{gpu}.log',cpus))
        http_json(f'http://127.0.0.1:{port}/api/generate',{'model':model,'prompt':'hi','stream':False,'keep_alive':-1,'options':{'num_ctx':2048,'num_predict':3}},timeout=300)
        loaded=http_json(f'http://127.0.0.1:{port}/api/ps').get('models',[])
        assert loaded and all(m.get('size_vram',0)>=.98*m.get('size',1) for m in loaded),'Modelo parcialmente en CPU: prueba invalida.'
    stack.enter_context(service([PADDLE_PY,'tools/paddle_ocr_server.py','--port','8870'],dict(base,CUDA_VISIBLE_DEVICES='0'),
                                'http://127.0.0.1:8870/health',ROOT/'policy_paddle.log',cpus))
    policy_env=dict(base,PADDLE_OCR_PORT='8870',PADDLE_OCR_PORTS='8870',OCR_ENGINE='paddle',VISION_ENABLED='true',ANALYSIS_CACHE_ENABLED='false')
    subprocess.run([PY,'tools/benchmark_address_policies.py','--cases',str(ROOT/'cases.json'),'--output',str(results/'policies.json')],env=policy_env,check=True)
print('Cascada comparada. Este ensayo limita el OCR a una instancia para aislar la decision de escalamiento.')
""")
    python("""table=[]
for path in results.glob('*/results.json'):
    report=json.loads(path.read_text())
    for row in report.get('summary',[]):
        table.append(dict(model=report['model'],batch=report['photo_batch_size'],gpu=report['gpu'],**row))
    if report.get('failures'): print('INCONCLUSO:',path.parent.name,report['failures'])
(results/'summary.json').write_text(json.dumps(table,indent=2),encoding='utf-8')
for row in table: print(json.dumps(row),flush=True)
print('Los servicios de prueba se cerraron. Detener tambien la sesion de Kaggle para liberar su cuota.')
print('Descargar results/ para elegir por rendimiento, estabilidad y cambios de decision; no elegir por VRAM ocupada.')
""")
    out=ROOT/'output/benchmark_t4_3b_7b_20261028.ipynb'
    out.write_text(json.dumps({'nbformat':4,'nbformat_minor':5,'metadata':{'kernelspec':{
        'display_name':'Python 3','language':'python','name':'python3'}},'cells':cells},ensure_ascii=False,indent=1),encoding='utf-8')
    print(out,out.stat().st_size,'bytes')


if __name__=='__main__': main()
