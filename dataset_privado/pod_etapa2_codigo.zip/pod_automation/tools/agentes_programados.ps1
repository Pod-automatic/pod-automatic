# Corre los agentes de Claude Code de noche en MODO PROPUESTA (Programador de tareas de Windows), 07/10/2026.
#
# El agente trabaja en una COPIA del codigo (output\agentes\<tarea>_<dia>\copia) con git propio: puede editar y probar
# ahi, pero el codigo real nunca se toca. Al terminar quedan, en output\agentes\<tarea>_<dia>\:
#   INFORME.md     lo que hizo y lo que necesita decision del usuario
#   cambios.diff   (corrector) los cambios propuestos; se aplican a mano con tools\aplicar_propuesta.ps1
#   registro.log   salida completa de la corrida
#
#   corrector : pendientes del dia (antes de mediodia toma el dia anterior). Una vez por dia.
#   agrupador : falsas alarmas agrupadas; su archivo de propuestas se copia a output\
#
# Uso:  powershell -ExecutionPolicy Bypass -File tools\agentes_programados.ps1 -Tarea corrector|agrupador [-Forzar]

param(
    [Parameter(Mandatory = $true)][ValidateSet("corrector", "agrupador")][string]$Tarea,
    [switch]$Forzar
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$Agentes = Join-Path $Root "output\agentes"
New-Item -ItemType Directory -Force $Agentes | Out-Null

$Day = if ($Tarea -eq "corrector" -and (Get-Date).Hour -lt 12) { (Get-Date).AddDays(-1) } else { Get-Date }
$Ymd = $Day.ToString("yyyyMMdd")
$Work = Join-Path $Agentes "$($Tarea)_$Ymd"
$Copy = Join-Path $Work "copia"
$Log = Join-Path $Agentes "$($Tarea)_$Ymd.log"

function Write-Log([string]$msg) {
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $msg"
    Add-Content -Path $Log -Value $line -Encoding UTF8
    Write-Output $line
}

# --- Condiciones para correr ---------------------------------------------------------------------------------------
if ((Test-Path (Join-Path $Work "INFORME.md")) -and -not $Forzar) { Write-Log "Ya corrio $Tarea del $Ymd; nada que hacer"; exit 0 }
$Pend = Join-Path $Root "output\pendientes_$Ymd.md"
if ($Tarea -eq "corrector" -and -not (Test-Path $Pend)) { Write-Log "No existe pendientes_$Ymd.md; nada que hacer"; exit 0 }

# Una corrida de main.py (--date/--resume/--continuous) compite por Ollama y el OCR: esperar a la proxima hora
# programada. "main.py report" (pagina local) y "main.py portal" no cuentan.
$Busy = Get-CimInstance Win32_Process -Filter "Name='python.exe'" | Where-Object {
    $_.CommandLine -match 'main\.py' -and $_.CommandLine -notmatch 'main\.py"?\s+(report|portal)'
}
if ($Busy -and -not $Forzar) { Write-Log "Hay una corrida de main.py en curso; se reintenta en la proxima hora programada"; exit 0 }

# La extension de VS Code trae su propio claude.exe y cambia de carpeta en cada actualizacion: usar el mas nuevo
$Claude = Get-ChildItem "$env:USERPROFILE\.vscode\extensions" -Directory -Filter "anthropic.claude-code-*" |
    Sort-Object { [version](($_.Name -replace '^anthropic\.claude-code-', '') -replace '-.*$', '') } -Descending |
    ForEach-Object { Join-Path $_.FullName "resources\native-binary\claude.exe" } |
    Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $Claude) { Write-Log "ERROR: no se encontro claude.exe de la extension de VS Code"; exit 1 }

# --- Copia de trabajo ----------------------------------------------------------------------------------------------
if (Test-Path $Work) { Remove-Item -Recurse -Force $Work }
New-Item -ItemType Directory -Force $Copy, (Join-Path $Copy "output"), (Join-Path $Copy "storage") | Out-Null
foreach ($d in "processing", "models", "tests", "tools", "automation", "export", ".claude") {
    robocopy (Join-Path $Root $d) (Join-Path $Copy $d) /E /XD __pycache__ /NFL /NDL /NJH /NJS /NP | Out-Null
    if ($LASTEXITCODE -ge 8) { Write-Log "ERROR copiando $d"; exit 1 }
}
foreach ($f in "config.py", "drivers_config.json", ".env", "requirements.txt") {
    if (Test-Path (Join-Path $Root $f)) { Copy-Item (Join-Path $Root $f) $Copy }
}
Copy-Item (Join-Path $Root "storage\*.py") (Join-Path $Copy "storage")
# Lo que el agente necesita leer de output\ (pendientes, evaluaciones y lecturas anteriores)
Get-ChildItem (Join-Path $Root "output") -File -Include "pendientes_*.md", "evaluacion_*.jsonl", "cache_lecturas_$Ymd*.pkl" -Recurse:$false |
    Copy-Item -Destination (Join-Path $Copy "output")
# El venv no se copia: enlace (junction) al real
cmd /c mklink /J (Join-Path $Copy "venv") (Join-Path $Root "venv") | Out-Null

Set-Content -Path (Join-Path $Copy ".gitignore") -Value "venv/`noutput/`n__pycache__/`n*.pyc`n.pytest_cache/`nINFORME.md" -Encoding ASCII
git -C $Copy init -q
git -C $Copy add -A
git -C $Copy -c user.name=agente -c user.email=agente@local commit -q -m base

# --- Ejecutar el agente --------------------------------------------------------------------------------------------
# Bases, fotos y OCR reales (solo lectura por las reglas del agente); salidas en la copia
$env:STORAGE_DIR = Join-Path $Root "storage"
$env:OUTPUT_DIR = Join-Path $Copy "output"
$env:OUTPUT_DIRECTORY = Join-Path $Copy "output"
$env:PADDLE_PYTHON = Join-Path $Root "venv_paddle\Scripts\python.exe"
$env:PYTHONIOENCODING = "utf-8"

$Photos = "Read(//" + $Root.Substring(0, 1).ToLower() + ($Root.Substring(2) -replace '\\', '/') + "/storage/pod_images/**)"
$Py = @("Bash(venv/Scripts/python.exe -m pytest:*)", "Bash(venv/Scripts/python.exe tools/evaluar_dia.py:*)",
        "Bash(venv/Scripts/python.exe tools/cache_lecturas.py:*)", "Bash(venv/Scripts/python.exe tools/agrupar_falsas_alarmas.py:*)",
        "Bash(venv/Scripts/python.exe -:*)", "Bash(venv/Scripts/python.exe -c:*)")
$Tools = @("Read", "Grep", "Glob", "Edit", "Write", $Photos, "Bash(ls:*)", "Bash(diff:*)", "Bash(mkdir:*)", "Bash(cp:*)") + $Py
# Nunca, aunque el agente lo intente: recalificar escribe en la base y el portal; main.py procesa o envia
$Deny = @("Bash(venv/Scripts/python.exe tools/recalificar.py:*)", "Bash(venv/Scripts/python.exe main.py:*)",
          "Bash(python:*)", "Bash(git:*)", "PowerShell", "WebFetch", "WebSearch", "Agent")

$Comun = "Es una corrida automatica nocturna sin usuario: no hagas preguntas. MODO PROPUESTA: estas en una copia del " +
         "proyecto con git propio; el codigo real no se toca y el usuario revisa tus cambios por la manana. Las bases y " +
         "fotos son las reales: solo lectura. Al terminar escribe tu informe final en INFORME.md (raiz de esta carpeta)."
if ($Tarea -eq "corrector") {
    $Agent = "corrector-pendientes"
    $Prompt = "Corrige los pendientes de output/pendientes_$Ymd.md. $Comun Edita libremente esta copia (no hace falta " +
              "el respaldo de la regla 3: git guarda la base). Las evaluaciones anteriores para comparar estan en output/. " +
              "No apliques archivos propuestas_falsas_alarmas_*.md (esos los aprueba el usuario). En el informe, " +
              "marca claramente que los cambios son una PROPUESTA pendiente de aplicar."
}
else {
    $Agent = "agrupador-falsas-alarmas"
    $Prompt = "Analiza las falsas alarmas y deja las propuestas en output/. $Comun No edites codigo."
}

Write-Log "Inicio $Agent en $Copy ($Claude)"
Push-Location $Copy
try {
    $ClaudeArgs = @("-p", $Prompt, "--agent", $Agent, "--permission-mode", "acceptEdits",
                    "--allowedTools") + $Tools + @("--disallowedTools") + $Deny
    & $Claude @ClaudeArgs 2>&1 | ForEach-Object { "$_" } | Set-Content -Path (Join-Path $Work "registro.log") -Encoding UTF8
    $Code = $LASTEXITCODE
}
finally { Pop-Location }

# --- Resultados ----------------------------------------------------------------------------------------------------
git -C $Copy add -A
git -C $Copy diff --cached --output=(Join-Path $Work "cambios.diff")   # ">" en PowerShell 5.1 lo dejaria en UTF-16
$Changed = git -C $Copy diff --cached --name-only
if (Test-Path (Join-Path $Copy "INFORME.md")) { Copy-Item (Join-Path $Copy "INFORME.md") $Work }
else { Set-Content (Join-Path $Work "INFORME.md") "El agente no dejo informe (codigo $Code). Ver registro.log." -Encoding UTF8 }
if ($Tarea -eq "agrupador") {
    Get-ChildItem (Join-Path $Copy "output") -Filter "propuestas_falsas_alarmas_*.md" | Copy-Item -Destination (Join-Path $Root "output")
}
Write-Log "Fin $Agent (codigo $Code). Archivos cambiados en la copia: $(@($Changed).Count). Ver $Work\INFORME.md"
exit $Code
