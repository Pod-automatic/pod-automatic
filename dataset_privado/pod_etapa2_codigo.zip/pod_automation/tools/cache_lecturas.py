"""
Guarda las lecturas por foto (OCR + modelo de visión) de los albaranes de un día, para probar reglas nuevas de
puntuación sin volver a leer las fotos (02/10/2026).

    python tools/cache_lecturas.py --date 2026-10-02 --priorities Alta --extra-file output/pendientes_20261002.md \
        --out output/cache_lecturas_20261002.pkl

Se puede cortar y retomar: los albaranes ya guardados no se releen. Lee de la base SOLO los albaranes pedidos
(03/10: cargar los 3000 del día completos ocupaba 3.5 GB de RAM y tardaba más de 15 minutos).
"""

import argparse
import json
import logging
import pickle
import re
import sqlite3
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import config  # noqa: E402
from models.pod import PODRecord  # noqa: E402
from processing.pipeline import ocr_photos  # noqa: E402

LATEST = """SELECT p.tracking_number, p.payload_json FROM pod_checkpoints p
            JOIN audit_sessions s ON s.session_id = p.session_id
            WHERE s.query_date = ? AND p.tracking_number = ? ORDER BY s.started_at DESC LIMIT 1"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--date", required=True)
    ap.add_argument("--priorities", default="Alta")
    ap.add_argument("--extra-file", default=None, help="Archivo con albaranes extra (se buscan GFUS…/YT…)")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    logging.disable(logging.WARNING)

    out = Path(a.out)
    cache = pickle.loads(out.read_bytes()) if out.exists() else {}
    con = sqlite3.connect(f"file:{config.CHECKPOINT_DB_PATH.as_posix()}?mode=ro", uri=True, timeout=30)
    prios = [p for p in a.priorities.split(",") if p]
    wanted = set()
    if prios:
        marks = ",".join("?" * len(prios))
        wanted |= {r[0] for r in con.execute(
            f"""SELECT p.tracking_number FROM pod_checkpoints p JOIN audit_sessions s ON s.session_id = p.session_id
                WHERE s.query_date = ? AND p.priority IN ({marks})""", [a.date] + prios)}
    if a.extra_file:
        wanted |= set(re.findall(r"GFUS\d{14}|YT\d{16}", Path(a.extra_file).read_text(encoding="utf-8")))
    todo = sorted(t for t in wanted if t not in cache)
    print(f"{len(wanted)} albaranes; {len(wanted) - len(todo)} ya guardados; faltan {len(todo)}", flush=True)
    for i, t in enumerate(todo, 1):
        row = con.execute(LATEST, (a.date, t)).fetchone()
        if not row:
            print(f"[{i}/{len(todo)}] {t} no está en ese día", flush=True)
            continue
        pod = PODRecord.from_dict(json.loads(row[1]))
        t0 = time.time()
        try:
            photos = ocr_photos(pod.photo_paths, pod.expected_address)
        except Exception as e:
            print(f"[{i}/{len(todo)}] {t} ERROR {e}", flush=True)
            continue
        cache[t] = {"photos": photos, "priority": pod.priority, "address": pod.expected_address,
                    "driver": " ".join((pod.driver_name or "").split())}
        out.write_bytes(pickle.dumps(cache))
        print(f"[{i}/{len(todo)}] {t} {time.time() - t0:.0f}s", flush=True)
    print("FIN", flush=True)


if __name__ == "__main__":
    main()
