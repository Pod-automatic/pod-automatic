"""
Agrupa las falsas alarmas (descartadas por el usuario) por el motivo que las mandó a Alta/Media y lo compara con los
errores reales (reportados) del mismo motivo (07/10/2026). Sirve para elegir qué regla atacar: un grupo grande con
casi ningún error real es una ganancia segura; uno mezclado necesita una regla más fina.

Solo lectura: lee report_status.db y pod_checkpoints.db (el puntaje guardado en la corrida, no el código actual).

Uso:  python tools/agrupar_falsas_alarmas.py [--desde 2026-10-01] [--hasta 2026-10-06] [--ejemplos 8]
Deja output/agrupacion_falsas_alarmas_<hoy>.md y .json
"""

import argparse
import json
import re
import sqlite3
import sys
from collections import defaultdict
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import config  # noqa: E402

LATEST = """SELECT p.priority, p.driver_name, p.payload_json FROM pod_checkpoints p
            JOIN audit_sessions s ON s.session_id = p.session_id
            WHERE s.query_date = ? AND p.tracking_number = ? ORDER BY s.started_at DESC LIMIT 1"""


def ro(path: Path) -> sqlite3.Connection:
    return sqlite3.connect(f"file:{path.as_posix()}?mode=ro", uri=True, timeout=30)


def active_checks(payload: dict) -> list:
    """Chequeos que sumaron puntaje, de mayor a menor peso (mismo orden que top_reasons)."""
    act = [r for r in payload.get("check_results") or [] if r.get("applicable", True) and r.get("score", 0) > 0]
    act.sort(key=lambda r: (not r.get("force_report"), -(r["score"] * r["weight"])))
    return act


def key_of(check: dict) -> str:
    status = (check.get("details") or {}).get("status")
    return f"{check['check']}:{status}" if status else check["check"]


def plantilla(text: str) -> str:
    """'Número leído incompleto (414 de 1414): verificar' -> 'Número leído incompleto (# de #): verificar'"""
    return re.sub(r"\d+", "#", text or "")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--desde", default="0000-00-00")
    ap.add_argument("--hasta", default="9999-99-99")
    ap.add_argument("--ejemplos", type=int, default=8)
    a = ap.parse_args()

    marks = ro(config.STORAGE_DIR / "report_status.db").execute(
        "SELECT tracking_number, query_date, status FROM report_status WHERE query_date BETWEEN ? AND ? "
        "AND status IN ('descartado', 'reportado') AND " + config.REPORT_STATUS_TRUSTED_SQL, (a.desde, a.hasta)).fetchall()
    con = ro(config.CHECKPOINT_DB_PATH)

    groups = defaultdict(lambda: {"descartado": 0, "reportado": 0, "prioridad": defaultdict(int),
                                  "secundarios": defaultdict(int), "textos": defaultdict(int),
                                  "ejemplos_falsos": [], "ejemplos_reales": []})
    sin_puntaje = 0
    for trk, day, status in marks:
        row = con.execute(LATEST, (day, trk)).fetchone()
        if not row:
            continue
        priority, driver, payload = row[0], row[1], json.loads(row[2])
        act = active_checks(payload)
        if not act:
            sin_puntaje += 1
            continue
        g = groups[key_of(act[0])]
        g[status] += 1
        g["prioridad"][priority or "?"] += 1
        g["textos"][plantilla(act[0]["explanation"])] += 1
        for other in act[1:3]:
            g["secundarios"][key_of(other)] += 1
        sample = g["ejemplos_falsos" if status == "descartado" else "ejemplos_reales"]
        if len(sample) < a.ejemplos:
            sample.append({"tracking": trk, "fecha": day, "prioridad": priority, "repartidor": driver,
                           "direccion": payload.get("receipt_address") or payload.get("address"),
                           "motivos": [r["explanation"] for r in act[:3]]})

    total_falsos = sum(g["descartado"] for g in groups.values())
    rows = []
    for k, g in groups.items():
        n = g["descartado"] + g["reportado"]
        rows.append({"grupo": k, "falsas_alarmas": g["descartado"], "errores_reales": g["reportado"],
                     "pct_del_total_falsas": round(100 * g["descartado"] / max(total_falsos, 1), 1),
                     "precision_pct": round(100 * g["reportado"] / n, 1),
                     "prioridad": dict(g["prioridad"]),
                     "textos": dict(sorted(g["textos"].items(), key=lambda x: -x[1])[:4]),
                     "secundarios": dict(sorted(g["secundarios"].items(), key=lambda x: -x[1])[:4]),
                     "ejemplos_falsos": g["ejemplos_falsos"], "ejemplos_reales": g["ejemplos_reales"]})
    rows.sort(key=lambda r: -r["falsas_alarmas"])

    stem = config.OUTPUT_DIR / f"agrupacion_falsas_alarmas_{date.today():%Y%m%d}"
    meta = {"desde": a.desde, "hasta": a.hasta, "marcas": len(marks), "falsas_alarmas": total_falsos,
            "errores_reales": sum(g["reportado"] for g in groups.values()), "sin_puntaje": sin_puntaje}
    stem.with_suffix(".json").write_text(json.dumps({"meta": meta, "grupos": rows}, ensure_ascii=False, indent=1),
                                         encoding="utf-8")

    md = [f"# Falsas alarmas agrupadas por motivo ({a.desde} a {a.hasta})", "",
          f"{meta['falsas_alarmas']} falsas alarmas · {meta['errores_reales']} errores reales · "
          f"{sin_puntaje} marcados sin puntaje guardado", "",
          "Precisión = % del grupo que eran errores reales. Puntaje de la corrida (puede no reflejar arreglos posteriores).",
          "", "| Grupo (motivo principal) | Falsas | % del total | Reales | Precisión | Texto típico |",
          "|---|---:|---:|---:|---:|---|"]
    for r in rows:
        md.append(f"| `{r['grupo']}` | {r['falsas_alarmas']} | {r['pct_del_total_falsas']} % | {r['errores_reales']} | "
                  f"{r['precision_pct']} % | {next(iter(r['textos']), '')} |")
    stem.with_suffix(".md").write_text("\n".join(md) + "\n", encoding="utf-8")
    print("\n".join(md))
    print(f"\nDetalle con ejemplos: {stem.with_suffix('.json')}")


if __name__ == "__main__":
    main()
