"""Recupera resultados de checkpoints sin tocar Revisión ni inventar horas/modelos históricos.

python tools/portal_recuperar_analisis.py --date 2026-10-27
python tools/portal_recuperar_analisis.py --date 2026-10-27 --enqueue --send
Ejecutar en PC y Kaggle por separado, después de instalar analysis.php en el portal.
Para Kaggle indicar --model con el modelo que se utilizó realmente.
"""
import argparse
import json
import sqlite3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import config
from export.portal_sync import Outbox, PortalClient, PortalSync, analysis_item


def recover(day, model=None, enqueue=False, outbox=None):
    # La fecha de audit_sessions es la fecha auditada. query_date de algunos checkpoints
    # antiguos contiene una hora recortada; nunca se usa para reconstruir la fecha.
    c = sqlite3.connect(config.CHECKPOINT_DB_PATH.resolve().as_uri() + '?mode=ro', uri=True)
    try:
        rows = c.execute('''SELECT p.payload_json FROM pod_checkpoints p
            JOIN audit_sessions s ON s.session_id=p.session_id
            WHERE s.query_date=? AND p.risk_score IS NOT NULL
            ORDER BY p.created_at, s.started_at''', (day,)).fetchall()
    finally:
        c.close()
    items = {}
    for (body,) in rows:
        payload = json.loads(body)
        if payload.get('priority') not in ('Alta', 'Media', 'Baja', 'Lockers') or (payload.get('portal_meta') or {}).get('verify_of'):
            continue
        item = analysis_item(payload, day, None)
        item['model'] = model or 'historico-desconocido'
        items[item['tracking']] = item
    if enqueue:
        box = outbox or Outbox()
        for item in items.values():
            box.record_analysis(item)
    return items


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--date', required=True)
    ap.add_argument('--model')
    ap.add_argument('--enqueue', action='store_true')
    ap.add_argument('--send', action='store_true')
    args = ap.parse_args()
    from datetime import date
    date.fromisoformat(args.date)
    if config.PORTAL_GPU and not args.model:
        ap.error('En Kaggle indica --model con el modelo histórico real.')
    if args.send and not args.enqueue:
        ap.error('--send requiere --enqueue')
    if args.send and not config.PORTAL_SYNC_ENABLED:
        ap.error('Falta configurar PORTAL_URL / PORTAL_API_KEY')
    items = recover(args.date, args.model, args.enqueue)
    counts = {p: sum(it['priority'] == p for it in items.values()) for p in ('Alta', 'Media', 'Baja', 'Lockers')}
    print(f'{len(items)} resultados únicos: {counts}. ' + ('Encolados.' if args.enqueue else 'Solo diagnóstico; no se modificó la cola.'))
    if args.send:
        sync = PortalSync(PortalClient(config.PORTAL_URL, config.PORTAL_API_KEY), Outbox())
        sent = 0
        while True:
            n = sync.push_analyses()
            sent += n
            if not n:
                break
        print(f'{sent} resultados confirmados. Cola: {sync.outbox.counts()}')


if __name__ == '__main__':
    main()
