# Vigilante de Paddle (18/10/2026, pedido del usuario: "reinicia Paddle cada vez que sea necesario").
# El servidor de OCR (tools/paddle_ocr_server.py) acumula memoria de GPU durante el día (llegó a 3,4 GB) y con el modelo
# de visión la GPU de 6 GB se llena: la corrida baja de ~550 a ~200 albaranes/hora. Cada minuto mira cuánta memoria de
# GPU usa Paddle; si pasa del tope, lo cierra y la corrida lo vuelve a abrir sola (ocr_address.ensure_paddle_server).
# Se cierra solo si no hay corrida durante 20 minutos seguidos.
# 18/10 16:50 (usuario: "mantenlo siempre y cuando no se sature la memoria"): solo se reinicia si además la GPU entera
# está saturada (>= SaturaMB usados de 6 GB); si Paddle está grande pero la GPU no se llenó, se deja.
# 20/10 (usuario): límite 5.700 MB (con 5.900 la GPU quedaba en 5.850-5.898 y nunca actuaba).
#   powershell -File tools\vigilante_paddle.ps1 [-TopeMB 2200] [-SaturaMB 5700]
param([int]$TopeMB = 2200, [int]$SaturaMB = 5700, [int]$EsperaMin = 5)

$root = Split-Path -Parent $PSScriptRoot
$log = Join-Path $root ("storage\vigilante_paddle_{0}.log" -f (Get-Date -Format "yyyyMMdd"))
function Write-Log($msg) { Add-Content -Path $log -Value ("{0}  {1}" -f (Get-Date -Format "HH:mm:ss"), $msg) -Encoding UTF8 }

function Get-PyProc($pattern) {
    Get-CimInstance Win32_Process -Filter "Name like 'python%'" | Where-Object { $_.CommandLine -like $pattern }
}

Write-Log "Vigilante iniciado (Paddle > $TopeMB MB y GPU >= $SaturaMB MB)"
$sinCorrida = 0
$ultimo = [datetime]::MinValue
while ($true) {
    Start-Sleep -Seconds 60
    if (-not (Get-PyProc "*main.py run*")) {
        $sinCorrida++
        if ($sinCorrida -ge 20) { Write-Log "Sin corrida hace 20 min: el vigilante se cierra"; break }
        continue
    }
    $sinCorrida = 0
    $paddle = @(Get-PyProc "*paddle_ocr_server*")
    if (-not $paddle) { continue }
    $ids = $paddle | ForEach-Object { [string]$_.ProcessId }
    try {
        $mb = ((Get-Counter '\GPU Process Memory(*)\Dedicated Usage' -ErrorAction Stop).CounterSamples |
            Where-Object { $ids -contains [regex]::Match($_.InstanceName, 'pid_(\d+)').Groups[1].Value } |
            Measure-Object CookedValue -Sum).Sum / 1MB
    } catch { continue }
    $gpu = 0; try { $gpu = [int](nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits) } catch {}
    if ($gpu -lt $SaturaMB -or $mb -lt $TopeMB -or ((Get-Date) - $ultimo).TotalMinutes -lt $EsperaMin) { continue }
    $paddle | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    $ultimo = Get-Date
    Write-Log ("GPU saturada ({0:N0} MB usados); Paddle usaba {1:N0} MB: reiniciado" -f $gpu, $mb)
}
