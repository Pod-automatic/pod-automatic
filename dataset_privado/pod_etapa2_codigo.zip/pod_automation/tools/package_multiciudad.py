"""Preparar codigo, notebook, dos cookies privadas y endpoint del portal sin arrancar corridas."""
import argparse
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from tools.run_kaggle_multi import validate_sessions


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--luis',type=Path,default=ROOT/'storage/session_state.json')
    parser.add_argument('--tracking',type=Path,default=ROOT/'storage/session_state_trackingintus_20261027.json')
    parser.add_argument('--portal-root',type=Path,required=True,help='Directorio local que contiene portal/api e inc.')
    args=parser.parse_args()
    validate_sessions(args.luis,args.tracking)
    for relative in ('portal/api/session_guard.php','portal/inc/session_guard.php'):
        if not (args.portal_root/relative).is_file(): raise ValueError('Falta '+relative)
    subprocess.run([sys.executable,'deploy/kaggle/empaquetar_etapa2.py','--solo-codigo'],cwd=ROOT,check=True)
    out=ROOT/'output'
    private=out/'pod_multisesion_secretos.zip'
    with zipfile.ZipFile(private,'w',zipfile.ZIP_DEFLATED) as z:
        z.write(args.luis,'luis.json'); z.write(args.tracking,'tracking.json')
    portal=out/'actualizacion-coordinacion-sesiones-20261028.zip'
    with zipfile.ZipFile(portal,'w',zipfile.ZIP_DEFLATED) as z:
        for rel in ('portal/api/session_guard.php','portal/inc/session_guard.php'):
            z.write(args.portal_root/rel,rel)
    print('Cookies preparadas para dataset PRIVADO:',private)
    print('Actualizacion del portal (sin credenciales):',portal)


if __name__=='__main__': main()
