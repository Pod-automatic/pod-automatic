"""
Vuelve a mandar al portal web los Alta/Media de un día (09/10: para que los albaranes enviados antes de agregar el GPS
reciban "Ver en mapa" / "Street View" / la distancia). El portal actualiza los datos sin tocar el estado de cada albarán.

Por defecto SOLO cuenta cuántos son; para encolarlos hay que pasar --si. Si hay una corrida en marcha, la bandeja de
salida la vacía la propia corrida: ojo, ella usa el código con el que arrancó, así que el GPS solo sale si se reinició
después del cambio de portal_sync.py.

Uso:
  python tools/portal_reenviar.py --date 2026-10-09          (solo cuenta)
  python tools/portal_reenviar.py --date 2026-10-09 --si     (los encola)
"""

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from export import portal_sync  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--date", required=True, help="AAAA-MM-DD")
    ap.add_argument("--si", action="store_true", help="encolarlos de verdad (sin esto solo cuenta)")
    args = ap.parse_args()
    n = portal_sync.requeue_day(args.date, dry_run=not args.si)
    print(f"{n} albarán(es) Alta/Media del {args.date} " + ("encolados para el portal." if args.si else "se reenviarían (usa --si para encolarlos)."))
    return 0


if __name__ == "__main__":
    sys.exit(main())
