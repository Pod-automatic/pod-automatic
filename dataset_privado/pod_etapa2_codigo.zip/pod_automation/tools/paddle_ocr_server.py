"""
Servicio local de OCR con PaddleOCR (corre en el entorno aparte venv_paddle, 02/10/2026).

Paddle necesita versiones de numpy/OpenCV distintas a las del proyecto, así que no se instala en el venv principal:
corre aquí y el script le pide la lectura por HTTP local (solo 127.0.0.1, las fotos no salen de la computadora).

Uso (lo arranca solo `processing.ocr_address` si no está corriendo):
    venv_paddle\\Scripts\\python.exe tools\\paddle_ocr_server.py --port 8770

POST /ocr  {"path": "C:/.../foto_1.jpg", "upscale": 1}
  -> {"height": H, "width": W, "detections": [{"box": [[x, y], ...], "text": "...", "conf": 0.0-1.0}, ...]}
GET  /health -> {"ok": true}
"""

import argparse
import json
import os
import threading

# Nota 02/10: limitar la memoria de Paddle (FLAGS_fraction_of_gpu_memory_to_use=0.3) lo hacía ~40x más lento
# (22 s por foto). Se deja la configuración por defecto.
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import numpy as np
from PIL import Image, ImageOps

from paddleocr import PaddleOCR

_OCR = None
MAX_SIDE = 3200   # Lado máximo de la imagen que se manda a la GPU
_LOCK = threading.Lock()   # Una lectura a la vez en la GPU
# 12/10: el servicio pierde memoria con las horas (llegó a 9,7 GB con 15,6 GB en total: Windows mandaba todo a disco y
# cada lectura tardaba ~80 s). Pasado este límite de RAM REAL (working set) se cierra solo después de responder; el
# script lo vuelve a abrir en la lectura siguiente (ensure_paddle_server). No se mide la memoria "privada": pasa de 4,5 GB
# ya en la primera lectura (reserva de CUDA) y lo reiniciaba después de cada pedido
MAX_PRIVATE_MB = int(os.environ.get("PADDLE_MAX_RAM_MB", "3000"))


def _private_mb() -> float:
    try:
        import psutil
        return psutil.Process().memory_info().rss / 2**20
    except Exception:
        return 0.0


def _exit_if_bloated() -> None:
    mb = _private_mb()
    if mb > MAX_PRIVATE_MB:
        with _LOCK:   # Que no quede ninguna lectura a medias
            print(f"Memoria {mb:.0f} MB > {MAX_PRIVATE_MB} MB: el servicio se cierra para liberarla", flush=True)
            os._exit(0)


def ocr():
    global _OCR
    if _OCR is None:
        _OCR = PaddleOCR(lang="en", use_doc_orientation_classify=False, use_doc_unwarping=False,
                         use_textline_orientation=True)
    return _OCR


def read(path: str, upscale: float = 1.0) -> dict:
    with Image.open(path) as im:
        img = ImageOps.exif_transpose(im).convert("RGB")
    if upscale and upscale != 1:
        img = img.resize((int(img.width * upscale), int(img.height * upscale)), Image.LANCZOS)
    # 04/10: una foto entera ampliada al doble (8000 px) dejaba sin memoria la GPU de 6 GB ("CUDA out of memory")
    if max(img.size) > MAX_SIDE:
        k = MAX_SIDE / max(img.size)
        img = img.resize((int(img.width * k), int(img.height * k)), Image.LANCZOS)
    arr = np.array(img)[:, :, ::-1]   # BGR, como espera Paddle
    with _LOCK:
        try:
            res = ocr().predict(arr)
        except Exception as e:
            if "memory" not in str(e).lower():
                raise
            import paddle
            paddle.device.cuda.empty_cache()   # Libera la memoria que Paddle guarda y reintenta una vez
            res = ocr().predict(arr)
    dets = []
    for r in res:
        for poly, text, score in zip(r["rec_polys"], r["rec_texts"], r["rec_scores"]):
            dets.append({"box": [[float(x), float(y)] for x, y in poly], "text": text, "conf": float(score)})
    return {"height": img.height, "width": img.width, "detections": dets}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def _json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.startswith("/health"):
            return self._json({"ok": True})
        self._json({"error": "no existe"}, 404)

    def do_POST(self):
        if not self.path.startswith("/ocr"):
            return self._json({"error": "no existe"}, 404)
        try:
            req = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
            self._json(read(req["path"], float(req.get("upscale", 1))))
        except Exception as e:
            self._json({"error": f"{type(e).__name__}: {e}"}, 500)
        self.wfile.flush()
        _exit_if_bloated()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8770)
    a = ap.parse_args()
    ocr()   # Carga el modelo antes de aceptar pedidos
    print(f"PaddleOCR listo en http://127.0.0.1:{a.port}", flush=True)
    ThreadingHTTPServer(("127.0.0.1", a.port), Handler).serve_forever()


if __name__ == "__main__":
    main()
