"""Un Kaggle, dos sesiones GOFO, servicios GPU compartidos. No exporta cookies a logs.

28/10 (pedido del usuario): la sesion de Luis apoya a la PC en DFW y DFW02 (reparto de albaranes y turnos de sesion con
la PC). 29/10 (pedido del usuario): la sesion tracking revisa SOLO las ciudades que se indiquen ese dia en TRACKING_STATIONS
(celda 4 del notebook); sin ese valor no se lanza."""
import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from datetime import datetime,timedelta
from zoneinfo import ZoneInfo

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))


# Luis comparte cuenta con la PC: solo sus ciudades. 30/10 (pedido del usuario): por ahora, solo DFW02 (igual que la PC)
LUIS_STATIONS='DFW02-BAA'


def tracking_stations(env):
    """Ciudades del dia para la sesion tracking (TRACKING_STATIONS='DFW-BAA,DFW02-BAA'). Obligatorio y validado: main.py,
    ante un codigo desconocido, revisaria en silencio las ciudades por defecto."""
    import config
    known=set(config.GOFO_STATION_NAMES.values())
    codes=[c.strip().upper().replace(' ','') for c in env.get('TRACKING_STATIONS','').split(',') if c.strip()]
    if not codes:
        raise ValueError('Falta TRACKING_STATIONS: indica en la celda 4 las ciudades de Tracking para hoy (ej. DFW-BAA,DFW02-BAA).')
    bad=[c for c in codes if c not in known]
    if bad:
        raise ValueError(f"Ciudad desconocida en TRACKING_STATIONS: {', '.join(bad)}. Validas: {', '.join(sorted(known))}.")
    return ','.join(dict.fromkeys(codes))


def stop_timestamp(now=None,env=None):
    """Hora de cierre. Por defecto las 22:30 de HOY en Venezuela. Corrida nocturna (28/10): MULTI_STOP_AT='10:00' = la
    PROXIMA vez que sean esas HH:MM, y MULTI_MAX_HOURS = tope de horas desde ahora (Kaggle corta cada sesion a las 12 h)."""
    env=os.environ if env is None else env
    zone=ZoneInfo('America/Caracas')
    now=(now or datetime.now(zone)).astimezone(zone)
    spec=env.get('MULTI_STOP_AT','').strip()
    if spec:
        hour,minute=(int(part) for part in spec.split(':'))
        stop=now.replace(hour=hour,minute=minute,second=0,microsecond=0)
        if stop<=now: stop+=timedelta(days=1)
    else:
        stop=now.replace(hour=22,minute=30,second=0,microsecond=0)
    stamp=stop.timestamp()
    if env.get('MULTI_MAX_HOURS','').strip():
        stamp=min(stamp,now.timestamp()+float(env['MULTI_MAX_HOURS'])*3600)
    return stamp


def restart_delay(failures):
    return min(300,30*2**min(max(0,failures-1),4))


def restart_plan(code,failures,uptime,now):
    failures=(0 if uptime>=600 else failures)+1
    return {'disabled':code==2,'failures':failures,'next_try':now+restart_delay(failures)}


def cleanup_previous_workers(state_path,run_id):
    """Un supervisor muerto puede dejar hijos vivos; no lanzar duplicados con las mismas cookies."""
    if not run_id or not state_path.exists(): return
    import psutil
    try: state=json.loads(state_path.read_text(encoding='utf-8'))
    except (OSError,ValueError): return
    if state.get('run_id')!=run_id: return
    roots=[];family=[]
    for pid in state.get('workers',[]):
        try:
            process=psutil.Process(pid)
            if process.environ().get('MULTI_RUN_ID')!=run_id or 'main.py' not in process.cmdline(): continue
            roots.append(process);family.extend([process]+process.children(recursive=True))
        except (psutil.NoSuchProcess,psutil.AccessDenied): continue
    for process in roots:
        try: process.send_signal(signal.SIGINT)
        except psutil.NoSuchProcess: pass
    _,alive=psutil.wait_procs(family,timeout=90)
    for process in alive:
        try: process.terminate()
        except psutil.NoSuchProcess: pass
    _,alive=psutil.wait_procs(alive,timeout=5)
    for process in alive:
        try: process.kill()
        except psutil.NoSuchProcess: pass


def validate_sessions(luis,tracking):
    from automation.browser import session_file_has_cookies
    states=[]
    for path in (Path(luis),Path(tracking)):
        if not session_file_has_cookies(path):
            raise ValueError(f'No hay cookies validas en {path.name}.')
        data=json.loads(path.read_text(encoding='utf-8'))
        tokens=[x['value'] for origin in data.get('origins',[]) for x in origin.get('localStorage',[])
                if x.get('name')=='Admin-Token']
        states.append(tokens or [(c.get('name'),c.get('value')) for c in data.get('cookies',[])])
    if states[0]==states[1]:
        raise ValueError('Los dos archivos tienen la misma sesion. Se requieren dos inicios de sesion diferentes.')


def worker_env(base,worker,cookies,shared,shared_session=False):
    storage=shared/'workers'/worker
    return dict(base,STORAGE_DIR=str(storage),OUTPUT_DIR=str(ROOT/'output'/worker),
                SESSION_FILE=str(Path(cookies).resolve()),AUTH_MODE='storage_state',HEADLESS='true',
                CLAIM_WORK='1',CLAIM_WORKER=worker,GOFO_SESSION_GROUP='luisvivas' if shared_session else '',
                # 30/10: bloques de 16 (antes 5; dos tandas de 8 detalles): con los detalles a la vez, cada bloque es un pedido al portal y uno a GOFO
                CLAIM_BATCH_SIZE='16',CLAIM_DENY_TTL_S='30',CITY_DISPATCH_DB=str(shared/'cities.db'),
                # 29/10: medido en la PC: de un turno de 180 s solo 25-120 s eran extraccion; el resto, volver a listar
                # rutas porque la cache (180 s) vencia antes del siguiente turno (ciclo PC+Kaggle de 4-6 min). Turnos
                # mas largos para Kaggle (analiza mas rapido que la PC, que tiene 120 s) y cache que cubre el ciclo; la
                # lista se reutiliza solo si los totales del repartidor no cambiaron.
                CITY_TURN_S='240',
                # 29/10: cada corrida empieza en otro punto de cada ruta (la PC en la primera parada): no chocan al empezar
                ROUTE_START_FRACTION={'gpu_luis':'0.34','gpu_tracking':'0.67'}.get(worker,'0'),
                # 30/10: cola de 16 (antes 8): con la extracción más rápida, que un albarán lento de visión no la frene
                ASYNC_ANALYSIS='1',ANALYSIS_QUEUE_SIZE='16',ROUTES_PER_BLOCK='1',
                ROUTE_LIST_CACHE_S='600',EMPTY_ROUTE_CACHE_S='120',
                GPU_DISPATCH_DB=str(shared/'gpu_slots.db'),ANALYSIS_POOL_DB=str(shared/'analysis_pool.db'),ANALYSIS_POOL_SIZE='4',
                # 29/10: igual al OLLAMA_NUM_PARALLEL con que el notebook arranca Ollama (lo fija la celda 3)
                GPU_SLOTS_PER_URL=base.get('GPU_SLOTS_PER_URL','1'),
                # 30/10 (pedido del usuario: mucha mas extraccion de GOFO): 8 detalles a la vez (antes 4) con una pausa por lote y freno
                # automatico a uno por uno si GOFO falla o tarda; fotos de 6 albaranes en vuelo (vienen de S3, no de GOFO)
                OCR_WORKERS='4',EXTRACT_PREFETCH='6',REQUEST_DELAY_S='0.5',GOFO_DETAIL_CONCURRENCY='8',
                # 30/10: una falla HTTP de Ollama se repite en la otra GPU sin gastar el tope del albaran; gramatica JSON adaptable
                VISION_FAILOVER='1',VISION_GRAMMAR_ADAPTIVE='1',
                OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',
                VISION_NUM_CTX='2048',
                OLLAMA_URLS='http://127.0.0.1:11434,http://127.0.0.1:11435',
                PADDLE_OCR_PORTS='8770,8771',VISION_MODEL='qwen2.5vl:3b',
                # 28/10: sin cascada. El 7b gastaba el tope de 5 consultas por albaran (VisionCapped -> Media "revisar a mano") y
                # dejaba la GPU 1 al 94 % de VRAM (HTTP 500 de Ollama). El 3b va en las dos GPU, como la prueba del 25/10.
                VISION_FALLBACK_MODEL='',VISION_FALLBACK_URL='',
                ANALYSIS_CACHE_ENABLED='true',ANALYSIS_CACHE_PATH=str(ROOT/'storage'/'analysis_cache.db'),
                OPERATION_TIMEZONE='America/Caracas',PORTAL_MODE='gpu',GPU_SEND_PHOTOS='1',VERIFY_WORK='',
                PYTHONIOENCODING='utf-8')


def selected_sessions(env):
    """29/10 (pedido del usuario): MULTI_SESSIONS='luis' o 'tracking' = una sola sesion por cuenta de Kaggle (cada una
    con la maquina completa). Vacio = las dos, como antes. Una misma sesion nunca debe correr en dos cuentas a la vez:
    el reparto del portal le daria a las dos los mismos albaranes (mismo nombre de corrida)."""
    names=[s.strip().lower() for s in env.get('MULTI_SESSIONS','luis,tracking').split(',') if s.strip()]
    bad=[s for s in names if s not in ('luis','tracking')]
    if not names or bad:
        raise ValueError(f"MULTI_SESSIONS invalido ({env.get('MULTI_SESSIONS')!r}): usar 'luis', 'tracking' o 'luis,tracking'.")
    return list(dict.fromkeys(names))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--luis',type=Path)
    p.add_argument('--tracking',type=Path)
    p.add_argument('--check',action='store_true',help='Validar configuracion sin iniciar navegadores ni GPU.')
    args=p.parse_args()
    base=dict(os.environ)
    sessions=selected_sessions(base)
    cookies={'luis':args.luis,'tracking':args.tracking}
    for name in sessions:
        if cookies[name] is None: raise ValueError(f'Falta --{name} para la sesion {name}.')
    if len(sessions)==2:
        validate_sessions(args.luis,args.tracking)
    else:
        from automation.browser import session_file_has_cookies
        if not session_file_has_cookies(cookies[sessions[0]]):
            raise ValueError(f'No hay cookies validas en {Path(cookies[sessions[0]]).name}.')
    shared=ROOT/'storage'/'multi'; shared.mkdir(parents=True,exist_ok=True)
    stations={'gpu_luis':LUIS_STATIONS}   # antes de lanzar nada
    if 'tracking' in sessions: stations['gpu_tracking']=tracking_stations(base)
    run_id=base.get('MULTI_RUN_ID','')
    if not args.check:
        import fcntl
        supervisor_lock=(shared/'supervisor.lock').open('a')
        try: fcntl.flock(supervisor_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError: raise RuntimeError('Ya hay un supervisor multiciudad ejecutandose.')
        cleanup_previous_workers(shared/'supervisor.json',run_id)
        (shared/'supervisor.json').write_text(json.dumps({'pid':os.getpid(),'workers':[],'run_id':run_id}),encoding='utf-8')
    from export.portal_sync import PortalClient
    if not args.check:
        if not base.get('PORTAL_URL') or not base.get('PORTAL_API_KEY'):
            raise ValueError('Falta la conexion al portal en el entorno del lanzador.')
        if 'luis' in sessions:
            # Preflight obligatorio: sin endpoint de coordinacion nunca lanzar la sesion compartida.
            from automation.session_guard import SessionGuard
            # 29/10: 'release' de un token nuevo no cambia nada: solo prueba que el endpoint responda (pedir la exclusiva
            # dejaba un aviso de espera que retrasaba el cambio de ciudad compartida)
            SessionGuard(PortalClient(base['PORTAL_URL'],base['PORTAL_API_KEY'],timeout=15),'luisvivas','gpu_preflight').request('release')
    specs=[spec for spec in [('gpu_luis',args.luis,True),('gpu_tracking',args.tracking,False)]
           if spec[0][4:] in sessions]
    if args.check:
        for worker,cookies,shared_session in specs:
            env=worker_env(base,worker,cookies,shared,shared_session)
            print(worker,': ciudades',stations[worker],'; coordinacion PC:',bool(env['GOFO_SESSION_GROUP']),
                  '; vision por GPU:',env['GPU_SLOTS_PER_URL'])
        return
    children=[]; stopping=False
    deadline=stop_timestamp()
    slots=[]
    def stop(*_):
        nonlocal stopping
        stopping=True
        for child in children:
            if child.poll() is None:
                child.send_signal(signal.SIGINT)
    signal.signal(signal.SIGTERM,stop); signal.signal(signal.SIGINT,stop)
    try:
        def launch(worker,cookies,shared_session):
            env=worker_env(base,worker,cookies,shared,shared_session)
            logfile=shared/f'{worker}.log'
            with logfile.open('a',encoding='utf-8') as stream:
                child=subprocess.Popen([sys.executable,'main.py','run','--continuous','--stations',
                                        stations[worker]],cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT)
            children.append(child)
            return child
        if time.time()>=deadline:
            print('Ya paso la hora de cierre configurada (por defecto 22:30 de Venezuela); no se inician corridas.',flush=True)
            return
        for worker,cookies,shared_session in specs:
            slots.append({'spec':(worker,cookies,shared_session),'process':launch(worker,cookies,shared_session),
                          'failures':0,'next_try':0,'disabled':False,'started':time.time()})
        (shared/'supervisor.json').write_text(json.dumps({'pid':os.getpid(),'workers':[c.pid for c in children],'run_id':run_id}),encoding='utf-8')
        print(f"Sesion(es) iniciada(s): {', '.join(s[0] for s in specs)}; logs separados en storage/multi.",flush=True)
        # Se recuperan caidas del script hasta las 22:30. Cookies vencidas (exit 2) requieren intervencion.
        while not stopping and time.time()<deadline:
            for slot in slots:
                child=slot['process']
                if child is not None and child.poll() is not None:
                    code=child.returncode
                    slot['process']=None
                    slot.update(restart_plan(code,slot['failures'],time.time()-slot['started'],time.time()))
                    print(slot['spec'][0],': sesion vencida; renovar cookies.' if code==2 else
                          f': proceso detenido ({code}); reintento en {restart_delay(slot["failures"])} s.',flush=True)
                if slot['process'] is None and not slot['disabled'] and time.time()>=slot['next_try']:
                    slot['process']=launch(*slot['spec']);slot['started']=time.time()
                    (shared/'supervisor.json').write_text(json.dumps({'pid':os.getpid(),
                        'workers':[c.pid for c in children if c.poll() is None],'run_id':run_id}),encoding='utf-8')
            if all(slot['disabled'] for slot in slots):
                raise SystemExit(2)
            time.sleep(1)
    finally:
        stop()
        for child in children:
            try: child.wait(timeout=90)
            except subprocess.TimeoutExpired:
                child.terminate()
                try: child.wait(timeout=10)
                except subprocess.TimeoutExpired: child.kill()
        if any(c.returncode not in (0,None) for c in children):
            print('Una corrida termino con error; revisar su log y la vigencia de sus cookies.',flush=True)


if __name__=='__main__':
    main()
