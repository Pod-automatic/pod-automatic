"""
Prueba, SIN activar nada, variantes más estrictas de la regla de entrega en mano (29/10/2026).

La regla actual (processing.pipeline.detect_handoff) baja a Baja un albarán Alta/Media si el modelo dice que en una foto una persona
recibe el paquete. Fallos vistos: la mano del repartidor con la etiqueta, el reflejo del repartidor en un vidrio, y un paquete solo.

Casos: los albaranes que la corrida omitió como entrega en mano y que tienen marca VÁLIDA del usuario (config.REPORT_STATUS_TRUSTED_SQL):
"reportado" = era un error real (NO debe omitirse), "descartado" = falsa alarma (omitirla está bien).

  python tools/probar_entrega_mano.py grabar [--limit N]   graba lo que responde el modelo en cada foto (se puede cortar y retomar)
  python tools/probar_entrega_mano.py resumen              compara las variantes con lo grabado

Solo lectura sobre las bases; escribe únicamente output/prueba_entrega_mano.jsonl.
"""
import os
import re
import sys
import json
import sqlite3
import argparse
from collections import Counter
from pathlib import Path

os.environ["HANDOFF_BUDGET_S"] = "0"      # grabar TODAS las fotos candidatas, sin cortar por tiempo
os.environ["ANALYSIS_CACHE_ENABLED"] = "false"

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
OUT = ROOT / "output" / "prueba_entrega_mano.jsonl"

PERSON_VISIBLE_PROMPT = (
    "Look at this delivery photo. Is a real person's body physically present in the scene (face, torso, or a full arm and hand "
    "taking the package)? A reflection in glass or a mirror, a shadow, or only the delivery driver's own hand holding the package "
    "to show its label does NOT count. Answer JSON only: {\"customer_present\": true or false}"
)
LABEL_WORDS = re.compile(r"\b(GFUS\w*|GOFO|SHIP\s*TO|TRACKING|FROM:)\b", re.I)


def ro(path):
    return sqlite3.connect(f"file:{Path(path).as_posix()}?mode=ro", uri=True, timeout=30)


def casos():
    import config
    st = ro(config.STORAGE_DIR / "report_status.db")
    marks = {t: (s, q) for t, s, q in st.execute(
        "SELECT tracking_number, status, query_date FROM report_status WHERE " + config.REPORT_STATUS_TRUSTED_SQL)}
    ck = ro(config.CHECKPOINT_DB_PATH)
    out = []
    for trk, pj in ck.execute("SELECT tracking_number, payload_json FROM pod_checkpoints ORDER BY rowid"):
        m = marks.get(trk)
        if m and m[0] in ("reportado", "descartado") and (json.loads(pj).get("portal_meta") or {}).get("handoff_confirmed"):
            out.append((m[1], trk, m[0]))
    return sorted(set(out))


def q_person_visible(path):
    from processing import vision_llm
    try:
        body = {"model": vision_llm.config.VISION_MODEL, "prompt": PERSON_VISIBLE_PROMPT, "format": "json", "stream": False,
                "images": [vision_llm._image_b64(path, vision_llm.config.VISION_MAX_SIDE)],
                "options": {"temperature": 0, "num_predict": 40}}
        data, _ = vision_llm._ask_json(body, vision_llm.config.VISION_TIMEOUT_S)
        return None if data is None else bool(data.get("customer_present"))
    except Exception:
        return None


def grabar(limit):
    import config
    from tools.evaluar_dia import load_pod
    from processing import vision_llm
    from processing.pipeline import ocr_photos, detect_handoff
    from processing.scoring import score_pod, _has_label_text
    done = set()
    if OUT.exists():
        done = {json.loads(l)["tracking"] for l in OUT.read_text(encoding="utf-8").splitlines() if l.strip()}
    con = ro(config.CHECKPOINT_DB_PATH)
    todo = [c for c in casos() if c[1] not in done][:limit]
    print(f"{len(casos())} casos con marca válida; {len(done)} grabados; faltan {len(todo)}", flush=True)
    with OUT.open("a", encoding="utf-8") as f:
        for i, (day, trk, marca) in enumerate(todo, 1):
            rec = {"tracking": trk, "dia": day, "marca": marca, "fotos": [], "aplica": False}
            try:
                pod = load_pod(con, day, trk)
                if pod is None:
                    rec["error"] = "sin pod"
                else:
                    photos = ocr_photos(pod.photo_paths, pod.expected_address)
                    score_pod(pod, photos)
                    rec["prioridad_sin_mano"] = pod.priority
                    seen = {}

                    def asker(path):
                        q1 = vision_llm.person_receiving(path)
                        q2 = None
                        if q1:
                            body = {"model": config.VISION_MODEL, "prompt": vision_llm.HANDOFF_CONFIRM_PROMPT, "format": "json",
                                    "stream": False, "images": [vision_llm._image_b64(path, config.VISION_MAX_SIDE)],
                                    "options": {"temperature": 0, "num_predict": 40}}
                            try:
                                data, _ = vision_llm._ask_json(body, config.VISION_TIMEOUT_S)
                                q2 = bool(data and data.get("customer_has_package"))
                            except Exception:
                                q2 = None
                        q3 = q_person_visible(path) if (q1 and q2) else None
                        seen.setdefault(str(path), {}).update(q1=q1, q2=q2, q3=q3)
                        return False      # nunca corta: así se preguntan todas las fotos candidatas

                    def reception(path):
                        seen.setdefault(str(path), {})["recepcion"] = bool(vision_llm.reception_desk_confirmed(path))
                        return False

                    detect_handoff(pod, photos, asker=asker, reception_asker=reception)
                    rec["aplica"] = bool(seen)
                    for idx, p in enumerate(photos, 1):
                        s = seen.get(str(p.path))
                        if s is None:
                            continue
                        text = p.text or ""
                        rec["fotos"].append(dict(
                            n=idx, is_label=bool(p.is_label), label_tracking=bool(p.label_tracking), tipo=p.photo_type or "",
                            palabras_etiqueta=bool(LABEL_WORDS.search(text)) or bool(_has_label_text(text)),
                            q1=s.get("q1"), q2=s.get("q2"), q3=s.get("q3"), recepcion=s.get("recepcion")))
            except Exception as e:
                rec["error"] = f"{type(e).__name__}: {e}"
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            f.flush()
            print(f"[{i}/{len(todo)}] {trk} {marca} fotos_preguntadas={len(rec['fotos'])}", flush=True)


def positiva(f):
    """La foto cuenta como entrega en mano con la regla actual."""
    return bool((f["q1"] and f["q2"]) or f.get("recepcion"))


VARIANTES = {
    "A actual": lambda fs: any(positiva(f) for f in fs),
    "B sin fotos de etiqueta": lambda fs: any(positiva(f) for f in fs
                                              if not (f["is_label"] or f["tipo"] == "label" or f["palabras_etiqueta"])),
    "C dos fotos distintas": lambda fs: sum(1 for f in fs if positiva(f)) >= 2,
    "D B + dos fotos": lambda fs: sum(1 for f in fs if positiva(f)
                                      and not (f["is_label"] or f["tipo"] == "label" or f["palabras_etiqueta"])) >= 2,
    "E persona presente (q3)": lambda fs: any(positiva(f) and (f["q3"] is True or f.get("recepcion")) for f in fs),
    "F B + persona presente": lambda fs: any(positiva(f) and (f["q3"] is True or f.get("recepcion"))
                                             for f in fs if not (f["is_label"] or f["tipo"] == "label" or f["palabras_etiqueta"])),
}


def resumen():
    rows = [json.loads(l) for l in OUT.read_text(encoding="utf-8").splitlines() if l.strip()]
    ok = [r for r in rows if not r.get("error")]
    print(f"grabados {len(rows)} ({len(rows) - len(ok)} con error) | marcas:", dict(Counter(r["marca"] for r in ok)))
    sin = [r for r in ok if not r["aplica"]]
    print(f"{len(sin)} ya no pasan por la regla con el código actual (no hay foto candidata): {dict(Counter(r['marca'] for r in sin))}")
    print(f"\n{'variante':26} {'reportados omitidos':>20} {'descartados omitidos':>22}   (menos reportados = mejor; más descartados = menos trabajo para ti)")
    rep = [r for r in ok if r["marca"] == "reportado"]
    des = [r for r in ok if r["marca"] == "descartado"]
    for name, fn in VARIANTES.items():
        a = sum(1 for r in rep if r["aplica"] and fn(r["fotos"]))
        b = sum(1 for r in des if r["aplica"] and fn(r["fotos"]))
        print(f"{name:26} {a:>12} de {len(rep):<5} {b:>14} de {len(des):<5}")
    print("\nReportados que cada variante todavía omite:")
    for name, fn in VARIANTES.items():
        t = [r["tracking"][-8:] for r in rep if r["aplica"] and fn(r["fotos"])]
        print(f"  {name:26} {t}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("modo", choices=["grabar", "resumen"])
    ap.add_argument("--limit", type=int, default=None)
    a = ap.parse_args()
    grabar(a.limit) if a.modo == "grabar" else resumen()
