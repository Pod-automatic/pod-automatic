# Aplica al codigo real los cambios que el corrector nocturno dejo como propuesta (07/10/2026).
# Muestra el resumen, pide confirmacion, respalda los archivos que se tocan, aplica y corre las pruebas.
#
# Uso:  powershell -ExecutionPolicy Bypass -File tools\aplicar_propuesta.ps1 [-Dia 20261007]
#       (sin -Dia toma la propuesta mas reciente)

param([string]$Dia)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$Agentes = Join-Path $Root "output\agentes"
$Work = if ($Dia) { Join-Path $Agentes "corrector_$Dia" } else {
    Get-ChildItem $Agentes -Directory -Filter "corrector_*" | Sort-Object Name -Descending | Select-Object -First 1 -ExpandProperty FullName
}
$Diff = Join-Path $Work "cambios.diff"
if (-not $Work -or -not (Test-Path $Diff) -or (Get-Item $Diff).Length -eq 0) { Write-Output "No hay cambios propuestos en $Work"; exit 0 }
$Applied = Join-Path $Work ".aplicada"
if (Test-Path $Applied) { Write-Output "Esta propuesta ya se aplico ($Work)"; exit 0 }

Set-Location $Root
Write-Output "Propuesta: $Work`n"
Get-Content (Join-Path $Work "INFORME.md") -Encoding UTF8 | Select-Object -First 40
Write-Output "`n--- Archivos que cambian ---"
git apply --stat $Diff
git apply --check $Diff
if ($LASTEXITCODE -ne 0) { Write-Output "`nNo se puede aplicar: el codigo cambio desde la noche. Pedile a Claude que la revise."; exit 1 }

$Ok = Read-Host "`nAplicar estos cambios al codigo real? (s/n)"
if ($Ok -ne "s") { Write-Output "Cancelado"; exit 0 }

$Backup = Join-Path $Root ("storage\respaldo_reglas\" + (Get-Date -Format "yyyyMMdd_HHmm") + "_propuesta")
foreach ($f in (git apply --numstat $Diff | ForEach-Object { ($_ -split "`t")[2] })) {
    $src = Join-Path $Root $f
    if (Test-Path $src) {
        $dst = Join-Path $Backup $f
        New-Item -ItemType Directory -Force (Split-Path $dst) | Out-Null
        Copy-Item $src $dst
    }
}
git apply $Diff
New-Item -ItemType File $Applied | Out-Null
Write-Output "Aplicado. Respaldo de los archivos anteriores: $Backup`nCorriendo pruebas..."
& (Join-Path $Root "venv\Scripts\python.exe") -m pytest tests -q
