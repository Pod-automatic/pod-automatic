"""
Evaluación del modelo contra lo que el usuario ya revisó (pendiente n.º 20, 01/10/2026).

Verdad:
- report_status.db de la página: "reportado" = error real (debe seguir en Alta/Media),
  "descartado" = falsa alarma (idealmente Baja).
- tests/casos_reales_<fecha>.json: casos explicados uno por uno (ok / revisar / alta).

Re-evalúa cada albarán con el código ACTUAL (OCR + modelo de visión + relecturas + puntaje), SIN escribir en la base,
y guarda una línea JSON por albarán (se puede cortar y retomar). Al final imprime el resumen.

Uso:  python tools/evaluar_dia.py --date 2026-10-01 [--out resultados.jsonl] [--limit N]
"""

import argparse
import json
import sqlite3
import sys
import time
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import config  # noqa: E402
from models.pod import PODRecord  # noqa: E402
from processing import vision_llm  # noqa: E402
from processing.pipeline import LAST_STAGES, detect_handoff, ocr_photos  # noqa: E402
from processing.scoring import score_pod, top_reasons  # noqa: E402

FLAG = ("Alta", "Media")
RESET_META = ("handoff_photo", "handoff_confirmed")
MANUAL_CHECKS = ("revision_manual", "entrega_en_mano", "entrega_en_casillero")


def truth(date: str) -> dict:
    out = {}
    st = sqlite3.connect(f"file:{(config.STORAGE_DIR / 'report_status.db').as_posix()}?mode=ro", uri=True)
    for trk, status in st.execute("SELECT tracking_number, status FROM report_status WHERE query_date = ? AND " + config.REPORT_STATUS_TRUSTED_SQL, (date,)):
        out[trk] = {"fuente": "marca", "esperado": "revisar" if status == "reportado" else "ok", "marca": status}
    cases = ROOT / "tests" / f"casos_reales_{date.replace('-', '')}.json"
    if cases.exists():
        for c in json.loads(cases.read_text(encoding="utf-8"))["casos"]:
            out[c["tracking"]] = {"fuente": "caso", "esperado": c["esperado"], "motivo": c["motivo"]}
    return out


def load_pod(con, date: str, trk: str):
    row = con.execute("""SELECT p.payload_json FROM pod_checkpoints p JOIN audit_sessions s ON s.session_id = p.session_id
                         WHERE s.query_date = ? AND p.tracking_number = ? ORDER BY s.started_at DESC LIMIT 1""",
                      (date, trk)).fetchone()
    if not row:
        return None
    data = json.loads(row[0])
    for k in RESET_META:
        (data.get("portal_meta") or {}).pop(k, None)
    data["check_results"] = [r for r in data.get("check_results") or [] if r.get("check") not in MANUAL_CHECKS]
    return PODRecord.from_dict(data)


def ok(expected: str, priority: str) -> bool:
    if expected == "ok":
        return priority not in FLAG
    if expected == "alta":
        return priority == "Alta"
    return priority in FLAG


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--date", required=True)
    ap.add_argument("--out", default=None)
    ap.add_argument("--limit", type=int, default=None)
    ap.add_argument("--solo-esperado", default=None, help="Evaluar solo los de este esperado (ej. alta,revisar)")
    ap.add_argument("--subset", choices=["casos-reportados"], default=None,
                    help="casos-reportados: solo los casos explicados y los errores reales (marca reportado)")
    ap.add_argument("--shard", default="0/1", help="I/N: evaluar solo la parte I de N (para varios procesos en paralelo)")
    ap.add_argument("--skip-from", nargs="*", default=[], help="Archivos .jsonl cuyos albaranes ya están evaluados")
    a = ap.parse_args()
    # La computadora no entra en reposo mientras evalúa (04/10: se durmió de 4:00 a 6:36 a mitad de una evaluación)
    try:
        import ctypes
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000000 | 0x00000001)
    except Exception:
        pass
    out = Path(a.out or ROOT / "output" / f"evaluacion_{a.date}.jsonl")
    done = {}
    if out.exists():
        for line in out.read_text(encoding="utf-8").splitlines():
            r = json.loads(line)
            done[r["tracking"]] = r
    for extra in a.skip_from:
        if Path(extra).exists():
            for line in Path(extra).read_text(encoding="utf-8").splitlines():
                r = json.loads(line)
                done.setdefault(r["tracking"], r)
    con = sqlite3.connect(f"file:{config.CHECKPOINT_DB_PATH.as_posix()}?mode=ro", uri=True, timeout=30)
    gt = truth(a.date)
    # Primero los casos explicados uno por uno (resultado visible enseguida), después las marcas de la página
    wanted = set(a.solo_esperado.split(",")) if a.solo_esperado else None
    def in_subset(t):
        return a.subset is None or gt[t]["fuente"] == "caso" or gt[t].get("marca") == "reportado"
    todo = sorted((t for t in gt if t not in done and in_subset(t) and (wanted is None or gt[t]["esperado"] in wanted)),
                  key=lambda t: gt[t]["fuente"] != "caso")
    shard_i, shard_n = (int(x) for x in a.shard.split("/"))
    todo = todo[shard_i::shard_n][: a.limit]
    print(f"{len(gt)} albaranes con verdad; {len(done)} ya evaluados; faltan {len(todo)}", flush=True)
    with out.open("a", encoding="utf-8") as f:
        for i, trk in enumerate(todo, 1):
            pod = load_pod(con, a.date, trk)
            if pod is None:
                continue
            t0 = time.time()
            try:
                photos = ocr_photos(pod.photo_paths, pod.expected_address)
                etapas = dict(LAST_STAGES)
                score_pod(pod, photos)
                vision_llm.reset_stats()
                t1 = time.time()
                if detect_handoff(pod, photos):
                    score_pod(pod, photos)
                etapas["entrega_mano"] = time.time() - t1
                for k, v in vision_llm.STATS.items():
                    etapas[k] = etapas.get(k, 0) + v
                res = {"tracking": trk, **gt[trk], "prioridad": pod.priority, "score": pod.risk_score,
                       "motivos": top_reasons(pod), "segundos": round(time.time() - t0, 1),
                       "etapas": {k: round(v, 1) for k, v in etapas.items()}}
            except Exception as e:
                res = {"tracking": trk, **gt[trk], "prioridad": "ERROR", "error": f"{type(e).__name__}: {e}"}
            res["acierto"] = ok(res["esperado"], res["prioridad"])
            f.write(json.dumps(res, ensure_ascii=False) + "\n"); f.flush()
            done[trk] = res
            print(f"[{i}/{len(todo)}] {trk} esperado={res['esperado']} -> {res['prioridad']} "
                  f"{'OK' if res['acierto'] else 'FALLA'}", flush=True)
    resumen(list(done.values()))


def resumen(rows):
    rep = [r for r in rows if r.get("marca") == "reportado"]
    desc = [r for r in rows if r.get("marca") == "descartado"]
    casos = [r for r in rows if r["fuente"] == "caso"]
    print("\n===== RESUMEN =====")
    print(f"Errores reales (reportados por el usuario): {sum(r['prioridad'] in FLAG for r in rep)}/{len(rep)} "
          f"siguen detectados (Alta/Media)")
    print(f"Falsas alarmas (descartadas por el usuario): {sum(r['prioridad'] in FLAG for r in desc)}/{len(desc)} "
          f"siguen apareciendo; {sum(r['prioridad'] not in FLAG for r in desc)} ya no aparecen")
    print(f"Casos explicados: {sum(r['acierto'] for r in casos)}/{len(casos)} con el resultado esperado")
    for r in casos:
        if not r["acierto"]:
            print(f"   FALLA {r['tracking']} ({r.get('motivo')}): esperado {r['esperado']}, dio {r['prioridad']} "
                  f"{r.get('motivos') or r.get('error')}")
    lost = [r for r in rep if r["prioridad"] not in FLAG]
    for r in lost:
        print(f"   ERROR REAL QUE YA NO SE DETECTA: {r['tracking']} -> {r['prioridad']}")
    print("Prioridades:", Counter(r["prioridad"] for r in rows))


if __name__ == "__main__":
    main()
