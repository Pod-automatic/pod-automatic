"""Exporta, para los casos reales, las fotos, el número esperado y lo que lee EasyOCR (para comparar con otro OCR)."""
import json
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import config  # noqa: E402
from processing.ocr_address import ocr_photo, parse_us_address, reread_numbers  # noqa: E402

date = sys.argv[1] if len(sys.argv) > 1 else "2026-10-01"
cases = json.loads((ROOT / "tests" / f"casos_reales_{date.replace('-', '')}.json").read_text(encoding="utf-8"))["casos"]
con = sqlite3.connect(f"file:{config.CHECKPOINT_DB_PATH.as_posix()}?mode=ro", uri=True)
out = []
for c in cases:
    row = con.execute("SELECT payload_json FROM pod_checkpoints WHERE tracking_number = ? ORDER BY created_at DESC LIMIT 1",
                      (c["tracking"],)).fetchone()
    if not row:
        continue
    p = json.loads(row[0])
    a = parse_us_address(p.get("receipt_address") or p.get("address") or "")
    target = sorted(a.expected_numbers()["unit" if a.is_apartment else "house"])
    photos = []
    for path in p.get("photo_paths") or []:
        if not Path(path).exists():
            continue
        r = ocr_photo(path)
        if r.is_label:
            continue
        easy = sorted(set(r.numbers) | set(r.alt_numbers))
        easy_re = sorted({n for n, _ in reread_numbers(path)})
        photos.append({"path": path, "easyocr": easy, "easyocr_relectura": easy_re})
    out.append({"tracking": c["tracking"], "motivo": c["motivo"], "esperado": c["esperado"], "objetivo": target,
                "fotos": photos})
    print(c["tracking"], target, [f["easyocr"] for f in photos], flush=True)
(ROOT / "output" / "casos_ocr_easyocr.json").write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
print("guardado")
