"""Comparar el coste y decisiones del numero de direccion, sin reportar ni modificar entregas.

Requiere dos servicios Ollama y un servicio Paddle activos. No mide login, descarga,
GPS ni los chequeos de entrega en mano: esos tiempos NO se presentan como verificacion completa.
"""
import argparse
from copy import deepcopy
from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import sys
import threading
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cases',type=Path,required=True)
    parser.add_argument('--primary-url',default='http://127.0.0.1:11544')
    parser.add_argument('--fallback-url',default='http://127.0.0.1:11545')
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--workers',type=int,default=4)
    parser.add_argument('--policies',default='paddle,paddle_3b,paddle_7b,paddle_3b_7b,paddle_3b_7b_ordenada')
    args=parser.parse_args()
    import config
    config.ANALYSIS_CACHE_ENABLED=False
    config.GPU_DISPATCH_DB=''
    from processing.ocr_address import ocr_photo,parse_us_address,match_numbers
    from processing.pipeline import add_vision_opinion
    from processing.vision_llm import PROMPT,_image_b64,VisionResult
    from tools.benchmark_gpu_concurrency import http_json,percentile
    cases=json.loads(args.cases.read_text(encoding='utf-8'))
    primary=threading.BoundedSemaphore(2);fallback=threading.BoundedSemaphore(1);ocr_lock=threading.Lock()
    policies=args.policies.split(',')
    if any(p not in ('paddle','paddle_3b','paddle_7b','paddle_3b_7b','paddle_3b_7b_ordenada') for p in policies):
        raise ValueError('Politica desconocida.')
    output={'scope':'Solo lectura y coincidencia del numero de direccion; no es el tiempo total de un albaran.',
            'human_labels_available':any(c.get('reference') for c in cases),'policies':[]}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    for policy in policies:
        def process(case):
            started=time.perf_counter();calls={'3b':0,'7b':0};errors=[]
            def reader(model,url,semaphore):
                def read(path):
                    calls['7b' if '7b' in model else '3b']+=1
                    try:
                        with semaphore:
                            value=http_json(url+'/api/generate',{'model':model,'prompt':PROMPT,
                                'images':[_image_b64(path,1024)],'format':'json','stream':False,'keep_alive':-1,
                                'options':{'temperature':0,'num_ctx':2048,'num_predict':150}})
                        data=json.loads(value.get('response',''))
                        return VisionResult(path=path,numbers=[str(n) for n in data.get('numbers',[])],
                                            photo_type=data.get('photo_type','other'))
                    except Exception as error:
                        errors.append(type(error).__name__)
                        return VisionResult(path=path,error=str(error))
                return read
            photos=[]
            for path in case['paths']:
                with ocr_lock: photos.append(ocr_photo(str(path)))
            errors.extend(p.error for p in photos if p.error)
            before=match_numbers(parse_us_address(case['address']),photos).status
            if policy.endswith('ordenada'):
                # Se conservan TODAS las fotos del 3B. Solo cambia el orden para el respaldo.
                photos.sort(key=lambda p:(p.is_label,p.error!='',-len(p.numbers or []),
                                         -max((p.number_conf or {}).values(),default=0)))
            if policy!='paddle':
                use_7b=policy=='paddle_7b'
                normal=reader('qwen2.5vl:7b' if use_7b else 'qwen2.5vl:3b',
                              args.fallback_url if use_7b else args.primary_url,fallback if use_7b else primary)
                rescue=reader('qwen2.5vl:7b',args.fallback_url,fallback) if '3b_7b' in policy else None
                add_vision_opinion(photos,case['address'],reader=normal,fallback_reader=rescue)
            after=match_numbers(parse_us_address(case['address']),photos).status
            return {'case':case['id'],'before':before,'after':after,'seconds':round(time.perf_counter()-started,4),
                    'calls':calls,'errors':errors,'reference':case.get('reference')}
        started=time.perf_counter()
        with ThreadPoolExecutor(max_workers=max(1,min(4,args.workers))) as pool:
            rows=list(pool.map(process,deepcopy(cases)))
        elapsed=time.perf_counter()-started
        result={'policy':policy,'cases':len(rows),'wall_s':round(elapsed,3),
                'cases_per_hour':round(len(rows)*3600/elapsed,2),'p50_s':percentile([r['seconds'] for r in rows],.5),
                'p95_s':percentile([r['seconds'] for r in rows],.95),'matched':sum(r['after']=='match' for r in rows),
                'calls_3b':sum(r['calls']['3b'] for r in rows),'calls_7b':sum(r['calls']['7b'] for r in rows),
                'read_errors':sum(len(r['errors']) for r in rows),'results':rows}
        output['policies'].append(result)
        args.output.write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf-8')
        print(json.dumps({k:v for k,v in result.items() if k!='results'}),flush=True)
    print('Sin etiquetas humanas no se puede elegir la politica mas precisa solo por sus coincidencias.',flush=True)


if __name__=='__main__': main()
