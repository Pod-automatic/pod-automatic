﻿# Arranque diario de la auditoría de POD (lo lanza la tarea programada "POD - corrida diaria" a las 10:00).
# - Si ya hay una corrida activa, no lanza otra.
# - Se asegura de que Ollama y la página local estén arriba (Paddle lo levanta el propio script).
# - Corre las dos ciudades en modo continuo y espera a que termine; si se detiene con error, avisa con una ventana.
#   Código 2 = sesión de GOFO vencida: hay que iniciar sesión a mano (el script nunca guarda ni escribe contraseñas).

#   -Estaciones DFW02-BAA : solo esa ciudad (a pedido; la tarea programada no lo usa y corre las dos)
#   -Repartidores "456804,454409" : solo esos repartidores (IDs o nombres, separados por coma) (17/10)
param([string]$Estaciones = "", [string]$Repartidores = "")

$ErrorActionPreference = "Continue"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
$python = Join-Path $root "venv\Scripts\python.exe"
$stamp = Get-Date -Format "yyyyMMdd"
$log = Join-Path $root "storage\arranque_$stamp.log"

function Write-Log($msg) {
    Add-Content -Path $log -Value ("{0}  {1}" -f (Get-Date -Format "HH:mm:ss"), $msg) -Encoding UTF8
}

function Show-Alert($title, $msg, $icon = 48) {
    try { (New-Object -ComObject WScript.Shell).Popup($msg, 0, $title, $icon) | Out-Null } catch { Write-Log "No se pudo mostrar el aviso: $_" }
}

function Get-PodProcess($pattern) {
    Get-CimInstance Win32_Process -Filter "Name like 'python%'" | Where-Object { $_.CommandLine -like $pattern }
}

Write-Log "Arranque programado"

if (Get-PodProcess "*main.py run*") {
    Write-Log "Ya hay una corrida activa: no se lanza otra"
    exit 0
}

# 07/10: un servidor de Paddle que queda abierto de un día para otro acumula ~3 GB de GPU; con el modelo de visión la
# GPU (6 GB) se llena y la corrida baja de ~450 a ~180 albaranes/hora. Se cierra para que la corrida abra uno limpio.
# También los procesos de OCR que quedan huérfanos si una corrida anterior se cerró a la fuerza.
Get-PodProcess "*paddle_ocr_server*" | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Get-CimInstance Win32_Process -Filter "Name like 'python%'" | Where-Object {
    $_.CommandLine -like '*multiprocessing-fork*' -and -not (Get-Process -Id $_.ParentProcessId -ErrorAction SilentlyContinue)
} | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Write-Log "Paddle viejo y procesos huérfanos cerrados"

# Ollama (modelo de visión): si no está corriendo, se abre la app
if (-not (Get-Process -Name "ollama*" -ErrorAction SilentlyContinue)) {
    $ollama = Join-Path $env:LOCALAPPDATA "Programs\Ollama\ollama app.exe"
    if (Test-Path $ollama) {
        Start-Process -FilePath $ollama
        Write-Log "Ollama no estaba corriendo: se abrió"
        Start-Sleep -Seconds 15
    } else {
        Write-Log "Ollama no está corriendo y no se encontró la app"
    }
}

# Página local de reportes (http://127.0.0.1:8765)
if (-not (Get-PodProcess "*main.py report*")) {
    Start-Process -FilePath $python -ArgumentList "main.py", "report" -WorkingDirectory $root -WindowStyle Minimized
    Write-Log "Página local iniciada"
}

# 24/10: vigilante de Paddle (reinicia Paddle solo si la GPU se satura); antes había que lanzarlo a mano cada día.
# Se cierra solo si no hay corrida durante 20 minutos.
if (-not (Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -like '*vigilante_paddle*' })) {
    Start-Process -FilePath "powershell.exe" -WindowStyle Hidden -ArgumentList "-NoProfile", "-ExecutionPolicy", "Bypass",
        "-File", (Join-Path $root "tools\vigilante_paddle.ps1")
    Write-Log "Vigilante de Paddle iniciado"
}

$env:PYTHONIOENCODING = "utf-8"
$out = Join-Path $root "storage\corrida_$stamp.log"
$err = Join-Path $root "storage\corrida_${stamp}_errores.log"
$runArgs = @("main.py", "run", "--continuous")
# 13/10: ciudades SOLO DEL DÍA ('_estaciones_solo_hoy' en drivers_config.json: {"fecha": "AAAA-MM-DD", "estaciones": "DFW-BAA"}).
# Otro día se ignora sola y la corrida vuelve a las dos ciudades
if (-not $Estaciones) {
    try {
        $cfg = Get-Content (Join-Path $root "drivers_config.json") -Raw -Encoding UTF8 | ConvertFrom-Json
        $hoy = $cfg._estaciones_solo_hoy
        if ($hoy -and $hoy.fecha -eq (Get-Date -Format "yyyy-MM-dd") -and $hoy.estaciones) { $Estaciones = [string]$hoy.estaciones }
    } catch { Write-Log "No se pudo leer las ciudades del día: $_" }
}
if ($Estaciones) { $runArgs += @("--stations", $Estaciones) }
if ($Repartidores) { $runArgs += @("--drivers", $Repartidores) }
Write-Log ("Corrida iniciada (" + $(if ($Estaciones) { $Estaciones } else { "ciudades de GOFO_STATION_IDS en .env" }) + ", modo continuo). Salida en $out")
$p = Start-Process -FilePath $python -ArgumentList $runArgs -WorkingDirectory $root `
    -WindowStyle Hidden -RedirectStandardOutput $out -RedirectStandardError $err -PassThru -Wait
$code = $p.ExitCode
Write-Log "La corrida terminó con código $code"

if ($code -eq 2) {
    Show-Alert "POD - sesión de GOFO vencida" ("La corrida diaria NO pudo seguir: la sesión del portal de GOFO venció.`n`n" +
        "Inicia sesión en GOFO y luego vuelve a lanzarla (o pídeselo a Claude).`n`nDetalle: $log")
} elseif ($code -ne 0) {
    Show-Alert "POD - la corrida se detuvo" ("La corrida diaria se detuvo con un error (código $code).`n`n" +
        "Revisa:`n$err`n$out")
}
