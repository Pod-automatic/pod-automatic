"""Copia consistente de la caché, incluyendo escrituras WAL, para conservarla entre entornos.
Uso: python tools/analysis_cache_snapshot.py --out output/analysis_cache.db
Restaurar el archivo como storage/analysis_cache.db con la corrida detenida.
"""
import argparse
import sqlite3
import sys
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import config


def snapshot(source,destination):
    source,destination=Path(source).resolve(),Path(destination).resolve()
    if source==destination: raise ValueError('La copia debe tener una ruta diferente de la caché activa.')
    if not source.is_file(): raise FileNotFoundError('Todavía no hay lecturas guardadas en caché.')
    if destination.exists(): raise FileExistsError('La copia ya existe. Elige otro nombre para conservarla.')
    destination.parent.mkdir(parents=True,exist_ok=True)
    src=sqlite3.connect(source.as_uri()+'?mode=ro',uri=True,timeout=15)
    dst=sqlite3.connect(destination)
    try: src.backup(dst)
    finally: dst.close(); src.close()
    return destination


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    print(snapshot(config.ANALYSIS_CACHE_PATH,args.out))
