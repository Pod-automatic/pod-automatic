"""A/B real: clientes concurrentes, dos Paddle independientes y Ollama paralelo 1/2.

No consulta GOFO ni escribe resultados de entregas. Usa servicios aislados y fotos locales.
Los resultados de otra GPU no representan automaticamente el rendimiento de Kaggle T4.
"""
import argparse
import base64
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from datetime import datetime,timezone
import hashlib
import io
import json
import os
from pathlib import Path
import random
import queue
import statistics
import subprocess
import sys
import threading
import time
import urllib.request

import psutil
from PIL import Image,ImageOps

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from processing.vision_llm import PROMPT


def photo_batches(paths,size=1):
    """No mezclar fotos de distintas entregas dentro de una consulta multimodal."""
    by_delivery={}
    for path in paths: by_delivery.setdefault(path.parent,[]).append(path)
    return [photos[i:i+size] for photos in by_delivery.values() for i in range(0,len(photos),size)]


def http_json(url,body=None,timeout=180):
    req=urllib.request.Request(url,data=json.dumps(body).encode() if body is not None else None,
                               headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=timeout) as response:
        result=json.load(response)
    if result.get('error'): raise RuntimeError(str(result['error'])[:250])
    return result


def percentile(values,p):
    if not values: return None
    ordered=sorted(values)
    return ordered[min(len(ordered)-1,max(0,int((len(ordered)-1)*p+.5)))]


class Monitor:
    def __init__(self,gpu):
        self.gpu=str(gpu);self.samples=[];self.stop=threading.Event();self.thread=None
    def tick(self):
        while not self.stop.is_set():
            try:
                raw=subprocess.run(['nvidia-smi',f'--id={self.gpu}',
                    '--query-gpu=memory.used,utilization.gpu','--format=csv,noheader,nounits'],
                    capture_output=True,text=True,timeout=5)
                memory,usage=[float(x.strip()) for x in raw.stdout.strip().split(',')]
                self.samples.append({'memory_mib':memory,'gpu_pct':usage,'cpu_host_pct':psutil.cpu_percent()})
            except Exception: pass
            self.stop.wait(.5)
    def __enter__(self):
        self.thread=threading.Thread(target=self.tick,daemon=True);self.thread.start();return self
    def __exit__(self,*_):
        self.stop.set();self.thread.join(timeout=6)
    def summary(self):
        if not self.samples: return {'telemetry_samples':0}
        return {'telemetry_samples':len(self.samples),
                'peak_vram_mib':max(s['memory_mib'] for s in self.samples),
                'mean_gpu_pct':round(statistics.mean(s['gpu_pct'] for s in self.samples),1),
                'mean_cpu_host_pct':round(statistics.mean(s['cpu_host_pct'] for s in self.samples),1)}


@contextmanager
def service(command,env,health,log_path,cpu_ids):
    with log_path.open('w',encoding='utf-8') as log:
        process=subprocess.Popen(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
    try:
        if cpu_ids: psutil.Process(process.pid).cpu_affinity(cpu_ids)
        deadline=time.monotonic()+300
        while time.monotonic()<deadline:
            if process.poll() is not None: raise RuntimeError(f'Servicio termino; ver {log_path.name}')
            try:
                http_json(health,timeout=2)
                break
            except Exception: time.sleep(1)
        else: raise TimeoutError(f'Servicio no listo; ver {log_path.name}')
        yield process
    finally:
        try:
            descendants=psutil.Process(process.pid).children(recursive=True)
            process.terminate()
            try: process.wait(timeout=10)
            except subprocess.TimeoutExpired: process.kill();process.wait(timeout=5)
            for child in descendants:
                try: child.terminate()
                except psutil.NoSuchProcess: pass
            _,alive=psutil.wait_procs(descendants,timeout=5)
            for child in alive:
                try: child.kill()
                except psutil.NoSuchProcess: pass
        except psutil.NoSuchProcess: pass


def fingerprint(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False).encode()).hexdigest()


def run_round(label,concurrency,items,call,gpu,photo_counts=None):
    def one(pair):
        index,path=pair;started=time.perf_counter()
        try:
            value=call(index,path)
            row={'image_index':index,'photos':(photo_counts or {}).get(str(path),1),'latency_s':round(time.perf_counter()-started,4),
                 'signature':fingerprint(value),'ok':True}
            reading=value.get('vision',value) if isinstance(value,dict) else None
            if isinstance(reading,dict) and 'numbers' in reading: row['vision']=reading
            elif isinstance(reading,list) and all(isinstance(r,dict) and 'numbers' in r for r in reading): row['vision']=reading
            return row
        except Exception as error:
            return {'image_index':index,'photos':(photo_counts or {}).get(str(path),1),'latency_s':round(time.perf_counter()-started,4),
                    'ok':False,'error':f'{type(error).__name__}: {error}'[:300]}
    started=time.perf_counter()
    with Monitor(gpu) as monitor:
        with ThreadPoolExecutor(max_workers=concurrency) as pool:
            rows=list(pool.map(one,enumerate(items)))
        elapsed=time.perf_counter()-started
    successful=[r for r in rows if r['ok']]
    latencies=[r['latency_s'] for r in successful]
    return {'label':label,'clients':concurrency,'wall_s':round(elapsed,4),'count':len(rows),
            'ok':len(successful),'errors':len(rows)-len(successful),
            'images_per_minute':round(sum(r['photos'] for r in successful)*60/elapsed,3),
            'requests_per_minute':round(len(successful)*60/elapsed,3),
            'latency_p50_s':percentile(latencies,.5),'latency_p95_s':percentile(latencies,.95),
            **monitor.summary(),'requests':rows}


def summarize(report):
    groups={}
    for result in report['rounds']:
        key=(result['label'],result['clients'])
        groups.setdefault(key,[]).append(result)
    summary=[]
    baseline={}
    for result in groups.get(('ollama_parallel_1',1),[]):
        for index,row in enumerate(result['requests']):
            if row['ok']: baseline.setdefault(index,set()).add(row['signature'])
    for (label,clients),rounds in groups.items():
        rows=[r for run in rounds for r in run['requests']]
        good=[r for r in rows if r['ok']]
        wall=sum(r['wall_s'] for r in rounds)
        mismatches=compared=0
        if label.startswith('ollama'):
            for run in rounds:
                for index,row in enumerate(run['requests']):
                    if row['ok'] and len(baseline.get(index,set()))==1:
                        compared+=1;mismatches+=row['signature'] not in baseline[index]
        summary.append({'label':label,'clients':clients,'images':len(rows),'ok':len(good),
            'errors':len(rows)-len(good),'images_per_minute':round(sum(r.get('photos',1) for r in good)*60/wall,3),
            'requests_per_minute':round(len(good)*60/wall,3),
            'p50_s':percentile([r['latency_s'] for r in good],.5),
            'p95_s':percentile([r['latency_s'] for r in good],.95),
            'peak_vram_mib':max((r.get('peak_vram_mib',0) for r in rounds),default=0),
            'compared_to_stable_ollama_baseline':compared,'different_outputs':mismatches})
    return summary


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--images',type=Path,default=ROOT/'storage/pod_images/2026-10-27')
    parser.add_argument('--manifest',type=Path)
    parser.add_argument('--count',type=int,default=6)
    parser.add_argument('--gpu',type=int,default=0)
    parser.add_argument('--cpu-count',type=int,default=4)
    parser.add_argument('--paddle-python',type=Path,default=ROOT/'venv_paddle/Scripts/python.exe')
    parser.add_argument('--output',type=Path,default=ROOT/'output/benchmark_concurrencia_20261028')
    parser.add_argument('--engines',choices=['all','paddle','ollama','pipeline'],default='all')
    parser.add_argument('--model',default='qwen2.5vl:3b')
    parser.add_argument('--photo-batch-size',type=int,choices=[1,2],default=1)
    parser.add_argument('--require-full-gpu',action='store_true',help='Rechazar comparaciones con partes del modelo en CPU.')
    parser.add_argument('--parallel-modes',default='1,2')
    parser.add_argument('--round-clients',default='1,2,2,1')
    args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    parallel_modes=[int(p) for p in args.parallel_modes.split(',')]
    round_clients=[int(p) for p in args.round_clients.split(',')]
    if not parallel_modes or not round_clients or any(p not in (1,2) for p in parallel_modes+round_clients):
        raise ValueError('La prueba admite concurrencia 1 o 2.')
    paddle_port=8870+args.gpu*10
    paddle_url=f'http://127.0.0.1:{paddle_port}'
    if args.manifest:
        items=[Path(p) for p in json.loads(args.manifest.read_text(encoding='utf-8'))]
    else:
        # Tomar fotos de albaranes distintos; misma muestra y orden en todos los ensayos.
        folders=sorted(p for p in args.images.iterdir() if p.is_dir())
        random.Random(28).shuffle(folders)
        items=[]
        for folder in folders:
            photos=sorted(p for p in folder.iterdir() if p.suffix.lower() in ('.jpg','.png','.jpeg'))
            if photos: items.append(photos[0].resolve())
            if len(items)>=args.count: break
    if not items: raise ValueError('No hay fotos para medir.')
    cpu_ids=psutil.Process().cpu_affinity()[:args.cpu_count] if hasattr(psutil.Process(),'cpu_affinity') else []
    if cpu_ids: psutil.Process().cpu_affinity(cpu_ids)
    base=dict(os.environ,CUDA_VISIBLE_DEVICES=str(args.gpu),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',
              MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PADDLE_MAX_RAM_MB='6000',
              PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK='True',PYTHONIOENCODING='utf-8')
    original_items=list(items)
    batches=photo_batches(items,args.photo_batch_size)
    grouped={str(batch[0]):batch for batch in batches}
    items=[batch[0] for batch in batches]
    photo_counts={key:len(batch) for key,batch in grouped.items()}
    report={'started_utc':datetime.now(timezone.utc).isoformat(),'images':[str(p) for p in original_items],
            'groups':[[str(p) for p in batch] for batch in batches],'model':args.model,'photo_batch_size':args.photo_batch_size,
            'cpu_affinity':cpu_ids,'gpu':subprocess.run(['nvidia-smi',f'--id={args.gpu}',
                '--query-gpu=name,memory.total','--format=csv,noheader'],capture_output=True,text=True).stdout.strip(),
            'notes':['HTTP directo; sin cache de lecturas del proyecto.','Calentamiento excluido.',
                     'Latencia incluye cola del servicio.','Telemetria muestreada cada ~0.5 s.',
                     'Firmas comparan estabilidad; no acreditan exactitud contra etiquetas humanas.'],
            'rounds':[],'failures':[]}
    (args.output/'manifest.json').write_text(json.dumps([str(p) for p in original_items],indent=2),encoding='utf-8')
    def save():
        (args.output/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    def measure(label,clients,call):
        result=run_round(label,clients,items,call,args.gpu,photo_counts)
        report['rounds'].append(result);save()
        print(label,'clientes',clients,':',result['images_per_minute'],'imagenes/min;',
              result['latency_p50_s'],'s p50;',result.get('peak_vram_mib'),'MiB;',result['errors'],'errores',flush=True)
    if args.engines in ('paddle','all'):
        try:
            cmd=[str(args.paddle_python),'tools/paddle_ocr_server.py','--port']
            def paddle_one(url,path):
                data=http_json(url+'/ocr',{'path':str(path),'upscale':1})
                return [(d['text'],round(float(d['conf']),3)) for d in data.get('detections',[])]
            def paddle(url,index,path):
                return [paddle_one(url,p) for p in grouped[str(path)]]
            with service(cmd+[str(paddle_port)],base,paddle_url+'/health',args.output/'paddle_1.log',cpu_ids):
                for index,path in enumerate(items): paddle(paddle_url,index,path)
                single=lambda index,path:paddle(paddle_url,index,path)
                for clients in round_clients: measure('paddle_un_servidor',clients,single)
                second_url=f'http://127.0.0.1:{paddle_port+1}'
                with service(cmd+[str(paddle_port+1)],base,second_url+'/health',args.output/'paddle_2.log',cpu_ids):
                    for index,path in enumerate(items): paddle(second_url,index,path)
                    ports=queue.Queue()
                    for port in (paddle_port,paddle_port+1): ports.put(port)
                    def two_paddles(index,path):
                        port=ports.get()
                        try: return paddle(f'http://127.0.0.1:{port}',index,path)
                        finally: ports.put(port)
                    for _ in range(2): measure('paddle_dos_instancias',2,
                                               two_paddles)
        except Exception as error:
            report['failures'].append({'engine':'paddle','error':f'{type(error).__name__}: {error}'});save()
            print('Paddle:',type(error).__name__,str(error),flush=True)
    if args.engines in ('ollama','all','pipeline'):
        encoded={}
        for path in original_items:
            with Image.open(path) as image:
                image=ImageOps.exif_transpose(image).convert('RGB');image.thumbnail((1024,1024))
                stream=io.BytesIO();image.save(stream,format='JPEG',quality=90)
                encoded[str(path)]=base64.b64encode(stream.getvalue()).decode()
        model=args.model;url=f'http://127.0.0.1:{11544+args.gpu}'
        for parallel in parallel_modes:
            try:
                env=dict(base,OLLAMA_HOST=f'127.0.0.1:{11544+args.gpu}',OLLAMA_NUM_PARALLEL=str(parallel),
                         OLLAMA_MAX_LOADED_MODELS='1',OLLAMA_CONTEXT_LENGTH='2048',OLLAMA_FLASH_ATTENTION='1',OLLAMA_KEEP_ALIVE='-1')
                with service(['ollama','serve'],env,url+'/api/tags',args.output/f'ollama_p{parallel}.log',cpu_ids):
                    def vision(index,path):
                        photos=grouped[str(path)]
                        prompt=PROMPT if len(photos)==1 else ('These photos show the SAME delivery. Read each photo separately. '
                            'Rules for each photo: '+PROMPT.rsplit('Answer only JSON:',1)[0]+
                            ' Return only JSON with one result for EVERY photo: '
                            '{"photos":[{"index":0,"numbers":[],"photo_type":"other"},'
                            '{"index":1,"numbers":[],"photo_type":"other"}]}. Use zero-based indexes, never merge photos.')
                        schema='json' if len(photos)==1 else {'type':'object','properties':{'photos':{
                            'type':'array','minItems':len(photos),'maxItems':len(photos),'items':{'type':'object',
                            'properties':{'index':{'type':'integer','enum':list(range(len(photos)))},
                                          'numbers':{'type':'array','items':{'type':'string'}},
                                          'photo_type':{'type':'string','enum':['door','building','label','locker','package_room','other']}},
                            'required':['index','numbers','photo_type']}}},'required':['photos']}
                        context=2048 if len(photos)==1 else 4096
                        result=http_json(url+'/api/generate',{'model':model,'prompt':prompt,'images':[encoded[str(p)] for p in photos],
                            'format':schema,'stream':False,'keep_alive':-1,
                            'options':{'temperature':0,'num_ctx':context,'num_predict':150*len(photos)}},timeout=180)
                        value=json.loads(result.get('response',''))
                        if len(photos)>1:
                            readings=value.get('photos',[])
                            if len(readings)!=len(photos) or {r.get('index') for r in readings}!=set(range(len(photos))):
                                raise ValueError('La respuesta multimagen no identifica todas las fotos.')
                            return [{'index':r['index'],'numbers':sorted(r.get('numbers',[])),'photo_type':r.get('photo_type')}
                                    for r in sorted(readings,key=lambda r:r['index'])]
                        return {'numbers':sorted(value.get('numbers',[])),'photo_type':value.get('photo_type')}
                    for index,path in enumerate(items): vision(index,path)
                    report.setdefault('ollama_loaded',{})[str(parallel)]=http_json(url+'/api/ps')
                    loaded=report['ollama_loaded'][str(parallel)].get('models',[])
                    if args.require_full_gpu and (not loaded or any(
                            float(m.get('size_vram',0))<.98*float(m.get('size',1)) for m in loaded)):
                        raise RuntimeError('El modelo no esta completamente en GPU; no es una comparacion valida de GPU.')
                    if args.engines=='pipeline':
                        cmd=[str(args.paddle_python),'tools/paddle_ocr_server.py','--port',str(paddle_port)]
                        with service(cmd,base,paddle_url+'/health',args.output/f'paddle_combined_p{parallel}.log',cpu_ids):
                            def combined(index,path):
                                readings=[]
                                for p in grouped[str(path)]:
                                    ocr=http_json(paddle_url+'/ocr',{'path':str(p),'upscale':1})
                                    readings.append([(d['text'],round(float(d['conf']),3)) for d in ocr.get('detections',[])])
                                return {'ocr':readings,'vision':vision(index,path)}
                            for index,path in enumerate(items): combined(index,path)
                            for clients in round_clients: measure(f'pipeline_paddle_ollama_p{parallel}',clients,combined)
                    else:
                        for clients in round_clients: measure(f'ollama_parallel_{parallel}',clients,vision)
            except Exception as error:
                report['failures'].append({'engine':f'ollama_p{parallel}','error':f'{type(error).__name__}: {error}'});save()
                print('Ollama:',type(error).__name__,str(error),flush=True)
    report['finished_utc']=datetime.now(timezone.utc).isoformat()
    report['summary']=summarize(report);save()
    print('Resultados:',args.output/'results.json',flush=True)


if __name__=='__main__': main()
