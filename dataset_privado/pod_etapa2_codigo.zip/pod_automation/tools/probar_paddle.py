"""
Prueba PaddleOCR (entorno venv_paddle) sobre las fotos de los casos reales y lo compara con EasyOCR.
Uso: venv_paddle\\Scripts\\python.exe tools\\probar_paddle.py
Lee output/casos_ocr_easyocr.json (generado con tools/exportar_casos_ocr.py en el venv del proyecto).
"""
import json
import re
import time
from pathlib import Path

from paddleocr import PaddleOCR

ROOT = Path(__file__).resolve().parents[1]
casos = json.loads((ROOT / "output" / "casos_ocr_easyocr.json").read_text(encoding="utf-8"))

ocr = PaddleOCR(lang="en", use_doc_orientation_classify=False, use_doc_unwarping=False,
                use_textline_orientation=True)


def digits(s):
    return re.sub(r"\D", "", s or "")


def numbers_from(texts, scores, min_score=0.5):
    out = set()
    for t, s in zip(texts, scores):
        if s < min_score:
            continue
        for m in re.findall(r"\d+", (t or "").replace("O", "0").replace("o", "0")):
            out.add(m)
    return out


def stacked(polys, texts, scores):
    """Dígitos sueltos alineados en columna -> un número (misma idea que en el OCR del proyecto)."""
    boxes = []
    for poly, t, s in zip(polys, texts, scores):
        t = re.sub(r"\s", "", t or "")
        if not re.fullmatch(r"\d{1,2}", t):
            continue
        xs = [p[0] for p in poly]; ys = [p[1] for p in poly]
        boxes.append({"t": t, "cx": (min(xs) + max(xs)) / 2, "w": max(xs) - min(xs), "y0": min(ys), "y1": max(ys),
                      "h": max(ys) - min(ys)})
    boxes.sort(key=lambda b: b["y0"])
    out = set()
    for i, b in enumerate(boxes):
        col = [b]
        for c in boxes[i + 1:]:
            last = col[-1]
            aw = max(1.0, (last["w"] + c["w"]) / 2); ah = max(1.0, (last["h"] + c["h"]) / 2)
            if abs(c["cx"] - last["cx"]) < 0.8 * aw and 0 <= c["y0"] - last["y1"] < 1.6 * ah:
                col.append(c)
        num = "".join(x["t"] for x in col)
        if len(col) >= 3 and 3 <= len(num) <= 6:
            out.add(num)
    return out


resumen = {"paddle": 0, "easy": 0, "easy_relectura": 0, "total": 0}
filas = []
t0 = time.time()
for c in casos:
    if not c["objetivo"]:
        continue
    tgt = set(c["objetivo"])
    found_p, found_e, found_er, leidos_p = False, False, False, set()
    for f in c["fotos"]:
        res = ocr.predict(f["path"])
        for r in res:
            texts, scores, polys = r["rec_texts"], r["rec_scores"], r["rec_polys"]
            nums = numbers_from(texts, scores) | stacked(polys, texts, scores)
            leidos_p |= nums
        found_e |= bool(tgt & set(digits(x) for x in f["easyocr"]))
        found_er |= bool(tgt & set(f["easyocr_relectura"]))
    found_p = bool(tgt & {n.lstrip("0") or n for n in leidos_p} | tgt & leidos_p)
    resumen["total"] += 1
    resumen["paddle"] += found_p
    resumen["easy"] += found_e
    resumen["easy_relectura"] += found_e or found_er
    filas.append((c["tracking"], c["motivo"][:45], "/".join(sorted(tgt)), found_e, found_e or found_er, found_p,
                  sorted(leidos_p)[:8]))
    print(f"{c['tracking']} {c['motivo'][:40]:40} objetivo={'/'.join(sorted(tgt)):6} "
          f"EasyOCR={'SI' if found_e else 'no'} +relectura={'SI' if (found_e or found_er) else 'no'} "
          f"Paddle={'SI' if found_p else 'no'}  paddle_leyo={sorted(leidos_p)[:8]}", flush=True)

print(f"\nNúmero correcto encontrado (de {resumen['total']} casos con número esperado):")
print(f"  EasyOCR solo:            {resumen['easy']}")
print(f"  EasyOCR + relectura:     {resumen['easy_relectura']}")
print(f"  PaddleOCR:               {resumen['paddle']}")
print(f"Tiempo PaddleOCR: {time.time() - t0:.0f} s")
(ROOT / "output" / "comparacion_paddle_easyocr.json").write_text(json.dumps(filas, ensure_ascii=False, indent=1),
                                                               encoding="utf-8")
