"""Comparacion pareada de los cuatro cambios. Sin escribir bases de produccion.

python tools/probar_primera_lectura.py
Reanuda desde resultados por caso y conserva previews y cajas para auditoria.
"""
from collections import Counter
from copy import deepcopy
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import statistics
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
OUT = ROOT / 'output' / 'piloto_primera_lectura_20261027'


def merge_readings(records, results, order=None, limit=None):
    from processing.ocr_address import PhotoOCR
    photos = [PhotoOCR(**deepcopy(r['reading'])) for r in records]
    if order is None:
        order = range(len(photos))
    for i in list(order)[:limit]:
        result = results.get(str(i))
        if not result or photos[i].is_label or photos[i].error:
            continue
        photo = photos[i]
        if result['error']:
            photo.vision_error = result['error']
            continue
        if result['photo_type'] not in ('door', 'building'):
            continue
        photo.vision_used = True
        photo.photo_type = result['photo_type']
        photo.vision_error = ''
        for value in result['numbers']:
            number = ''.join(c for c in value if c.isdigit())
            if not number:
                continue
            if number not in photo.numbers:
                photo.numbers.append(number)
                photo.vision_numbers.append(number)
            if number not in photo.vision_all:
                photo.vision_all.append(number)
            import config
            photo.number_conf[number] = max(photo.number_conf.get(number, 0), config.VISION_NUMBER_CONFIDENCE)
    return photos


def project(sample, photos):
    from models.pod import PODRecord
    from processing.scoring import CheckResult, check_address_number, check_vision_failure, combine_scores, priority_for
    pod = PODRecord.from_dict(sample['pod'])
    number = check_address_number(pod, deepcopy(photos))
    matched = (number.details or {}).get('status') == 'match'
    vision = check_vision_failure([] if matched else photos)
    checks = [CheckResult(**r) for r in pod.check_results if r.get('check') not in ('numero_direccion', 'vision_fallida')]
    checks += [number, vision]
    score = combine_scores(checks)
    return {'prioridad': priority_for(score).value, 'score': score,
            'numero': number.to_dict(), 'vision': vision.to_dict()}


def projections(sample, row):
    records,results=row['records'],row['responses']
    row['normal']=project(sample,merge_readings(records,results['normal']))
    row['detail']=project(sample,merge_readings(records,results['detail']))
    row['normal_primera']=project(sample,merge_readings(records,results['normal'],row['orden_natural'],1))
    row['detail_priorizada_primera']=project(sample,merge_readings(records,results['detail'],row['orden_priorizado'],1))
    row['normal_priorizada_primera']=project(sample,merge_readings(records,results['normal'],row['orden_priorizado'],1))
    row['detail_primera']=project(sample,merge_readings(records,results['detail'],row['orden_natural'],1))
    row['isolation_version']=2
    return row


def summarize(manifest):
    rows = []
    for i in range(len(manifest)):
        p = OUT / f'caso_{i:03}.json'
        if p.exists():
            rows.append(json.loads(p.read_text(encoding='utf-8')))
    flagged = lambda result: result['prioridad'] in ('Alta', 'Media')
    totals = {'muestra': len(manifest), 'completados': len(rows),
              'marcas': dict(Counter(r['marca'] for r in rows))}
    for variant in ('normal', 'detail', 'normal_primera', 'detail_priorizada_primera',
                    'normal_priorizada_primera','detail_primera'):
        if not all(variant in r for r in rows):
            continue
        totals[variant] = {
            'reportados_detectados': sum(r['marca'] == 'reportado' and flagged(r[variant]) for r in rows),
            'descartados_en_revision': sum(r['marca'] == 'descartado' and flagged(r[variant]) for r in rows),
            'numeros_confirmados': sum(r[variant]['numero']['details'].get('status') == 'match' for r in rows)}
    totals['mejoras_detail_vs_normal'] = sum(r['marca']=='descartado' and flagged(r['normal']) and not flagged(r['detail']) for r in rows)
    totals['nuevas_falsas_detail_vs_normal'] = sum(r['marca']=='descartado' and not flagged(r['normal']) and flagged(r['detail']) for r in rows)
    totals['reportados_perdidos_detail_vs_normal'] = sum(r['marca']=='reportado' and flagged(r['normal']) and not flagged(r['detail']) for r in rows)
    totals['region_records'] = sum(len(r['records']) for r in rows)
    totals['detector_calls'] = sum(r['detector_calls'] for r in rows)
    totals['segundos_preparacion_ocr'] = round(sum(r['ocr_seconds'] for r in rows), 3)
    totals['ocr_regions_cache_hits'] = sum(r['ocr_cache_hits'] for r in rows)
    for variant in ('normal', 'detail'):
        times = [sum(s['seconds'] for s in r['timing'][variant].values()) for r in rows]
        totals[variant]['tiempo_total_s'] = round(sum(times), 3)
        totals[variant]['promedio_por_paquete_s'] = round(statistics.mean(times), 3) if times else None
        totals[variant]['consultas_backend'] = sum(not s['cache_hit'] for r in rows for s in r['timing'][variant].values())
        totals[variant]['errores_lectura'] = sum(bool(v['error']) for r in rows for v in r['responses'][variant].values())
    totals['vistas_con_detalle'] = sum(s['used_detail'] for r in rows for s in r['timing']['detail'].values())
    for variant,source,order in [('normal_primera','normal','orden_natural'),
                                  ('detail_priorizada_primera','detail','orden_priorizado'),
                                  ('normal_priorizada_primera','normal','orden_priorizado'),
                                  ('detail_primera','detail','orden_natural')]:
        if variant not in totals:
            continue
        indices=[(r,r[order][0]) for r in rows if r[order]]
        totals[variant]['consultas_logicas_simuladas']=len(indices)
        totals[variant]['tiempo_consultas_estimado_s']=round(sum(r['timing'][source][str(i)]['seconds'] for r,i in indices),3)
        totals[variant]['decisiones_diferentes_vs_normal_completa']=sum(r[variant]['prioridad']!=r['normal']['prioridad'] for r in rows)
        totals[variant]['cambios_entrada_revision_vs_normal_completa']=sum(flagged(r[variant])!=flagged(r['normal']) for r in rows)
    totals['paquetes_con_orden_distinto']=sum(r['orden_natural']!=r['orden_priorizado'] for r in rows)
    warm = OUT / 'cache_reutilizacion.json'
    if warm.exists():
        totals['cache_reutilizacion'] = json.loads(warm.read_text(encoding='utf-8'))
    (OUT/'resumen.json').write_text(json.dumps(totals,ensure_ascii=False,indent=2),encoding='utf-8')
    lines = ['# Prueba de cuatro mejoras de primera lectura', '',
             'Comparacion exploratoria pareada con las mismas fotos y modelo local. No modifica estados, '
             'puntajes ni cache de produccion. Los chequeos independientes de direccion se mantienen guardados. '
             'No equivale a repetir toda la corrida actual: compara una consulta por foto normal frente a una '
             'consulta por foto con detalle, y simula un presupuesto de una sola foto por paquete.', '',
             'Las coordenadas se obtienen de la misma llamada inicial de OCR. La prioridad usa cajas numericas '
             'y nitidez, sin direccion esperada ni marca humana. La lectura ampliada conserva los numeros '
             'contradictorios del OCR. En ambas variantes completas se leen todas las fotos utiles; no se '
             'ocultan otras puertas al detenerse en la primera coincidencia.', '',
             '```json', json.dumps(totals,ensure_ascii=False,indent=2), '```', '',
             '| Tracking | Marca | Normal | Con detalle | Primera normal | Primera priorizada | Tiempo normal/detalle (s) |',
             '|---|---|---|---|---|---|---:|']
    for r in rows:
        a=sum(s['seconds'] for s in r['timing']['normal'].values())
        b=sum(s['seconds'] for s in r['timing']['detail'].values())
        lines.append(f"| {r['tracking']} | {r['marca']} | {r['normal']['prioridad']} | {r['detail']['prioridad']} | "
                     f"{r['normal_primera']['prioridad']} | {r['detail_priorizada_primera']['prioridad']} | {a:.2f}/{b:.2f} |")
    lines += ['', 'La cache reutiliza solo lecturas exitosas por bytes y parametros; nunca estados de revision ni '
              'puntajes. La prueba de repeticion muestra el ahorro cuando SI se repite una imagen, no el '
              'porcentaje de imagenes repetidas de toda la operacion. Las marcas humanas no se vuelven a auditar. '
              'Una muestra de 24 casos no permite estimar una tasa global de revision ni garantizar ausencia de omisiones.', '']
    if len(rows)==len(manifest):
        lines += ['## Resultado de los cuatro puntos', '',
                  '- Coordenadas: se guardan las cajas de la misma deteccion inicial; la ampliacion no solicita otro OCR.',
                  f"- Foto con detalle: {totals['mejoras_detail_vs_normal']} falsas alarmas eliminadas y "
                  f"{totals['nuevas_falsas_detail_vs_normal']} nuevas frente a la foto normal. "
                  f"Tiempo de vision: {totals['normal']['tiempo_total_s']} s normal frente a "
                  f"{totals['detail']['tiempo_total_s']} s con detalle.",
                  '- Priorizacion: se evaluan por separado el orden y el formato de imagen. Limitar a una foto '
                  'es una simulacion, con tiempos estimados de las consultas ya medidas; no se habilita como regla '
                  'de descarte. Mantener una alerta en Media en lugar de Alta puede cambiar la urgencia aunque siga detectada.',
                  '- Cache: la repeticion comprueba reutilizacion exacta. Los aciertos de la preparacion pueden incluir '
                  'reanudaciones del piloto; las repeticiones naturales de la muestra se cuentan aparte por bytes.', '',
                  'Conclusion: no activar la vista ampliada por defecto con estos resultados. Conservar la captura '
                  'de regiones y la reutilizacion de lecturas como candidatos para integracion posterior. '
                  'Estos cambios no demostraron reducir el porcentaje de paquetes en revision.']
    (OUT/'informe.md').write_text('\n'.join(lines),encoding='utf-8')
    return totals


def main():
    import config
    config.ANALYSIS_CACHE_ENABLED = False
    from processing.ocr_address import ensure_paddle_server
    from processing.first_read_experiment import ByteCache, capture_ocr, rank_photos, vision_read
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT/'vistas').mkdir(exist_ok=True)
    source = ROOT/'output/piloto_reintento_dirigido_20261027/muestra.json'
    manifest = json.loads(source.read_text(encoding='utf-8'))
    target = OUT/'muestra.json'
    if not target.exists():
        target.write_text(source.read_text(encoding='utf-8'),encoding='utf-8')
    else:
        manifest=json.loads(target.read_text(encoding='utf-8'))
    cache=ByteCache(OUT/'cache')
    ensure_paddle_server()
    for index, sample in enumerate(manifest):
        file=OUT/f'caso_{index:03}.json'
        if file.exists():
            row=json.loads(file.read_text(encoding='utf-8'))
            if row.get('isolation_version')!=2:
                original_records=[]
                for path in sample['pod']['photo_paths']:
                    record,hit=capture_ocr(path,cache)
                    assert hit, 'Recalculo requiere OCR original guardado'
                    original_records.append(record)
                row['records']=original_records
                row=projections(sample,row)
                file.write_text(json.dumps(row,ensure_ascii=False,indent=2),encoding='utf-8')
                print(f'RECALCULADO {index+1}/{len(manifest)}',flush=True)
            continue
        started=time.perf_counter()
        records=[]
        detector_calls=0
        cache_hits=0
        for path in sample['pod']['photo_paths']:
            record,hit=capture_ocr(path,cache)
            records.append(record)
            cache_hits+=hit
            detector_calls+=0 if hit else record['detector_calls']
        ocr_seconds=time.perf_counter()-started
        natural=[i for i,r in enumerate(records) if not r['reading']['is_label'] and not r['reading']['error']]
        ranked=rank_photos(records)
        results={'normal':{},'detail':{}}
        timing={'normal':{},'detail':{}}
        # Alternar el orden entre casos para distribuir calentamiento y fluctuaciones de GPU.
        for photo in natural:
            for variant in (('normal','detail') if index%2==0 else ('detail','normal')):
                path=sample['pod']['photo_paths'][photo]
                preview=OUT/'vistas'/f'{index:03}_{photo+1}.jpg' if variant=='detail' else None
                response,stats=vision_read(path,records[photo],variant,cache,preview=preview)
                results[variant][str(photo)]=asdict(response)
                timing[variant][str(photo)]=stats
            print(f'foto caso {index+1}/{len(manifest)} foto {photo+1}: completadas las dos variantes',flush=True)
        row={k:sample[k] for k in ('fecha','tracking','marca','grupo')}
        row.update({'records':records,'responses':results,'timing':timing,'orden_natural':natural,
                    'orden_priorizado':ranked,'ocr_seconds':round(ocr_seconds,4),
                    'detector_calls':detector_calls,'ocr_cache_hits':cache_hits})
        row=projections(sample,row)
        file.write_text(json.dumps(row,ensure_ascii=False,indent=2),encoding='utf-8')
        print(f'CASO {index+1}/{len(manifest)} '+json.dumps(summarize(manifest),ensure_ascii=False),flush=True)
    # Repetir todas las lecturas exitosas: un miss aqui es un fallo de la prueba, no una nueva consulta.
    warm_started=time.perf_counter()
    successful=0
    warm_ocr=0
    digests=[]
    for index,sample in enumerate(manifest):
        row=json.loads((OUT/f'caso_{index:03}.json').read_text(encoding='utf-8'))
        for photo,path in enumerate(sample['pod']['photo_paths']):
            digests.append(hashlib.sha256(Path(path).read_bytes()).hexdigest())
            record,hit=capture_ocr(path,cache)
            if not record['reading']['error']:
                assert hit, 'OCR exitoso no reutilizado'
                warm_ocr+=1
            for variant in ('normal','detail'):
                original=row['responses'][variant].get(str(photo))
                if not original or original['error']:
                    continue
                def no_backend(*args,**kwargs):
                    raise AssertionError('La repeticion no debe llamar al modelo')
                response,stats=vision_read(path,record,variant,cache,reader=no_backend)
                assert stats['cache_hit'] and response.numbers==original['numbers']
                successful+=1
    warm={'lecturas_modelo_reutilizadas':successful,'lecturas_ocr_reutilizadas':warm_ocr,
          'consultas_modelo_en_repeticion':0,'segundos_repeticion':round(time.perf_counter()-warm_started,4),
          'fotos_en_muestra':len(digests),'imagenes_unicas_por_bytes':len(set(digests)),
          'repeticiones_exactas_en_muestra':len(digests)-len(set(digests))}
    (OUT/'cache_reutilizacion.json').write_text(json.dumps(warm,indent=2),encoding='utf-8')
    print('FINAL '+json.dumps(summarize(manifest),ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
