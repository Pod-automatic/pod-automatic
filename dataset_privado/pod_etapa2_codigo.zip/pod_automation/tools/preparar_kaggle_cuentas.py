r"""Una carpeta por cuenta de Kaggle (29/10, pedido del usuario): output/kaggle_luis y output/kaggle_trackingint.

Cada carpeta trae lo que se carga en ESA cuenta y nada de la otra:
  dataset_privado/  pod_etapa2_codigo.zip + pod_multisesion_secretos.zip (SOLO las cookies de esa sesion)
  pod_kaggle_<cuenta>.ipynb  notebook con SESION ya fijada
  celdas/           las mismas celdas para pegar a mano
  LEEME.md          pasos

    venv\Scripts\python.exe tools\preparar_kaggle_cuentas.py

Antes regenera output/pod_etapa2_codigo.zip con el codigo actual. No sube nada ni arranca corridas.
"""
import argparse
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'deploy' / 'kaggle'))
sys.path.insert(0, str(ROOT / 'deploy' / 'ubuntu'))

CUENTAS = {
    'luis': {'carpeta': 'kaggle_luis', 'titulo': 'Luis',
             'que': 'solo DFW02-BAA (30/10: por ahora, igual que la PC; misma cuenta de GOFO, trabajan juntas en esa ciudad).'},
    'tracking': {'carpeta': 'kaggle_trackingint', 'titulo': 'Trackingint',
                 'que': "las ciudades que indiques ese dia en la celda 4 (env['TRACKING_STATIONS'])."},
}

LEEME = """# Kaggle {titulo}

Esta carpeta es SOLO para la cuenta de Kaggle de **{titulo}**. Revisa {que}
No cargar nada de esta carpeta en la otra cuenta: la misma sesion en dos cuentas repetiria el trabajo y chocaria en GOFO.

## 1. Dataset privado

En esta cuenta de Kaggle, crear (o actualizar con **New Version**) un dataset **privado** con los dos archivos de
`dataset_privado/`:

- `pod_etapa2_codigo.zip` (codigo actual)
- `pod_multisesion_secretos.zip` (solo `{sesion}.json`: las cookies de {titulo})

## 2. Notebook

**File > Import Notebook** y elegir `{notebook}`. Ya trae `SESION='{sesion}'` en la celda 1.
En el panel derecho, **Add Input** con el dataset del paso 1 (o pasar a su ultima version si ya estaba).

## 3. Ajustes

- Settings > Accelerator: **GPU T4 x2**
- Settings > Internet: **On**
- Add-ons > Secrets: **PORTAL_API_KEY** adjuntado a este notebook
{extra}
## 4. Iniciar

Run All (o las celdas 1 a 6 en orden). Para que siga sin la pestana abierta: **Save Version > Save & Run All (Commit)**.
La celda 4 muestra la sesion y sus ciudades antes de lanzar. La celda 6 vigila hasta la proxima 10:00 de Venezuela
(tope 11 h). Al terminar, descargar de Output `pod_kaggle_estado.zip` (adjuntarlo como Input la proxima vez, en ESTA
misma cuenta) y `diagnostico_kaggle.zip`.

## 5. Cuello de botella (29/10)

Cada 10 minutos la celda 6 imprime `=== Cuello de botella ===` con un veredicto: **cpu**, **gpu**, **analisis_espera** o
**sin_trabajo** (y los porcentajes de GPU, CPU, cola de vision y analisis). Dejar correr al menos 30 minutos antes de leerlo.
Despues, en la PC: `venv/Scripts/python.exe tools/cuello_kaggle.py diagnostico_kaggle.zip --ventana 30`.

## 6. Registro en el portal (30/10)

Todo lo que escribe la corrida se manda al portal cada 20 s: **Auditoria > Registro**, con filtros por equipo, nivel y texto
(por ejemplo `Detalles a la vez` para ver si salto el freno, o `Etapas de extracción` para el tiempo por albaran).

Generado el {fecha} desde el codigo de pod_automation.
"""

EXTRA = {
    'luis': '',
    'tracking': "- Celda 4: revisar `env['TRACKING_STATIONS']` CADA DIA (hoy: `'DFW-BAA,DFW02-BAA'`). Validas: DFW-BAA, "
                'DFW02-BAA, IAH-BAA, IAH02-BAA, ORD-BAA.\n',
}


def main():
    from datetime import date
    from empaquetar_etapa2 import write_notebook
    from tools.run_kaggle_multi import validate_sessions
    from automation.browser import session_file_has_cookies
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--luis', type=Path, default=ROOT / 'storage/session_state.json')
    parser.add_argument('--tracking', type=Path, default=ROOT / 'storage/session_state_trackingintus_20261027.json')
    args = parser.parse_args()
    validate_sessions(args.luis, args.tracking)   # dos inicios de sesion distintos
    subprocess.run([sys.executable, 'deploy/kaggle/empaquetar_etapa2.py', '--solo-codigo'], cwd=ROOT, check=True,
                   stdout=subprocess.DEVNULL)
    code = ROOT / 'output' / 'pod_etapa2_codigo.zip'
    for sesion, info in CUENTAS.items():
        cookies = getattr(args, sesion)
        assert session_file_has_cookies(cookies), f'Sin cookies en {cookies}'
        out = ROOT / 'output' / info['carpeta']
        if out.exists():
            shutil.rmtree(out)
        (out / 'dataset_privado').mkdir(parents=True)
        shutil.copy2(code, out / 'dataset_privado' / code.name)
        with zipfile.ZipFile(out / 'dataset_privado' / 'pod_multisesion_secretos.zip', 'w', zipfile.ZIP_DEFLATED) as z:
            z.write(cookies, f'{sesion}.json')
        notebook = f"pod_kaggle_{info['carpeta'][len('kaggle_'):]}.ipynb"
        write_notebook(out, 'notebook_multiciudad.py', notebook, 'celdas',
                       replace={"SESION='luis,tracking'": f"SESION='{sesion}'"})
        (out / 'LEEME.md').write_text(LEEME.format(titulo=info['titulo'], que=info['que'], sesion=sesion, notebook=notebook,
                                                   extra=EXTRA[sesion], fecha=date.today().strftime('%d/%m/%Y')),
                                      encoding='utf-8')
        with zipfile.ZipFile(out / 'dataset_privado' / 'pod_multisesion_secretos.zip') as z:
            assert z.namelist() == [f'{sesion}.json'], z.namelist()
        print(f"{out}: {notebook}, dataset_privado (codigo + {sesion}.json), celdas, LEEME.md")


if __name__ == '__main__':
    main()
