﻿"""
Copia de seguridad diaria de las bases (07/10). Lo lanza la tarea programada "POD - respaldo diario" a las 23:45.

- Usa la API de respaldo de SQLite: copia consistente aunque la corrida esté escribiendo en ese momento.
- Guarda un .zip por día en storage/respaldos/ (carpeta dentro de OneDrive: queda también en la nube) y conserva los
  últimos DIAS_A_GUARDAR. Lo más valioso son las marcas (report_status.db) y los casos guía: con ellos se ajustan las
  reglas. Las fotos (storage/pod_images) no se copian: pesan GB.

Uso: venv/Scripts/python.exe tools/respaldo.py [--dias 14]
"""

import argparse
import sqlite3
import sys
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import config  # noqa: E402

BASES = ("pod_checkpoints.db", "report_status.db", "portal_outbox.db")
EXTRAS = ("drivers_config.json",)   # Selección de repartidores (raíz del proyecto)
DIAS_A_GUARDAR = 14


def respaldar(storage: Path, destino: Path, dias: int = DIAS_A_GUARDAR, hoy: datetime = None) -> Path:
    hoy = hoy or datetime.now()
    destino.mkdir(parents=True, exist_ok=True)
    zip_path = destino / f"respaldo_{hoy:%Y%m%d}.zip"
    tmp_zip = zip_path.with_suffix(".tmp")
    with tempfile.TemporaryDirectory() as tmp, zipfile.ZipFile(tmp_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        for name in BASES:
            src = storage / name
            if not src.exists():
                continue
            copia = Path(tmp) / name
            s = sqlite3.connect(f"file:{src.as_posix()}?mode=ro", uri=True, timeout=60)
            d = sqlite3.connect(copia)
            try:
                s.backup(d)
            finally:
                d.close()
                s.close()
            zf.write(copia, name)
        for name in EXTRAS:
            p = config.PROJECT_ROOT / name
            if p.exists():
                zf.write(p, name)
        for p in sorted((config.PROJECT_ROOT / "tests").glob("casos_reales_*.json")):
            zf.write(p, f"casos_guia/{p.name}")
    tmp_zip.replace(zip_path)
    # Rotación: solo los últimos `dias` respaldos
    for viejo in sorted(destino.glob("respaldo_*.zip"))[:-dias]:
        viejo.unlink()
    return zip_path


def main():
    ap = argparse.ArgumentParser(description="Copia de seguridad diaria de las bases")
    ap.add_argument("--dias", type=int, default=DIAS_A_GUARDAR, help="cuántos respaldos diarios conservar")
    args = ap.parse_args()
    zip_path = respaldar(config.STORAGE_DIR, config.STORAGE_DIR / "respaldos", args.dias)
    print(f"Respaldo listo: {zip_path} ({zip_path.stat().st_size / 1e6:.1f} MB)")


if __name__ == "__main__":
    main()
