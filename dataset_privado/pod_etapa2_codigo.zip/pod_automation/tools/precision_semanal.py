"""
Precisión del sistema, semana a semana (07/10/2026). Lo lanza la tarea "POD - precisión semanal" los lunes a las 8:00.

Con las marcas del usuario (report_status.db) y lo guardado por la corrida (pod_checkpoints.db):
- Por día y por semana: revisados, Alta, Media, cuántos se marcaron y qué parte eran errores reales (precisión).
- Errores que se escaparon: albaranes en Baja (muestra al azar) que el usuario marcó como reportados.
- Qué motivos dan más falsas alarmas esta semana (para el agente agrupador / corrector).
- Comparación con la semana anterior: si los cambios de reglas mejoraron o empeoraron.

Solo lectura. Usa el puntaje guardado en la corrida de cada día (no el código actual).
Uso:  python tools/precision_semanal.py [--hasta 2026-10-06] [--dias 7]
Deja output/precision_semanal_<hasta>.md y .json
"""

import argparse
import json
import sys
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import config  # noqa: E402
from tools.agrupar_falsas_alarmas import active_checks, key_of, plantilla, ro  # noqa: E402

PRIOS = ("Alta", "Media", "Baja")


def load_day(con, marks: dict, day: str) -> dict:
    """Resumen de un día: conteos por prioridad, marcas y motivos de las falsas alarmas."""
    rows = con.execute("""
        SELECT p.tracking_number, p.priority, p.payload_json FROM pod_checkpoints p
        JOIN audit_sessions s ON s.session_id = p.session_id
        WHERE s.query_date = ? AND p.risk_score IS NOT NULL
        ORDER BY s.started_at""", (day,)).fetchall()
    latest = {trk: (prio, payload) for trk, prio, payload in rows}   # Si hubo varias sesiones, gana la última
    out = {"dia": day, "revisados": len(latest), "por_prioridad": {p: 0 for p in PRIOS},
           "marcas": {p: {"reportado": 0, "descartado": 0} for p in PRIOS},
           "motivos_falsas": Counter(), "textos_falsas": defaultdict(Counter), "escapados": []}
    for trk, (prio, payload) in latest.items():
        prio = prio if prio in PRIOS else "Baja"
        out["por_prioridad"][prio] += 1
        status = marks.get(trk)
        if status not in ("reportado", "descartado"):
            continue
        out["marcas"][prio][status] += 1
        if status == "descartado" and prio in ("Alta", "Media"):
            act = active_checks(json.loads(payload))
            if act:
                k = key_of(act[0])
                out["motivos_falsas"][k] += 1
                out["textos_falsas"][k][plantilla(act[0].get("explanation"))] += 1
        elif status == "reportado" and prio == "Baja":
            out["escapados"].append(trk)
    return out


def merge(days: list) -> dict:
    tot = {"revisados": 0, "por_prioridad": Counter(), "marcas": {p: Counter() for p in PRIOS},
           "motivos_falsas": Counter(), "textos_falsas": defaultdict(Counter), "escapados": []}
    for d in days:
        tot["revisados"] += d["revisados"]
        tot["por_prioridad"].update(d["por_prioridad"])
        for p in PRIOS:
            tot["marcas"][p].update(d["marcas"][p])
        tot["motivos_falsas"].update(d["motivos_falsas"])
        for k, c in d["textos_falsas"].items():
            tot["textos_falsas"][k].update(c)
        tot["escapados"] += [(d["dia"], t) for t in d["escapados"]]
    return tot


def precision(m) -> float:
    n = m["reportado"] + m["descartado"]
    return round(100 * m["reportado"] / n, 1) if n else None


def marcado(m, total) -> float:
    return round(100 * (m["reportado"] + m["descartado"]) / total, 1) if total else None


def resumen(tot: dict) -> dict:
    rev = tot["revisados"]
    falsas = sum(tot["marcas"][p]["descartado"] for p in ("Alta", "Media"))
    return {
        "revisados": rev,
        "alta": tot["por_prioridad"]["Alta"], "media": tot["por_prioridad"]["Media"],
        "precision_alta": precision(tot["marcas"]["Alta"]), "precision_media": precision(tot["marcas"]["Media"]),
        "marcado_alta": marcado(tot["marcas"]["Alta"], tot["por_prioridad"]["Alta"]),
        "marcado_media": marcado(tot["marcas"]["Media"], tot["por_prioridad"]["Media"]),
        "errores_reales": sum(tot["marcas"][p]["reportado"] for p in PRIOS),
        "falsas_alarmas": falsas,
        "falsas_por_1000": round(1000 * falsas / rev, 1) if rev else None,
        "escapados": len(tot["escapados"]),
        "muestra_baja_marcada": tot["marcas"]["Baja"]["reportado"] + tot["marcas"]["Baja"]["descartado"],
    }


def fmt(v, suf=""):
    return "–" if v is None else f"{v}{suf}"


def delta(now, before, mejor_si_sube=True):
    if now is None or before is None:
        return ""
    d = round(now - before, 1)
    if d == 0:
        return " (=)"
    flecha = "▲" if d > 0 else "▼"
    bien = (d > 0) == mejor_si_sube
    return f" ({flecha}{abs(d)} {'mejor' if bien else 'peor'})"


def build(hasta: date, dias: int = 7):
    marks_rows = ro(config.STORAGE_DIR / "report_status.db").execute(
        "SELECT query_date, tracking_number, status FROM report_status WHERE " + config.REPORT_STATUS_TRUSTED_SQL).fetchall()
    marks = defaultdict(dict)
    for day, trk, status in marks_rows:
        marks[day][trk] = status
    con = ro(config.CHECKPOINT_DB_PATH)

    def semana(fin: date):
        ds = [(fin - timedelta(days=i)).isoformat() for i in range(dias - 1, -1, -1)]
        return [load_day(con, marks.get(d, {}), d) for d in ds]

    esta, anterior = semana(hasta), semana(hasta - timedelta(days=dias))
    esta = [d for d in esta if d["revisados"]]
    anterior = [d for d in anterior if d["revisados"]]
    t_esta, t_ant = merge(esta), merge(anterior)
    return esta, resumen(t_esta), (resumen(t_ant) if anterior else None), t_esta


def render(hasta: date, dias: int, esta, r, r_ant, tot) -> str:
    desde = hasta - timedelta(days=dias - 1)
    a = r_ant or {}
    md = [f"# Precisión del sistema · {desde:%d/%m} al {hasta:%d/%m/%Y}", "",
          "Precisión = de los albaranes que marcaste, qué % eran errores reales. Solo cuenta lo marcado.", "",
          "## Resumen de la semana" + (" (entre paréntesis: contra la semana anterior)" if r_ant else ""), "",
          f"- Revisados: **{r['revisados']}** · Alta {r['alta']} · Media {r['media']}",
          f"- Precisión **Alta: {fmt(r['precision_alta'], ' %')}**{delta(r['precision_alta'], a.get('precision_alta'))}"
          f" (marcaste el {fmt(r['marcado_alta'], ' %')})",
          f"- Precisión **Media: {fmt(r['precision_media'], ' %')}**{delta(r['precision_media'], a.get('precision_media'))}"
          f" (marcaste el {fmt(r['marcado_media'], ' %')})",
          f"- Errores reales confirmados: **{r['errores_reales']}** · falsas alarmas: {r['falsas_alarmas']} "
          f"(**{fmt(r['falsas_por_1000'])} por cada 1.000 revisados**"
          f"{delta(r['falsas_por_1000'], a.get('falsas_por_1000'), mejor_si_sube=False)})",
          f"- Errores que se escaparon (Baja marcados como reportados): **{r['escapados']}** "
          f"de {r['muestra_baja_marcada']} de la muestra marcados", ""]
    if tot["escapados"]:
        md += ["### Errores que se escaparon (revisar por qué quedaron en Baja)", ""]
        md += [f"- {d} · {t}" for d, t in tot["escapados"]] + [""]
    md += ["## Por día", "", "| Día | Revisados | Alta | Media | Precisión Alta | Precisión Media | Falsas | Escapados |",
           "|---|---:|---:|---:|---:|---:|---:|---:|"]
    for d in esta:
        falsas = d["marcas"]["Alta"]["descartado"] + d["marcas"]["Media"]["descartado"]
        md.append(f"| {d['dia']} | {d['revisados']} | {d['por_prioridad']['Alta']} | {d['por_prioridad']['Media']} | "
                  f"{fmt(precision(d['marcas']['Alta']), ' %')} | {fmt(precision(d['marcas']['Media']), ' %')} | "
                  f"{falsas} | {len(d['escapados'])} |")
    md += ["", "## Motivos con más falsas alarmas", "",
           "Para atacarlos: agente `agrupador-falsas-alarmas` (propone) y `corrector-pendientes` (aplica).", "",
           "| Motivo | Falsas | Texto típico |", "|---|---:|---|"]
    for k, n in tot["motivos_falsas"].most_common(8):
        md.append(f"| `{k}` | {n} | {tot['textos_falsas'][k].most_common(1)[0][0]} |")
    return "\n".join(md) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--hasta", default=None, help="último día incluido (por defecto, ayer)")
    ap.add_argument("--dias", type=int, default=7)
    a = ap.parse_args()
    hasta = datetime.strptime(a.hasta, "%Y-%m-%d").date() if a.hasta else date.today() - timedelta(days=1)
    esta, r, r_ant, tot = build(hasta, a.dias)
    md = render(hasta, a.dias, esta, r, r_ant, tot)
    stem = config.OUTPUT_DIR / f"precision_semanal_{hasta:%Y%m%d}"
    stem.with_suffix(".md").write_text(md, encoding="utf-8")
    stem.with_suffix(".json").write_text(json.dumps({"hasta": hasta.isoformat(), "dias": a.dias, "semana": r,
                                                     "semana_anterior": r_ant, "por_dia": esta},
                                                    ensure_ascii=False, indent=1, default=dict), encoding="utf-8")
    print(md)
    print(f"Guardado: {stem.with_suffix('.md')}")


if __name__ == "__main__":
    main()
