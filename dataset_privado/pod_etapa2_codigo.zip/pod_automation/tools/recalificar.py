"""
Vuelve a puntuar albaranes YA procesados de un día con el código actual (06/10: los Alta falsos del locker "Deposit
Package" de Hidden Ridge y los que quedaron mal por la traba de Ollama de 11:28 a 12:37). Relee las fotos (OCR + modelo
de visión), guarda el nuevo puntaje en la base (la página local lo muestra) y lo manda al portal web (si baja a Baja,
el portal lo retira mientras siga pendiente). No toca las marcas de reportado/descartado.

Uso:
  python tools/recalificar.py --date 2026-10-06 GFUS... GFUS...
  python tools/recalificar.py --date 2026-10-06 --driver "Carla Colina" --solo-alta-media
  python tools/recalificar.py --date 2026-10-06 --desde 11:28 --hasta 12:40   (Alta/Media de una traba del modelo)
"""

import argparse
import json
import sqlite3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import config  # noqa: E402
from export import portal_sync  # noqa: E402
from processing.pipeline import detect_handoff, detect_package_room, ocr_photos  # noqa: E402
from processing.scoring import score_pod, top_reasons  # noqa: E402
from storage.checkpoint_manager import CheckpointManager  # noqa: E402
from tools.evaluar_dia import load_pod  # noqa: E402


def pick(con, date: str, args) -> list:
    if args.trackings:
        return list(args.trackings)
    sql = """SELECT p.tracking_number, p.payload_json FROM pod_checkpoints p JOIN audit_sessions s
             ON s.session_id = p.session_id WHERE s.query_date = ?"""
    params = [date]
    if args.solo_alta_media or args.desde:
        sql += " AND p.priority IN ('Alta', 'Media')"
    if args.desde:
        sql += " AND p.created_at BETWEEN ? AND ?"
        params += [f"{date} {args.desde}", f"{date} {args.hasta or '23:59'}"]
    norm = lambda s: " ".join((s or "").split()).lower()   # "Carla  Colina " (doble espacio en el portal)
    return [trk for trk, drv in con.execute(sql.replace("p.payload_json", "p.driver_name"), params)
            if not args.driver or norm(drv) == norm(args.driver)]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--date", required=True)
    ap.add_argument("--driver")
    ap.add_argument("--solo-alta-media", action="store_true")
    ap.add_argument("--desde", help="HH:MM: los Alta/Media procesados desde esa hora (ej. una traba del modelo)")
    ap.add_argument("--hasta", help="HH:MM")
    ap.add_argument("trackings", nargs="*")
    args = ap.parse_args()

    con = sqlite3.connect(f"file:{config.CHECKPOINT_DB_PATH.as_posix()}?mode=ro", uri=True, timeout=30)
    session = con.execute("SELECT session_id FROM audit_sessions WHERE query_date = ? ORDER BY started_at DESC LIMIT 1",
                          (args.date,)).fetchone()
    if not session:
        sys.exit(f"No hay sesión del {args.date}")
    trackings = pick(con, args.date, args)
    print(f"{len(trackings)} albaranes a recalificar")
    ckpt = CheckpointManager()
    web = portal_sync.from_config(start=False)
    changed = 0
    for trk in trackings:
        pod = load_pod(con, args.date, trk)
        if pod is None or not pod.photo_paths:
            print(f"  {trk}: sin datos o sin fotos, se deja igual")
            continue
        before = pod.priority
        photos = ocr_photos(pod.photo_paths, pod.expected_address)
        score_pod(pod, photos)
        if detect_handoff(pod, photos) or detect_package_room(pod, photos):
            score_pod(pod, photos)
        ckpt.save_pod_checkpoint(session[0], pod)
        if web:
            web.enqueue_pod(pod, args.date)
        changed += before != pod.priority
        print(f"  {trk}: {before} -> {pod.priority} | {(top_reasons(pod, 1) or ['sin motivos'])[0][:90]}")
    if web:
        try:
            web.sync_once(pull=False)
        except Exception as e:
            print(f"Portal: quedó en la bandeja para el próximo envío ({e})")
    print(f"Listo: {changed} cambiaron de prioridad")


if __name__ == "__main__":
    main()
