"""Detalle de los albaranes marcados que guardó cada corrida en el portal (30/10/2026, pedido del usuario).

Cada corrida (PC, gpu_luis, gpu_tracking) manda con cada Alta/Media/Lockers lo que leyeron el OCR y el modelo en cada foto
(export/portal_sync.detail_blob). Con esto se reproducen en la PC los casos de Kaggle: se repuntúan con el código ACTUAL,
sin volver a leer las fotos (no hace falta GPU), y se ve si una corrección de reglas los cambia.

    venv\\Scripts\\python.exe tools\\detalle_portal.py --date 2026-10-29 --tracking GFUS01080165625218
    venv\\Scripts\\python.exe tools\\detalle_portal.py --date 2026-10-29 --run gpu_luis --repuntuar

Guarda cada detalle en output/detalle_<fecha>/<tracking>__<corrida>.json. El portal lo conserva 21 días.
"""
import argparse
import base64
import json
import sys
import zlib
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import config  # noqa: E402
from export.portal_sync import PortalClient  # noqa: E402


def fetch(client, date: str, trackings=None, run: str = ""):
    """Todos los detalles del día (o de esos albaranes), página por página."""
    out, after = [], ""
    trackings = list(trackings or [])
    for i in range(0, max(1, len(trackings)), 200):
        body = {"date": date, "run": run, "limit": 200}
        if trackings:
            body["trackings"] = trackings[i:i + 200]
        after = ""
        while True:
            resp = client.call("analysis_detail.php", dict(body, after=after))
            items = resp.get("items") or []
            out += items
            if not resp.get("more") or not items:
                break
            after = items[-1]["tracking"]
    return out


def decode(blob: str) -> dict:
    return json.loads(zlib.decompress(base64.b64decode(blob)).decode("utf-8"))


def rescore(detail: dict):
    """Puntaje con el código actual a partir de las lecturas guardadas (sin OCR ni modelo; la entrega en mano no se repite)."""
    from models.pod import PODRecord
    from processing.ocr_address import PhotoOCR
    from processing.scoring import score_pod, top_reasons
    data = dict(detail["pod"])
    data["check_results"] = [r for r in data.get("check_results") or []
                             if r.get("check") not in ("revision_manual", "entrega_en_mano", "entrega_en_casillero")]
    pod = PODRecord.from_dict(data)
    fields = PhotoOCR.__dataclass_fields__
    photos = [PhotoOCR(**{k: v for k, v in p.items() if k in fields}) for p in detail["photos"]]
    score_pod(pod, photos)
    return pod.priority, pod.risk_score, top_reasons(pod)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--date", required=True)
    ap.add_argument("--tracking", nargs="*", default=[])
    ap.add_argument("--run", default="", help="pc, gpu_luis, gpu_tracking (vacío = todas)")
    ap.add_argument("--repuntuar", action="store_true", help="Repuntuar con el código actual y comparar")
    a = ap.parse_args()
    if not config.PORTAL_SYNC_ENABLED:
        sys.exit("Falta PORTAL_URL / PORTAL_API_KEY en el .env")
    items = fetch(PortalClient(config.PORTAL_URL, config.PORTAL_API_KEY), a.date, [t.upper() for t in a.tracking], a.run)
    folder = ROOT / "output" / f"detalle_{a.date}"
    folder.mkdir(parents=True, exist_ok=True)
    changes = Counter()
    for it in items:
        detail = decode(it["detail"])
        (folder / f"{it['tracking']}__{it['run']}.json").write_text(json.dumps(detail, ensure_ascii=False, indent=1),
                                                                    encoding="utf-8")
        before = detail["pod"].get("priority")
        line = f"{it['tracking']} {it['run']}: {before} {detail['pod'].get('risk_score')}"
        if a.repuntuar:
            try:
                after, score, reasons = rescore(detail)
                changes[(before, after)] += 1
                line += f" -> {after} {score}" + (f"  ({reasons[0]})" if reasons and after != before else "")
            except Exception as e:
                line += f" -> ERROR {type(e).__name__}: {e}"
        print(line)
    print(f"{len(items)} detalle(s) en {folder}")
    if a.repuntuar and changes:
        print("Antes -> ahora:", ", ".join(f"{b}->{c}: {n}" for (b, c), n in sorted(changes.items())))


if __name__ == "__main__":
    main()
