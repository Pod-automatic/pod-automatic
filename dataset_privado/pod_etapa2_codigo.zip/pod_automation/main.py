"""
Punto de Entrada Principal e Interfaz CLI Interactiva de POD Automation (Fases 1 a 13).

Menú Principal:
=================================
POD AUTOMATION
=================================
1. Procesar fecha
2. Reanudar proceso anterior
3. Ver configuración
4. Modo inspect (Fase 12)
5. Ejecutar demostración con datos de ejemplo (Offline)
6. Salir

Soporta también ejecución por argumentos de consola:
  python main.py inspect
  python main.py --date MM/DD/YYYY
  python main.py --resume
  python main.py report        (página local de reportes: http://127.0.0.1:8765)
  python main.py limpiar       (borra el historial de días pasados salvo los casos guía)
  python main.py portal        (prueba la conexión con el portal web y envía lo pendiente; --date para reenviar un día)
"""

import sys
import json
import logging
import sqlite3
import time
import argparse
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, List

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.prompt import Prompt, Confirm

import config
from models.pod import (
    VerdictEnum,
    PODRecord,
    PODMemoryStorage,
    ProcessingStatusEnum,
)
from automation.browser import BrowserManager
from automation.login import LoginManager, run_manual_login
from automation.browser import SessionExpiredError
from automation.politeness import ThroughputTracker
from automation.business_time import operation_now, operation_day
from automation.day_carry import DayCarry
from automation.activity import recent_activity
from storage.closing_queue import ClosingQueue
from automation.work_claims import LeaseCoordinator
from automation.city_dispatch import CityDispatcher
from automation.session_guard import (SessionGuard, SessionCoordinationError, classify_failure, log_throttled, WAIT,
                                      offline_fallback_allowed, LAST_CONTACT, OUTAGE_SINCE)
from automation.portal_api import PortalAPI
from automation.api_extractor import ApiPODExtractor
from processing.pipeline import ScoringPipeline
from automation.drivers import DriverSelection, manual_priority, normalize_name, sampling_for
from automation.dashboard import DashboardManager
from automation.pod_scraper import PODScraper
from automation.audit_logger import AuditLogger
from automation.inspector import PlatformInspector
from automation.selectors import SELECTORS, validate_configured_selectors, get_unconfigured_selectors
from storage.checkpoint_manager import CheckpointManager
from processing.validator import PODValidator
from export.excel_exporter import PODExcelExporter
from export import portal_sync

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

console = Console(highlight=False)
logger = logging.getLogger("PODAutomation.Main")


def print_main_banner():
    """Muestra el encabezado corporativo del sistema."""
    console.print(Panel.fit(
        "[bold cyan]=================================[/bold cyan]\n"
        "[bold yellow]        POD AUTOMATION           [/bold yellow]\n"
        "[bold cyan]=================================[/bold cyan]\n"
        "[italic white]Auditoría Inteligente de Entregas | Modo Seguro READ-ONLY[/italic white]\n"
        f"[dim]Salida: {config.OUTPUT_DIRECTORY} | Checkpoints: SQLite | Logs: storage/logs/[/dim]",
        border_style="cyan"
    ))


def display_configuration():
    """Muestra una tabla detallada con los parámetros de configuración actuales (Fase 9)."""
    table = Table(title="Configuración del Sistema (Fase 9 & 13)", show_header=True, header_style="bold magenta")
    table.add_column("Parámetro", style="cyan", width=25)
    table.add_column("Valor Actual", style="white", width=35)
    table.add_column("Descripción / Estado", style="dim", width=40)

    table.add_row("HEADLESS", str(config.HEADLESS), "Navegador visible para supervisión humana")
    table.add_row("SLOW_MO", f"{config.SLOW_MO} ms", "Demora entre acciones para estabilidad")
    table.add_row("DEFAULT_TIMEOUT", f"{config.DEFAULT_TIMEOUT} ms", "Timeout general de esperas inteligentes")
    table.add_row("MAX_RETRIES", str(config.MAX_RETRIES), "Reintentos máximos tolerantes por POD")
    table.add_row("OUTPUT_DIRECTORY", str(config.OUTPUT_DIRECTORY), "Ruta de exportación de reportes Excel")
    table.add_row("SCREENSHOT_ON_ERROR", str(config.SCREENSHOT_ON_ERROR), "Captura automática de fallos en screenshots/")
    table.add_row("DATE_FORMAT", config.DATE_FORMAT, "Formato esperado de fecha")
    table.add_row("DUPLICATE_THRESHOLD", str(config.DUPLICATE_THRESHOLD), "Distancia Hamming para perceptual hash")
    table.add_row("READ_ONLY_MODE", "[bold green]TRUE[/bold green]", "Estricto: No aprueba/rechaza ni muta datos")

    console.print("\n", table)

    # Estado de selectores (Fase 11)
    sel_table = Table(title="Estado de Selectores de Plataforma (Fase 11)", show_header=True, header_style="bold yellow")
    sel_table.add_column("Clave Selector", style="cyan", width=22)
    sel_table.add_column("Valor Configurado", style="white", width=38)
    sel_table.add_column("Estado", justify="center", width=16)

    for k, v in SELECTORS.items():
        if v and v.strip():
            status = "[green]CONFIGURADO[/green]"
            val_display = v
        else:
            status = "[yellow]PENDIENTE (None)[/yellow]"
            val_display = "[dim]None (Requiere inspect)[/dim]"
        sel_table.add_row(k, val_display, status)

    console.print(sel_table, "\n")


def display_live_pod_card(index: int, total: int, pod: PODRecord):
    """Muestra el panel de estado en tiempo real para cada POD en curso (Fase 10)."""
    val_res = getattr(pod, "classification", "ANALIZANDO")
    if hasattr(val_res, "value"):
        val_res = val_res.value

    color = "green" if "VALID" in str(val_res) else ("yellow" if "REVIEW" in str(val_res) else "red")

    panel_text = (
        f"[bold white]Procesando POD {index} / {total}[/bold white]\n\n"
        f"[cyan]Tracking:[/cyan] {pod.albaran}\n"
        f"[cyan]Fotos:[/cyan] {pod.number_of_photos}\n"
        f"[cyan]Estado:[/cyan] {pod.processing_status}\n"
        f"[cyan]Resultado:[/cyan] [{color}]{val_res}[/{color}]"
    )
    console.print(Panel(panel_text, border_style=color, width=50))


def process_date_workflow(
    input_date_str: str,
    resume_session_id: Optional[str] = None,
    max_records: Optional[int] = None,
):
    """
    Flujo completo de procesamiento de una fecha:
    1. Abre navegador.
    2. Espera login manual.
    3. Espera confirmación interactiva.
    4. Procesa los PODs con SQLite checkpoints y audit logger.
    5. Muestra progreso en vivo.
    6. Exporta a Excel.
    """
    # 1. Normalizar fecha
    # Si viene en MM/DD/YYYY, convertir a YYYY-MM-DD para la plataforma
    query_date = input_date_str.strip()
    if "/" in query_date:
        parts = query_date.split("/")
        if len(parts) == 3 and len(parts[0]) <= 2 and len(parts[2]) == 4:
            # MM/DD/YYYY -> YYYY-MM-DD
            query_date_iso = f"{parts[2]}-{parts[0].zfill(2)}-{parts[1].zfill(2)}"
        else:
            query_date_iso = query_date
    else:
        query_date_iso = query_date

    # 2. Verificar estado de selectores
    unconfigured = get_unconfigured_selectors()
    if unconfigured:
        console.print(Panel(
            "[bold yellow]AVISO DE SELECTORES PENDIENTES (FASE 11):[/bold yellow]\n"
            f"Existen {len(unconfigured)} selectores en 'None' dentro de 'automation/selectors.py'.\n\n"
            "[italic white]Si deseas capturar la estructura de la plataforma real para completarlos, ejecuta:[/italic white]\n"
            "[bold cyan]python main.py inspect[/bold cyan] (o elige la opción 4 del menú).\n\n"
            "[dim]El sistema continuará utilizando estrategias de fallback heurísticas durante este recorrido.[/dim]",
            border_style="yellow"
        ))

    # 3. Inicializar CheckpointManager y AuditLogger
    ckpt_mgr = CheckpointManager()
    if resume_session_id:
        session_id = resume_session_id
        console.print(f"[bold cyan]Reanudando sesión existente:[/bold cyan] {session_id}")
        preloaded_records = ckpt_mgr.load_session_pods(session_id)
        console.print(f"[green][OK] {len(preloaded_records)} registros previos cargados (evitando duplicados).[/green]")
    else:
        session_id = ckpt_mgr.create_session(query_date_iso)
        preloaded_records = []
        console.print(f"[bold cyan]Nueva sesión creada:[/bold cyan] {session_id}")

    audit_logger = AuditLogger(session_id=session_id)

    # 4. Inicializar Navegador en modo visible
    console.print(f"\n[cyan]Paso 1: Iniciando navegador (HEADLESS = {config.HEADLESS}, AUTH_MODE = {config.AUTH_MODE})...[/cyan]")
    bm = BrowserManager(
        headless=config.HEADLESS,  # leído aquí (no al importar) para respetar --headless
        slow_mo_ms=config.SLOW_MO,
        timeout_ms=config.DEFAULT_TIMEOUT,
        prefer_chrome=True,
    )

    try:
        bm.start_browser()

        # Paso 2 & 3: Verificar la sesión guardada (nunca se intenta loguear sola)
        console.print("\n[cyan]Paso 2: Verificando la sesión guardada en el portal...[/cyan]")
        if config.AUTH_MODE == "cdp":
            bm.page.goto(config.GOFO_PORTAL_URL)
            Prompt.ask("[bold cyan](modo CDP) Presiona ENTER cuando estés en el Dashboard[/bold cyan]")
            bm.session_valid = True
        else:
            LoginManager(bm).require_valid_session()

        # Paso 4: Navegar a Dashboard, fijar fecha y ejecutar consulta
        dash_mgr = DashboardManager(bm)
        console.print(f"\n[cyan]Paso 4: Aplicando filtro de fecha '{query_date_iso}' y ejecutando consulta...[/cyan]")
        dash_mgr.run_query(query_date_iso)

        # Paso 5: Extracción y visualización en vivo
        scraper = PODScraper(bm)

        def on_pod_progress(idx, total, pod):
            display_live_pod_card(idx, total, pod)

        console.print("\n[cyan]Paso 5: Procesando los PODs con persistencia atómica en SQLite...[/cyan]")
        records = scraper.scrape_all_pods(
            query_date=query_date_iso,
            max_records=max_records,
            audit_logger=audit_logger,
            checkpoint_manager=ckpt_mgr,
            session_id=session_id,
            preloaded_records=preloaded_records,
            on_pod_processed=on_pod_progress,
        )

        if not records:
            console.print(f"[bold yellow]No se encontraron entregas disponibles para la fecha {query_date_iso}.[/bold yellow]")
            return

        # Validación final con Computer Vision y Reglas de Negocio
        console.print("\n[cyan]Auditando comprobantes y detectando duplicados (Fase 6)...[/cyan]")
        storage = PODMemoryStorage()
        for r in records:
            storage.add(r)

        validator = PODValidator()
        validator.validate_storage(storage)

        # Actualizar checkpoints finales
        for r in storage.get_all():
            ckpt_mgr.save_pod_checkpoint(session_id, r)
        ckpt_mgr.mark_session_completed(session_id)

        # Exportar a Excel
        console.print("\n[cyan]Generando reporte Excel profesional con semaforización (Fase 3)...[/cyan]")
        exporter = PODExcelExporter()
        excel_path = exporter.export(storage, filename=f"resultados_pod_{query_date_iso}.xlsx")

        # Resumen de sesión en audit logger
        all_pods = storage.get_all()
        total_valid = sum(1 for p in all_pods if p.verdict == VerdictEnum.VALIDO)
        total_rev = sum(1 for p in all_pods if p.verdict == VerdictEnum.REQUIERE_REVISION)
        total_err = sum(1 for p in all_pods if p.verdict == VerdictEnum.SOSPECHOSO)
        audit_logger.log_session_summary(len(all_pods), total_valid, total_rev, 0, total_err)

        console.print(Panel.fit(
            f"[bold green][OK] PROCESAMIENTO COMPLETADO EXITOSAMENTE[/bold green]\n\n"
            f"[bold]Fecha Auditada:[/bold] {query_date_iso}\n"
            f"[bold]Total Entregas:[/bold] {len(all_pods)}\n"
            f"[bold]Reporte Excel:[/bold] [underline cyan]{excel_path}[/underline cyan]\n"
            f"[bold]Base de Checkpoints:[/bold] [underline]{config.CHECKPOINT_DB_PATH}[/underline]\n"
            f"[bold]Log de Auditoría:[/bold] [underline]{audit_logger.log_file}[/underline]",
            border_style="green",
            title="[bold yellow]★ AUDITORÍA FINALIZADA ★[/bold yellow]"
        ))

    except SessionExpiredError as e:
        console.print(Panel(f"[bold red]{e}[/bold red]", title="SESIÓN NO DISPONIBLE", border_style="red"))
        if not resume_session_id and not ckpt_mgr.load_session_pods(session_id):
            ckpt_mgr.delete_session(session_id)  # No dejar sesiones vacías 'reanudables'
        raise SystemExit(2)
    except Exception as e:
        console.print(f"[bold red]Excepción durante el proceso:[/bold red] {e}")
        logger = audit_logger.logger if "audit_logger" in locals() else None
        if logger:
            logger.exception("Fallo fatal en el flujo de procesamiento")
    finally:
        console.print("[dim]Cerrando sesión de navegador...[/dim]")
        bm.close_browser()


def resume_previous_workflow():
    """Flujo para la opción 2: Reanudar proceso anterior (Fase 8)."""
    ckpt_mgr = CheckpointManager()
    session = ckpt_mgr.get_latest_incomplete_session()

    if not session:
        console.print(Panel(
            "[bold yellow]No se encontraron sesiones incompletas pendientes de reanudación.[/bold yellow]\n"
            "Todas las sesiones previas en SQLite han concluido o no hay registros.",
            border_style="yellow"
        ))
        return

    console.print(Panel(
        f"[bold cyan]SESIÓN PREVIA ENCONTRADA (Fase 8):[/bold cyan]\n\n"
        f"[white]ID Sesión:[/white] {session['session_id']}\n"
        f"[white]Fecha de Consulta:[/white] {session['query_date']}\n"
        f"[white]Iniciada el:[/white] {session['started_at']}\n"
        f"[white]Última Actualización:[/white] {session['updated_at']}\n"
        f"[white]PODs ya procesados:[/white] [bold green]{session['total_processed']}[/bold green]\n"
        f"[white]Último Albarán Procesado:[/white] {session['last_processed_tracking'] or 'Ninguno'}",
        border_style="cyan"
    ))

    if Confirm.ask("[bold yellow]¿Deseas continuar la auditoría desde el último POD procesado?[/bold yellow]", default=True):
        process_date_workflow(
            input_date_str=session["query_date"],
            resume_session_id=session["session_id"],
        )


def print_throughput_projection(tracker: Optional[ThroughputTracker] = None):
    """Muestra albaranes/hora reales × 24 contra la meta diaria (DAILY_TARGET_PODS)."""
    tracker = tracker or ThroughputTracker.from_log(config.THROUGHPUT_LOG_PATH)
    proj = tracker.projection()
    if not proj.get("samples"):
        console.print("[yellow]Aún no hay tiempos registrados en storage/throughput.jsonl.[/yellow]")
        return proj
    color = "red" if proj["sampling_needed"] else "green"
    console.print(Panel.fit(
        f"Muestras: {proj['samples']} albaranes\n"
        f"Extracción por albarán: promedio {proj['avg_seconds']}s | p50 {proj['p50_seconds']}s | p95 {proj['p95_seconds']}s\n"
        + (f"Análisis (OCR/visión): promedio {proj['analysis_avg_seconds']}s | p95 {proj['analysis_p95_seconds']}s "
           f"({proj['analysis_samples']} albaranes)\n"
           f"Extracción {proj['extraction_per_hour']}/h vs análisis {proj['analysis_per_hour']}/h → "
           f"cuello de botella: [bold]{proj['bottleneck']}[/bold]\n" if proj.get("analysis_samples") else
           "[yellow]Sin tiempos de análisis aún: la proyección solo mide la extracción[/yellow]\n")
        + f"Throughput: {proj['per_hour']} albaranes/hora → {proj['per_day']:,} albaranes/día (×24)\n"
        f"Meta: {proj['daily_target']:,}/día → cobertura [bold {color}]{proj['coverage_pct']}%[/bold {color}]\n"
        f"[bold {color}]{'Hace falta muestreo o priorización' if proj['sampling_needed'] else 'Alcanza para revisar el 100%'}[/bold {color}]",
        title="Proyección de throughput", border_style=color,
    ))
    return proj


def save_backlog(summary: dict, ckpt_mgr: CheckpointManager, session_id: str, day: str,
                 path: Path = None, now: Optional[datetime] = None) -> dict:
    """
    07/10: faltantes a la vista (página local y resumen). El 06/10 la corrida se cortó sin saber que quedaban ~800
    de DFW-BAA. Ritmo = albaranes revisados en la última hora (real, con OCR y portal); estimado = faltan / ritmo.
    """
    now = now or operation_now()
    since = (now - timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S")
    per_hour = ckpt_mgr.count_reviewed_since(session_id, since)
    data = dict(summary, date=day, updated_at=now.strftime("%Y-%m-%d %H:%M:%S"), per_hour=per_hour,
                eta_hours=round(summary["total"] / per_hour, 1) if per_hour >= 20 else None)
    path = Path(path or config.BACKLOG_PATH)
    try:
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
        tmp.replace(path)
    except OSError as e:
        logger.warning(f"No se pudo guardar {path.name}: {e}")
    return data


def load_priority_drivers(ckpt_mgr: CheckpointManager, day: str) -> set:
    """07/10: repartidores con más errores reales de los últimos días, a revisar primero (IDs y nombres normalizados)."""
    if config.PRIORITY_MAX <= 0:
        return set()
    since = (datetime.strptime(day, "%Y-%m-%d") - timedelta(days=config.PRIORITY_DAYS)).strftime("%Y-%m-%d")
    try:
        top = ckpt_mgr.top_error_drivers(config.STORAGE_DIR / "report_status.db", since, config.PRIORITY_MIN_ERRORS,
                                         config.PRIORITY_MAX, config.PRIORITY_PER_STATION_MIN)
    except Exception as e:
        logger.warning(f"No se pudo calcular la prioridad por errores: {e}")
        return set()
    if top:
        console.print("[magenta]Primero, los repartidores con más errores reales: " + ", ".join(
            f"{' '.join(d['driver_name'].split())} ({d['errors']}, {d['station']})" for d in top) + "[/magenta]")
    keys = set()
    for d in top:
        if d["driver_id"]:
            keys.add(d["driver_id"])
        keys.add(normalize_name(d["driver_name"]))
    return keys


def backlog_line(data: dict) -> str:
    """'Faltan 812 (DFW-BAA 790, DFW02-BAA 22) · ~1,8 h a 450/h · más atrasados: …'"""
    states = data.get('states') or {}
    if not data.get('total') and states.get('not_granted'):
        return (f"Sin trabajo concedido: {states['not_granted']} albaranes reservados o ya hechos según el reparto. "
                'Se reconsultarán sin tomar reservas vigentes de otra corrida.')
    if not data.get("total") and data.get("unlisted"):
        return f"Listando rutas: faltan {data['unlisted']}"
    if not data.get("total"):
        return "Al día: no falta ningún entregado por revisar."
    cities = ", ".join(f"{k} {v}" for k, v in data["by_station"].items() if v)
    eta = f" · ~{data['eta_hours']} h a {data['per_hour']}/h" if data.get("eta_hours") is not None else ""
    top = ", ".join(f"{d['driver']} {d['pending']}" for d in data.get("top", [])[:3])
    unlisted = f" · todavía sin listar: {data['unlisted']} rutas" if data.get("unlisted") else ""
    sample = (f" · muestra del {data['sample_pct']} % a los sin prioridad" if data.get("sample_pct") else "")
    detail = (f" · disponibles listados {states.get('available_listed',0)}, "
              f"sin conceder {states.get('not_granted',0)}, sin POD {states.get('without_pod',0)}, "
              f"excluidos estimados {states.get('excluded_estimated',0)}" if states else '')
    return (f"Faltan {data['total']} ({cities}){eta}" + (f" · más atrasados: {top}" if top else "") + unlisted
            + sample + detail)


def export_review_queue(ckpt_mgr: CheckpointManager, session_id: str, day: str) -> Optional[Path]:
    """Regenera el Excel del día: 'Review Queue' ordenada por riesgo + avance por repartidor."""
    pods = ckpt_mgr.get_review_queue(session_id)
    if not pods:
        return None
    exporter = PODExcelExporter()
    name = f"review_queue_{day}.xlsx"
    try:
        path = exporter.export(pods, filename=name, route_progress=ckpt_mgr.get_route_progress(session_id))
    except PermissionError:
        # El Excel está abierto (Windows lo bloquea): guardar una copia con hora en vez de fallar
        name = f"review_queue_{day}_{operation_now().strftime('%H%M%S')}.xlsx"
        path = exporter.export(pods, filename=name, route_progress=ckpt_mgr.get_route_progress(session_id))
        console.print(f"[yellow]El Excel del día estaba abierto; se guardó como {name}.[/yellow]")
    alta = sum(1 for p in pods if p.priority == "Alta")
    console.print(f"[bold]Cola de revisión:[/bold] {path} ({len(pods)} albaranes, {alta} en prioridad Alta)")
    return path


def recheck_false_pod_flags(ckpt_mgr: CheckpointManager, session_id: str, api) -> int:
    """
    Control de cierre del día: vuelve a consultar el detalle de cada albarán revisado y detecta los que
    el portal marcó como "POD falso sospechoso" después de la revisión. Una llamada por albarán (con pausas).
    """
    from processing.scoring import portal_info_is_false_pod, is_portal_flagged_false_pod
    pods = [p for p in ckpt_mgr.load_session_pods(session_id)
            if (p.portal_meta or {}).get("sign_id") and not is_portal_flagged_false_pod(p)]
    console.print(f"[cyan]Control de cierre: verificando la marca de POD falso en {len(pods)} albaranes...[/cyan]")
    found = 0
    for pod in pods:
        try:
            info = api.get_sign_info(pod.portal_meta["sign_id"])
        except SessionExpiredError:
            raise
        except Exception as e:
            console.print(f"[yellow]No se pudo verificar {pod.tracking_number}: {e}[/yellow]")
            continue
        if portal_info_is_false_pod(info):
            ckpt_mgr.mark_portal_false_pod(session_id, pod.tracking_number,
                                           info.get("whetherReported"), info.get("falseSignature"))
            found += 1
    console.print(f"[bold]{found} albaranes marcados como POD falso después de revisados.[/bold]")
    return found


def keep_system_awake() -> None:
    """
    Windows: pide no suspender el equipo por inactividad mientras corre el proceso (como un reproductor de video).
    Caso real 01/10: el equipo entró en espera de 15:23 a 16:36 y la corrida quedó pausada. No cambia la
    configuración de energía; deja de aplicar al terminar el proceso. Cerrar la tapa igual lo suspende.
    En equipos con "espera moderna" apagar la pantalla por inactividad YA es entrar en reposo ("Idle Timeout"),
    así que también hay que pedir pantalla encendida. Con batería, Windows igual puede suspender
    ("Austerity Battery Drain Budget Exceeded"): eso solo se evita con el cargador conectado.
    """
    if sys.platform != "win32":
        return
    try:
        import ctypes
        ES_CONTINUOUS, ES_SYSTEM_REQUIRED, ES_DISPLAY_REQUIRED = 0x80000000, 0x00000001, 0x00000002
        ctypes.windll.kernel32.SetThreadExecutionState(ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_DISPLAY_REQUIRED)
    except Exception as e:
        console.print(f"[yellow]No se pudo evitar la suspensión del equipo: {e}[/yellow]")


def battery_status() -> Optional[tuple]:
    """(con cargador, % de batería) en Windows; None si no se puede leer o el equipo no tiene batería."""
    if sys.platform != "win32":
        return None
    try:
        import ctypes

        class SYSTEM_POWER_STATUS(ctypes.Structure):
            _fields_ = [("ACLineStatus", ctypes.c_ubyte), ("BatteryFlag", ctypes.c_ubyte),
                        ("BatteryLifePercent", ctypes.c_ubyte), ("SystemStatusFlag", ctypes.c_ubyte),
                        ("BatteryLifeTime", ctypes.c_ulong), ("BatteryFullLifeTime", ctypes.c_ulong)]

        s = SYSTEM_POWER_STATUS()
        if not ctypes.windll.kernel32.GetSystemPowerStatus(ctypes.byref(s)) or s.BatteryFlag & 128 or s.ACLineStatus == 255:
            return None
        return s.ACLineStatus == 1, (None if s.BatteryLifePercent == 255 else int(s.BatteryLifePercent))
    except Exception:
        return None


class BatteryWatch:
    """
    Avisa cuando la PC pasa a batería y cuando baja de 30 % y 15 %. Caso real 05/10: con batería crítica Windows
    suspendió el equipo de 21:49 a 04:52 y la corrida quedó parada 7 horas (keep_system_awake no lo evita).
    """

    LEVELS = (30, 15)

    def __init__(self, reader=battery_status, warn=None):
        self.reader = reader
        self.warn = warn or (lambda msg: (logger.warning(msg), console.print(f"[bold red]{msg}[/bold red]")))
        self.on_battery = False
        self.warned = set()

    def check(self) -> None:
        st = self.reader()
        if st is None:
            return
        plugged, pct = st
        if plugged:
            if self.on_battery:
                self.warn(f"Cargador conectado de nuevo ({pct} %).")
            self.on_battery, self.warned = False, set()
            return
        if not self.on_battery:
            self.on_battery = True
            self.warn(f"La PC está funcionando a batería ({pct} %): conecta el cargador o la corrida se detendrá "
                      f"cuando Windows suspenda el equipo.")
        for level in self.LEVELS:
            if pct is not None and pct <= level and level not in self.warned:
                self.warned.add(level)
                self.warn(f"Batería en {pct} %: conecta el cargador ya; con batería crítica la PC se suspende.")


def run_continuous_workflow(poll_interval: int, max_passes: Optional[int] = None, sleep=time.sleep,
                            only_drivers: Optional[list] = None, fixed_day: Optional[str] = None,
                            stations: Optional[list] = None, skip_drivers: Optional[list] = None,
                            extra_drivers: Optional[list] = None):
    """
    `python main.py run --continuous`: corre indefinidamente sobre la fecha del día,
    procesando solo albaranes nuevos en cada pasada. Usa una sesión SQLite por día que queda
    IN_PROGRESS, así un corte (Ctrl+C, reinicio) retoma sin reprocesar lo ya guardado.
    Se detiene con exit 2 si la sesión del portal vence (nunca se re-loguea).
    """
    keep_system_awake()
    battery = BatteryWatch()
    battery.check()
    ckpt_mgr = CheckpointManager()
    tracker = ThroughputTracker(log_path=config.THROUGHPUT_LOG_PATH)
    validator = PODValidator()
    bm = BrowserManager(headless=config.HEADLESS, slow_mo_ms=config.SLOW_MO, timeout_ms=config.DEFAULT_TIMEOUT)
    current_day, session_id, passes = None, None, 0
    drivers = DriverSelection(only=only_drivers, stations=stations, skip=skip_drivers, extra=extra_drivers)
    # 14/10: con --stations solo se listan esas ciudades (antes se listaban todas y se filtraba por repartidor; así
    # entra IAH02, que no está en GOFO_STATION_IDS). Con --extra-drivers se listan todas: el extra puede estar en otra.
    station_ids = list(config.GOFO_STATION_IDS)
    if stations and not extra_drivers:
        wanted = {str(s).strip().upper().replace(" ", "") for s in stations}
        station_ids = [sid for sid, name in config.GOFO_STATION_NAMES.items() if name in wanted] or station_ids
    pipeline = None  # Uno por corrida: el proceso de OCR conserva el modelo cargado entre pasadas
    closing = ClosingQueue(ckpt_mgr)
    claims_by_day = {}
    dispatcher = CityDispatcher(config.CITY_DISPATCH_DB,config.CLAIM_WORKER,station_ids) if config.CITY_DISPATCH_DB else None
    selected_station = None
    active_guard = None

    _coord = {}

    def coord_client():
        """28/10: cliente del portal con espera corta para reparto y turnos (que un portal lento no frene la corrida)."""
        if 'client' not in _coord:
            from export.portal_sync import PortalClient
            base = web_portal.client
            _coord['client'] = PortalClient(base.base[:-len('api/')], base.key, timeout=config.PORTAL_COORD_TIMEOUT_S)
        return _coord['client']

    def guarded_api():
        api=PortalAPI(bm.page)
        api.session_guard=active_guard
        return api

    def close_some():
        guard=None
        if config.GOFO_SESSION_GROUP:
            if not web_portal: return
            guard=SessionGuard(coord_client(),config.GOFO_SESSION_GROUP,config.CLAIM_WORKER)
            try:
                if not guard.acquire(): return
            except Exception:
                logger.warning('Cierre aplazado: coordinacion de sesion no disponible.')
                return
        try:
            api=PortalAPI(bm.page)
            api.session_guard=guard
            api.require_station=bool(guard)
            progress=closing.run_some(api)
            if progress['attempted']:
                console.print(f"[cyan]Cierre: {progress['attempted']} consultas, {progress['remaining']} pendientes.[/cyan]")
            for finished in closing.ready_to_finish():
                export_review_queue(ckpt_mgr,finished['session_id'],finished['day'])
                ckpt_mgr.mark_session_completed(finished['session_id'])
                closing.finish(finished['session_id'])
        finally:
            if guard:
                try: guard.close()
                except Exception: pass

    def set_phase(phase, **details):
        state={'phase':phase,'day':current_day,'worker':config.CLAIM_WORKER,
               'station':config.GOFO_STATION_NAMES.get(selected_station),
               'updated_at':operation_now().isoformat(timespec='seconds'),**details}
        path=config.RUNTIME_STATE_DIR / f'runtime_{config.CLAIM_WORKER}.json'
        try:
            path.parent.mkdir(parents=True,exist_ok=True)
            temp=path.with_suffix('.tmp')
            temp.write_text(json.dumps(state,ensure_ascii=False),encoding='utf-8')
            temp.replace(path)
        except OSError as error:
            logger.warning('No se pudo guardar actividad: %s',error)
    web_portal = portal_sync.from_config()  # Envía los Alta / Media al portal web en segundo plano (None si no está configurado)
    if web_portal:
        console.print(f"[cyan]Portal web: enviando los Alta / Media a {config.PORTAL_URL}[/cyan]")

        def heartbeat_info():
            # 07/10: el portal avisa por correo si deja de llegar el latido o si "revisados" no sube (corrida trabada)
            if not session_id:
                return {"day": current_day, "reviewed_today": 0, "last_reviewed_at": None, "backlog": None}
            info = dict(ckpt_mgr.last_activity(session_id), day=current_day)
            info['activity'] = recent_activity(config.THROUGHPUT_LOG_PATH)
            backlog = pass_state.get("backlog")
            info["backlog"] = backlog if backlog and backlog.get("date") == current_day else None
            return info

        web_portal.heartbeat_info = heartbeat_info

    def on_scored(pod):
        if pod.portal_meta.get("verify_of"):
            # 26/10: verificación cruzada de un albarán que marcó la otra corrida: solo se manda su resultado al portal
            if web_portal:
                web_portal.enqueue_verify(pod, current_day)
            return
        import time as analysis_clock
        pod.portal_meta['analysis_processed_at']=analysis_clock.time_ns() // 1000
        ckpt_mgr.save_pod_checkpoint(session_id, pod)
        coordinator = claims_by_day.get(pod.portal_meta.get('station_date') or current_day)
        from storage.checkpoint_manager import needs_retry
        if coordinator and pod.risk_score is not None and not needs_retry(str(pod.processing_status), pod.error_message):
            coordinator.complete(pod.tracking_number)
        if web_portal:
            web_portal.enqueue_pod(pod, current_day)

    def ui_pass(today, preloaded):
        DashboardManager(bm).run_query(today)
        records = PODScraper(bm, throughput=tracker).scrape_all_pods(
            query_date=today,
            audit_logger=AuditLogger(session_id=session_id),
            checkpoint_manager=ckpt_mgr,
            session_id=session_id,
            preloaded_records=preloaded,
        )
        known = {p.tracking_number for p in preloaded}
        return [r for r in records if r.tracking_number not in known]

    def api_pass(today, preloaded):
        nonlocal pipeline, active_guard, selected_station
        new_records = []
        extractor = None
        if not dispatcher:
            selected_station = None   # La fija la ciudad compartida de esta pasada (si la hay)
        pass_stations = [selected_station] if selected_station is not None else station_ids
        if config.GOFO_SESSION_GROUP:
            if not web_portal:
                raise SessionCoordinationError('La sesion compartida requiere el portal de coordinacion.')
            # 29/10 (pedido del usuario): ciudad compartida. Se ofrecen TODAS las ciudades de esta corrida y el portal dice
            # en cual trabajar (la que ya tiene otra corrida de la cuenta, o la menos atendida)
            cities=[config.GOFO_STATION_NAMES[s] for s in station_ids if s in config.GOFO_STATION_NAMES]
            active_guard=SessionGuard(coord_client(),config.GOFO_SESSION_GROUP,config.CLAIM_WORKER,
                                      cities=cities,turn_s=config.CITY_TURN_S)
            try:
                granted=active_guard.acquire()
            except Exception as error:
                if not offline_fallback_allowed(error):
                    active_guard=None
                    raise
                # 28/10 (pedido del usuario): portal caido hace mas de GOFO_SESSION_OFFLINE_S: la PC sigue sola
                log_throttled('guard-offline',f'Portal sin respuesta hace {time.monotonic()-(OUTAGE_SINCE[0] or LAST_CONTACT[0]):.0f} s ({error}): '
                              'la PC sigue sola con la sesion y retoma los turnos cuando vuelva.',every_s=300)
                active_guard.start_offline()
                granted=True
            if not granted:
                active_guard=None
                raise SessionCoordinationError('Sesion compartida: cambio de ciudad en curso u otra corrida con la sesion exclusiva.')
            if active_guard.city:
                shared_id=next((sid for sid,name in config.GOFO_STATION_NAMES.items() if name==active_guard.city),None)
                if shared_id is None or shared_id not in station_ids:
                    active_guard.close()
                    active_guard=None
                    raise SessionCoordinationError(f'El portal asigno una ciudad que esta corrida no revisa ({shared_id}).')
                pass_stations=[shared_id]
                selected_station=shared_id
        coordinator = None
        if config.CLAIM_WORK and web_portal:
            coordinator = claims_by_day.get(today)
            if coordinator is None:
                coordinator = LeaseCoordinator(coord_client(), config.CLAIM_WORKER, today,
                                               config.CLAIM_LEASE_S, ckpt_mgr.db_path).start()
                claims_by_day[today] = coordinator
        if pipeline is None:
            pipeline = ScoringPipeline(validator, on_scored=on_scored, tracker=tracker,
                                       max_pending=config.ANALYSIS_QUEUE_SIZE if config.ASYNC_ANALYSIS else None)
            if config.ASYNC_ANALYSIS:
                from processing.analysis_queue import AnalysisQueue
                pipeline = AnalysisQueue(pipeline, config.ANALYSIS_QUEUE_SIZE)
        try:
            # Albaranes extraídos en una corrida anterior que se cortó antes de terminar su score
            resume_records = preloaded if not config.ASYNC_ANALYSIS or pass_state.get('resumed_day') != today else []
            for pod in resume_records:
                if drivers.only and not drivers.should_review({"driverName": pod.driver_name}):
                    continue
                if pod.risk_score is None and pod.processing_status != ProcessingStatusEnum.FAILED:
                    pipeline.submit(pod)
            pass_state['resumed_day'] = today

            def on_record(pod):
                ckpt_mgr.save_pod_checkpoint(session_id, pod)  # Checkpoint apenas se extrae
                pipeline.submit(pod)                           # El OCR corre en otro proceso
                new_records.append(pod)
                if time.monotonic()-pass_state.get('last_runtime',-1e9)>=15:
                    set_phase('analyzing',closing_pending=closing.pending_count(),backlog=pass_state.get('backlog'))
                    pass_state['last_runtime']=time.monotonic()
                if time.monotonic() - pass_state.get("last_battery", -1e9) >= 300:
                    battery.check()
                    pass_state["last_battery"] = time.monotonic()
                portal_sync.coverage_tick(extractor.api, web_portal, today, pass_state)   # 29/10: cobertura, cada 10 min
                # 04/10: una pasada por bloques dura horas (el Excel quedó de las 12:51 a las 20:49): también se
                # regenera aquí cada 15 min, no solo al final de la pasada
                if time.monotonic() - pass_state.get("last_export", -1e9) >= 900:
                    export_review_queue(ckpt_mgr, session_id, today)
                    pass_state["last_export"] = time.monotonic()

            def on_backlog(summary):
                data = pass_state["backlog"] = save_backlog(summary, ckpt_mgr, session_id, today)
                # En consola: al listar las rutas y luego cada 15 min (no en cada bloque)
                if time.monotonic() - pass_state.get("last_backlog_print", -1e9) >= 900:
                    console.print(f"[magenta]{backlog_line(data)}[/magenta]")
                    pass_state["last_backlog_print"] = time.monotonic()

            extractor = ApiPODExtractor(guarded_api(), tracker=tracker, on_backlog=on_backlog)
            # Los de más errores reales (calculados al empezar el día) + la lista manual 'prioridad' (se lee cada pasada)
            extractor.priority_drivers = pass_state.get("priority", set()) | manual_priority()
            # 07/10: faltantes estimados sin listar cada ruta, y qué rutas se listaron hace poco (entre pasadas)
            extractor.reviewed_counts = lambda: ckpt_mgr.count_by_driver(session_id)
            from storage import route_panel   # 11/10: panel de rutas de la página local
            extractor.on_couriers = lambda station, cs: route_panel.save_couriers(today, station, cs)
            extractor.on_exception = lambda station, c, raw: route_panel.save_exception(today, station, c, raw)
            from storage import package_control   # 15/10: todos los albaranes de cada ruta, para `main.py control`
            extractor.on_route_listed = lambda station, c, ws: package_control.save_route(today, station, c, ws)
            extractor.route_cache = pass_state.setdefault("route_cache", {})
            extractor.route_lists = pass_state.setdefault("route_lists", {})
            if config.VERIFY_WORK and web_portal:
                from automation.verifier import CrossVerifier
                verifier = pass_state.setdefault("verifier", CrossVerifier(web_portal.fetch_verifications,
                                                                           web_portal.report_verify_error))
                extractor.verify_fn = lambda: verifier.run_some(extractor, pipeline, today)
            if config.CLAIM_WORK and web_portal:
                # 25/10: reparto con la otra corrida a través del portal (las reservas no se pierden entre pasadas)
                extractor._denied = pass_state.setdefault("denied", {})
                extractor._claim_done = pass_state.setdefault("claim_done", [])
                extractor.claim_fn = coordinator.acquire
                extractor.defer_claim_done = True
                extractor.reservation_info = coordinator.info
                # 29/10: con el portal nuevo: lista de lo hecho hoy por todas las corridas, varios candidatos por pedido y reparto
                # por repartidor (con el portal anterior done_set() es None y sigue el reparto de siempre)
                done_today = coordinator.done_set()
                if done_today is not None:
                    extractor.done_elsewhere = done_today
                    extractor.claim_some_fn = coordinator.acquire_some
                    if config.ROUTE_CLAIMS:
                        extractor.route_claim_fn = coordinator.routes
                        extractor.route_release_fn = coordinator.release_route
            # Muestreo solo el día indicado en drivers_config.json (se lee cada pasada; otro día, se revisa todo)
            extractor.sample_pct = sampling_for(today)
            extractor._taken = pass_state.setdefault("taken", {})
            # 29/10: una sola ciudad sin sesion compartida (Tracking con DFW02): cortar cada CITY_TURN_S solo relistaba
            extractor.rotate = bool(config.GOFO_SESSION_GROUP) or len(station_ids) > 1
            if active_guard and active_guard.city:
                extractor.turn_s = active_guard.turn_left   # Lo que queda del turno de la ciudad compartida
            pass_state["extractor"] = extractor
            # 29/10: totales de GOFO de TODAS las ciudades para la cobertura del portal (cada 10 min; también en Kaggle)
            portal_sync.coverage_tick(extractor.api, web_portal, today, pass_state)
            status_map = ckpt_mgr.get_status_map(session_id)  # tracking -> estado en el portal
            extractor.run_pass(
                pass_stations, today, status_map, on_record,
                on_status_change=lambda trk, old, new: ckpt_mgr.mark_status_change(session_id, trk, old, new),
                on_route=lambda st, courier, stats: ckpt_mgr.save_route_snapshot(session_id, st, courier, stats),
                should_review=drivers.should_review,  # Todos menos los excluidos (o solo los de --drivers)
            )
        finally:
            if coordinator:
                coordinator.release_routes()   # 29/10: las rutas de esta pasada quedan libres para las demas corridas
            if active_guard:
                try:
                    # Ciudad compartida sin nada nuevo ni pendiente: el portal la salta un rato y cambia de ciudad ya
                    active_guard.close(empty=extractor is not None and not new_records and not extractor.capped)
                except Exception as error:
                    logger.warning('Reserva de sesion se liberara por vencimiento: %s',type(error).__name__)
                active_guard=None
            set_phase('draining_analysis',closing_pending=closing.pending_count())
            if not config.ASYNC_ANALYSIS:
                pipeline.drain()
            if coordinator:
                try:
                    coordinator.tick()
                except Exception as error:
                    logger.warning('Confirmaciones de reparto pendientes en disco: %s', error)
        return new_records

    pass_state = {}

    def day_has_work(day):
        """30/10: GOFO ya tiene entregas con POD ese día (solo el resumen de repartidores, sin cambiar de ciudad)."""
        api = PortalAPI(bm.page)
        total = 0
        for sid in station_ids:
            for c in api.list_couriers(sid, day):
                try:
                    total += int(c.get('podPieces') or 0)
                except (TypeError, ValueError):
                    pass
        return total >= config.DAY_CARRY_MIN_POD

    def day_still_open(day):
        """30/10: el día anterior se puede seguir aquí: su sesión no está cerrada (o este equipo no tiene ninguna)."""
        with ckpt_mgr._get_connection() as con:
            row = con.execute('SELECT status FROM audit_sessions WHERE query_date=? ORDER BY updated_at DESC LIMIT 1',
                              (day,)).fetchone()
        return row is None or row[0] == 'IN_PROGRESS'

    carry = DayCarry(day_has_work, now=lambda: operation_now())   # Misma hora que el resto de la corrida

    try:
        bm.start_browser()
        LoginManager(bm).require_valid_session()

        while True:
            # --date: terminar un día anterior. 30/10: pasada la medianoche se sigue el anterior mientras el nuevo no tenga entregas
            today = fixed_day or carry.pick(current_day, day_still_open)
            if today != current_day:
                if pipeline is not None:
                    pipeline.drain()  # No trasladar resultados al checkpoint de otro día.
                if session_id:
                    closing.enqueue(session_id, current_day)
                    previous_claims = claims_by_day.get(current_day)
                    if previous_claims:
                        previous_claims.close()
                    console.print('[cyan]Cierre anterior encolado; se atenderá por bloques cuando no haya extracción nueva.[/cyan]')
                existing = ckpt_mgr.get_latest_incomplete_session(today)
                session_id = existing["session_id"] if existing else ckpt_mgr.create_session(today)
                current_day = today
                console.print(f"[cyan]Día {today} → sesión {session_id}[/cyan]")
                pass_state["priority"] = load_priority_drivers(ckpt_mgr, today)
                pass_state["route_cache"] = {}   # Rutas listadas: se cuentan de nuevo cada día
                pass_state["route_lists"] = {}
                pass_state["taken"] = {}

            set_phase('extracting',closing_pending=closing.pending_count())
            if dispatcher:
                selected_station=dispatcher.choose(today)
                if selected_station is None and carry.active(today):
                    carry.stop('ya no queda trabajo del día anterior en sus ciudades')   # Al día nuevo en la próxima vuelta
                    continue
                if selected_station is None:
                    close_some()
                    set_phase('waiting',wait_s=10,reason='Sin trabajo disponible en las tres ciudades')
                    sleep(10)
                    continue
                set_phase('extracting',closing_pending=closing.pending_count())
            if config.EXTRACTION_MODE == "api":
                # Solo los que quedaron sin puntaje (los demás ya están en la base y se saltan por su tracking)
                preloaded = ckpt_mgr.load_unscored_pods(session_id)
                try:
                    new_records = api_pass(today, preloaded)
                    if dispatcher:
                        # 29/10: la pausa de una ciudad vacia es para pasar a otra; con una sola ciudad solo dejaba parada la corrida
                        dispatcher.finish(today,selected_station,empty=not new_records and len(station_ids)>1)
                except SessionCoordinationError as error:
                    if dispatcher: dispatcher.release()
                    set_phase('waiting_session',reason=str(error),wait_s=5)
                    WAIT.add(5)
                    log_throttled('wait-session',f'Esperando coordinacion de sesion: {error} (acumulado: {WAIT.total/60:.0f} min).',every_s=300)
                    sleep(5)
                    continue
                except SessionExpiredError:
                    raise
                except Exception as api_err:
                    if dispatcher: dispatcher.release()
                    if config.GOFO_SESSION_GROUP:
                        kind=classify_failure(api_err)
                        set_phase('waiting_session',reason='Coordinacion o extraccion no disponible',wait_s=min(poll_interval,30))
                        if kind=='auth':
                            if log_throttled('main-auth',f'El portal rechazo la clave: {api_err}. Revisa PORTAL_API_KEY en .env; sin ella no se coordina la sesion.',every_s=300,level=logging.ERROR):
                                console.print(f'[red]Portal: {api_err}. Revisa PORTAL_API_KEY en .env.[/red]')
                        else:
                            if log_throttled('main-coord-'+kind,f'No se pudo consultar con coordinacion de sesion ({type(api_err).__name__}: {api_err}); se reintenta (acumulado: {WAIT.total/60:.0f} min).',every_s=300):
                                console.print('[yellow]No se pudo consultar con coordinacion de sesion; se reintentara sin usar la interfaz.[/yellow]')
                        WAIT.add(min(poll_interval,30))
                        sleep(min(poll_interval,30))
                        continue
                    if max_passes != 1:
                        # 03/10: un "Failed to fetch" pasajero mandaba la corrida continua a la interfaz (muy lenta, casi no
                        # avanzaba). En modo continuo se reintenta la API en la próxima pasada.
                        console.print(f"[yellow]La API interna falló ({api_err}). Reintento en la próxima pasada.[/yellow]")
                        sleep(min(poll_interval, 60))
                        continue
                    # "Intentar con la API interna, si no, la interfaz"
                    console.print(f"[yellow]La API interna falló ({api_err}). Usando la interfaz en esta pasada.[/yellow]")
                    preloaded = ckpt_mgr.load_session_pods(session_id)
                    new_records = ui_pass(today, preloaded)
                    for r in new_records:
                        validator.validate_pod(r)
                        ckpt_mgr.save_pod_checkpoint(session_id, r)
            else:
                new_records = ui_pass(today, ckpt_mgr.load_session_pods(session_id))
                for r in new_records:
                    validator.validate_pod(r)
                    ckpt_mgr.save_pod_checkpoint(session_id, r)

            passes += 1
            total_day = len(ckpt_mgr.get_processed_trackings(session_id))
            console.print(f"[green]Pasada {passes}: {len(new_records)} albaranes nuevos (total del día: {total_day}).[/green]")
            if pass_state.get("backlog"):
                console.print(f"[magenta]{backlog_line(pass_state['backlog'])}[/magenta]")
            # 03/10: el Excel carga los ~3000 albaranes del día; con pasadas por bloques seguidas se regenera cada 15 min
            if time.monotonic() - pass_state.get("last_export", -1e9) >= 900 or max_passes == 1:
                export_review_queue(ckpt_mgr, session_id, today)
                pass_state["last_export"] = time.monotonic()
            print_throughput_projection(tracker)
            activity = recent_activity(config.THROUGHPUT_LOG_PATH)
            console.print(f"[dim]Últimos 5 min: {activity['completed_recent']} analizados · "
                          f"{activity['actual_per_hour']}/h reales · sin completar: {activity['idle_seconds']} s.[/dim]")
            if max_passes and passes >= max_passes:
                break
            if dispatcher:
                # Un proceso por sesion conserva su pool OCR; cambia de ciudad sin recargar modelos.
                continue
            if getattr(pass_state.get("extractor"), "capped", False):
                # Por bloques: quedan albaranes de repartidores que llegaron al tope; seguir sin esperar
                console.print("[dim]Quedan albaranes por bloques: siguiente pasada sin esperar.[/dim]")
                continue
            if carry.active(today) and not new_records:
                carry.stop('ya no queda trabajo del día anterior')   # 30/10: al día nuevo sin esperar
                continue
            if not new_records:
                set_phase('closing',closing_pending=closing.pending_count())
                close_some()
            wait_s = min(poll_interval, config.CLOSING_IDLE_POLL_S) if closing.pending_count() else poll_interval
            set_phase('waiting',wait_s=wait_s,closing_pending=closing.pending_count(),
                      backlog=pass_state.get('backlog'))
            console.print(f"[dim]Esperando {wait_s}s antes de la próxima pasada...[/dim]")
            sleep(wait_s)

    except SessionExpiredError as e:
        console.print(Panel(f"[bold red]{e}[/bold red]", title="SESIÓN VENCIDA — corrida detenida", border_style="red"))
        raise SystemExit(2)
    except KeyboardInterrupt:
        console.print("[yellow]Detenido por el usuario. La próxima corrida retoma desde el checkpoint.[/yellow]")
    finally:
        if dispatcher: dispatcher.release()
        if active_guard:
            try: active_guard.close()
            except Exception: pass
        if pipeline is not None:
            pipeline.close()
        for coordinator in claims_by_day.values():
            coordinator.close()
        if web_portal:
            web_portal.stop()
        bm.close_browser()
        set_phase('stopped',closing_pending=closing.pending_count())


def run_recheck_flags(date_str: Optional[str]) -> None:
    """`python main.py recheck-flags --date MM/DD/YYYY`: control manual de marcas de POD falso de un día."""
    day = operation_now().strftime("%Y-%m-%d")
    if date_str:
        day = (datetime.strptime(date_str, "%m/%d/%Y") if "/" in date_str
               else datetime.strptime(date_str, "%Y-%m-%d")).strftime("%Y-%m-%d")
    ckpt_mgr = CheckpointManager()
    with ckpt_mgr._get_connection() as conn:
        row = conn.execute("SELECT session_id FROM audit_sessions WHERE query_date = ? ORDER BY started_at DESC LIMIT 1;",
                           (day,)).fetchone()
    if not row:
        console.print(f"[yellow]No hay albaranes revisados del {day}.[/yellow]")
        return
    bm = BrowserManager(headless=True)
    try:
        bm.start_browser()
        LoginManager(bm).require_valid_session()
        recheck_false_pod_flags(ckpt_mgr, row["session_id"], PortalAPI(bm.page))
        export_review_queue(ckpt_mgr, row["session_id"], day)
    except SessionExpiredError as e:
        console.print(Panel(f"[bold red]{e}[/bold red]", title="SESIÓN NO DISPONIBLE", border_style="red"))
        raise SystemExit(2)
    finally:
        bm.close_browser()


def control_candidates(days: List[str]) -> List[str]:
    """
    Albaranes a los que pedir el historial: las rutas completas que guardó la corrida, lo revisado por el script y
    las entregas con problema de esos días, más los que siguen abiertos de días anteriores (sin entregar ni perder).
    Se saltan los que ya no cambian (entregados o perdidos con el historial pedido después).
    """
    from storage import package_control, route_panel
    found = dict.fromkeys(package_control.roster_trackings(days))
    marks = ",".join("?" * len(days))
    with CheckpointManager()._get_connection() as conn:
        found.update(dict.fromkeys(r[0] for r in conn.execute(
            f"SELECT p.tracking_number FROM pod_checkpoints p JOIN audit_sessions s ON s.session_id = p.session_id "
            f"WHERE s.query_date IN ({marks})", days)))
    for d in days:
        found.update(dict.fromkeys(e["tracking"] for e in route_panel.load(d)["exceptions"]))
    settled = package_control.settled_trackings()
    todo = [t for t in found if t and t not in settled]
    todo += [t for t in package_control.open_trackings() if t not in found]
    return todo


def recalc_package_control() -> int:
    """
    Vuelve a calcular los tres controles con los historiales ya guardados (sin pedir nada a GOFO): al cambiar una regla
    (ej. el plazo de devolución) y al final de cada control, para que los pendientes pasen a vencidos.
    El doble escaneo se recalcula para cada día que el paquete salió a reparto.
    """
    from processing import package_control as pc
    from storage import package_control
    trks = package_control.recent_trackings()
    now = operation_now()
    for i in range(0, len(trks), 2000):
        tracks = package_control.load_tracks(trks[i:i + 2000])
        days = {e.when.date() for t in tracks for e in t.events if e.code == pc.OUT_FOR_DELIVERY}
        package_control.save_results(pc.analyze(tracks, days, now, config.RETURN_DEADLINE_DAYS,
                                                config.RETURN_DEADLINE_HOUR, stations=config.GOFO_STATION_NAMES.values()))
    return len(trks)


def run_package_control(date_str: Optional[str], recalc_only: bool = False) -> None:
    """
    `python main.py control [--date YYYY-MM-DD]`: control de paquetes del día y del anterior (doble escaneo,
    devoluciones a tiempo, perdidos), con el historial de escaneos de GOFO. Solo lectura y sin cambiar de ciudad:
    se puede correr con la corrida andando. Resultado en la página local (botón "Control de paquetes").
    `--recalcular`: solo recalcula con lo ya guardado (sin abrir el portal).
    """
    from processing import package_control as pc
    from storage import package_control
    if recalc_only:
        console.print(f"[green]Recalculados {recalc_package_control()} historiales con las reglas actuales.[/green]")
        return
    day = operation_now().strftime("%Y-%m-%d")
    if date_str:
        day = (datetime.strptime(date_str, "%m/%d/%Y") if "/" in date_str
               else datetime.strptime(date_str, "%Y-%m-%d")).strftime("%Y-%m-%d")
    d0 = datetime.strptime(day, "%Y-%m-%d").date()
    days = [(d0 - timedelta(days=1)).isoformat(), day]
    todo = control_candidates(days)
    console.print(f"[cyan]Control de paquetes {', '.join(days)}: {len(todo)} albaranes por consultar en GOFO "
                  f"(~{len(todo) // 50 + 1} consultas de 50).[/cyan]")
    if not todo:
        recalc_package_control()
        return
    from automation.portal_api import PortalAPIError, TRACK_BATCH
    bm = BrowserManager(headless=True)
    totals = {"scans": 0, "returns": 0, "lost": 0}
    fetched, skipped = 0, []

    def fetch(api, batch):
        """Un lote que no responde se parte en dos; uno de pocos albaranes que igual falla se salta (no corta todo)."""
        try:
            return api.get_tracks(batch)
        except PortalAPIError as e:
            if len(batch) <= 5:
                logging.getLogger("PODAutomation.Control").warning(f"Sin historial para {batch}: {e}")
                skipped.extend(batch)
                return []
            half = len(batch) // 2
            return fetch(api, batch[:half]) + fetch(api, batch[half:])

    try:
        bm.start_browser()
        LoginManager(bm).require_valid_session()
        api = PortalAPI(bm.page)
        scan_days = [d0 - timedelta(days=1), d0]
        for i in range(0, len(todo), TRACK_BATCH):
            now = operation_now()
            tracks = [t for t in (pc.parse_track(x) for x in fetch(api, todo[i:i + TRACK_BATCH])) if t]
            package_control.save_tracks(tracks, {t.tracking: pc.is_settled(t, now) for t in tracks})
            res = pc.analyze(tracks, scan_days, now, config.RETURN_DEADLINE_DAYS, config.RETURN_DEADLINE_HOUR,
                             stations=config.GOFO_STATION_NAMES.values())
            package_control.save_results(res)
            fetched += len(tracks)
            for k in totals:
                totals[k] += len(res[k])
            done = min(i + TRACK_BATCH, len(todo))
            if done % 500 < TRACK_BATCH or done == len(todo):
                console.print(f"[dim]  {done}/{len(todo)} consultados[/dim]")
        package_control.save_run(days, fetched, totals)
        if skipped:
            console.print(f"[yellow]{len(skipped)} albaranes sin respuesta de GOFO; se piden de nuevo en el próximo control.[/yellow]")
    except SessionExpiredError as e:
        console.print(Panel(f"[bold red]{e}[/bold red]", title="SESIÓN NO DISPONIBLE", border_style="red"))
        raise SystemExit(2)
    finally:
        bm.close_browser()
    recalc_package_control()   # Los pendientes de días anteriores que ya no se consultaron pasan a vencidos
    data = package_control.load(day)
    bad = [s for s in data["scans"] if s["verdict"] != "ok"]
    overdue = [r for r in data["returns"] if r["outcome"] in ("vencido", "tarde", "salio_sin_devolver",
                                                               "entregado_sin_devolver")]
    console.print(f"[green]Listo: {fetched} historiales. Del {day}: {len(data['scans'])} salidas a reparto, "
                  f"{len(bad)} sin doble escaneo propio; {len(overdue)} devoluciones fuera de plazo o sin devolver; "
                  f"{len(data['lost'])} perdidos en los últimos 14 días. Detalle en la página local.[/green]")


def run_cleanup(assume_yes: bool = False) -> None:
    """`python main.py limpiar`: borra el historial de días pasados salvo los casos guía (ver storage/limpieza.py)."""
    from storage.limpieza import build_plan, apply_plan
    ckpt_mgr = CheckpointManager()
    conn = sqlite3.connect(str(ckpt_mgr.db_path), timeout=30.0)
    try:
        plan = build_plan(conn)
        table = Table(title="Limpieza del historial")
        table.add_column("Día")
        table.add_column("Albaranes a borrar", justify="right")
        table.add_column("Casos guía que quedan", justify="right")
        for day in sorted(set(plan.rows_by_day) | set(plan.kept_rows_by_day)):
            table.add_row(day, str(plan.rows_by_day.get(day, 0)), str(plan.kept_rows_by_day.get(day, 0)))
        console.print(table)
        console.print(f"Días completos que se conservan: {', '.join(sorted(plan.keep_days))}\n"
                      f"Carpetas de fotos a borrar: {len(plan.photo_dirs)} ({plan.photo_bytes / 1e9:.2f} GB)")
        if not plan.total_rows and not plan.photo_dirs:
            console.print("[green]No hay nada que limpiar.[/green]")
            return
        if not assume_yes and not Confirm.ask("[bold yellow]¿Borrar?[/bold yellow]", default=False):
            console.print("[yellow]Cancelado; no se borró nada.[/yellow]")
            return
        apply_plan(conn, plan)
        console.print(f"[green]Listo: {plan.total_rows} albaranes y {len(plan.photo_dirs)} carpetas de fotos borradas; "
                      f"base compactada ({ckpt_mgr.db_path.stat().st_size / 1e6:.0f} MB).[/green]")
    finally:
        conn.close()


def run_portal_sync(date_str: Optional[str] = None) -> None:
    """
    `python main.py portal`: prueba la conexión con el portal web y envía lo que quedó pendiente.
    `--date YYYY-MM-DD`: envía también todos los Alta / Media de ese día (ej. un día procesado antes de conectar el portal).
    """
    if not config.PORTAL_SYNC_ENABLED:
        console.print("[yellow]El portal no está configurado: agrega PORTAL_URL y PORTAL_API_KEY al archivo .env "
                      "(la clave se genera en el portal, Ajustes > Conexión con el script).[/yellow]")
        return
    sync = portal_sync.from_config(start=False)
    try:
        info = sync.client.call("ping.php")
    except portal_sync.PortalError as e:
        console.print(f"[bold red]No se pudo conectar con {config.PORTAL_URL}: {e}[/bold red]")
        raise SystemExit(1)
    console.print(f"[green]Conexión con el portal correcta (día en el portal: {info.get('today')}).[/green]")
    if date_str:
        day = (datetime.strptime(date_str, "%m/%d/%Y") if "/" in date_str
               else datetime.strptime(date_str, "%Y-%m-%d")).strftime("%Y-%m-%d")
        ckpt_mgr = CheckpointManager()
        with ckpt_mgr._get_connection() as conn:
            sessions = [r["session_id"] for r in conn.execute(
                "SELECT session_id FROM audit_sessions WHERE query_date = ? ORDER BY started_at", (day,))]
        latest = {}
        for sid in sessions:  # La sesión más reciente del día pisa a las anteriores
            latest.update({p.tracking_number: p for p in ckpt_mgr.load_session_pods(sid)})
        queued = 0
        for pod in latest.values():
            if pod.priority in portal_sync.SEND_PRIORITIES and pod.risk_score is not None:
                sync.enqueue_pod(pod, day, analyzed_now=False)
                queued += 1
        console.print(f"{queued} albaranes Alta / Media del {day} en la bandeja de salida.")
    try:
        result = sync.sync_once()
    except portal_sync.PortalError as e:
        console.print(f"[bold red]El envío se cortó: {e}. Lo que falta queda en la bandeja y sale en la próxima corrida.[/bold red]")
        raise SystemExit(1)
    console.print(f"[green]Enviados {result['albaranes']} albaranes y {result['marcas_enviadas']} marcas; "
                  f"recibidas {result['marcas_recibidas']} marcas de la web.[/green]")
    pending = sync.outbox.counts()
    if pending.get("pod") or pending.get("status"):
        console.print(f"[yellow]En espera de reintento: {pending.get('pod', 0)} albaranes y {pending.get('status', 0)} marcas.[/yellow]")


def update_drivers_catalog(date_str: Optional[str] = None):
    """`python main.py drivers`: escribe drivers_config.json con todos los repartidores del día (solo lectura)."""
    bm = BrowserManager(headless=True)
    try:
        bm.start_browser()
        LoginManager(bm).require_valid_session()
        api = PortalAPI(bm.page)
        today = operation_now().strftime("%Y-%m-%d")
        if date_str:  # MM/DD/YYYY o YYYY-MM-DD
            today = (datetime.strptime(date_str, "%m/%d/%Y") if "/" in date_str
                     else datetime.strptime(date_str, "%Y-%m-%d")).strftime("%Y-%m-%d")
        by_station = {}
        for sid in config.GOFO_STATION_IDS:
            couriers = api.list_couriers(sid, today)
            name = couriers[0].get("siteName") if couriers else str(sid)
            by_station[name] = couriers
        path = DriverSelection().update_catalog(by_station)
        total = sum(len(v) for v in by_station.values())
        console.print(f"[green]Catálogo de {total} repartidores guardado en {path}.[/green]\n"
                      "Agregá en 'excluir' los nombres (o IDs) que NO hay que revisar.")
    except SessionExpiredError as e:
        console.print(Panel(f"[bold red]{e}[/bold red]", title="SESIÓN NO DISPONIBLE", border_style="red"))
        raise SystemExit(2)
    finally:
        bm.close_browser()


def run_offline_demo():
    """Ejecuta una demostración completa con datos de muestra sin acceder a la plataforma web."""
    console.print("\n[cyan]Ejecutando pipeline de demostración offline con evidencias sintéticas...[/cyan]")
    from generate_demo_dataset import generate_demo_dataset
    excel_path = generate_demo_dataset()
    console.print(f"[bold green][OK] Demostración completada. Reporte generado en:[/bold green] {excel_path}\n")


def interactive_menu():
    """Menú interactivo CLI principal (Fase 10)."""
    while True:
        print_main_banner()
        console.print("[bold]1.[/bold] Procesar fecha")
        console.print("[bold]2.[/bold] Reanudar proceso anterior")
        console.print("[bold]3.[/bold] Ver configuración")
        console.print("[bold]4.[/bold] Modo inspect (Fase 12)")
        console.print("[bold]5.[/bold] Ejecutar demostración con datos de ejemplo (Offline)")
        console.print("[bold]6.[/bold] Salir\n")

        choice = Prompt.ask("[bold cyan]Selecciona una opción[/bold cyan]", choices=["1", "2", "3", "4", "5", "6"], default="1")

        if choice == "1":
            default_today = operation_now().strftime("%m/%d/%Y")
            date_input = Prompt.ask(
                f"[bold cyan]Introduce la fecha ({config.DATE_FORMAT})[/bold cyan]",
                default=default_today,
            )
            process_date_workflow(date_input)

        elif choice == "2":
            resume_previous_workflow()

        elif choice == "3":
            display_configuration()

        elif choice == "4":
            inspector = PlatformInspector()
            inspector.run_inspect_mode()

        elif choice == "5":
            run_offline_demo()

        elif choice == "6":
            console.print("[bold green]Saliendo de POD Automation. ¡Hasta pronto![/bold green]")
            sys.exit(0)

        Prompt.ask("\n[dim]Presiona ENTER para volver al menú principal...[/dim]")


def parse_cli_args():
    """Parsea argumentos de línea de comandos para ejecución directa desatendida."""
    parser = argparse.ArgumentParser(description="POD Automation - Sistema de Verificación y Auditoría de Entregas.")
    parser.add_argument("command", nargs="?", choices=["inspect", "demo", "menu", "login", "run", "throughput", "drivers", "recheck-flags", "report", "limpiar", "portal", "control"], help="Comando directo a ejecutar.")
    parser.add_argument("--yes", action="store_true", help="limpiar: borrar sin pedir confirmación.")
    parser.add_argument("--recalcular", action="store_true", help="control: recalcular con los historiales ya guardados (sin abrir el portal).")
    parser.add_argument("--continuous", action="store_true", help="run: procesar indefinidamente los albaranes nuevos del día.")
    parser.add_argument("--poll-interval", type=int, default=config.CONTINUOUS_POLL_INTERVAL_S, help="run --continuous: segundos entre pasadas.")
    parser.add_argument("--max-passes", type=int, default=None, help="run: detener tras N pasadas (por defecto, sin límite en --continuous).")
    parser.add_argument("--account", type=str, default=None, help="Cuenta de Google con la que iniciar sesión (login).")
    parser.add_argument("--from-profile", type=str, default=None, help="login: reutiliza la sesión de tu Chrome normal con esta cuenta de Google (Chrome cerrado).")
    parser.add_argument("--wait-seconds", type=int, default=0, help="login: esperar hasta N s a detectar el dashboard en vez de pedir ENTER.")
    parser.add_argument("--headless", action="store_true", help="Ejecuta el navegador sin ventana (requiere sesión guardada).")
    parser.add_argument("--date", type=str, default=None, help=f"Fecha a procesar ({config.DATE_FORMAT}).")
    parser.add_argument("--resume", action="store_true", help="Reanuda la última sesión incompleta.")
    parser.add_argument("--extra-drivers", type=str, default=None,
                        help="run: revisar también estos repartidores aunque sean de otra estación (nombres o IDs).")
    parser.add_argument("--skip-drivers", type=str, default=None,
                        help="run: NO revisar estos repartidores solo en esta corrida (nombres o IDs, separados por coma).")
    parser.add_argument("--stations", type=str, default=None, help="run: revisar SOLO estas estaciones (ej. DFW02-BAA).")
    parser.add_argument("--drivers", type=str, default=None, help="run: revisar SOLO estos repartidores (nombres exactos o IDs, separados por coma).")
    parser.add_argument("--port", type=int, default=8765, help="report: puerto de la página local de reportes.")
    parser.add_argument("--limit", type=int, default=None, help="Límite máximo de entregas a procesar.")
    return parser.parse_args()


def setup_run_log(name: str = "run") -> None:
    """
    Guarda los mensajes del análisis ("PODAutomation.*": tiempos por etapa, avisos del modelo de visión) en
    storage/logs/run_<fecha>.log. Antes del 02/10 no tenían destino y se perdían.
    """
    import logging
    config.LOGS_DIR.mkdir(parents=True, exist_ok=True)
    log = logging.getLogger("PODAutomation")
    if any(isinstance(h, logging.FileHandler) for h in log.handlers):
        return
    handler = logging.FileHandler(config.LOGS_DIR / f"{name}_{operation_now():%Y%m%d}.log", encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] [%(name)s] %(message)s", "%Y-%m-%d %H:%M:%S"))
    log.addHandler(handler)
    log.setLevel(logging.INFO)


def main():
    args = parse_cli_args()
    if args.headless:
        config.HEADLESS = True

    if args.command == "login":
        sys.exit(0 if run_manual_login(account=args.account, wait_seconds=args.wait_seconds, from_profile=args.from_profile) else 1)
    elif args.command == "run":
        setup_run_log()
        from export import portal_log
        portal_log.install()   # 30/10: el registro de esta corrida también en el portal (Auditoría > Registro)
        max_passes = args.max_passes if args.continuous else 1
        only = [d.strip() for d in args.drivers.split(",")] if args.drivers else None
        fixed_day = datetime.strptime(args.date, "%m/%d/%Y").strftime("%Y-%m-%d") if args.date else None
        run_continuous_workflow(poll_interval=args.poll_interval, max_passes=max_passes, only_drivers=only,
                                fixed_day=fixed_day,
                                stations=[s.strip() for s in args.stations.split(",")] if args.stations else None,
                                skip_drivers=[s.strip() for s in args.skip_drivers.split(",")] if args.skip_drivers else None,
                                extra_drivers=[s.strip() for s in args.extra_drivers.split(",")] if args.extra_drivers else None)
    elif args.command == "recheck-flags":
        run_recheck_flags(args.date)
    elif args.command == "drivers":
        update_drivers_catalog(args.date)
    elif args.command == "control":
        setup_run_log("control")
        run_package_control(args.date, recalc_only=args.recalcular)
    elif args.command == "portal":
        setup_run_log()
        run_portal_sync(args.date)
    elif args.command == "limpiar":
        run_cleanup(assume_yes=args.yes)
    elif args.command == "report":
        setup_run_log("pagina")   # 11/10: envíos de WhatsApp con el tiempo de cada paso (antes no quedaba registro)
        from export.report_server import serve
        serve(args.port)
    elif args.command == "throughput":
        print_throughput_projection()
    elif args.command == "inspect":
        inspector = PlatformInspector()
        inspector.run_inspect_mode()
    elif args.command == "demo":
        run_offline_demo()
    elif args.resume:
        resume_previous_workflow()
    elif args.date:
        process_date_workflow(args.date, max_records=args.limit)
    else:
        interactive_menu()


if __name__ == "__main__":
    main()
