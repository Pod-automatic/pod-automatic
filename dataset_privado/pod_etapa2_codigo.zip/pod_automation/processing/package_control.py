"""
Control de paquetes (15/10/2026, pedido de los dueños: "poner fin a los paquetes perdidos" y "el doble escaneo es
obligatorio"). Analiza el historial de escaneos de GOFO (Consulta de seguimiento, PortalAPI.get_tracks).

Tres controles:
1. Doble escaneo: el conductor debe hacer él mismo el escaneo de clasificación (500) de cada paquete antes de salir a
   reparto (208). La salida a reparto es una sola confirmación para toda la ruta (misma hora en todos los paquetes),
   así que la única prueba por paquete de que lo tuvo en la mano es su propio 500. Regla de los dueños: el cobro va a
   quien hizo el último escaneo.
2. Devoluciones: cada entrega fallida (206), y cada salida a reparto que terminó el día sin entrega ni fallo, tiene
   que volver a la estación (209). GOFO lo marca perdido al día siguiente del fallo.
3. Perdidos: códigos 300 (perdido), 301 (robado) y 700 (sospecha de pérdida en la estación), con quién tuvo el
   paquete por última vez.

Funciones puras (sin portal ni base): se prueban con historiales reales en tests/test_package_control.py.
"""

import re
from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta
from typing import Dict, Iterable, List, Optional

SORT_SCAN = "500"
OUT_FOR_DELIVERY = "208"
DELIVERED = "205"
FAILED = "206"
RETURN_CODES = {"209", "261", "204"}           # Devuelto a la estación / al centro
LOST_CODES = {"300": "Perdido", "301": "Robado", "700": "Sospecha de pérdida"}
# Escaneos que dejan el paquete "a nombre" de una persona (para saber quién lo tuvo por última vez)
HOLDER_CODES = {SORT_SCAN, OUT_FOR_DELIVERY, FAILED, DELIVERED}

_DATE_RE = re.compile(r"(\d{1,2})/(\d{1,2})/(\d{4})")
_TIME_RE = re.compile(r"(\d{1,2}):(\d{2})(?::(\d{2}))?")


@dataclass
class Event:
    when: datetime
    code: str
    by: str
    location: str = ""
    text: str = ""


@dataclass
class Track:
    tracking: str
    events: List[Event] = field(default_factory=list)   # De más viejo a más nuevo


def norm_name(name: str) -> str:
    return " ".join((name or "").split()).lower()


def parse_block_date(text: str) -> Optional[date]:
    """'Jueves, 15/10/2026' -> 2026-10-15. El portal manda día/mes/año (verificado 15/10 con y sin encabezados)."""
    m = _DATE_RE.search(text or "")
    if not m:
        m2 = re.search(r"(\d{4})-(\d{1,2})-(\d{1,2})", text or "")
        return date(int(m2.group(1)), int(m2.group(2)), int(m2.group(3))) if m2 else None
    a, b, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
    if b > 12 >= a:   # Por si algún día llega como mes/día
        a, b = b, a
    try:
        return date(y, b, a)
    except ValueError:
        return None


def parse_track(item: Dict) -> Optional[Track]:
    """Un elemento de la respuesta de track/private/list -> Track con los eventos en orden."""
    tracking = ((item.get("waybill") or {}).get("waybillNo") or "").strip()
    events = []
    for blk in item.get("list") or []:
        day = parse_block_date(blk.get("operationTime") or "")
        if day is None:
            continue
        for e in blk.get("trackList") or []:
            tracking = tracking or (e.get("order_no") or "").strip()
            m = _TIME_RE.search(e.get("operationTime") or "")
            if not m:
                continue
            when = datetime.combine(day, time(int(m.group(1)), int(m.group(2)), int(m.group(3) or 0)))
            events.append(Event(when, str(e.get("operation_move") or e.get("corto") or ""),
                                " ".join((e.get("create_by_name") or "").split()),
                                e.get("location") or "", (e.get("es_context") or "").strip()))
    if not tracking:
        return None
    # Estable: a igual hora queda el orden del portal (que viene del más nuevo al más viejo)
    events.reverse()
    events.sort(key=lambda e: e.when)
    return Track(tracking, events)


# ---------------------------------------------------------------- 1. Doble escaneo
def scan_checks(track: Track, day: date) -> List[Dict]:
    """
    Una fila por conductor que sacó el paquete a reparto ese día. Cuentan los escaneos de clasificación del día hasta
    la entrega o el fallo, no solo los anteriores a la salida: la salida a reparto se confirma para toda la ruta y
    muchos siguen escaneando mientras cargan (caso real 15/10: Román confirma la ruta 07:10:59 y escanea 07:15:15).
    - ok: el último escaneo de clasificación es suyo;
    - otro_despues: lo escaneó él, pero después lo escaneó otro (queda a nombre del otro: regla del último escaneo);
    - otro: él nunca lo escaneó, solo otros;
    - sin_escaneo: nadie lo escaneó en clasificación ese día.
    """
    rows = []
    seen = set()
    day_events = [e for e in track.events if e.when.date() == day]
    for out in [e for e in day_events if e.code == OUT_FOR_DELIVERY]:
        driver = out.by
        if not driver or norm_name(driver) in seen:
            continue
        seen.add(norm_name(driver))
        mine = lambda e: norm_name(e.by) == norm_name(driver)
        # Hasta la entrega, el fallo, la devolución o la salida con otro conductor (o el fin del día)
        end = next((e.when for e in day_events if e.when > out.when and (
            e.code in (DELIVERED, FAILED) or e.code in RETURN_CODES or (e.code == OUT_FOR_DELIVERY and not mine(e)))),
            None)
        scans = [e for e in day_events if e.code == SORT_SCAN and (end is None or e.when <= end)]
        own = [e for e in scans if mine(e)]
        after = [e for e in scans if own and e.when > own[-1].when and not mine(e)]
        if not scans:
            verdict = "sin_escaneo"
        elif mine(scans[-1]):
            verdict = "ok"
        else:
            verdict = "otro_despues" if own else "otro"
        rows.append({
            "tracking": track.tracking, "date": day.isoformat(), "driver": driver, "station": out.location,
            "out_time": out.when.isoformat(sep=" "), "verdict": verdict,
            "own_scan": own[-1].when.isoformat(sep=" ") if own else None,
            "scanned_by": ", ".join(dict.fromkeys(e.by for e in scans if not mine(e))),
            "after_by": ", ".join(dict.fromkeys(e.by for e in after)),
        })
    return rows


# ---------------------------------------------------------------- 2. Devoluciones
def return_deadline(start: datetime, deadline_days: int, deadline_hour: int = 13) -> datetime:
    """
    Regla de los dueños (15/10): devolver el MISMO día del fallo; GOFO lo marca perdido al día siguiente. La estación
    escanea las devoluciones solo de mañana (visto 15/10: 209 entre las 5 y las 13 h, nunca de noche), así que lo que
    se devolvió la noche del fallo aparece la mañana siguiente: plazo = día siguiente a las `deadline_hour`.
    """
    return datetime.combine(start.date() + timedelta(days=deadline_days), time(deadline_hour, 0))


def _holder_before(track: Track, when: datetime) -> Optional[Event]:
    prev = [e for e in track.events if e.code in HOLDER_CODES and e.when <= when and e.by]
    return prev[-1] if prev else None


def return_checks(track: Track, now: datetime, deadline_days: int = 1, deadline_hour: int = 13) -> List[Dict]:
    """
    Una fila por entrega fallida (206) y por salida a reparto que cerró el día sin entrega ni fallo. Qué pasó después:
    - devuelto: escaneo de devolución a la estación (209) -> a_tiempo / tarde según el plazo;
    - entregado_sin_devolver / salio_sin_devolver: se entregó o volvió a salir sin escaneo de devolución de por medio
      (con el mismo conductor o con otro: no prueba que se lo quedó, pero no hubo devolución registrada);
    - perdido: GOFO lo marcó perdido / robado / sospecha de pérdida;
    - pendiente (todavía en plazo) / vencido (pasó el plazo y no hay devolución).
    """
    rows = []
    evs = track.events
    starts = []
    for i, e in enumerate(evs):
        if e.code == FAILED:
            starts.append((i, "fallido"))
        elif e.code == OUT_FOR_DELIVERY:
            # Sin entrega ni fallo de ese conductor antes de terminar el día (solo días ya cerrados)
            day_end = datetime.combine(e.when.date(), time(23, 59, 59))
            if now <= day_end:
                continue
            nxt = next((x for x in evs[i + 1:] if x.code in (DELIVERED, FAILED, OUT_FOR_DELIVERY)
                        or x.code in RETURN_CODES or x.code in LOST_CODES), None)
            if nxt is None or nxt.when > day_end:
                starts.append((i, "sin_estado"))
    for i, kind in starts:
        start = evs[i]
        deadline = return_deadline(start.when, deadline_days, deadline_hour)
        outcome, resolved = None, None
        for x in evs[i + 1:]:
            if x.code in RETURN_CODES:
                outcome = "a_tiempo" if x.when <= deadline else "tarde"
                resolved = x
            elif x.code in LOST_CODES:
                outcome, resolved = "perdido", x
            elif x.code == DELIVERED:
                outcome, resolved = "entregado_sin_devolver", x
            elif x.code in (OUT_FOR_DELIVERY, FAILED) and kind == "fallido":
                outcome, resolved = "salio_sin_devolver", x
            elif x.code == OUT_FOR_DELIVERY and kind == "sin_estado":
                outcome, resolved = "salio_sin_devolver", x
            if outcome:
                break
        if not outcome:
            outcome = "pendiente" if now <= deadline else "vencido"
        rows.append({
            "tracking": track.tracking, "kind": kind, "date": start.when.date().isoformat(),
            "start_time": start.when.isoformat(sep=" "), "driver": start.by, "station": start.location,
            "issue": _issue(start.text) if kind == "fallido" else "Sin entrega ni fallo al cerrar el día",
            "deadline": deadline.isoformat(sep=" "), "outcome": outcome,
            "resolved_time": resolved.when.isoformat(sep=" ") if resolved else None,
            "resolved_by": resolved.by if resolved else None,
            "hours": round((resolved.when - start.when).total_seconds() / 3600, 1) if resolved else None,
        })
    return rows


def _issue(text: str) -> str:
    """'**Delivery failed, type : Bad Address, description : -.' -> 'Bad Address'."""
    m = re.search(r"type\s*:\s*([^,]+)", text or "", re.I)
    return m.group(1).strip() if m else (text or "").strip("* ")[:80]


# ---------------------------------------------------------------- 3. Perdidos
def lost_checks(track: Track) -> List[Dict]:
    rows = []
    for e in track.events:
        if e.code not in LOST_CODES:
            continue
        holder = _holder_before(track, e.when)
        outs = [x for x in track.events if x.code == OUT_FOR_DELIVERY and x.when <= e.when]
        fails = [x for x in track.events if x.code == FAILED and x.when <= e.when]
        rows.append({
            "tracking": track.tracking, "date": e.when.date().isoformat(), "lost_time": e.when.isoformat(sep=" "),
            # La ruta (DSP) del último que lo sacó a reparto; la pérdida la marca el centro (ej. "DFW01")
            "code": e.code, "label": LOST_CODES[e.code], "station": outs[-1].location if outs else e.location,
            "last_scan_by": holder.by if holder else None,
            "last_scan_code": holder.code if holder else None,
            "last_scan_time": holder.when.isoformat(sep=" ") if holder else None,
            "last_out_by": outs[-1].by if outs else None,
            "last_fail_time": fails[-1].when.isoformat(sep=" ") if fails else None,
        })
    return rows


def is_settled(track: Track, now: datetime, keep_days: int = 10) -> bool:
    """True si ya no hace falta volver a pedir el historial: entregado, perdido/robado, o muy viejo."""
    if not track.events:
        return False
    last = track.events[-1]
    if last.code == DELIVERED or last.code in ("300", "301"):
        return True
    return (now - last.when) > timedelta(days=keep_days)


def analyze(tracks: Iterable[Track], days: Iterable[date], now: datetime, deadline_days: int = 1, deadline_hour: int = 13,
            stations: Optional[Iterable[str]] = None) -> Dict[str, List[Dict]]:
    """
    `stations`: solo las rutas de estas estaciones (las nuestras, ej. DFW02-BAA). El historial de un paquete trae
    también los intentos de otros DSP (caso real 15/10: DFW02-MEL, DFW02-WJL) y no son nuestros conductores.
    """
    days = sorted(set(days))
    ours = {s.upper() for s in stations} if stations else None
    keep = (lambda row: (row.get("station") or "").upper() in ours) if ours else (lambda row: True)
    scans, returns, lost = [], [], []
    for t in tracks:
        for d in days:
            scans += [r for r in scan_checks(t, d) if keep(r)]
        returns += [r for r in return_checks(t, now, deadline_days, deadline_hour) if keep(r)]
        lost += [r for r in lost_checks(t) if keep(r)]
    return {"scans": scans, "returns": returns, "lost": lost}
