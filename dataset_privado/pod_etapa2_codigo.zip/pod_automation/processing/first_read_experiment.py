"""Experimento aislado: regiones OCR reutilizables, vista ampliada, orden y cache por bytes."""
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import re
import time
from unittest.mock import patch

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageOps

import config
from processing import ocr_address
from processing.ocr_address import PhotoOCR
from processing.retry_experiment import read_local
from processing.vision_llm import PROMPT, VisionResult

DETAIL_PROMPT = ('This image shows ONE delivery photo: the left panel is the original, and the right panels '
                 'are enlarged details of that SAME photo, not different deliveries. Read each physical '
                 'plaque only once. Ignore the panel captions. ' + PROMPT)


class ByteCache:
    def __init__(self, folder):
        self.folder = Path(folder)
        self.folder.mkdir(parents=True, exist_ok=True)
        self.hits = 0
        self.misses = 0

    def key(self, path, kind, options):
        digest = hashlib.sha256(Path(path).read_bytes()).hexdigest()
        code = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        return hashlib.sha256(json.dumps([digest, kind, options, code], sort_keys=True).encode()).hexdigest()

    def get(self, key):
        file = self.folder / (key + '.json')
        try:
            if time.time() - file.stat().st_mtime > 7 * 86400:
                raise ValueError('expired')
            value = json.loads(file.read_text(encoding='utf-8'))
            self.hits += 1
            return value
        except (OSError, ValueError):
            self.misses += 1
            return None

    def put(self, key, value):
        target = self.folder / (key + '.json')
        temporary = target.with_suffix('.tmp')
        temporary.write_text(json.dumps(value, ensure_ascii=False), encoding='utf-8')
        temporary.replace(target)


def capture_ocr(path, cache):
    """Captura las cajas de la MISMA llamada que produce el OCR; no pide otro detector."""
    options = {'engine': config.OCR_ENGINE, 'confidence': config.OCR_MIN_CONFIDENCE,
               'max_side': config.OCR_MAX_SIDE,
               'ocr_code': hashlib.sha256(Path(ocr_address.__file__).read_bytes()).hexdigest()}
    key = cache.key(path, 'ocr_regions', options)
    saved = cache.get(key)
    if saved is not None:
        saved['reading']['path'] = str(path)
        return saved, True
    captured = {'regions': [], 'detector_calls': 0}
    original = ocr_address._readtext

    def recording(photo_path, max_side):
        detections, height = original(photo_path, max_side)
        captured['regions'] = [{'box': box, 'text': text, 'confidence': float(conf)} for box, text, conf in detections]
        captured['height'] = height
        captured['width'] = ocr_address._LAST_PADDLE_WIDTH.get('w', 0)
        captured['detector_calls'] += 1
        return detections, height

    with patch.object(ocr_address, '_readtext', recording):
        reading = ocr_address.ocr_photo.__wrapped__(path)
    with Image.open(path) as source:
        image = ImageOps.exif_transpose(source).convert('L')
        image.thumbnail((640, 640))
        captured['sharpness'] = float(cv2.Laplacian(np.array(image), cv2.CV_64F).var())
    captured['reading'] = asdict(reading)
    if not reading.error:
        cache.put(key, captured)
    return captured, False


def numeric_regions(record):
    zones = []
    for region in record.get('regions', []):
        text = re.sub(r'\s', '', region['text'])
        if not re.fullmatch(r'\d{1,6}[A-Za-z]?', text):
            continue
        xs = [p[0] for p in region['box']]
        ys = [p[1] for p in region['box']]
        zones.append({'rect': [min(xs), min(ys), max(xs), max(ys)],
                      'text': text, 'confidence': region['confidence']})
    # Incluir columnas de digitos verticales en un solo detalle con contexto.
    singles = [z for z in zones if len(z['text']) == 1]
    for zone in singles:
        x0, y0, x1, y1 = zone['rect']
        height = max(1, y1-y0)
        aligned = [z for z in singles if abs((z['rect'][0]+z['rect'][2]-x0-x1)/2) < 2*height
                   and abs((z['rect'][1]+z['rect'][3]-y0-y1)/2) < 10*height]
        if len(aligned) > 1:
            aligned.sort(key=lambda z: z['rect'][1])
            zones.append({'rect': [min(z['rect'][0] for z in aligned), min(z['rect'][1] for z in aligned),
                                   max(z['rect'][2] for z in aligned), max(z['rect'][3] for z in aligned)],
                          'text': ''.join(z['text'] for z in aligned),
                          'confidence': min(z['confidence'] for z in aligned)})
    zones.sort(key=lambda z: (-min(6, len(z['text'])), -z['confidence']))
    unique = []
    for zone in zones:
        if zone['rect'] not in [z['rect'] for z in unique]:
            unique.append(zone)
    return unique[:2]


def build_detail(path, record):
    """Misma imagen de 1024 px de lado maximo que admite la consulta habitual."""
    if record['reading']['is_label']:
        return None
    zones = numeric_regions(record)
    if not zones or not record.get('width') or not record.get('height'):
        return None
    with Image.open(path) as source:
        original = ImageOps.exif_transpose(source).convert('RGB')
    canvas = Image.new('RGB', (1024, 1024), '#eeeeee')
    full = ImageOps.contain(original, (660, 986))
    canvas.paste(full, ((660-full.width)//2, 30+(986-full.height)//2))
    draw = ImageDraw.Draw(canvas)
    draw.text((10, 8), 'Overview', fill='black')
    sx, sy = original.width/record['width'], original.height/record['height']
    for index, zone in enumerate(zones):
        x0, y0, x1, y1 = zone['rect']
        height = max(1, y1-y0)
        width = max(1, x1-x0)
        rect = (max(0, int((x0-max(height, width*.4))*sx)), max(0, int((y0-height*1.5)*sy)),
                min(original.width, int((x1+max(height, width*.4))*sx)), min(original.height, int((y1+height*1.5)*sy)))
        if rect[2] <= rect[0] or rect[3] <= rect[1]:
            continue
        crop = ImageOps.autocontrast(original.crop(rect))
        crop = ImageOps.contain(crop, (348, 464))
        top = index*512
        canvas.paste(crop, (668+(348-crop.width)//2, top+30+(470-crop.height)//2))
        draw.text((674, top+8), 'Detail', fill='black')
    return canvas


def rank_photos(records):
    """No usa direccion esperada, marca humana ni resultado de vision."""
    return sorted((i for i, r in enumerate(records) if not r['reading']['is_label'] and not r['reading']['error']),
                  key=lambda i: (not bool(numeric_regions(records[i])),
                                 -min(records[i].get('sharpness', 0), 1000), i))


def vision_read(path, record, variant, cache, preview=None, reader=None):
    prompt = DETAIL_PROMPT if variant == 'detail' and numeric_regions(record) else PROMPT
    options = {'model': config.VISION_MODEL, 'endpoint': config.OLLAMA_URL, 'prompt': prompt,
               'max_side': config.VISION_MAX_SIDE, 'context': config.VISION_NUM_CTX, 'tokens': 100,
               'variant': variant}
    key = cache.key(path, 'vision', options)
    saved = cache.get(key)
    if saved is not None:
        saved['path'] = str(path)
        return _cached_result(saved)
    start = time.perf_counter()
    image = build_detail(path, record) if variant == 'detail' else None
    if preview is not None and image is not None:
        image.save(preview)
    result = (reader or read_local)(path, timeout=12, image=image, prompt=prompt)
    seconds = time.perf_counter()-start
    if not result.error:
        payload = asdict(result)
        payload['_used_detail'] = image is not None
        cache.put(key, payload)
    return result, {'cache_hit': False, 'seconds': round(seconds, 4), 'used_detail': image is not None}


def _cached_result(saved):
    saved = dict(saved)
    detail = saved.pop('_used_detail', False)
    return VisionResult(**saved), {'cache_hit': True, 'seconds': 0, 'used_detail': detail}
