"""Una sola consumidora conserva el orden de puntuación sin bloquear Playwright."""
from concurrent.futures import Future
import queue
import threading


class AnalysisQueue:
    def __init__(self, pipeline, capacity=8):
        self.pipeline = pipeline
        self.queue = queue.Queue(maxsize=capacity)
        self.error = None
        self.inflight = set()
        self.lock = threading.Lock()
        original = pipeline.on_scored

        def scored(pod):
            original(pod)
            with self.lock:
                self.inflight.discard(pod.tracking_number)

        pipeline.on_scored = scored
        self.thread = threading.Thread(target=self._run, name='ordered-analysis', daemon=True)
        self.thread.start()

    def _put(self, item):
        while True:
            if self.error:
                raise RuntimeError('La cola de analisis se detuvo') from self.error
            try:
                self.queue.put(item, timeout=.1)
                return
            except queue.Full:
                pass

    def submit(self, pod):
        with self.lock:
            if pod.tracking_number in self.inflight:
                return
            self.inflight.add(pod.tracking_number)
        self._put(pod)

    def _run(self):
        try:
            while True:
                try:
                    item = self.queue.get(timeout=.1)
                except queue.Empty:
                    self.pipeline.collect(block=False)
                    continue
                if item is None:
                    self.pipeline.close()
                    return
                if isinstance(item, Future):
                    self.pipeline.drain()
                    item.set_result(None)
                else:
                    self.pipeline.submit(item)
        except BaseException as error:
            self.error = error

    def drain(self):
        barrier = Future()
        self._put(barrier)
        while not barrier.done():
            if self.error:
                raise RuntimeError('No se pudo completar el analisis pendiente') from self.error
            self.thread.join(timeout=.1)
        barrier.result()

    def close(self):
        try:
            self.drain()
            self._put(None)
            self.thread.join()
        finally:
            if self.error:
                self.pipeline.executor.shutdown(wait=True)
        if self.error:
            raise RuntimeError('La cola de analisis fallo') from self.error
