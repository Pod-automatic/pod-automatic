"""
Segunda opinión con un modelo de visión LOCAL (Ollama) para las fotos donde el OCR no leyó el número.

- Todo corre en la PC: las fotos no salen del equipo.
- Al modelo NO se le pasa la dirección esperada (evita que "confirme" lo que se le sugiere):
  solo transcribe los números que ve y clasifica la foto. La comparación la hace el código.
- Lee números verticales (dígitos apilados), chicos o decorativos, que el OCR no lee.
"""

import base64
import io
import json
import logging
import re
import socket
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import List, Optional

from PIL import Image, ImageOps

import config
from storage.analysis_cache import track_read_failures

logger = logging.getLogger("PODAutomation.VisionLLM")

PHOTO_TYPES = ("door", "building", "label", "locker", "package_room", "other")

PROMPT = (
    "You are checking a delivery photo. List every house number, apartment/unit number or building "
    "number that is VISIBLE in the photo: on plaques, doors, walls, curbs, mailboxes or signs. "
    "Numbers can be written vertically (digits stacked from top to bottom): read them top to bottom "
    "as one number. Do not guess and do not invent numbers: if you cannot read a number clearly, "
    "leave it out. Ignore numbers printed on shipping labels, phone numbers, prices and dates. "
    "Also classify the photo as one of: door, building, label, locker, package_room, other. "
    'Answer only JSON: {"numbers": ["..."], "photo_type": "..."}'
)


@dataclass
class VisionResult:
    path: str
    numbers: List[str] = field(default_factory=list)
    photo_type: str = "other"
    error: str = ""
    raw: str = ""


def _image_b64(path: str, max_side: int, angle: int = 0) -> str:
    with Image.open(path) as im:
        im = ImageOps.exif_transpose(im).convert("RGB")
        if angle:
            im = im.rotate(angle, expand=True, fillcolor=(0, 0, 0))
        im.thumbnail((max_side, max_side))
        buf = io.BytesIO()
        im.save(buf, format="JPEG", quality=90)
    return base64.b64encode(buf.getvalue()).decode("ascii")


# Contadores del albarán en curso (los reinicia el pipeline): para medir dónde se va el tiempo
STATS = {"llamadas_vision": 0, "segundos_vision": 0.0, "sin_gramatica": 0, "recargas": 0, "escalaciones": 0,
         "fallos_servicio": 0, "otra_gpu": 0}

# 30/10: la última consulta de este proceso terminó en error HTTP de Ollama (falla del servicio, no respuesta del modelo)
_SERVICE = {"fallo": False}
# 30/10: fallas recientes de la gramática JSON (monotonic) y hasta cuándo se pregunta primero sin ella (VISION_GRAMMAR_ADAPTIVE)
_GRAMMAR = {"fallos": [], "sin_hasta": 0.0}


def reset_stats() -> None:
    for k in STATS:
        STATS[k] = 0


class VisionCapped(RuntimeError):
    """Se llegó al tope de consultas del albarán (VISION_MAX_CALLS_PER_POD)."""


# El tope solo rige mientras ocr_photos lo activa (lectura y confirmación del número de un albarán)
_CAP = {"activo": False, "alcanzado": False, "desde": 0.0}


def start_capped() -> None:
    _CAP["activo"] = bool(config.VISION_MAX_CALLS_PER_POD or config.VISION_POD_BUDGET_S)
    _CAP["alcanzado"], _CAP["desde"] = False, time.perf_counter()


def stop_capped() -> bool:
    """Apaga el tope y devuelve si se alcanzó."""
    reached = _CAP["alcanzado"]
    _CAP["activo"], _CAP["alcanzado"] = False, False
    return reached


# 29/10: límite de tiempo de una etapa posterior (entrega en mano, sala de paquetes): ninguna consulta pasa del tiempo que queda
_DEADLINE = {"t": 0.0}


def set_deadline(seconds: float) -> None:
    _DEADLINE["t"] = time.perf_counter() + seconds if seconds else 0.0


def clear_deadline() -> None:
    _DEADLINE["t"] = 0.0


_RECENT: List[float] = []   # Segundos de las últimas consultas (vigilante de Ollama)


def _watch_speed(seconds: float, model: str) -> None:
    _RECENT.append(seconds)
    del _RECENT[:-config.VISION_SLOW_WINDOW]
    if len(_RECENT) >= config.VISION_SLOW_WINDOW:
        median = sorted(_RECENT)[len(_RECENT) // 2]
        if median > config.VISION_SLOW_MEDIAN_S:
            logger.warning(f"Ollama está lento (mediana {median:.0f} s en las últimas {len(_RECENT)} consultas): "
                           f"se descarga y recarga el modelo")
            _RECENT.clear()
            _unload_model(model)


def _generate(body: dict, timeout: float) -> str:
    ka = config.VISION_KEEP_ALIVE
    body = dict(body, keep_alive=int(ka) if ka.lstrip("-").isdigit() else ka)
    body["options"] = dict(body.get("options") or {}, num_ctx=config.VISION_NUM_CTX)
    # 20/10: preguntas cortas que EVITAN un Alta (dónde está escrito un número) no se cortan por el tope: con las
    # 5 consultas gastadas en leer, el "259" escrito a mano en la etiqueta quedaba como "dos puertas" (Alta).
    capped = _CAP["activo"] and not body.pop("_sin_tope", False)
    if capped and config.VISION_MAX_CALLS_PER_POD and STATS["llamadas_vision"] >= config.VISION_MAX_CALLS_PER_POD:
        _CAP["alcanzado"] = True
        raise VisionCapped(f"tope de {config.VISION_MAX_CALLS_PER_POD} consultas al modelo en este albarán")
    if (capped and config.VISION_POD_BUDGET_S
            and time.perf_counter() - _CAP["desde"] > config.VISION_POD_BUDGET_S):
        _CAP["alcanzado"] = True
        raise VisionCapped(f"tope de {config.VISION_POD_BUDGET_S:.0f} s de consultas al modelo en este albarán")
    # 29/10: una consulta ya iniciada no pasa del tiempo que le queda al albarán (mínimo VISION_MIN_CALL_S): en 21 errores
    # reales 5 consultas de 20-34 s sumaron el 37 % del tiempo de visión. Al cortarse queda en revisión manual, como el tope.
    left = None
    if capped and config.VISION_POD_BUDGET_S:
        left = config.VISION_POD_BUDGET_S - (time.perf_counter() - _CAP["desde"])
    if _DEADLINE["t"]:
        stage_left = _DEADLINE["t"] - time.perf_counter()
        if stage_left <= 0:
            raise VisionCapped("tope de tiempo de esta etapa")
        left = stage_left if left is None else min(left, stage_left)
    wait = timeout   # La espera de un hueco en la cola de GPU conserva el valor original: solo se acota la consulta en sí
    if left is not None and left < timeout:
        timeout = max(config.VISION_MIN_CALL_S, left)
        body["_recortado"] = True   # Un corte por tope no cuenta como "Ollama no responde" (no recarga el modelo)
    STATS["llamadas_vision"] += 1
    started = time.perf_counter()
    _SERVICE["fallo"] = False
    try:
        return _post_generate(body, timeout) if wait == timeout else _post_generate(body, timeout, wait)
    finally:
        elapsed = time.perf_counter() - started
        STATS["segundos_vision"] += elapsed
        if config.VISION_FAILOVER and _SERVICE["fallo"]:
            # 30/10: el modelo no llegó a mirar la foto: no gasta el tope de consultas del albarán (el de tiempo sí rige)
            STATS["llamadas_vision"] -= 1
            STATS["fallos_servicio"] += 1
        try:
            _watch_speed(elapsed, body.get("model") or config.VISION_MODEL)
        except Exception as e:   # El vigilante nunca frena la consulta
            logger.debug(f"Vigilante de Ollama: {e}")


def _post_generate(body: dict, timeout: float, wait: float = None) -> str:
    if config.GPU_DISPATCH_DB:
        from automation.gpu_dispatch import gpu_slot
        requested=body.get('_url')
        urls=[requested] if requested else config.OLLAMA_URLS
        with gpu_slot(config.GPU_DISPATCH_DB,urls,wait or timeout,config.GPU_SLOTS_PER_URL) as selected:
            out=_post_generate_at(body,timeout,selected)
        others=[u for u in urls if u!=selected]
        if config.VISION_FAILOVER and _SERVICE["fallo"] and others:
            # 30/10: Ollama cortó la consulta con error HTTP en esa GPU: se repite una vez en la otra
            STATS["otra_gpu"]+=1
            with gpu_slot(config.GPU_DISPATCH_DB,others,wait or timeout,config.GPU_SLOTS_PER_URL) as selected:
                out=_post_generate_at(body,timeout,selected)
        return out
    return _post_generate_at(body,timeout)


def _post_generate_at(body: dict, timeout: float, selected: str = None) -> str:
    body = dict(body)
    url_propia = body.pop("_url", None)   # Servicio de otro modelo (cascada)
    recortado = body.pop("_recortado", False)
    base = selected or url_propia or config.pick_for_worker(config.OLLAMA_URLS)
    _SERVICE["fallo"] = False
    req = urllib.request.Request(
        base.rstrip("/") + "/api/generate",
        data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            out = json.loads(resp.read().decode("utf-8")).get("response", "")
        _TIMEOUTS["seguidos"] = 0
        return out
    except urllib.error.HTTPError as e:  # 500 "token repeat limit reached": runner degradado
        # 30/10: con el motivo que da Ollama (antes solo el código: no se podía saber la causa de los 500 en Kaggle)
        try:
            detail = e.read().decode("utf-8", "replace").strip()[:200]
        except Exception:
            detail = ""
        logger.warning(f"Ollama devolvió HTTP {e.code}" + (f" en {base}: {detail}" if detail else f" en {base}"))
        _SERVICE["fallo"] = True
        return ""
    except (TimeoutError, socket.timeout, urllib.error.URLError) as e:
        if isinstance(e, urllib.error.URLError) and not isinstance(e.reason, (TimeoutError, socket.timeout)):
            raise
        # 06/10: con la GPU casi llena el runner se trababa al codificar la imagen ("encoding mtmd batch") y TODAS las
        # consultas se cortaban a los 60 s con la GPU al 0 % (la corrida iba a 140 albaranes/hora). Descargar el modelo
        # lo arregla: la siguiente consulta lo vuelve a cargar (3 s por consulta).
        if recortado:
            raise
        _TIMEOUTS["seguidos"] += 1
        if _TIMEOUTS["seguidos"] >= config.VISION_TIMEOUTS_BEFORE_RELOAD:
            _TIMEOUTS["seguidos"] = 0
            logger.warning(f"Ollama no responde ({config.VISION_TIMEOUTS_BEFORE_RELOAD} consultas seguidas cortadas): "
                           f"se recarga el modelo")
            _unload_model(body["model"], *([base] if url_propia else []))
        raise


_TIMEOUTS = {"seguidos": 0}


@track_read_failures
def _ask_json(body: dict, timeout: float, attempts: int = None) -> tuple:
    """
    Pide JSON al modelo y devuelve (dict o None, texto crudo).

    02/10: la mayoría de las "respuestas vacías" eran un fallo de la gramática JSON de Ollama
    ("Unexpected empty grammar stack after accepting piece: @"). Con temperatura 0 el fallo se repite
    igual en cada intento, así que recargar el modelo no servía y costaba ~10-50 s. Ahora el segundo
    intento va SIN "format": "json" (texto libre, se rescata el JSON del texto) y solo si eso también
    falla se recarga el modelo para el intento siguiente.
    """
    attempts = attempts or config.VISION_ATTEMPTS
    text = ""
    # 30/10: con la gramática pausada (fallaba seguido) el primer intento va sin ella y el segundo con ella
    skip = config.VISION_GRAMMAR_ADAPTIVE and "format" in body and time.monotonic() < _GRAMMAR["sin_hasta"]
    grammar_failed = False
    for attempt in range(max(attempts, 2)):
        b = dict(body)
        grammar = attempt == 1 if skip else attempt == 0
        if not grammar:
            b.pop("format", None)
            if attempt >= 1:
                STATS["sin_gramatica"] += 1
        text = _generate(b, timeout)
        data = _parse_json_lenient(text)
        if data is not None:
            if grammar_failed and not grammar:
                _grammar_failed()
            return data, text
        # Vacío CON gramática y sin falla del servicio: la gramática es la sospechosa
        grammar_failed = grammar_failed or (grammar and "format" in body and not _SERVICE["fallo"])
        if attempt == 1:
            # Sin gramática también vacío: el runner quedó degradado de verdad (responde vacío a TODO)
            _unload_model(body["model"], *([body["_url"]] if body.get("_url") else []))
            if not config.GPU_DISPATCH_DB:   # 30/10: con el servicio compartido no se recarga: esperar no arregla nada
                time.sleep(1.5)
    return None, text


@track_read_failures
def read_photo(path: str, model: str = None, timeout: float = None, angle: int = 0, url: str = None) -> VisionResult:
    model = model or config.VISION_MODEL
    timeout = timeout or config.VISION_TIMEOUT_S
    out = VisionResult(path=str(path))
    body = {
        "model": model,
        "prompt": PROMPT,
        "images": [_image_b64(path, config.VISION_MAX_SIDE, angle)],
        "format": "json",
        "stream": False,
        "options": {"temperature": 0, "num_predict": config.VISION_NUM_PREDICT},
    }
    if url:
        body["_url"] = url
    try:
        data, text = _ask_json(body, timeout)
        out.raw = text
        if data is None:
            raise ValueError(f"respuesta no JSON: {text[:80]!r}")
        nums = []
        for n in data.get("numbers") or []:
            d = re.sub(r"[^0-9A-Za-z\-]", "", str(n))
            if re.search(r"\d", d):
                nums.append(d)
        out.numbers = nums
        pt = str(data.get("photo_type") or "other").lower().strip()
        out.photo_type = pt if pt in PHOTO_TYPES else "other"
    except Exception as e:
        out.error = f"{type(e).__name__}: {e}"
    return out


def _grammar_failed() -> None:
    """La gramática dejó vacía una respuesta que sin ella salió bien. Tras varias seguidas se pausa un rato."""
    if not config.VISION_GRAMMAR_ADAPTIVE:
        return
    now = time.monotonic()
    fails = [t for t in _GRAMMAR["fallos"] if now - t < config.VISION_GRAMMAR_WINDOW_S] + [now]
    _GRAMMAR["fallos"] = fails
    if len(fails) >= config.VISION_GRAMMAR_FAILS and now >= _GRAMMAR["sin_hasta"]:
        _GRAMMAR["sin_hasta"] = now + config.VISION_GRAMMAR_PAUSE_S
        _GRAMMAR["fallos"] = []
        logger.info(f"Gramática JSON de Ollama: {len(fails)} respuestas vacías en {config.VISION_GRAMMAR_WINDOW_S:.0f} s; "
                    f"se pregunta primero sin ella durante {config.VISION_GRAMMAR_PAUSE_S:.0f} s")


def _unload_model(model: str, url: str = None) -> None:
    if config.GPU_DISPATCH_DB:
        # 30/10: como mucho uno cada 5 min (en Kaggle llenaba los «últimos eventos» y tapaba la causa)
        from automation.session_guard import log_throttled
        log_throttled('vision-unload-shared', 'Servicio compartido: se omite recarga global desde un worker de analisis.',
                      every_s=300)
        return
    """keep_alive=0 descarga el modelo; la próxima llamada levanta un runner nuevo."""
    STATS["recargas"] += 1
    req = urllib.request.Request(
        (url or config.pick_for_worker(config.OLLAMA_URLS)).rstrip("/") + "/api/generate",
        data=json.dumps({"model": model, "keep_alive": 0}).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            resp.read()
        logger.warning(f"Modelo de visión {model} recargado tras respuesta vacía de Ollama")
    except Exception as e:
        logger.warning(f"No se pudo descargar el modelo {model}: {e}")


def _parse_json_lenient(text: str) -> Optional[dict]:
    """JSON del modelo; si viene cortado, rescata al menos la lista de números y el tipo de foto."""
    try:
        data = json.loads(text)
        if isinstance(data, dict):
            return data
    except (ValueError, TypeError):
        pass
    # Sin gramática el modelo puede envolver el JSON en texto o en ```json ... ```
    for blob in re.findall(r"\{[^{}]*\}", text or ""):
        try:
            data = json.loads(blob)
            if isinstance(data, dict):
                return data
        except ValueError:
            continue
    m = re.search(r'"numbers"\s*:\s*\[([^\]]*)\]', text or "")
    if not m:
        return None
    t = re.search(r'"photo_type"\s*:\s*"(\w+)"', text)
    return {
        "numbers": re.findall(r'"([^"]+)"', m.group(1)),
        "photo_type": t.group(1) if t else "other",
    }


HANDOFF_PROMPT = (
    "Look at this delivery photo. Is a PERSON holding, carrying or receiving the package in their hands "
    "(a hand-to-hand delivery)? A package lying on the ground, porch, doormat or in a locker is NOT. "
    'Answer only JSON: {"person_receiving": true or false}'
)


HANDOFF_CONFIRM_PROMPT = (
    "Delivery photo check. Answer true ONLY if you can clearly see a customer (a person other than the photographer) "
    "receiving or holding the package in their hands. A hand of the photographer holding a label, a package on the "
    "floor, a door, a wall or a building is false. Decorations, scarecrows, statues, mannequins, posters or people "
    "seen through a car window are NOT a customer: false. "
    'Answer only JSON: {"customer_has_package": true or false}'
)


RECEPTION_PROMPT = (
    "Delivery photo check. Is the package being delivered at a RECEPTION or SERVICE COUNTER: the package is on a "
    "counter or desk of a front office, leasing office, hotel front desk, shop or mail store, and a staff person is "
    "behind that counter (even in the background)? A package on the floor at a house or apartment door is false. "
    "A package on a porch, doormat or in a locker is false. "
    'Answer only JSON: {"reception_counter": true or false}'
)


def reception_desk_confirmed(path: str) -> bool:
    """
    Entrega en el mostrador de una recepción/oficina/tienda con una persona atendiendo (04/10; casos reales 03/10:
    recepción de 6350 Winter Park Dr, tienda de correo con PMB, oficina Suite 100). Se pregunta dos veces (foto derecha
    y girada 90° si está de lado) y basta con un sí claro en la foto derecha o en la girada.
    """
    try:
        for angle in (0, 90):
            body = {"model": config.VISION_MODEL, "prompt": RECEPTION_PROMPT, "format": "json", "stream": False,
                    "images": [_image_b64(path, config.VISION_MAX_SIDE, angle)],
                    "options": {"temperature": 0, "num_predict": 40}}
            data, _ = _ask_json(body, config.VISION_TIMEOUT_S)
            if data and data.get("reception_counter") is True:
                return True
        return False
    except Exception as e:
        logger.warning(f"Modelo de visión no disponible (recepción) para {path}: {e}")
        return False


PACKAGE_ROOM_PROMPT = (
    "Is this photo taken INSIDE a package room or mail room of a building: shelves or racks holding MANY packages "
    "of different people? A single package at a house door, porch, garage or doormat is NOT. "
    'Answer only JSON: {"package_room": true or false}'
)


SCREENSHOT_ADDRESS_PROMPT = (
    'This is a phone screenshot of a navigation or delivery app. Read the full street address written below '
    '"Llegaste a" (or "You have arrived", or the destination). Answer only JSON: {"address": "..."}'
)


def screenshot_address(path: str) -> str:
    """Dirección que el modelo lee en una captura de mapa ("" si no responde). Solo sirve para CONFIRMAR (06/10)."""
    try:
        body = {"model": config.VISION_MODEL, "prompt": SCREENSHOT_ADDRESS_PROMPT, "format": "json", "stream": False,
                "images": [_image_b64(path, config.VISION_MAX_SIDE)], "options": {"temperature": 0, "num_predict": 80}}
        data, _ = _ask_json(body, config.VISION_TIMEOUT_S)
        return str((data or {}).get("address") or "")
    except Exception as e:
        logger.warning(f"Modelo de visión no disponible (dirección de la captura) para {path}: {e}")
        return ""


NUMBER_LOCATION_PROMPT = (
    'In this photo, where is the number "{n}" written? Choose one: "door" (on a door or door frame), '
    '"wall" (plaque or sign on a house or building wall), "mailbox", "curb", "package" (handwritten or printed on a '
    'cardboard box, envelope or parcel), "label" (shipping label), "bin" (trash or recycling cart), "vehicle" (car, '
    'truck or license plate), "other". Answer only JSON: {{"where": "..."}}'
)
# 30/10: "bin" y "vehicle" agregados (4899 en el buzón y "7274" en el contenedor de basura, GFUS01080165625218)


def number_location(path: str, number: str) -> str:
    """Dónde está escrito un número en la foto (door/wall/mailbox/curb/package/label/other); "" si no responde."""
    try:
        body = {"model": config.VISION_MODEL, "prompt": NUMBER_LOCATION_PROMPT.format(n=number), "format": "json",
                "stream": False, "images": [_image_b64(path, config.VISION_MAX_SIDE)],
                "options": {"temperature": 0, "num_predict": 30}, "_sin_tope": True}
        data, _ = _ask_json(body, config.VISION_TIMEOUT_S)
        return str((data or {}).get("where") or "").lower().strip()
    except Exception as e:
        logger.warning(f"Modelo de visión no disponible (ubicación del número) para {path}: {e}")
        return ""


PACKAGE_ROOM_SHELVES_PROMPT = (
    'Count the packages and parcels visible in this photo. Are there SHELVES or RACKS holding them? '
    'Answer only JSON: {"packages": number, "shelves": true or false}'
)


def package_room_confirmed(path: str) -> bool:
    """
    06/10: sala de paquetes reconocida por la escena (estantes con muchos paquetes) cuando no hay palabras que la
    nombren (caso 3549 Medical Center Dr: estantes y un cartel de papel "BUILDING 3"). Probado con 3 salas/casilleros
    (sí) y 4 puertas con paquetes en el piso (no), dos veces cada una.
    """
    try:
        body = {"model": config.VISION_MODEL, "prompt": PACKAGE_ROOM_PROMPT, "format": "json", "stream": False,
                "images": [_image_b64(path, config.VISION_MAX_SIDE)], "options": {"temperature": 0, "num_predict": 30}}
        data, _ = _ask_json(body, config.VISION_TIMEOUT_S)
        if not (data and data.get("package_room")):
            return False
        # Segunda pregunta: la primera sola dijo "sala" ante el portón de un campo (2375 Rock Ridge Rd, error real que
        # quedaba escondido). Con estantes/racks, sí; portones, patios y puertas dicen "shelves: false"
        body = dict(body, prompt=PACKAGE_ROOM_SHELVES_PROMPT, options={"temperature": 0, "num_predict": 40})
        data, _ = _ask_json(body, config.VISION_TIMEOUT_S)
        return bool(data and data.get("shelves"))
    except Exception as e:
        logger.warning(f"Modelo de visión no disponible (sala de paquetes) para {path}: {e}")
        return False


def person_receiving_confirmed(path: str) -> bool:
    """Dos preguntas distintas tienen que decir que sí (el modelo de 3B decía "persona" con demasiada facilidad)."""
    if not person_receiving(path):
        return False
    try:
        body = {"model": config.VISION_MODEL, "prompt": HANDOFF_CONFIRM_PROMPT, "format": "json", "stream": False,
                "images": [_image_b64(path, config.VISION_MAX_SIDE)], "options": {"temperature": 0, "num_predict": 40}}
        data, _ = _ask_json(body, config.VISION_TIMEOUT_S)
        return bool(data and data.get("customer_has_package"))
    except Exception as e:
        logger.warning(f"Modelo de visión no disponible (confirmación de entrega en mano) para {path}: {e}")
        return False


def person_receiving(path: str, timeout: float = None) -> Optional[bool]:
    """
    True si una persona sostiene/recibe el paquete (entrega en mano). None si el modelo no respondió.
    Si la respuesta viene vacía, reintenta sin gramática JSON y, si hace falta, recargando el modelo
    (caso real 01/10: 6631 Jannie St).
    """
    try:
        body = {"model": config.VISION_MODEL, "prompt": HANDOFF_PROMPT, "format": "json", "stream": False,
                "images": [_image_b64(path, config.VISION_MAX_SIDE)], "options": {"temperature": 0, "num_predict": 40}}
        data, _ = _ask_json(body, timeout or config.VISION_TIMEOUT_S, attempts=3)
        return bool(data.get("person_receiving")) if data is not None else None
    except Exception as e:
        logger.warning(f"Modelo de visión no disponible (entrega en mano) para {path}: {e}")
        return None


def is_available() -> bool:
    try:
        with urllib.request.urlopen(config.OLLAMA_URL.rstrip("/") + "/api/tags", timeout=3) as resp:
            models = [m.get("name", "") for m in json.loads(resp.read()).get("models", [])]
        return any(m.split(":")[0] == config.VISION_MODEL.split(":")[0] for m in models)
    except Exception:
        return False
