"""
Módulo de Reglas Centralizadas y Configurables para la Fase 4 (Motor de Validación).

Diseñado con la filosofía de soporte a la decisión humana:
- NINGUNA entrega se rechaza automáticamente.
- Clasificación para triaje: VALID / LIKELY VALID, REVIEW REQUIRED, POSSIBLE ISSUE, ERROR.
- Todo resultado es revisable por un operador humano.
- Reglas desacopladas, configurables y fácilmente extensibles.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from pathlib import Path

from config import VALIDATION_RULES_CONFIG
from models.pod import (
    PODRecord,
    ValidationClassification,
    AnomalyCode,
)


@dataclass
class RuleEvaluationResult:
    """Resultado emitido por una regla individual tras ser evaluada."""
    rule_name: str
    triggered: bool
    suggested_classification: ValidationClassification = ValidationClassification.VALID
    flag: Optional[str] = None
    message: str = ""
    penalty: float = 0.0


class BaseRule:
    """Clase base para todas las reglas del motor de validación."""
    name: str = "BaseRule"

    def __init__(self, config_dict: Optional[Dict[str, Any]] = None):
        self.config = config_dict or {}
        self.enabled = self.config.get("enabled", True)

    def evaluate(self, pod: PODRecord) -> Optional[RuleEvaluationResult]:
        raise NotImplementedError


# Alias para retrocompatibilidad
PODBusinessRule = BaseRule


class MissingPhotoRule(BaseRule):
    """Regla 1: Si no existen fotografías -> REVIEW REQUIRED."""
    name = "NoPhotosRule"

    def __init__(self):
        super().__init__(VALIDATION_RULES_CONFIG.get("RULE_NO_PHOTOS", {}))

    def evaluate(self, pod: PODRecord) -> Optional[RuleEvaluationResult]:
        if not self.enabled:
            return None

        total_photos = len(pod.photo_paths) + len(pod.photo_urls) + pod.number_of_photos
        if total_photos == 0:
            penalty = self.config.get("penalty", 30.0)
            if pod.has_signature:
                msg = "Sin fotografías de entrega adjuntas, pero cuenta con firma del cliente."
            else:
                msg = "No se encontraron fotografías de comprobante ni firma adjunta."

            pod.add_anomaly(AnomalyCode.FOTO_FALTANTE, msg, penalty=penalty)
            return RuleEvaluationResult(
                rule_name=self.name,
                triggered=True,
                suggested_classification=ValidationClassification.REVIEW_REQUIRED,
                flag="NO PHOTO",
                message=msg,
                penalty=penalty,
            )
        return None


class UnreadableImageRule(BaseRule):
    """Regla 2: Si existe fotografía pero el archivo no puede analizarse -> ERROR o REVIEW REQUIRED."""
    name = "UnreadableImageRule"

    def __init__(self):
        super().__init__(VALIDATION_RULES_CONFIG.get("RULE_UNREADABLE_IMAGE", {}))

    def evaluate(self, pod: PODRecord) -> Optional[RuleEvaluationResult]:
        if not self.enabled:
            return None

        for local_file in pod.photo_paths:
            path = Path(local_file)
            # Archivo inexistente o tamaño 0 bytes
            if not path.exists() or path.stat().st_size == 0:
                penalty = self.config.get("penalty", 50.0)
                msg = f"El archivo de imagen '{path.name}' está vacío o inaccesible."
                pod.add_anomaly(AnomalyCode.FOTO_BORROSA, msg, penalty=penalty)
                return RuleEvaluationResult(
                    rule_name=self.name,
                    triggered=True,
                    suggested_classification=ValidationClassification.ERROR,
                    flag="UNREADABLE IMAGE",
                    message=msg,
                    penalty=penalty,
                )
        return None


class BasicInfoCompletenessRule(BaseRule):
    """Regla 3: Verifica si la información básica de entrega está completa."""
    name = "BasicInfoCompletenessRule"

    def __init__(self):
        super().__init__(VALIDATION_RULES_CONFIG.get("RULE_BASIC_INFO_COMPLETENESS", {}))

    def evaluate(self, pod: PODRecord) -> Optional[RuleEvaluationResult]:
        if not self.enabled:
            return None

        min_len = self.config.get("min_address_length", 6)
        issues = []
        if not pod.tracking_number or pod.tracking_number.startswith("UNKNOWN"):
            issues.append("Albarán / Tracking ausente")
        if not pod.address or len(pod.address.strip()) < min_len:
            issues.append("Dirección de entrega incompleta")

        if issues:
            penalty = self.config.get("penalty", 20.0)
            msg = " | ".join(issues)
            pod.add_anomaly(AnomalyCode.DIRECCION_INCOMPLETA, msg, penalty=penalty)
            return RuleEvaluationResult(
                rule_name=self.name,
                triggered=True,
                suggested_classification=ValidationClassification.REVIEW_REQUIRED,
                flag="INCOMPLETE INFO",
                message=msg,
                penalty=penalty,
            )
        return None


class DuplicatePhotoRule(BaseRule):
    """Regla 4: Si se detectan fotografías visualmente idénticas -> POSSIBLE DUPLICATE / POSSIBLE ISSUE."""
    name = "DuplicatePhotoRule"

    def __init__(self):
        super().__init__(VALIDATION_RULES_CONFIG.get("RULE_DUPLICATE_PHOTOS", {}))

    def evaluate(self, pod: PODRecord) -> Optional[RuleEvaluationResult]:
        if not self.enabled:
            return None

        anomaly_str = " ".join(pod.anomalies)
        if AnomalyCode.FOTO_DUPLICADA.value in anomaly_str:
            tag = self.config.get("tag", "POSSIBLE DUPLICATE")
            penalty = self.config.get("penalty", 50.0)
            pod.add_flag(tag)
            return RuleEvaluationResult(
                rule_name=self.name,
                triggered=True,
                suggested_classification=ValidationClassification.POSSIBLE_ISSUE,
                flag=tag,
                message="Posible fotografía reutilizada detectada por Perceptual Hashing o SHA-256.",
                penalty=penalty,
            )
        return None


class ImageQualityRule(BaseRule):
    """Reglas 5 y 6: Detección de imágenes extremadamente borrosas o de baja calidad."""
    name = "ImageQualityRule"

    def __init__(self):
        super().__init__(VALIDATION_RULES_CONFIG.get("RULE_BLURRY_IMAGE", {}))

    def evaluate(self, pod: PODRecord) -> Optional[RuleEvaluationResult]:
        if not self.enabled:
            return None

        for idx, metric in enumerate(pod.image_metrics, 1):
            # A. Obstrucción o encuadre plano (dedo tapando lente)
            if metric.is_blank_or_covered:
                pod.add_flag("LOW IMAGE QUALITY")
                pod.add_anomaly(
                    AnomalyCode.FOTO_UNIFORME_TAPADA,
                    f"Foto #{idx}: Lente u objetivo presuntamente obstruido.",
                    penalty=40.0,
                )
                return RuleEvaluationResult(
                    rule_name=self.name,
                    triggered=True,
                    suggested_classification=ValidationClassification.POSSIBLE_ISSUE,
                    flag="LOW IMAGE QUALITY",
                    message="Cámara u objetivo presuntamente obstruido.",
                    penalty=40.0,
                )

            # B. Imagen excesivamente borrosa
            if metric.is_blurry:
                pod.add_flag("LOW IMAGE QUALITY")
                pod.add_anomaly(
                    AnomalyCode.FOTO_BORROSA,
                    f"Foto #{idx}: Desenfoque severo (Var Laplaciano={metric.blur_score:.1f}).",
                    penalty=25.0,
                )
                return RuleEvaluationResult(
                    rule_name=self.name,
                    triggered=True,
                    suggested_classification=ValidationClassification.REVIEW_REQUIRED,
                    flag="LOW IMAGE QUALITY",
                    message=f"Foto #{idx} con desenfoque severo (Laplaciano={metric.blur_score:.1f}).",
                    penalty=25.0,
                )

            # C. Exposición extrema
            if metric.is_dark or metric.is_overexposed:
                pod.add_flag("LOW IMAGE QUALITY")
                detail = "subexpuesta / oscura" if metric.is_dark else "sobreexpuesta"
                pod.add_anomaly(
                    AnomalyCode.FOTO_MUY_OSCURA if metric.is_dark else AnomalyCode.FOTO_SOBREEXPUESTA,
                    f"Foto #{idx}: Iluminación {detail} (Brillo={metric.mean_brightness:.1f}).",
                    penalty=20.0,
                )
                return RuleEvaluationResult(
                    rule_name=self.name,
                    triggered=True,
                    suggested_classification=ValidationClassification.REVIEW_REQUIRED,
                    flag="LOW IMAGE QUALITY",
                    message=f"Foto #{idx} con iluminación {detail}.",
                    penalty=20.0,
                )

        return None


class PlatformIncidentRule(BaseRule):
    """Regla: Evalúa si la plataforma Gofo Express reportó una no conformidad."""
    name = "PlatformIncidentRule"

    def __init__(self):
        super().__init__(VALIDATION_RULES_CONFIG.get("RULE_PLATFORM_INCIDENTS", {}))

    def evaluate(self, pod: PODRecord) -> Optional[RuleEvaluationResult]:
        if not self.enabled:
            return None

        if pod.non_compliance_reason and pod.non_compliance_reason.strip():
            reason = pod.non_compliance_reason.strip()
            pod.add_anomaly(
                AnomalyCode.INCUMPLIMIENTO_PLATAFORMA,
                f"No conformidad de plataforma: '{reason}'",
                penalty=25.0,
            )
            return RuleEvaluationResult(
                rule_name=self.name,
                triggered=True,
                suggested_classification=ValidationClassification.REVIEW_REQUIRED,
                flag="PLATFORM FLAGGED",
                message=f"Plataforma reportó: {reason}",
                penalty=25.0,
            )
        return None
