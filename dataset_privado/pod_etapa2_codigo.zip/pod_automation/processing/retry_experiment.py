"""Reintento experimental y acotado. No se conecta a la corrida de produccion.

Reutiliza PhotoOCR; nunca recibe la direccion en el prompt del modelo. Un recorte
solo aporta numeros si la lectura de la foto completa los corrobora.
"""
import base64
from copy import deepcopy
import io
import json
import re
import time
import urllib.request

from PIL import Image, ImageOps

import config
from processing.vision_llm import PROMPT, VisionResult


def read_local(path, timeout, image=None, prompt=None):
    try:
        if image is None:
            with Image.open(path) as source:
                image = ImageOps.exif_transpose(source).convert('RGB')
        else:
            image = image.copy().convert('RGB')
        image.thumbnail((config.VISION_MAX_SIDE, config.VISION_MAX_SIDE))
        buffer = io.BytesIO()
        image.save(buffer, format='JPEG', quality=92)
        body = {'model': config.VISION_MODEL, 'prompt': prompt or PROMPT,
                'images': [base64.b64encode(buffer.getvalue()).decode('ascii')],
                'format': 'json', 'stream': False,
                'keep_alive': int(config.VISION_KEEP_ALIVE) if config.VISION_KEEP_ALIVE.lstrip('-').isdigit() else config.VISION_KEEP_ALIVE,
                'options': {'temperature': 0, 'num_predict': 100, 'num_ctx': config.VISION_NUM_CTX}}
        request = urllib.request.Request(config.OLLAMA_URL.rstrip('/') + '/api/generate',
                                         data=json.dumps(body).encode(),
                                         headers={'Content-Type': 'application/json'})
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = json.load(response)
        if not raw.get('done') or raw.get('done_reason') == 'length':
            raise ValueError('Respuesta incompleta del modelo')
        data = json.loads(raw['response'])
        if not isinstance(data.get('numbers'), list) or data.get('photo_type') not in (
                'door', 'building', 'label', 'locker', 'package_room', 'other'):
            raise ValueError('Respuesta sin estructura valida')
        numbers = [str(n) for n in data['numbers'] if re.fullmatch(r'\d{1,6}[A-Za-z]?', str(n))]
        return VisionResult(path=str(path), numbers=numbers, photo_type=data['photo_type'])
    except Exception as error:
        return VisionResult(path=str(path), error=f'{type(error).__name__}: {error}')


def number_crop(photo, timeout):
    """Un recorte alrededor de una zona numerica detectada, con contexto de soporte."""
    body = json.dumps({'path': str(photo.path), 'upscale': 1}).encode()
    port = config.pick_for_worker(config.PADDLE_OCR_PORTS)
    request = urllib.request.Request(f'http://127.0.0.1:{port}/ocr', data=body,
                                     headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        data = json.load(response)
    zones = [d for d in data.get('detections', []) if re.fullmatch(r'\d{1,6}', d['text'].strip())]
    if not zones:
        return None
    # Priorizar la lectura dudosa ya detectada, sin usar la direccion esperada.
    zones.sort(key=lambda d: (d['text'].strip() not in photo.numbers, -len(d['text'].strip()), -d['conf']))
    zone = zones[0]
    with Image.open(photo.path) as source:
        image = ImageOps.exif_transpose(source).convert('RGB')
    sx, sy = image.width / data['width'], image.height / data['height']
    xs = [point[0] * sx for point in zone['box']]
    ys = [point[1] * sy for point in zone['box']]
    height = max(ys) - min(ys)
    width = max(xs) - min(xs)
    crop = image.crop((max(0, int(min(xs) - max(width, 3 * height))),
                       max(0, int(min(ys) - 5 * height)),
                       min(image.width, int(max(xs) + max(width, 3 * height))),
                       min(image.height, int(max(ys) + 5 * height))))
    if min(crop.size) < 8:
        return None
    return ImageOps.autocontrast(crop.resize((crop.width * 2, crop.height * 2), Image.Resampling.LANCZOS))


def retry_photos(photos, budget=25, max_photos=2, reader=None, cropper=None):
    """Cola local: fallos primero; despues fotos con numeros dudosos. Nunca muta el original."""
    reader, cropper = reader or read_local, cropper or number_crop
    output = deepcopy(photos)
    started = time.monotonic()
    deadline = started + budget
    events = []
    order = sorted((i for i, p in enumerate(output) if not p.is_label and not p.error),
                   key=lambda i: (not bool(output[i].vision_error), not bool(output[i].numbers), i))[:max_photos]
    for index in order:
        if deadline - time.monotonic() < 2:
            break
        photo = output[index]
        event = {'foto': index + 1, 'fallo_previo': photo.vision_error, 'lectura_completa': None, 'recorte': None}
        # Solo la foto completa puede resolver un fallo de analisis previo.
        result = reader(photo.path, timeout=max(1, min(10, deadline - time.monotonic())))
        if result.error:
            event['error'] = result.error
            events.append(event)
            continue
        event['lectura_completa'] = result.numbers
        event['tipo'] = result.photo_type
        photo.vision_used = True
        if result.photo_type in ('door', 'building'):
            photo.vision_error = ''
            photo.photo_type = result.photo_type
        # La reclasificacion como etiqueta/casillero no elimina alertas en este experimento.
        if result.photo_type not in ('door', 'building'):
            events.append(event)
            continue
        full = {re.sub(r'\D', '', n) for n in result.numbers}
        corroborated = full.intersection(photo.numbers)
        if deadline - time.monotonic() > 4:
            try:
                crop = cropper(photo, timeout=min(4, deadline - time.monotonic()))
                if crop is not None and deadline - time.monotonic() > 2:
                    second = reader(photo.path, timeout=max(1, min(8, deadline - time.monotonic())), image=crop)
                    event['recorte'] = second.numbers if not second.error else second.error
                    if not second.error and second.photo_type in ('door', 'building', 'other'):
                        corroborated |= full.intersection(re.sub(r'\D', '', n) for n in second.numbers)
            except Exception as error:
                event['error_recorte'] = f'{type(error).__name__}: {error}'
        # Mantener numeros anteriores y contradicciones. No hacer que el recorte confirme por si solo.
        for number in sorted(corroborated):
            if number not in photo.numbers:
                photo.numbers.append(number)
                photo.vision_numbers.append(number)
            if number not in photo.vision_all:
                photo.vision_all.append(number)
            photo.number_conf[number] = max(photo.number_conf.get(number, 0), config.VISION_NUMBER_CONFIDENCE)
        event['corroborados'] = sorted(corroborated)
        events.append(event)
    return output, {'segundos': round(time.monotonic() - started, 2), 'eventos': events,
                    'presupuesto_s': budget, 'fallos_antes': sum(bool(p.vision_error) for p in photos),
                    'fallos_despues': sum(bool(p.vision_error) for p in output)}
