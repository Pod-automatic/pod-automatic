"""
Triaje por score de riesgo (0 = sin riesgo, 100 = riesgo alto).

Cada chequeo devuelve un CheckResult con su score, peso y explicación. El total es
    total = max(promedio_ponderado, SCORE_MAX_WEIGHT_FACTOR × score_máximo)
para que un solo chequeo muy alto no se diluya entre los que dan 0. Los chequeos con
force_report=True (reglas de negocio de "reportar siempre") llevan el total a 100.
La prioridad sale de umbrales configurables: Alta >= 60, Media >= 30, si no Baja.

Reglas de negocio (definidas por la operación):
- 3 a 5 fotos es lo normal.
- 2 o más fotos de etiqueta suman riesgo; una etiqueta de OTRO paquete es riesgo máximo.
- Fotos duplicadas suman riesgo.
- Números en la foto que no concuerdan con la dirección: riesgo máximo.
- Número de casa/unidad no visible en ninguna foto: reportar siempre.
- Edificio sin foto del edificio o de la puerta: reportar siempre, salvo entrega en
  oficina/sala/casillero de paquetería del edificio.
"""

import re
from dataclasses import dataclass, field, asdict, replace
from typing import Any, Dict, List, Optional

import config
from models.pod import PODRecord, PriorityEnum, DuplicateStatusEnum, ProcessingStatusEnum
from processing.map_screenshot import (chat_addresses, is_chat_screenshot, is_map_screenshot, is_phone_screenshot,
                                       is_place_card, screenshot_address_status)
from processing.ocr_address import (PhotoOCR, building_key, match_numbers, parse_us_address, reread_screenshot_text,
                                    same_building_key, unit_ranges)


@dataclass
class CheckResult:
    check: str
    score: float                  # 0-100
    weight: float
    explanation: str
    applicable: bool = True
    force_report: bool = False
    details: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        self.score = max(0.0, min(100.0, float(self.score)))

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def combine_scores(results: List[CheckResult], factor: float = None) -> float:
    """total = max(promedio ponderado, factor × máximo); 100 si algún chequeo fuerza reporte."""
    factor = config.SCORE_MAX_WEIGHT_FACTOR if factor is None else factor
    active = [r for r in results if r.applicable]
    if not active:
        return 0.0
    if any(r.force_report for r in active):
        return 100.0
    total_w = sum(r.weight for r in active) or 1.0
    weighted = sum(r.score * r.weight for r in active) / total_w
    return round(max(weighted, factor * max(r.score for r in active)), 1)


def priority_for(score: float) -> PriorityEnum:
    if score >= config.PRIORITY_HIGH_THRESHOLD:
        return PriorityEnum.ALTA
    if score >= config.PRIORITY_MEDIUM_THRESHOLD:
        return PriorityEnum.MEDIA
    return PriorityEnum.BAJA


# ---------------------------------------------------------------------------- helpers

def _w(name: str) -> float:
    return float(config.CHECK_WEIGHTS.get(name, 1.0))


def _contains_any(text: str, keywords) -> bool:
    t = (text or "").lower()
    # Sin espacios también: Paddle a veces junta o parte las palabras ("PARCELPENDING", "Lux erOne"; 02/10)
    compact = re.sub(r"\s", "", t)
    return any(k in t or re.sub(r"\s", "", k) in compact for k in keywords)


def is_package_room_delivery(pod: PODRecord, photos: List[PhotoOCR]) -> bool:
    """Entrega en oficina / sala / casillero de paquetería del edificio (excepción de las reglas)."""
    if _contains_any(pod.billing_type or pod.delivery_type, config.PACKAGE_ROOM_BILLING_KEYWORDS):
        return True
    if any(p.photo_type in ("package_room", "locker") for p in photos):
        return True
    if is_reception_address(pod):
        return True   # Hotel / restaurante: recepción o mostrador (casos 05/10: Hampton Inn, Wendy's)
    # La dirección cubre lo que decía la etiqueta (ya no se lee con OCR si su QR se decodificó)
    ocr_text = " ".join([pod.expected_address or ""] + [p.text for p in photos])
    # 06/10: la pantalla de un casillero del complejo (kiosco "Deposit Package", Luxer, Parcel Pending) también es la
    # sala de paquetes del edificio: el número de la oficina del complejo ("1100 OFFICE") no es otra puerta
    return (_contains_any(ocr_text, config.PACKAGE_ROOM_OCR_KEYWORDS)
            or any(_contains_any(p.text, config.LOCKER_PHOTO_KEYWORDS) or _is_parcel_sign(p.text)
                   for p in photos if not p.is_label))


def _is_parcel_sign(text: str) -> bool:
    """Cartel corto de la puerta de la sala ("PARCEL 21", "PARCELS", "PACKAGES"); caso 06/10: 6520 Browning Dr 5314."""
    words = re.findall(r"\w+", text or "")
    return 0 < len(words) <= 4 and bool(re.search(r"\b(parcels?|packages)\b", text or "", re.I))


# ---------------------------------------------------------------------------- chequeos

def _as_label_if_address_text(photo: PhotoOCR, address) -> PhotoOCR:
    if photo.is_label or photo.error or not photo.text:
        return photo
    words = [w for w in re.findall(r"[A-Za-z]{4,}", address.street or "")
             if w.lower() not in ("street", "drive", "avenue", "lane", "road", "north", "south", "east", "west")]
    text = photo.text.upper()
    # Una placa de la casa con número y calle ("2806 Stafford St", 3 palabras) no es una etiqueta: solo se trata
    # como etiqueta si además hay señales de etiqueta (texto largo, palabras de etiqueta o código postal)
    label_signals = (len(text.split()) > config.PLATE_MAX_TOKENS or any(k in text for k in LABEL_WORDS)
                     or re.search(r"\b7[5-9]\d{3}\b", text))
    if re.search(r"\bDFW", text) or (words and any(w.upper() in text for w in words) and label_signals):
        return PhotoOCR(path=photo.path, text=photo.text, is_label=True, label_tracking=photo.label_tracking)
    return photo


LABEL_WORDS = ("SHIP", "GOFO", "TX ", "WEIGHT", "FROM", "GFUS", "REF")
GOFO_TEXT_RE = re.compile(r"GOFO|GFUS\d{6,}|SHIP TO")


def _has_label_text(text: str) -> bool:
    t = (text or "").upper()
    return sum(1 for k in LABEL_WORDS if k in t) >= 2 or bool(re.search(r"GFUS\d{6,}", t))


def _only_vision_contradicts(address, photos: List[PhotoOCR]) -> bool:
    """True si, quitando las lecturas que aportó solo el modelo de visión, el número ya no contradice."""
    if not any(p.vision_numbers for p in photos):
        return False
    ocr_only = [replace(p, numbers=[n for n in p.numbers if n not in p.vision_numbers]) for p in photos]
    return match_numbers(address, ocr_only).status not in ("mismatch", "wrong_building")


CHAT_YES_RE = re.compile(r"\b(s[ií]|yes|yeah|yep|ok|okay|correct[oa]?|exact[oa]?|that'?s it|es esa)\b", re.I)


def chat_confirmed_numbers(text: str) -> List[str]:
    """Números que el repartidor preguntó en el chat ("793?") y el cliente confirmó con un "sí" en el mensaje siguiente."""
    out = []
    for m in re.finditer(r"(?<![\d:/])(\d{1,5})\s*\?", text or ""):
        after = re.sub(r"\d{1,2}:\d{2}(:\d{2})?\s*\d{1,2}/\d{1,2}/\d{2,4}", " ", (text or "")[m.end(): m.end() + 60])
        if CHAT_YES_RE.search(after):
            out.append(m.group(1))
    return out


def _nearby_building_of_room(pod: PODRecord, photos: List[PhotoOCR], address, m) -> bool:
    """
    La sala de paquetes se LEE en un cartel ("SPECIAL DELIVERIES") y el único número que no concuerda es otro edificio
    del mismo complejo (mismo largo, a menos de 200 números): es el edificio de la sala, no otra puerta (casos 05/10:
    6309 con direcciones 6253 / 6365 / 6249 Iron Horse Blvd). Un número lejano o dos puertas siguen siendo problema.
    """
    room_words = config.PACKAGE_ROOM_OCR_KEYWORDS + config.LOCKER_PHOTO_KEYWORDS + config.MAILBOX_STORE_KEYWORDS
    # 06/10: también el cartel "PARCEL 21" (aunque el modelo lo llame "etiqueta"). NUNCA solo porque el modelo diga
    # "sala": llamó sala al portón de 2375 Rock Ridge Rd y escondía el error real (buzón 2395)
    room_seen = (_contains_any(" ".join(p.text or "" for p in photos), room_words)
                 or any(_is_parcel_sign(p.text) and not p.label_tracking for p in photos))
    if m.status != "mismatch" or not room_seen:
        return False
    house = _digits_only(address.house_number)
    seen = {_digits_only(n) for n in m.seen if len(_digits_only(n)) >= 3}   # "1", "24" sueltos son ruido
    return bool(house and seen) and all(len(n) == len(house) and abs(int(n) - int(house)) <= 200 for n in seen)


def check_address_number(pod: PODRecord, photos: List[PhotoOCR]) -> CheckResult:
    name, w = "numero_direccion", _w("numero_direccion")
    # Los números de una captura de mapa (teléfono, horario, CP) no son del lugar: los evalúa check_map_screenshot
    photos = [p for p in photos if not is_map_screenshot(p.text)]
    if not photos:
        return CheckResult(name, 0, w, "Sin fotos para leer el número.", applicable=False)
    if all(p.error for p in photos):
        # 04/10: con la GPU sin memoria el OCR falló en todas las fotos y esos albaranes quedaban en Baja sin revisar
        # (27 errores reales escondidos en una prueba). Si no se pudo leer nada, va a revisión manual.
        return CheckResult(name, config.FAR_NUMBERS_SCORE, w,
                           f"El OCR no pudo leer las fotos ({photos[0].error[:60]}): revisar manualmente.",
                           details={"status": "ocr_error"})
    address = parse_us_address(pod.expected_address)
    if address.house_number:
        # La pantalla del casillero o una captura del teléfono muestra la dirección completa de este paquete (caso 05/10:
        # Luxer One "Select Recipient Match — Dairius Benton, 1537 Meridian Drive 2204")
        for p in photos:
            if (not p.is_label and _label_text_has_address(p.text, address)
                    and (_contains_any(p.text, config.LOCKER_PHOTO_KEYWORDS) or is_phone_screenshot(p.text))):
                return CheckResult(name, 0, w, "Dirección completa confirmada en la pantalla del casillero / captura.",
                                   details={"status": "match", "casa": address.house_number, "unidad": address.unit})
    if is_package_room_delivery(pod, photos):
        # Deducido SOLO de una foto (el modelo dijo "sala de paquetería"), no tapa dos puertas / un número que no
        # concuerda leídos en las OTRAS fotos (caso real 01/10: puertas 2817 y 4224 + foto de la sala de correo)
        by_billing = _contains_any(pod.billing_type or pod.delivery_type, config.PACKAGE_ROOM_BILLING_KEYWORDS)
        address = parse_us_address(pod.expected_address)
        rest = [p for p in photos if p.photo_type not in ("package_room", "locker")]
        rest_match = match_numbers(address, [_as_label_if_address_text(p, address) for p in rest])
        hard = (not by_billing and address.house_number and rest_match.status in HARD_NUMBER_PROBLEMS
                and not _nearby_building_of_room(pod, photos, address, rest_match))
        # 11/10: la pantalla del casillero muestra OTRA unidad ("1100 Hidden Ridge 2094" para la 2090): se revisa el número
        if not hard and _locker_screen_unit(pod, photos) != "other":
            # Si igual se ve el número correcto en otra foto, queda anotado: así una foto repetida (cartel, "Leasing
            # Office") no suma riesgo (casos 05/10: 3947 / 3825 / 3983 N O'Connor Rd)
            return CheckResult(name, 0, w, "Entrega en sala/casillero de paquetería: no se exige número de unidad.",
                               applicable=False, details={"status": "match" if rest_match.status == "match" else "sala"})
    if _contains_any(pod.billing_type, config.HANDOVER_BILLING_KEYWORDS):
        return CheckResult(name, 0, w, "Entregado en mano al cliente: no se exige número visible.", applicable=False)
    if is_amazon_hub(pod, photos):
        # El locker de Amazon se reporta por su propio chequeo; los números del kiosco o del cartel del complejo no son
        # puertas (caso real 03/10: "800" del cartel de 818 W Royal Ln)
        return CheckResult(name, 0, w, "Locker de Amazon: el número de la puerta no aplica.", applicable=False)

    address = parse_us_address(pod.expected_address)
    if not address.house_number:
        return CheckResult(name, 50, w, "No se pudo interpretar la dirección esperada.",
                           details={"address": pod.expected_address})
    # Una foto cuyo texto trae el nombre de la calle es una etiqueta (la dirección impresa), aunque
    # el QR no se haya detectado: sus números no pueden contar como "vistos en la puerta".
    for p in photos:
        if _contains_any(p.text, config.MAIL_PIECE_KEYWORDS) and not GOFO_TEXT_RE.search((p.text or "").upper()):
            status, found = screenshot_address_status(p.text, address.house_number, address.street)
            if status == "match":
                return CheckResult(name, 0, w, f"Dirección confirmada por una carta de correo de la casa ({found}).",
                                   details={"status": "match", "carta_correo": found, "casa": address.house_number})
    chats = [p for p in photos if is_chat_screenshot(p.text)]
    photos = [_as_label_if_address_text(p, address) for p in photos if not is_chat_screenshot(p.text)]
    if not address.is_apartment:
        # Cartel de edificio con el rango de números ("18 / 87-94", caso 05/10: 89 Beechwood Pl): si la casa está en el
        # rango, ese cartel la confirma (solo sirve para CONFIRMAR, nunca como "otro número")
        house_num = int(_digits_only(address.house_number) or 0)
        photos = [replace(p, alt_numbers=list(p.alt_numbers or []) + [_digits_only(address.house_number)])
                  if not p.is_label and any(lo <= house_num <= hi for lo, hi in unit_ranges(p.text)) else p
                  for p in photos]
    m = match_numbers(address, photos)
    if m.status != "match":
        # Regla 01/10: el cliente corrige la dirección en el chat y las fotos coinciden con la dirección corregida
        for alt in (a for c in chats for a in chat_addresses(c.text)):
            alt_addr = parse_us_address(alt + (f" Apt {address.unit}" if address.unit else ""))
            if alt_addr.house_number and match_numbers(alt_addr, photos).status == "match":
                return CheckResult(name, 0, w, f"Dirección corregida por el cliente en el chat ({alt}) y concuerda.",
                                   details={"status": "match", "corregida_por_cliente": alt})
    if m.status != "match":
        # Tienda de buzones con dirección "local-buzón" (casos 05/10: "4843 Colleyville Blvd 251-126" con la puerta 251 de
        # The UPS Store; "391 Las Colinas Blvd E 130-425" con el 130 de "24 Hour Mailbox"): en la foto se ve el local
        suite = suite_of_mailbox_address(pod.expected_address)
        box = SUITE_BOX_RE.search((pod.expected_address or "").strip())
        if suite and len(suite) >= 3 and any(suite in (p.numbers or []) + (p.alt_numbers or []) for p in photos) and (
                is_mailbox_store(pod, photos) or len(box.group(2)) >= 3):
            return CheckResult(name, 0, w, f"Local {suite} de la tienda de buzones visible (dirección local-buzón).",
                               details={"status": "match", "local": suite, "casa": address.house_number,
                                        "unidad": address.unit})
        # Unidad "número + letra" (17B): el edificio 17 en un cartel y la placa con la letra "B" sola en la puerta (caso
        # 05/10: 6484 Iron Horse Blvd 17B; un cartelito de costado decía "17E 17A" y se tomaba como otra unidad)
        ul = re.fullmatch(r"(\d{1,4})\s*-?\s*([A-Za-z])", (address.unit or "").strip())
        if ul:
            bldg, letter = ul.group(1), ul.group(2).upper()
            has_bldg = any(bldg in [_digits_only(x) for x in (p.numbers or [])] for p in photos if not p.is_label)
            has_letter = any((p.text or "").strip().upper().strip(".,:;'\"") == letter for p in photos if not p.is_label)
            if has_bldg and has_letter:
                return CheckResult(name, 0, w, f"Edificio {bldg} y puerta con la letra {letter}: concuerda con la unidad "
                                               f"{address.unit}.",
                                   details={"status": "match", "casa": address.house_number, "unidad": address.unit})
        # El repartidor pregunta por el chat de GOFO un número ("793?") y el cliente responde que sí (caso real 05/10:
        # 807 Cavalier Plz sin unidad; la puerta 793 se ve en las fotos). Vale ese número si además se ve en una foto.
        for n in (n for c in chats for n in chat_confirmed_numbers(c.text)):
            if any(n in [_digits_only(x) for x in (p.numbers or []) + (p.alt_numbers or [])] for p in photos if not p.is_label):
                return CheckResult(name, 0, w, f"Número {n} confirmado por el cliente en el chat de GOFO y visible en la foto.",
                                   details={"status": "match", "confirmado_en_chat": n, "casa": address.house_number,
                                            "unidad": address.unit})
    details = {"status": m.status, "leidos": m.seen[:10], "casa": address.house_number, "unidad": address.unit}
    if m.status == "match":
        return CheckResult(name, 0, w, f"Número {m.matched[0]} visible y concuerda.", details=details)
    if m.status in ("near_match", "neighbor_digit"):
        return CheckResult(name, config.WEAK_NUMBER_SCORE, w, m.detail, details=details)
    if m.status == "partial_read":
        return CheckResult(name, config.WEAK_NUMBER_SCORE, w, m.detail, details=details)
    if m.status == "two_doors":
        return CheckResult(name, 100, w, m.detail, details=details)
    if m.status in ("two_doors_unconfirmed", "mismatch_unconfirmed"):
        # 02/10: lectura del OCR que el modelo de visión no confirma -> revisión manual (Media), no Alta
        return CheckResult(name, config.WEAK_NUMBER_SCORE, w, m.detail, details=details)
    if m.status == "mismatch" and _only_vision_contradicts(address, photos):
        # El modelo de visión (más débil que el OCR) es el único que lee otro número: ej. placa chica
        # "4808" leída como "4000". Va a revisión manual en vez de prioridad Alta.
        # Regla 01/10: no mostrar un número que el OCR no confirma (casos 9104 -> "1204", 1504 -> "1511", 707 -> "117")
        details["solo_modelo_vision"] = True
        details["lectura_modelo"] = m.detail
        return CheckResult(name, config.WEAK_NUMBER_SCORE, w,
                           "Número no legible con seguridad (foto pixelada, borrosa o lejana): verificar.",
                           details=details)
    if m.status in ("mismatch", "wrong_building"):
        return CheckResult(name, 100, w, m.detail, details=details)
    if m.status == "far_numbers":
        # Decisión del revisor: no se reporta automáticamente, queda para revisión manual
        return CheckResult(name, config.WEAK_NUMBER_SCORE, w, m.detail, details=details)
    # not_visible / partial: el OCR no distingue "no hay número" de "cartel chico/lejano",
    # así que por decisión del revisor va a revisión manual (Media), sin reporte automático.
    if config.NUMBER_NOT_VISIBLE_FORCES_REPORT:
        return CheckResult(name, 100, w, m.detail, force_report=True, details=details)
    unit = " de la unidad" if m.status == "partial" else ""
    # Unidad no leída con el edificio confirmado: "Media baja" (05/10: 1 reportado de 6); número sin leer: Media
    return CheckResult(name, config.WEAK_NUMBER_SCORE if m.status == "partial" else config.FAR_NUMBERS_SCORE, w,
                       f"Número{unit} no leído / posible número lejano: revisar manualmente.", details=details)


def check_photo_count(pod: PODRecord) -> CheckResult:
    name, w = "cantidad_fotos", _w("cantidad_fotos")
    n = len(pod.photo_paths) or pod.number_of_photos
    if n == 0:
        return CheckResult(name, 100, w, "Sin fotos de POD.", force_report=True, details={"fotos": 0})
    if n < config.MIN_EXPECTED_PHOTOS:
        return CheckResult(name, 60, w, f"Solo {n} foto(s); se esperan {config.MIN_EXPECTED_PHOTOS}-"
                                        f"{config.MAX_EXPECTED_PHOTOS}.", details={"fotos": n})
    if n > config.MAX_EXPECTED_PHOTOS:
        return CheckResult(name, 20, w, f"{n} fotos (más de lo habitual).", details={"fotos": n})
    return CheckResult(name, 0, w, f"{n} fotos (normal).", details={"fotos": n})


def address_of_tracking(tracking: str) -> Optional[str]:
    """Dirección de otro albarán ya extraído (cualquier sesión), para saber si su etiqueta es de la misma casa."""
    import sqlite3
    try:
        con = sqlite3.connect(f"file:{config.CHECKPOINT_DB_PATH.as_posix()}?mode=ro", uri=True, timeout=10)
        try:
            row = con.execute("""SELECT coalesce(json_extract(payload_json, '$.receipt_address'),
                                                 json_extract(payload_json, '$.address'))
                                 FROM pod_checkpoints WHERE tracking_number = ? ORDER BY created_at DESC LIMIT 1""",
                              (tracking,)).fetchone()
        finally:
            con.close()
        return row[0] if row else None
    except Exception:
        return None


def driver_of_tracking(tracking: str) -> Optional[str]:
    """Repartidor de otro albarán ya extraído (cualquier sesión)."""
    import sqlite3
    try:
        con = sqlite3.connect(f"file:{config.CHECKPOINT_DB_PATH.as_posix()}?mode=ro", uri=True, timeout=10)
        try:
            row = con.execute("SELECT driver_name FROM pod_checkpoints WHERE tracking_number = ? "
                              "ORDER BY created_at DESC LIMIT 1", (tracking,)).fetchone()
        finally:
            con.close()
        return row[0] if row else None
    except Exception:
        return None


def _label_text_has_address(text: str, address) -> bool:
    """El texto de una etiqueta trae el número de casa, una palabra de la calle y (si hay) la unidad de ESTA dirección."""
    t = (text or "").upper()
    if not re.search(rf"(?<!\d){re.escape(address.house_number)}(?!\d)", t):
        return False
    words = [w.upper() for w in re.findall(r"[A-Za-z]{4,}", address.street or "")
             if w.lower() not in ("street", "drive", "avenue", "lane", "road", "north", "south", "east", "west")]
    if words and not any(w in t for w in words):
        return False
    return not address.unit or re.search(rf"(?<!\d){re.escape(_digits_only(address.unit))}(?!\d)", t) is not None


def _digits_only(s: str) -> str:
    return re.sub(r"\D", "", s or "")


def check_label_photos(pod: PODRecord, photos: List[PhotoOCR], number_seen: bool = False,
                       address_of=address_of_tracking, driver_of=None) -> CheckResult:
    """
    El patrón a detectar (definido por la operación): 2 fotos del paquete/etiqueta y otra que NO muestra
    el número de la casa. Si el número se ve y concuerda en otra foto, las fotos de etiqueta no suman riesgo.
    """
    name, w = "fotos_etiqueta", _w("fotos_etiqueta")
    # Solo cuentan las etiquetas de verdad (QR/código o texto de etiqueta). Lo que SOLO el modelo de visión llamó
    # "etiqueta" puede ser el paquete en el piso (la foto que confirma dónde lo dejó) o un cartel ("PRIVATE PROPERTY")
    # (casos reales 02/10: 275 Lost Valley Dr, 550 Honeysuckle Ln)
    labels = [p for p in photos if p.is_label and (not getattr(p, "vision_label", False) or p.label_tracking
                                                   or _has_label_text(p.text))]
    other = [p.label_tracking for p in labels
             if p.label_tracking and p.label_tracking.upper() != pod.tracking_number.upper()]
    # Varios paquetes a la MISMA casa con una sola foto de todas las etiquetas es normal (caso real: 400 Settlers
    # Bnd, 4 albaranes). Solo es error si la etiqueta es de un paquete para otra dirección (o desconocida).
    mine = building_key(pod.expected_address)
    same = [t for t in other if mine and address_of and same_building_key(building_key(address_of(t) or ""), mine)]
    # 11/10: misma dirección pero entregado por OTRO repartidor = foto de la etiqueta de un paquete ajeno (2 errores reales
    # reportados: 2425 Bardin Rd Apt 6128 y 3655 Prairie Waters Dr Apt 6207)
    norm = lambda n: " ".join((n or "").split()).lower()
    driver_of = driver_of or driver_of_tracking
    same = [t for t in same if not driver_of or not driver_of(t) or norm(driver_of(t)) == norm(pod.driver_name)]
    # El otro paquete puede no estar todavía en la base (se procesa después; caso real 05/10: Apt 106 de 2400 Timberline
    # Dr, los dos firmados con 1 s de diferencia). Entonces vale la dirección impresa en la propia foto de esa etiqueta.
    address = parse_us_address(pod.expected_address)
    for t in [t for t in other if t not in same]:
        text = " ".join(p.text or "" for p in labels if (p.label_tracking or "").upper() == t.upper())
        if address.house_number and _label_text_has_address(text, address):
            same.append(t)
    other = [t for t in other if t not in same]
    details = {"etiquetas": len(labels), "tracking_leido": [p.label_tracking for p in labels if p.label_tracking]}
    if same:
        details["misma_direccion"] = same
    if other:
        # 25/10 (pedido del usuario): "La etiqueta fotografiada es de otro paquete" ya NO es error. Son varios paquetes a la
        # misma dirección y la etiqueta que se ve es la de uno de ellos: siempre es la dirección correcta (la GPU de Kaggle
        # lo dejó en Baja en el caso GFUS01079569534336 y el usuario confirmó que no era error). Se anota y no suma riesgo.
        details["etiqueta_otro_paquete_ignorada"] = other
    own = any((p.label_tracking or "").upper() == pod.tracking_number.upper() for p in labels)
    if same and not own:
        # 12/10 (pedido del usuario): solo se ve la etiqueta de OTRO paquete de la misma casa (no la de este): a revisión
        # (Media). Casos reales 09/10 reportados: 1509 Meadow View Dr y 1940 Winding Ridge Trl. Si la etiqueta de este
        # paquete también aparece (foto de todas las etiquetas, caso 400 Settlers Bnd) sigue siendo normal
        return CheckResult(name, config.FAR_NUMBERS_SCORE, w,
                           f"Solo se ve la etiqueta de otro paquete de la misma dirección ({same[0]}), no la de este: "
                           "verificar.", details=details)
    if len(labels) >= 2 and _contains_any(pod.billing_type, config.HANDOVER_BILLING_KEYWORDS):
        return CheckResult(name, 0, w, f"{len(labels)} fotos del paquete: entregado en mano al cliente (normal).",
                           applicable=False, details=details)
    if len(labels) >= 2 and number_seen:
        return CheckResult(name, 0, w, f"{len(labels)} fotos de etiqueta, pero el número de la casa se ve en otra foto.",
                           details=details)
    if len(labels) >= 2:
        return CheckResult(name, 70, w, f"{len(labels)} fotos de la etiqueta en vez de fotos del lugar.",
                           details=details)
    return CheckResult(name, 0, w, f"{len(labels)} foto(s) de etiqueta.", details=details)


def check_building_photos(pod: PODRecord, photos: List[PhotoOCR], number_seen: bool = False) -> CheckResult:
    """
    Apartamento: se exigen foto del edificio Y de la puerta. Sin clasificador de escena,
    se aproxima con "al menos 2 fotos que no sean etiqueta".
    TODO(inspect): usar los roles reales de las fotos cuando estén mapeados.
    """
    name, w = "fotos_edificio", _w("fotos_edificio")
    address = parse_us_address(pod.expected_address)
    if not address.is_apartment:
        return CheckResult(name, 0, w, "No es apartamento.", applicable=False)
    if is_package_room_delivery(pod, photos):
        return CheckResult(name, 0, w, "Entrega en sala/casillero de paquetería del edificio.", applicable=False)
    place_photos = [p for p in photos if not p.is_label]
    if len(place_photos) < 2 and number_seen:
        # 03/10: la unidad ya se confirmó (placa de la puerta, captura del mapa o de la app de GOFO): no falta nada
        return CheckResult(name, 0, w, "Unidad confirmada aunque haya una sola foto del lugar.",
                           details={"fotos_lugar": len(place_photos)})
    if len(place_photos) < 2:
        # 04/10: Media (antes forzaba Alta). Ninguno de los casos reales con esta regla era un error: recepciones, captura
        # de la app de GOFO, placa 060 tomada como etiqueta, kiosco Luxer. Se sigue mostrando para revisar.
        return CheckResult(name, config.FAR_NUMBERS_SCORE, w,
                           f"Apartamento con {len(place_photos)} foto(s) del lugar: falta la del edificio o la de la puerta.",
                           details={"fotos_lugar": len(place_photos)})
    return CheckResult(name, 0, w, f"{len(place_photos)} fotos del lugar (edificio y puerta).",
                       details={"fotos_lugar": len(place_photos)})


def other_pod_summary(tracking: str) -> Optional[Dict[str, Any]]:
    """Dirección y resultado del número de OTRO albarán ya puntuado (para comparar fotos compartidas)."""
    import json
    import sqlite3
    try:
        con = sqlite3.connect(f"file:{config.CHECKPOINT_DB_PATH.as_posix()}?mode=ro", uri=True, timeout=10)
        try:
            row = con.execute("""SELECT coalesce(json_extract(payload_json, '$.receipt_address'),
                                                 json_extract(payload_json, '$.address')),
                                        json_extract(payload_json, '$.check_results')
                                 FROM pod_checkpoints WHERE tracking_number = ? ORDER BY created_at DESC LIMIT 1""",
                              (tracking,)).fetchone()
        finally:
            con.close()
    except Exception:
        return None
    if not row:
        return None
    checks = json.loads(row[1] or "[]")
    num = next((r for r in checks if r.get("check") == "numero_direccion"), {})
    hub = any(r.get("check") == "amazon_hub" and r.get("applicable") for r in checks)
    status = (num.get("details") or {}).get("status")
    # 06/10: "match" de una sala/casillero/locker (chequeo no aplicable) no es una PUERTA confirmada (caso 06/10: el
    # locker de Amazon de 5334 Bond St Apt 220 hizo Alta a 3 albaranes de Carnaby St con su foto)
    if not num.get("applicable", True) or hub:
        status = "sala" if status == "match" else status
    return {"address": row[0] or "", "number_status": status}


def _shared_with_other_unit(pod: PODRecord, other_of=other_pod_summary) -> Optional[CheckResult]:
    """
    Foto idéntica a la de otro albarán del MISMO edificio pero de OTRA unidad (caso real 05/10: los paquetes del apto
    38 y del 40 en una sola foto frente a la puerta 40). No es "normal": si la otra unidad confirmó su puerta con esa
    foto, este paquete quedó en la puerta equivocada (Alta); si no, a revisar (Media).
    """
    name, w = "fotos_duplicadas", _w("fotos_duplicadas")
    other_trk = pod.duplicate_matched_tracking
    if not other_trk or not (pod.portal_meta or {}).get("duplicate_same_building"):
        return None
    mine = parse_us_address(pod.expected_address)
    info = other_of(other_trk) or {}
    other = parse_us_address(info.get("address") or "")
    if not (mine.unit and other.unit) or re.sub(r"\W", "", mine.unit).upper() == re.sub(r"\W", "", other.unit).upper():
        return None
    if info.get("number_status") == "match":
        return CheckResult(name, 100, w, f"La foto es la misma del albarán {other_trk} (unidad {other.unit}), donde se "
                                         f"confirmó esa puerta: este paquete era para la unidad {mine.unit}.",
                           details={"compartida_con": other_trk, "unidad_otra": other.unit})
    return CheckResult(name, config.FAR_NUMBERS_SCORE, w,
                       f"Foto compartida con el albarán {other_trk} de otra unidad ({other.unit}; esta es la "
                       f"{mine.unit}): verificar en qué puerta quedó.",
                       details={"compartida_con": other_trk, "unidad_otra": other.unit})


def check_duplicates(pod: PODRecord, other_of=other_pod_summary) -> CheckResult:
    name, w = "fotos_duplicadas", _w("fotos_duplicadas")
    is_dup = pod.duplicate_status in (DuplicateStatusEnum.EXACT_DUPLICATE.value,
                                      DuplicateStatusEnum.POSSIBLE_VISUAL_DUPLICATE.value)
    meta = pod.portal_meta or {}
    if is_dup:
        shared = _shared_with_other_unit(pod, other_of)
        if shared:
            return shared
    if (is_dup and (meta.get("duplicate_same_complex") or meta.get("duplicate_same_building"))
            and not config.DUPLICATE_SAME_BUILDING_SCORE):
        return CheckResult(name, 0, w, f"Foto repetida con el albarán {pod.duplicate_matched_tracking} de la misma "
                                       "dirección/edificio (normal).", applicable=False)
    if is_dup and (pod.portal_meta or {}).get("duplicate_same_complex"):
        return CheckResult(name, config.DUPLICATE_SAME_BUILDING_SCORE, w,
                           f"Foto repetida con el albarán {pod.duplicate_matched_tracking} del mismo complejo de "
                           "apartamentos (ej. el cartel de la entrada).")
    if is_dup and (pod.portal_meta or {}).get("duplicate_same_building"):
        return CheckResult(name, config.DUPLICATE_SAME_BUILDING_SCORE, w,
                           f"Foto repetida con el albarán {pod.duplicate_matched_tracking} del mismo edificio "
                           "(normal en entregas múltiples o en sala/casillero de paquetería).")
    if is_dup and config.DUPLICATE_NEAR_ADDRESS_M:
        # 29/10: la foto se tomó junto a ESTA dirección (el POD está en su puerta), así que no es una foto traída de otra casa:
        # es una entrega múltiple de unidades vecinas con una sola foto (930 y 932 W Rochelle Rd, a 3 y 23 m). Historial: de 30
        # alertas de "foto idéntica (otra dirección)" revisadas, 29 descartadas (21 con el POD a menos de 50 m) y 1 reportada,
        # esa tomada a 759 m. El POD que sí quedó lejos de su dirección sigue en Alta.
        try:
            near = float((pod.portal_meta or {}).get("sign_distance"))
        except (TypeError, ValueError):
            near = None
        if near is not None and near <= config.DUPLICATE_NEAR_ADDRESS_M:
            return CheckResult(name, 0, w, f"Foto repetida con el albarán {pod.duplicate_matched_tracking}, pero se tomó a "
                                           f"{near:.0f} m de esta dirección (entrega múltiple cercana).", applicable=False,
                               details={"distancia": near, "compartida_con": pod.duplicate_matched_tracking})
    if pod.duplicate_status == DuplicateStatusEnum.EXACT_DUPLICATE.value:
        return CheckResult(name, 100, w, f"Foto idéntica a la del albarán {pod.duplicate_matched_tracking} "
                                         "(otra dirección).")
    if pod.duplicate_status == DuplicateStatusEnum.POSSIBLE_VISUAL_DUPLICATE.value:
        return CheckResult(name, 80, w, f"Foto casi idéntica a la del albarán {pod.duplicate_matched_tracking} "
                                        "(otra dirección).")
    shas = [m.sha256 for m in pod.image_metrics if m.sha256]
    if len(shas) != len(set(shas)):
        return CheckResult(name, 70, w, "La misma foto aparece repetida dentro del albarán.")
    return CheckResult(name, 0, w, "Sin fotos duplicadas.")


# falseSignature: 3 = "No informado" (lo normal), 4 = "En proceso" (etiqueta roja). Caso real 04/10: el 2 (740 Summerfield
# Dr, foto correcta) no lleva etiqueta roja en el portal; antes todo lo distinto de 3 se tomaba como marcado.
FALSE_SIGNATURE_FLAGGED = ("1", "4")


def _false_pod_flag(whether_reported, false_signature) -> bool:
    return str(whether_reported or "") == "1" or str(false_signature or "") in FALSE_SIGNATURE_FLAGGED


def portal_info_is_false_pod(info: Dict[str, Any]) -> bool:
    """Misma regla que is_portal_flagged_false_pod, sobre la respuesta cruda de getInfoBySignId."""
    return _false_pod_flag(info.get("whetherReported"), info.get("falseSignature"))


def is_portal_flagged_false_pod(pod: PODRecord) -> bool:
    """
    Etiqueta roja "POD falso sospechoso" del portal: whetherReported = 1 ("Sí") o falseSignature 1 / 4 ("En proceso").
    """
    meta = pod.portal_meta or {}
    return _false_pod_flag(meta.get("whether_reported"), meta.get("false_signature"))


def check_portal_false_pod(pod: PODRecord) -> CheckResult:
    name, w = "pod_falso_portal", _w("pod_falso_portal")
    if is_portal_flagged_false_pod(pod):
        return CheckResult(name, 100, w, "El portal marcó este POD como FALSO SOSPECHOSO: revisar primero.",
                           force_report=True, details={"whetherReported": (pod.portal_meta or {}).get("whether_reported"),
                                                       "falseSignature": (pod.portal_meta or {}).get("false_signature")})
    return CheckResult(name, 0, w, "Sin marca de POD falso en el portal.")


def check_gps_distance(pod: PODRecord, number_match: bool = False) -> CheckResult:
    name, w = "distancia_gps", _w("distancia_gps")
    raw = (pod.portal_meta or {}).get("sign_distance")
    try:
        dist = float(raw)
    except (TypeError, ValueError):
        return CheckResult(name, 0, w, "Sin distancia GPS del POD.", applicable=False)
    score = 0
    for limit, s in config.GPS_DISTANCE_SCORES:
        if dist > limit:
            score = s
    if not score:
        return CheckResult(name, 0, w, f"POD tomado a {dist:.0f} de la dirección (normal).", details={"distancia": dist})
    if number_match:
        # 12/10: el número de la casa se ve y concuerda -> la distancia sola no suma (historial: 59 descartados, 0 reales;
        # 12/10 Colleyville, Suhana Martínez: 28 Media a 1,6-4,4 km, todas descartadas: la ubicación de GOFO estaba mal).
        # El único error real por GPS (2.192 m, 01/10) no mostraba el número
        return CheckResult(name, 0, w, f"POD tomado a {dist:.0f} de la dirección, pero el número de la casa se ve y "
                                       "concuerda: la distancia no suma riesgo.", details={"distancia": dist})
    return CheckResult(name, score, w, f"POD tomado a {dist:.0f} de la dirección: verificar.",
                       details={"distancia": dist})


def check_image_quality(pod: PODRecord, photos: Optional[List[PhotoOCR]] = None,
                        number_seen: bool = False) -> CheckResult:
    name, w = "calidad_imagen", _w("calidad_imagen")
    if not pod.image_metrics:
        return CheckResult(name, 0, w, "Sin métricas de imagen.", applicable=False)
    if number_seen:
        # 03/10: foto oscura/borrosa/sobreexpuesta en la que igual se lee el número correcto no es un problema
        return CheckResult(name, 0, w, "El número se lee y concuerda: la calidad de imagen no suma riesgo.",
                           applicable=False)
    # Capturas de pantalla (chat con el cliente, mapas) no son fotos de cámara: no se evalúan por calidad (regla 01/10)
    screens = {str(p.path) for p in photos or [] if is_phone_screenshot(p.text)}
    order = {str(x): i for i, x in enumerate(pod.photo_paths, 1)}
    worst, why = 0, "Calidad de imagen aceptable."
    for i, m in enumerate(pod.image_metrics, 1):
        if str(m.file_path) in screens:
            continue
        i = order.get(str(m.file_path), i)
        for flag, s, txt in ((m.is_corrupted, 60, "corrupta"), (m.is_blank_or_covered, 70, "tapada/plana"),
                             (m.is_blurry and m.blur_score < config.SCORE_BLUR_THRESHOLD, 30, "borrosa"),
                             (m.is_dark, 40, "muy oscura"),
                             (m.is_overexposed, 40, "sobreexpuesta")):
            if flag and s > worst:
                worst, why = s, f"Foto #{i} {txt}."
    return CheckResult(name, worst, w, why)


def check_vision_failure(photos: List[PhotoOCR]) -> CheckResult:
    """Caso dudoso en el que el modelo de visión no pudo leer alguna foto: revisión manual (Media)."""
    name, w = "vision_fallida", _w("vision_fallida")
    failed = [i for i, p in enumerate(photos, 1) if p.vision_error]
    if not failed:
        return CheckResult(name, 0, w, "Sin fallos del modelo de visión.", applicable=False)
    fotos = ", ".join(f"#{i}" for i in failed)
    # FAR_NUMBERS_SCORE (50) × SCORE_MAX_WEIGHT_FACTOR (0.8) = 40: asegura al menos prioridad Media
    return CheckResult(name, config.FAR_NUMBERS_SCORE, w,
                       f"El modelo de visión no pudo leer la(s) foto(s) {fotos}: revisar manualmente.",
                       details={"fotos": failed, "error": photos[failed[0] - 1].vision_error[:120]})


def _sha256(path: str) -> Optional[str]:
    import hashlib
    try:
        with open(path, "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()
    except OSError:
        return None


def check_map_screenshot(pod: PODRecord, photos: List[PhotoOCR]) -> CheckResult:
    """Captura de un mapa como prueba de la dirección: se compara la dirección de la captura con la del paquete."""
    name, w = "captura_mapa", _w("captura_mapa")
    shots = [(i, p) for i, p in enumerate(photos, 1) if is_map_screenshot(p.text)]
    if not shots:
        return CheckResult(name, 0, w, "Sin capturas de mapa.", applicable=False)
    address = parse_us_address(pod.expected_address)
    results = []
    for i, p in shots:
        status = screenshot_address_status(p.text, address.house_number, address.street)
        if status[0] != "match":
            # Letra chica del mapa: se relee ampliada (caso real 04/10, "723 Griffith Ave" leído solo "Griffith Ave")
            extra = reread_screenshot_text(p.path)
            if extra:
                again = screenshot_address_status(extra, address.house_number, address.street)
                if again[0] == "match" or status[0] == "unknown":
                    status = again
        if status[0] == "unknown" and config.VISION_ENABLED:
            # 06/10: captura muy comprimida que el OCR no lee ni ampliada (caso 05/10: "Llegaste a 3317 Sweet Gum Ln"
            # leído "3176/7Www"); el modelo de visión sí la lee. SOLO confirma: en fotos sin dirección el modelo inventa
            # direcciones genéricas ("1234 Elm Street"), así que nunca se usa para marcar otra dirección.
            from processing import vision_llm
            seen = vision_llm.screenshot_address(p.path)
            if seen and screenshot_address_status(seen, address.house_number, address.street)[0] == "match":
                status = ("match", seen)
        results.append((i, p) + status)
    details = {"fotos": [i for i, *_ in results], "leida": [r[3] for r in results],
               "shas": [_sha256(p.path) for _, p in shots]}
    bad = [r for r in results if r[2] == "mismatch"]
    if bad:
        return CheckResult(name, 100, w, f"La captura del mapa (foto #{bad[0][0]}) muestra otra dirección: "
                                         f"{bad[0][3]} (se espera {address.house_number} {address.street}).",
                           details={**details, "status": "mismatch"})
    if all(r[2] == "match" for r in results):
        return CheckResult(name, 0, w, f"Captura del mapa con la dirección correcta ({results[0][3]}).",
                           details={**details, "status": "match"})
    return CheckResult(name, config.FAR_NUMBERS_SCORE, w,
                       "Captura de mapa: no se pudo leer la dirección, revisar manualmente.",
                       details={**details, "status": "unknown"})


def _apply_map_confirmation(pod: PODRecord, map_check: CheckResult, number: CheckResult,
                            dup: CheckResult) -> tuple:
    """
    Si la captura del mapa confirma la dirección: el número cuenta como confirmado y la captura repetida
    en otros albaranes de esa misma dirección no es error (es la misma prueba reutilizada).
    """
    if map_check.details.get("status") != "match":
        return number, dup
    # 11/10: si la foto muestra OTRA unidad del edificio (caso real 951 Greenside Dr 7326: Street View del edificio
    # correcto y la puerta 7223), la captura confirma el edificio pero no la puerta: el error sigue
    other_unit = (parse_us_address(pod.expected_address).unit
                  and number.details.get("status") in HARD_NUMBER_PROBLEMS + ("mismatch_unconfirmed",))
    if number.applicable and number.details.get("status") != "match" and not other_unit:
        number = CheckResult(number.check, 0, number.weight, "Dirección confirmada por la captura del mapa.",
                             applicable=False, details=number.details)
    if dup.score > 0 and pod.duplicate_matched_photo and _sha256(pod.duplicate_matched_photo) in map_check.details["shas"]:
        dup = CheckResult(dup.check, 0, dup.weight,
                          f"Captura del mapa repetida con el albarán {pod.duplicate_matched_tracking} "
                          "(misma dirección confirmada).")
    return number, dup


def check_platform_flag(pod: PODRecord) -> CheckResult:
    name, w = "incumplimiento_portal", _w("incumplimiento_portal")
    if pod.non_compliance_reason and pod.non_compliance_reason.strip():
        return CheckResult(name, 50, w, f"El portal marcó: {pod.non_compliance_reason.strip()}")
    return CheckResult(name, 0, w, "Sin incumplimiento marcado por el portal.")


# ---------------------------------------------------------------------------- orquestación

NUMBER_PROBLEMS = ("mismatch", "wrong_building", "near_match", "partial", "partial_read", "two_doors",
                   "two_doors_unconfirmed", "mismatch_unconfirmed", "neighbor_digit")
HARD_NUMBER_PROBLEMS = ("mismatch", "wrong_building", "two_doors", "neighbor_digit")
HANDOVER_EXPLANATION = "Entregado en mano a una persona: se omite de la revisión."
# 11/10: cartel de la entrada de un complejo ("RANCHO MIRAGE APARTMENT HOMES"): se repite en todos sus paquetes
COMPLEX_SIGN_RE = r"\b(apartments?|apartment homes|apts|homes|villas|residences|townhomes|leasing)\b"
LOCKER_EXPLANATION = "Entregado en casillero/sala de paquetería: se omite de la revisión."


def is_handover_delivery(pod: PODRecord) -> bool:
    # Por tipo de facturación, o porque el modelo de visión vio a una persona recibiendo el paquete
    return (_contains_any(pod.billing_type, config.HANDOVER_BILLING_KEYWORDS)
            or bool((pod.portal_meta or {}).get("handoff_photo")))


def is_amazon_hub(pod: PODRecord, photos: Optional[List[PhotoOCR]] = None) -> bool:
    text = " ".join([pod.billing_type or "", pod.expected_address or ""] + [p.text or "" for p in photos or []])
    if _contains_any(text, config.AMAZON_HUB_KEYWORDS):
        return True
    # Pantalla de casillero con teclado y sin marca de otro casillero (Luxer, Parcel Pending): es el Amazon Hub
    # Apartment Locker (caso real 03/10)
    screen = any(re.search(config.LOCKER_KEYPAD_RE, p.text or "") or re.search(config.AMAZON_LOCKER_SIZES_RE, p.text or "")
                 for p in photos or [])
    return screen and not _contains_any(text, config.LOCKER_PHOTO_KEYWORDS)


# "4843 Colleyville Blvd 251-126": local 251, buzón 126 de una tienda de buzones (casos 05/10)
SUITE_BOX_RE = re.compile(r"\b(\d{2,5})-(\d{2,5})\s*$")


def is_mailbox_store(pod: PODRecord, photos: Optional[List[PhotoOCR]] = None) -> bool:
    """Tienda de buzones privados (The UPS Store, 24 Hour Mailbox): el cartel de la tienda se ve en alguna foto."""
    return any(_contains_any(p.text, config.MAILBOX_STORE_KEYWORDS) for p in photos or [])


def suite_of_mailbox_address(address: str) -> Optional[str]:
    """Local de una dirección "local-buzón" ("... Blvd 251-126" -> "251"), o None."""
    m = SUITE_BOX_RE.search((address or "").strip())
    return m.group(1) if m else None


def is_reception_address(pod: PODRecord) -> bool:
    """Hotel o restaurante en la dirección: entrega en recepción/mostrador."""
    return _contains_any(pod.expected_address, config.RECEPTION_ADDRESS_KEYWORDS)


def is_locker_delivery(pod: PODRecord, photos: Optional[List[PhotoOCR]] = None) -> bool:
    if is_amazon_hub(pod, photos):
        return False   # Los Amazon Hub se reportan (regla 01/10)
    if _contains_any(pod.billing_type, config.PACKAGE_ROOM_BILLING_KEYWORDS):
        return True
    if re.search(r"\bPMB\b", pod.expected_address or "", re.I):
        return True   # Buzón privado (PMB) de una tienda de correo: se entrega en el mostrador (caso real 03/10)
    if is_mailbox_store(pod, photos):
        return True
    # Casillero/kiosco visto en la foto aunque la facturación diga "En la puerta" (caso Luxer One, 01/10)
    return any(_contains_any(p.text, config.LOCKER_PHOTO_KEYWORDS) or p.photo_type in ("locker", "package_room")
               for p in photos or [])


def _locker_only_by_vision_type(pod: PODRecord, photos: Optional[List[PhotoOCR]]) -> bool:
    """El casillero sale solo del tipo de foto que dio el modelo de visión (sin facturación, PMB, tienda ni texto)."""
    if (_contains_any(pod.billing_type, config.PACKAGE_ROOM_BILLING_KEYWORDS)
            or re.search(r"\bPMB\b", pod.expected_address or "", re.I) or is_mailbox_store(pod, photos)):
        return False
    return not any(_contains_any(p.text, config.LOCKER_PHOTO_KEYWORDS) for p in photos or [])


def check_amazon_hub(pod: PODRecord, photos: List[PhotoOCR]) -> CheckResult:
    name, w = "amazon_hub", _w("amazon_hub")
    if not is_amazon_hub(pod, photos):
        return CheckResult(name, 0, w, "No es Amazon Hub.", applicable=False)
    # 06/10: Alta (100 x 0,8 = 80). El 05/10 se reportaron los 24 de 24 que llegaron como Media
    return CheckResult(name, 100, w, "Entregado en locker de Amazon: reportar como Pod Fake (Lockers de Amazon), todos "
                                    "los del repartidor en un mensaje.",
                       details={"amazon_hub": True})


def _hard_problem(results: List[CheckResult]) -> bool:
    """Problemas que una omisión deducida SOLO de la foto no puede tapar (precisión primero, 02/10/2026)."""
    num = next((r for r in results if r.check == "numero_direccion"), None)
    status = (num.details or {}).get("status") if num and num.applicable else None
    gps = next((r for r in results if r.check == "distancia_gps"), None)
    # "No concuerda" aunque el modelo de visión no lo confirme: el número correcto no se ve en ninguna foto
    return status in HARD_NUMBER_PROBLEMS + ("mismatch_unconfirmed",) or bool(gps and gps.applicable and gps.score > 0)


def _gps_problem(results: List[CheckResult]) -> bool:
    gps = next((r for r in results if r.check == "distancia_gps"), None)
    return bool(gps and gps.applicable and gps.score > 0)


def _locker_screen_unit(pod: PODRecord, photos: Optional[List[PhotoOCR]]) -> Optional[str]:
    """
    11/10: la pantalla del casillero ("Select Locker Size For <nombre> 1100 Hidden Ridge 2090") muestra la unidad del
    paquete: el sistema del locker lo asignó a esa unidad. El número de la casa del kiosco es el de la OFICINA del
    complejo (1100) y no el del edificio (1116): no es "otra dirección".
    "same": muestra la unidad esperada; "other": muestra OTRA unidad (no se omite); None: no se sabe.
    """
    unit = re.sub(r"\D", "", parse_us_address(pod.expected_address).unit or "")
    if len(unit) < 2:
        return None
    # 18/10: Luxer en español escribe la unidad con guion ("9590 Eden Road 6-301" para la Apt 6301)
    screens = [re.sub(r"(?<=\d)-(?=\d)", "", p.text or "") for p in photos or []
               if _contains_any(p.text, config.LOCKER_PHOTO_KEYWORDS)]
    if any(re.search(rf"(?<!\d){unit}(?!\d)", t) for t in screens):
        return "same"
    for t in screens:
        # "<número> <calle> <unidad>" en la pantalla ("1100 Hidden Ridge 2094"). 19/10: no el contador de casilleros
        # libres ("3500 Northstar R. 21 available" para la #814: 21 casilleros "Medium" disponibles)
        m = re.search(r"\b\d{3,5}\s+[A-Za-z][A-Za-z .]{2,30}?\s+(\d{2,5})\b(?!\s*ava[il])", t, re.I)
        if m and m.group(1) != unit:
            return "other"
    return None


def _contradicting_fragment(details: Dict[str, Any]) -> bool:
    """Algún número leído de 3+ dígitos que no es parte del número esperado (ni código postal)."""
    expected = [str(details.get("unidad") or ""), str(details.get("casa") or "")]
    expected = [re.sub(r"\D", "", e) for e in expected if e]
    for d in details.get("leidos") or []:
        if len(d) >= 3 and not re.match(r"^7[5-9]\d{3}$", d) and not any(d in e or e in d for e in expected):
            return True
    return False


def _omitted_delivery(pod: PODRecord, results: List[CheckResult], photos: Optional[List[PhotoOCR]] = None):
    """
    (check, explicación) si el albarán se omite de la revisión, si no None. Nunca se omite la marca roja del portal.
    - Por la FACTURACIÓN del portal (entrega en mano, casillero, sala de correo, punto de recogida): se omite siempre
      (pedido de la operación, 01/10/2026).
    - Deducido SOLO de la FOTO (modelo de visión / texto de un kiosco): no oculta un número que no concuerda, dos
      puertas ni una distancia de más de 800 m (casos reales 02/10: trailer 3813 vs 3824 y un POD a 2.192 m que el
      usuario había reportado, ocultos por un falso "cliente" / "casillero" en la foto).
    """
    if is_portal_flagged_false_pod(pod):
        return None
    # Amazon Hub: se reporta siempre. Caso real 04/10 (2650 S Forum Dr): la pantalla del hub en el lobby se tomó como
    # recepción y se omitió como entrega en mano
    if is_amazon_hub(pod, photos):
        return None
    meta = pod.portal_meta or {}
    if _contains_any(pod.billing_type, config.HANDOVER_BILLING_KEYWORDS):
        return "entrega_en_mano", HANDOVER_EXPLANATION
    if not is_amazon_hub(pod, photos) and _contains_any(pod.billing_type, config.PACKAGE_ROOM_BILLING_KEYWORDS):
        return "entrega_en_casillero", LOCKER_EXPLANATION
    if meta.get("handoff_photo"):
        num = next((r for r in results if r.check == "numero_direccion"), None)
        status = (num.details or {}).get("status") if num and num.applicable else None
        if _hard_problem(results) or (not meta.get("handoff_confirmed") and status in NUMBER_PROBLEMS):
            return None
        # Caso real 02/10 (reportado por el usuario): entrega en mano real pero el cartel del buzón dice otro número
        # (OCR "715" con dirección 3751). Un fragmento de 3+ dígitos que no es parte del número esperado contradice
        # la dirección: no se omite.
        # Excepción 02/10: si el número correcto SÍ se ve y el otro solo lo leyó el OCR (sin confirmar por el modelo de
        # visión), es ruido de la foto (teclado, fachada, etiqueta): la entrega en mano se omite igual
        # 10/10: se probó ignorar los números que solo leyó el modelo de visión (caso 1701 N Church St, "123") y escondía
        # 3 errores reales del mismo día (2315 Everton Dr, 1104 Brevito Dr, 1006 Inwood Dr: "entrega en mano" confirmada
        # por error). Este fragmento es la única defensa en esos casos: no se toca
        if (num and num.applicable and status != "two_doors_unconfirmed"
                and _contradicting_fragment(num.details or {})):
            return None
        return "entrega_en_mano", HANDOVER_EXPLANATION
    if is_locker_delivery(pod, photos):
        screen = _locker_screen_unit(pod, photos)
        if screen == "other":
            return None   # 11/10: la pantalla del casillero muestra OTRA unidad: el paquete se asignó a otro vecino
        if _hard_problem(results) and not (screen == "same" and not _gps_problem(results)):
            return None
        if _locker_only_by_vision_type(pod, photos) and any(r.check == "vision_fallida" and r.score > 0 for r in results):
            # 12/10 (caso real 10/10, 327 Mesquite Hill Dr: etiqueta fotografiada dentro del carro): con el tope de
            # consultas, el modelo marcó una foto de casa como "casillero" y no leyó las otras; la omisión tapaba la
            # revisión manual. Si el casillero sale solo del modelo y este falló en alguna foto, queda en Media
            return None
        return "entrega_en_casillero", LOCKER_EXPLANATION
    return None


def score_pod(pod: PODRecord, photos: Optional[List[PhotoOCR]] = None) -> PODRecord:
    """Ejecuta todos los chequeos, guarda check_results, risk_score y priority en el POD."""
    photos = photos or []
    if str(getattr(pod.processing_status, "value", pod.processing_status)) == ProcessingStatusEnum.FAILED.value:
        # Regla 01/10: un albarán que no se pudo extraer (ej. "sin permiso": otra ciudad) no es un POD sin fotos
        r = CheckResult("error_extraccion", config.FAR_NUMBERS_SCORE, 1.0,
                        f"No se pudo extraer el albarán del portal ({(pod.error_message or 'error')[:100]}): "
                        "revisar en el portal.")
        pod.check_results = [r.to_dict()]
        pod.risk_score = combine_scores([r])
        pod.priority = priority_for(pod.risk_score).value
        return pod
    map_check = check_map_screenshot(pod, photos)
    number, dup = _apply_map_confirmation(pod, map_check, check_address_number(pod, photos), check_duplicates(pod))
    if dup.score > 0 and (dup.details or {}).get("compartida_con") and pod.duplicate_matched_photo:
        # 11/10: compartir una captura de mapa o la ficha del lugar en Google Maps con otra unidad del mismo edificio no
        # es error: no muestra ninguna puerta (16 alertas "se confirmó esa puerta", ninguna real). El número de esta
        # unidad se sigue revisando aparte
        shared = _sha256(pod.duplicate_matched_photo)
        mine = next((p for p in photos if shared and _sha256(p.path) == shared), None)
        other_unit = re.sub(r"\D", "", str((dup.details or {}).get("unidad_otra") or ""))
        if mine is not None and (is_map_screenshot(mine.text) or is_place_card(mine.text)
                                 or re.search(COMPLEX_SIGN_RE, mine.text or "", re.I)):
            # Cartel de la entrada del complejo ("RANCHO MIRAGE APARTMENT HOMES", caso 1212 Hidden Rdg apt 1042): normal
            dup = CheckResult(dup.check, 0, dup.weight,
                              f"Captura del mapa / cartel del complejo repetido con el albarán "
                              f"{pod.duplicate_matched_tracking} del mismo edificio (no muestra la puerta).")
        elif (mine is not None and dup.score >= 100 and other_unit
              and not any(re.sub(r"\D", "", n) == other_unit for n in mine.numbers + mine.vision_numbers)):
            # La foto compartida no muestra el número de la otra unidad: no prueba que quedó en esa puerta (a revisar)
            dup = CheckResult(dup.check, config.FAR_NUMBERS_SCORE, dup.weight,
                              f"Foto compartida con el albarán {pod.duplicate_matched_tracking} de otra unidad "
                              f"({(dup.details or {}).get('unidad_otra')}), pero no muestra esa puerta: verificar.",
                              details=dup.details)
    number_seen = map_check.details.get("status") == "match" or number.details.get("status") == "match"
    if dup.score > 0 and (is_package_room_delivery(pod, photos) or is_locker_delivery(pod, photos)):
        # En una sala/casillero/tienda de buzones es normal una foto con paquetes de varias unidades (caso 05/10:
        # sala "SPECIAL DELIVERIES" de Iron Horse Blvd). Regla 01/10 "sin excepciones por foto repetida": también si
        # la otra es OTRA dirección del complejo (06/10: sala de N O'Connor Rd, Buildings 7 y 11 con la del 4459)
        dup = CheckResult(dup.check, 0, dup.weight, f"Foto repetida con el albarán {pod.duplicate_matched_tracking} en la "
                                                    "sala/casillero de paquetería (normal).", applicable=False)
    if number_seen and dup.score > 0:
        # 06/10: también con foto compartida con otra unidad: si ESTA puerta se ve y concuerda, la foto repetida es la
        # del edificio/locker (casos 06/10: 5302 Carnaby Apt 207 y 5308 Apt 125). El 38/40 sigue: el 38 no se veía.
        # Regla general 06/10 (casos 05/10: 2608 Salmon St; 3947/3825/3983 N O'Connor Rd con el cartel de "Las Colinas
        # Heights"): si la puerta confirma la dirección, una foto repetida en otro albarán (cartel, entrada, oficina) no
        # es error. Si la foto repetida fuera la de ESTA puerta usada en otra dirección, el error lo marca el otro albarán.
        dup = CheckResult(dup.check, 0, dup.weight,
                          f"Foto repetida con el albarán {pod.duplicate_matched_tracking}, pero el número de la puerta "
                          "concuerda: no suma riesgo.", applicable=False, details=dup.details)
    results = [
        check_portal_false_pod(pod),
        number,
        check_photo_count(pod),
        check_label_photos(pod, photos, number_seen=number_seen),
        check_building_photos(pod, photos, number_seen=number_seen),
        dup,
        map_check,
        check_gps_distance(pod, number_match=number.applicable and (number.details or {}).get("status") == "match"),
        check_image_quality(pod, photos, number_seen=number_seen),
        check_platform_flag(pod),
        check_amazon_hub(pod, photos),
        # Si el número ya quedó confirmado, que el modelo no lea OTRA foto no importa
        check_vision_failure([] if number_seen else photos),
    ]
    pod.check_results = [r.to_dict() for r in results]
    pod.risk_score = combine_scores(results)
    omit = _omitted_delivery(pod, results, photos)
    if omit:
        # Reglas de la operación: entregas en mano o en casillero no se revisan (salvo las excepciones)
        name, why = omit
        pod.check_results.append(CheckResult(name, 0, 0.0, why, applicable=False,
                                             details={"score_sin_regla": pod.risk_score}).to_dict())
        pod.risk_score = 0.0
    pod.priority = PriorityEnum.LOCKERS.value if any(r.check == 'amazon_hub' and r.applicable for r in results) else priority_for(pod.risk_score).value
    return pod


def queue_sort_key(pod: PODRecord):
    """Orden de la cola: POD falso sospechoso del portal primero; luego prioridad y score."""
    order = {"Alta": 0, "Media": 1, "Baja": 2, "Lockers": 3}
    return (0 if is_portal_flagged_false_pod(pod) else 1, order.get(pod.priority or "", 3),
            -(pod.risk_score or 0), pod.tracking_number)


def top_reasons(pod: PODRecord, n: int = 3) -> List[str]:
    """Motivos principales para el revisor (forzados primero, luego por score × peso)."""
    active = [r for r in pod.check_results if r.get("applicable", True) and r.get("score", 0) > 0]
    active.sort(key=lambda r: (not r.get("force_report"), -(r["score"] * r["weight"])))
    return [("[REPORTAR] " if r.get("force_report") else "") + r["explanation"] for r in active[:n]]
