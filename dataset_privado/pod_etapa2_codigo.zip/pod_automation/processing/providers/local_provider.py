"""
Proveedor Local de Análisis de Imágenes basado en OpenCV, Pillow e ImageHash (Fase 5).

Opera 100% de manera autónoma y local, sin llamadas de red ni dependencias de IA externa.
Audita resolución, tamaño, integridad de archivo, iluminación, contraste, nitidez
y calcula hashes criptográficos y perceptuales (dHash, pHash, aHash).

RESTRICCIÓN ÉTICA Y DE PRIVACIDAD:
El sistema NO implementa ni admitirá reconocimiento facial ni identificación
de personas. Solo audita calidad física del comprobante (POD) y evidencia objetiva.
"""

from pathlib import Path
from typing import Optional, Dict, Any, Tuple
import hashlib
import numpy as np
from PIL import Image

try:
    import cv2
    HAS_OPENCV = True
except ImportError:
    HAS_OPENCV = False

try:
    import imagehash
    HAS_IMAGEHASH = True
except ImportError:
    HAS_IMAGEHASH = False

from config import (
    IMAGE_ANALYSIS_CONFIG,
    BLUR_THRESHOLD,
    MIN_BRIGHTNESS,
    MAX_BRIGHTNESS,
    MAX_HAMMING_DISTANCE,
)
from processing.providers.base import (
    BaseImageAnalysisProvider,
    ImageAnalysisResult,
    ImageSimilarityResult,
    ImageHashes,
)


class LocalCVImageProvider(BaseImageAnalysisProvider):
    """
    Proveedor de análisis de calidad de imagen basado en visión computacional clásica
    utilizando OpenCV, Pillow e ImageHash.
    """
    name: str = "LocalCVImageProvider"
    provider_type: str = "local_heuristic"
    is_ai_powered: bool = False

    def __init__(self, config_dict: Optional[Dict[str, Any]] = None):
        self.config = config_dict or IMAGE_ANALYSIS_CONFIG
        self.min_width = self.config.get("MIN_IMAGE_WIDTH", 640)
        self.min_height = self.config.get("MIN_IMAGE_HEIGHT", 480)
        self.min_megapixels = self.config.get("MIN_MEGAPIXELS", 0.3)
        self.min_file_size = self.config.get("MIN_FILE_SIZE_BYTES", 10240)
        self.blur_threshold = self.config.get("BLUR_THRESHOLD", BLUR_THRESHOLD)
        self.min_brightness = self.config.get("MIN_BRIGHTNESS", MIN_BRIGHTNESS)
        self.max_brightness = self.config.get("MAX_BRIGHTNESS", MAX_BRIGHTNESS)
        self.min_contrast = self.config.get("MIN_CONTRAST_STD", 6.0)
        self.max_hamming_dist = self.config.get("MAX_HAMMING_DISTANCE_SIMILAR", MAX_HAMMING_DISTANCE)

        # Verificación estricta de cumplimiento ético
        if self.config.get("ALLOW_FACIAL_RECOGNITION", False):
            raise ValueError("Infracción de política de privacidad: El reconocimiento facial está estrictamente deshabilitado.")

    @staticmethod
    def _compute_sha256(file_path: Path) -> str:
        """Calcula el hash criptográfico SHA-256 de un archivo para detectar duplicados idénticos bit a bit."""
        hasher = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                hasher.update(chunk)
        return hasher.hexdigest()

    def _compute_perceptual_hashes(self, pil_image: Image.Image) -> Tuple[str, str, str]:
        """
        Calcula dHash, pHash y aHash usando imagehash con fallback si no está disponible.
        """
        if HAS_IMAGEHASH:
            dhash_str = str(imagehash.dhash(pil_image))
            phash_str = str(imagehash.phash(pil_image))
            ahash_str = str(imagehash.average_hash(pil_image))
            return dhash_str, phash_str, ahash_str

        # Fallback local de dHash si imagehash no estuviera presente
        rgb_img = pil_image.convert("L").resize((9, 8), Image.Resampling.BILINEAR)
        pixels = np.asarray(rgb_img, dtype=np.float32)
        diff = pixels[:, 1:] > pixels[:, :-1]
        decimal_val = 0
        for bit in diff.flatten():
            decimal_val = (decimal_val << 1) | int(bit)
        dhash_str = f"{decimal_val:016x}"
        return dhash_str, dhash_str, dhash_str

    def _calculate_blur_opencv(self, cv_gray: np.ndarray) -> float:
        """Calcula la varianza del operador Laplaciano con OpenCV."""
        return float(cv2.Laplacian(cv_gray, cv2.CV_64F).var())

    def _calculate_blur_numpy(self, gray_array: np.ndarray) -> float:
        """Fallback en NumPy puro para la varianza del Laplaciano."""
        padded = np.pad(gray_array, pad_width=1, mode="edge")
        laplacian = (
            padded[:-2, 1:-1]
            + padded[2:, 1:-1]
            + padded[1:-1, :-2]
            + padded[1:-1, 2:]
            - 4.0 * gray_array
        )
        return float(np.var(laplacian))

    def compute_hashes(self, file_path: Path) -> ImageHashes:
        """Calcula el conjunto completo de hashes para una imagen dada."""
        path = Path(file_path)
        if not path.exists() or path.stat().st_size == 0:
            return ImageHashes()

        sha256 = self._compute_sha256(path)
        try:
            with Image.open(path) as img:
                dhash, phash, ahash = self._compute_perceptual_hashes(img)
                return ImageHashes(dhash=dhash, phash=phash, ahash=ahash, sha256=sha256)
        except Exception:
            return ImageHashes(sha256=sha256)

    def analyze(self, file_path: Path) -> ImageAnalysisResult:
        """
        Realiza un análisis integral de calidad sobre la fotografía:
        - Resolución y aspect ratio.
        - Tamaño en disco y comprobación de truncamiento.
        - Integridad de archivo / detección de corrupción.
        - Brillo y detección de sub/sobreexposición.
        - Contraste y detección de cámara tapada.
        - Nitidez mediante operador Laplaciano.
        - Hashes criptográficos y perceptuales.
        """
        path = Path(file_path)

        # 1. Validación de existencia y tamaño de archivo
        if not path.exists() or not path.is_file():
            return ImageAnalysisResult(
                file_path=str(path),
                is_corrupted=True,
                error_detail="El archivo no existe en el disco.",
            )

        file_size_bytes = path.stat().st_size
        file_size_kb = round(file_size_bytes / 1024.0, 2)
        is_unusually_small = file_size_bytes < self.min_file_size

        if file_size_bytes == 0:
            return ImageAnalysisResult(
                file_path=str(path),
                file_size_bytes=0,
                file_size_kb=0.0,
                is_unusually_small=True,
                is_corrupted=True,
                error_detail="Archivo de tamaño 0 bytes (vacío o dañado).",
            )

        # 2. Verificación de integridad con Pillow
        try:
            with Image.open(path) as img:
                img.verify()  # Detecta headers rotos y truncamientos
        except Exception as e:
            return ImageAnalysisResult(
                file_path=str(path),
                file_size_bytes=file_size_bytes,
                file_size_kb=file_size_kb,
                is_unusually_small=is_unusually_small,
                is_corrupted=True,
                error_detail=f"Archivo de imagen corrupto o inválido: {str(e)}",
            )

        # 3. Decodificación y métricas visuales con Pillow y OpenCV
        try:
            with Image.open(path) as img:
                width, height = img.size
                aspect_ratio = round(width / height, 2) if height > 0 else 0.0
                megapixels = round((width * height) / 1_000_000.0, 2)
                is_low_res = (
                    width < self.min_width
                    or height < self.min_height
                    or megapixels < self.min_megapixels
                )

                rgb_img = img.convert("RGB")
                dhash_str, phash_str, ahash_str = self._compute_perceptual_hashes(rgb_img)

            sha256_hash = self._compute_sha256(path)
            hashes = ImageHashes(
                dhash=dhash_str,
                phash=phash_str,
                ahash=ahash_str,
                sha256=sha256_hash,
            )

            # Matriz de luminancia estándar Y = 0.299R + 0.587G + 0.114B
            rgb_arr = np.array(rgb_img, dtype=np.float32)
            gray_arr = 0.299 * rgb_arr[:, :, 0] + 0.587 * rgb_arr[:, :, 1] + 0.114 * rgb_arr[:, :, 2]

            mean_brightness = float(np.mean(gray_arr))
            std_contrast = float(np.std(gray_arr))

            # Nitidez (Laplaciano)
            if HAS_OPENCV:
                cv_img = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
                if cv_img is not None:
                    blur_score = self._calculate_blur_opencv(cv_img)
                else:
                    blur_score = self._calculate_blur_numpy(gray_arr)
            else:
                blur_score = self._calculate_blur_numpy(gray_arr)

            # Clasificaciones locales
            is_dark = mean_brightness < self.min_brightness
            is_overexposed = mean_brightness > self.max_brightness
            is_blurry = blur_score < self.blur_threshold
            is_blank_or_covered = std_contrast < self.min_contrast

            return ImageAnalysisResult(
                file_path=str(path),
                width=width,
                height=height,
                megapixels=megapixels,
                aspect_ratio=aspect_ratio,
                is_low_resolution=is_low_res,
                file_size_bytes=file_size_bytes,
                file_size_kb=file_size_kb,
                is_unusually_small=is_unusually_small,
                is_corrupted=False,
                error_detail="",
                mean_brightness=round(mean_brightness, 2),
                is_dark=is_dark,
                is_overexposed=is_overexposed,
                blur_score=round(blur_score, 2),
                is_blurry=is_blurry,
                std_contrast=round(std_contrast, 2),
                is_blank_or_covered=is_blank_or_covered,
                hashes=hashes,
            )

        except Exception as e:
            return ImageAnalysisResult(
                file_path=str(path),
                file_size_bytes=file_size_bytes,
                file_size_kb=file_size_kb,
                is_unusually_small=is_unusually_small,
                is_corrupted=True,
                error_detail=f"Error durante el análisis visual: {str(e)}",
            )

    def compare_similarity(
        self,
        file_path1: Path,
        file_path2: Path,
        max_hamming_distance: Optional[int] = None,
    ) -> ImageSimilarityResult:
        """
        Compara dos imágenes locales determinando si son idénticas o muy similares.
        
        Evaluación:
        - Si SHA-256 coincide -> 100% IDÉNTICAS (mismo archivo).
        - Si dHash o pHash tienen distancia Hamming == 0 -> IDÉNTICAS visualmente.
        - Si distancia Hamming <= max_hamming_distance -> MUY SIMILARES (reutilización / posible duplicado).
        """
        p1 = Path(file_path1)
        p2 = Path(file_path2)
        threshold = max_hamming_distance if max_hamming_distance is not None else self.max_hamming_dist

        hashes1 = self.compute_hashes(p1)
        hashes2 = self.compute_hashes(p2)

        # 1. Comprobación de archivo idéntico bit a bit
        if hashes1.sha256 and hashes1.sha256 == hashes2.sha256:
            return ImageSimilarityResult(
                file_path1=str(p1),
                file_path2=str(p2),
                is_identical=True,
                is_similar=True,
                dhash_distance=0,
                phash_distance=0,
                ahash_distance=0,
                similarity_type="identical",
                confidence_score=1.0,
                details="Archivos binariamente idénticos (mismo SHA-256).",
            )

        # 2. Distancia Hamming perceptual
        def _calc_hamming(h1_str: str, h2_str: str) -> int:
            if not h1_str or not h2_str:
                return 64
            if HAS_IMAGEHASH:
                try:
                    h1 = imagehash.hex_to_hash(h1_str)
                    h2 = imagehash.hex_to_hash(h2_str)
                    return h1 - h2
                except Exception:
                    pass
            try:
                val1 = int(h1_str, 16)
                val2 = int(h2_str, 16)
                return bin(val1 ^ val2).count("1")
            except Exception:
                return 64

        d_dist = _calc_hamming(hashes1.dhash, hashes2.dhash)
        p_dist = _calc_hamming(hashes1.phash, hashes2.phash)
        a_dist = _calc_hamming(hashes1.ahash, hashes2.ahash)

        min_dist = min(d_dist, p_dist)

        if min_dist == 0:
            return ImageSimilarityResult(
                file_path1=str(p1),
                file_path2=str(p2),
                is_identical=True,
                is_similar=True,
                dhash_distance=d_dist,
                phash_distance=p_dist,
                ahash_distance=a_dist,
                similarity_type="identical",
                confidence_score=1.0,
                details="Imágenes visualmente idénticas (Distancia Hamming = 0).",
            )
        elif min_dist <= threshold:
            confidence = round(1.0 - (min_dist / 64.0), 3)
            return ImageSimilarityResult(
                file_path1=str(p1),
                file_path2=str(p2),
                is_identical=False,
                is_similar=True,
                dhash_distance=d_dist,
                phash_distance=p_dist,
                ahash_distance=a_dist,
                similarity_type="highly_similar",
                confidence_score=confidence,
                details=f"Imágenes altamente similares (Distancia Hamming mínima = {min_dist} <= {threshold}).",
            )
        else:
            confidence = round(1.0 - (min_dist / 64.0), 3)
            return ImageSimilarityResult(
                file_path1=str(p1),
                file_path2=str(p2),
                is_identical=False,
                is_similar=False,
                dhash_distance=d_dist,
                phash_distance=p_dist,
                ahash_distance=a_dist,
                similarity_type="different",
                confidence_score=confidence,
                details=f"Imágenes distintas (Distancia Hamming mínima = {min_dist} > {threshold}).",
            )
