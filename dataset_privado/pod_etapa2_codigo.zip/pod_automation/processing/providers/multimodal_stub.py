"""
Proveedor Stub para Modelos Multimodales o Servicios Cloud Futuros (Fase 5).

Proporciona la base de integración preparada para conectar en el futuro modelos
multimodales autorizados (como Google Gemini o Vision APIs empresariales) sin
romper la arquitectura ni depender obligatoriamente de servicios externos.

RESTRICCIÓN ÉTICA Y DE PRIVACIDAD:
El sistema NO implementa ni admitirá reconocimiento facial ni identificación
de personas. Solo audita calidad física del comprobante (POD) y evidencia objetiva.
"""

from pathlib import Path
from typing import Optional, Dict, Any
import logging

from processing.providers.base import (
    BaseImageAnalysisProvider,
    ImageAnalysisResult,
    ImageSimilarityResult,
    ImageHashes,
)
from processing.providers.local_provider import LocalCVImageProvider

logger = logging.getLogger("pod_automation.multimodal_stub")


class MultimodalAIStubProvider(BaseImageAnalysisProvider):
    """
    Proveedor preparado para futura integración con modelos de IA Multimodal autorizados.
    
    Por diseño:
    - Opera con fallback automático al proveedor local si no hay credenciales o conexión.
    - Respeta estrictamente la política de privacidad (cero reconocimiento facial).
    """
    name: str = "MultimodalAIStubProvider"
    provider_type: str = "multimodal_ai"
    is_ai_powered: bool = True

    def __init__(
        self,
        api_key: Optional[str] = None,
        model_name: str = "gemini-2.0-flash",
        config_dict: Optional[Dict[str, Any]] = None,
    ):
        self.api_key = api_key
        self.model_name = model_name
        self.config = config_dict or {}
        # Proveedor local como fallback transparente
        self._fallback_provider = LocalCVImageProvider(self.config)

        # Salvaguarda ética estricta
        if self.config.get("ALLOW_FACIAL_RECOGNITION", False):
            raise ValueError("Infracción de política de privacidad: El reconocimiento facial está estrictamente prohibido.")

    @property
    def is_configured(self) -> bool:
        """Indica si el proveedor cuenta con credenciales activas para operar con la nube."""
        return bool(self.api_key and self.api_key.strip())

    def analyze(self, file_path: Path) -> ImageAnalysisResult:
        """
        Analiza una imagen mediante el modelo multimodal autorizado.
        Si no hay API key configurada, delega limpiamente al proveedor local.
        """
        # Ejecuta análisis físico base con el motor local
        base_result = self._fallback_provider.analyze(file_path)

        if not self.is_configured:
            base_result.metadata["ai_provider_status"] = "offline_local_fallback"
            base_result.metadata["ai_model"] = self.model_name
            return base_result

        # En el futuro, aquí se inyectará la llamada al cliente oficial de Gemini / Vision API
        base_result.metadata["ai_provider_status"] = "ai_enhanced_mock"
        base_result.metadata["ai_model"] = self.model_name
        base_result.metadata["evidence_tags"] = ["package_detected", "doorstep"]
        return base_result

    def compare_similarity(
        self,
        file_path1: Path,
        file_path2: Path,
        max_hamming_distance: int = 5,
    ) -> ImageSimilarityResult:
        """Compara la similitud de dos imágenes delegando al motor perceptual local."""
        return self._fallback_provider.compare_similarity(
            file_path1,
            file_path2,
            max_hamming_distance=max_hamming_distance,
        )

    def compute_hashes(self, file_path: Path) -> ImageHashes:
        """Calcula hashes delegando al motor local."""
        return self._fallback_provider.compute_hashes(file_path)
