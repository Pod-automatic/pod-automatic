"""
Interfaz Abstracta y Contratos de Datos para Proveedores de Análisis de Imágenes (Fase 5).

Diseñado para soportar múltiples proveedores (Local OpenCV/Pillow/ImageHash,
y futuros modelos multimodales autorizados) bajo una misma interfaz uniforme.

RESTRICCIÓN ÉTICA Y DE PRIVACIDAD:
El sistema NO implementa ni admitirá reconocimiento facial ni identificación
de personas. Solo audita calidad física del comprobante (POD) y evidencia objetiva.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, Dict, Any

from models.pod import ImageQualityMetrics


@dataclass
class ImageHashes:
    """Conjunto de hashes criptográficos y perceptuales de una fotografía."""
    dhash: str = ""    # Difference Hash (sensible a gradientes de luminosidad)
    phash: str = ""    # Perceptual Hash (basado en Transformada de Coseno Discreta - DCT)
    ahash: str = ""    # Average Hash (basado en niveles promedio de bits)
    sha256: str = ""   # Hash criptográfico de integridad bit a bit


@dataclass
class ImageSimilarityResult:
    """Resultado de la comparación de similitud visual entre dos fotografías."""
    file_path1: str
    file_path2: str
    is_identical: bool = False           # Exactamente idéntica (SHA-256 o dHash/pHash dist == 0)
    is_similar: bool = False             # Visualmente casi idéntica (distancia Hamming <= umbral)
    dhash_distance: int = 64             # Distancia de Hamming para dHash (0 = idéntica)
    phash_distance: int = 64             # Distancia de Hamming para pHash (0 = idéntica)
    ahash_distance: int = 64             # Distancia de Hamming para aHash (0 = idéntica)
    similarity_type: str = "different"   # "identical", "highly_similar", "different"
    confidence_score: float = 0.0        # 0.0 (distintas) a 1.0 (idénticas)
    details: str = ""


@dataclass
class ImageAnalysisResult:
    """Resultado integral del análisis de calidad de una fotografía de comprobante."""
    file_path: str
    width: int = 0
    height: int = 0
    megapixels: float = 0.0
    aspect_ratio: float = 0.0
    is_low_resolution: bool = False

    file_size_bytes: int = 0
    file_size_kb: float = 0.0
    is_unusually_small: bool = False

    is_corrupted: bool = False
    error_detail: str = ""

    mean_brightness: float = 0.0
    is_dark: bool = False
    is_overexposed: bool = False

    blur_score: float = 0.0
    is_blurry: bool = False

    std_contrast: float = 0.0
    is_blank_or_covered: bool = False

    hashes: ImageHashes = field(default_factory=ImageHashes)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_metrics(self) -> ImageQualityMetrics:
        """Convierte el resultado al dataclass unificado ImageQualityMetrics del modelo POD."""
        return ImageQualityMetrics(
            file_path=self.file_path,
            width=self.width,
            height=self.height,
            file_size_bytes=self.file_size_bytes,
            file_size_kb=self.file_size_kb,
            aspect_ratio=round(self.aspect_ratio, 2),
            megapixels=round(self.megapixels, 2),
            blur_score=round(self.blur_score, 2),
            mean_brightness=round(self.mean_brightness, 2),
            std_contrast=round(self.std_contrast, 2),
            perceptual_hash=self.hashes.dhash,
            phash=self.hashes.phash,
            ahash=self.hashes.ahash,
            sha256=self.hashes.sha256,
            is_blurry=self.is_blurry,
            is_dark=self.is_dark,
            is_overexposed=self.is_overexposed,
            is_blank_or_covered=self.is_blank_or_covered,
            is_low_resolution=self.is_low_resolution,
            is_corrupted=self.is_corrupted,
            error_detail=self.error_detail,
        )


class BaseImageAnalysisProvider(ABC):
    """
    Contrato base abstracto para cualquier motor de análisis de imágenes.
    
    Permite intercambiar el motor local por uno multimodal o cloud sin
    modificar la lógica de negocio ni los flujos de validación.
    """
    name: str = "BaseProvider"
    provider_type: str = "abstract"
    is_ai_powered: bool = False

    @abstractmethod
    def analyze(self, file_path: Path) -> ImageAnalysisResult:
        """Realiza un análisis integral de calidad sobre la fotografía especificada."""
        pass

    @abstractmethod
    def compare_similarity(
        self,
        file_path1: Path,
        file_path2: Path,
        max_hamming_distance: int = 5,
    ) -> ImageSimilarityResult:
        """Compara dos imágenes y determina si son idénticas o muy similares."""
        pass

    @abstractmethod
    def compute_hashes(self, file_path: Path) -> ImageHashes:
        """Calcula el conjunto de hashes criptográficos y perceptuales de la imagen."""
        pass
