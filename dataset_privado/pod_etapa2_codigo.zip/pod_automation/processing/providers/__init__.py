"""
Paquete de Proveedores de Análisis de Imágenes y Visión Computacional (Fase 5).

Proporciona abstracciones y proveedores concretos para auditar fotografías POD.
"""

from processing.providers.base import (
    BaseImageAnalysisProvider,
    ImageAnalysisResult,
    ImageSimilarityResult,
    ImageHashes,
)
from processing.providers.local_provider import LocalCVImageProvider
from processing.providers.multimodal_stub import MultimodalAIStubProvider

__all__ = [
    "BaseImageAnalysisProvider",
    "ImageAnalysisResult",
    "ImageSimilarityResult",
    "ImageHashes",
    "LocalCVImageProvider",
    "MultimodalAIStubProvider",
]
