"""
Etapa de análisis y score desacoplada de la extracción.

El OCR es lo más caro (CPU/GPU) y no toca el portal, así que corre en un proceso aparte
mientras la extracción sigue con su propio ritmo de cortesía. El resto del análisis
(calidad de imagen, duplicados, score) se hace en el proceso principal al recibir el OCR,
para que el detector de duplicados vea todos los albaranes en orden y sin carreras.
"""

import logging
import os
import re
import time
from concurrent.futures import Future, ProcessPoolExecutor, wait, FIRST_COMPLETED
from typing import Callable, Dict, List, Optional

import config
from storage.analysis_cache import cached_photo_batch
from models.pod import PODRecord, ProcessingStatusEnum
from processing import ocr_address
from processing.ocr_address import PhotoOCR, ocr_photo

logger = logging.getLogger("PODAutomation.Pipeline")


# "mismatch" incluido: una lectura errónea del OCR (218 leído como 210) no debe llegar sola a prioridad Alta
# 02/10: "otra puerta" y "casa vecina" solo van a Alta si el modelo de visión confirma el otro número: hay que leerlo
DOUBTFUL_STATUSES = ("not_visible", "far_numbers", "partial", "near_match", "mismatch", "two_doors",
                     "two_doors_unconfirmed", "mismatch_unconfirmed", "neighbor_digit")


OCR_CAP_MSG = "tope de tiempo del OCR: revisar a mano"


def _ocr_capped(photos) -> bool:
    return any(getattr(p, "vision_error", None) == OCR_CAP_MSG for p in photos or [])


@cached_photo_batch
def ocr_photos(paths: List[str], expected_address: Optional[str] = None) -> List[PhotoOCR]:
    """
    Función de nivel módulo (serializable) que ejecuta el proceso de OCR.
    Si con el OCR el número queda dudoso, pide una segunda opinión al modelo de visión local.
    """
    from processing import vision_llm
    vision_llm.reset_stats()
    stages = {}
    t = time.perf_counter()
    budget = config.OCR_POD_BUDGET_S
    ocr_address.OCR_DEADLINE["t"] = t + budget if budget else 0.0
    photos = []
    try:
        for p in paths:
            if budget and time.perf_counter() - t > budget:
                photos.append(PhotoOCR(path=str(p), error="tope de tiempo del OCR"))
            else:
                photos.append(ocr_photo(p))
    finally:
        ocr_address.OCR_DEADLINE["t"] = 0.0
    stages["ocr"] = time.perf_counter() - t
    ocr_capped = bool(budget and stages["ocr"] > budget)
    if ocr_capped:
        # 29/10: mismo trato que el tope del modelo de visión: sin más consultas y a revisión manual (nunca Baja)
        stages["tope_ocr"] = 1
    vision_llm.start_capped()
    try:
        if expected_address and config.VISION_ENABLED and not ocr_capped:
            t = time.perf_counter()
            photos = add_vision_opinion(photos, expected_address)
            stages["vision"] = time.perf_counter() - t
        if expected_address and not ocr_capped:
            t = time.perf_counter()
            photos = confirm_doubtful_number(photos, expected_address)
            photos = drop_numbers_on_packages(photos, expected_address)
            stages["confirmacion"] = time.perf_counter() - t
    finally:
        capped = vision_llm.stop_capped()
    if capped or ocr_capped:
        # 10/10: tope de consultas sin resolver -> revisión manual (check vision_fallida = Media; nunca Baja)
        # 29/10: también cuando se pasó el tope de tiempo del OCR
        if capped:
            stages["tope_vision"] = 1
        from processing.ocr_address import parse_us_address
        address = parse_us_address(expected_address)
        readable = [p for p in photos if not p.is_label and not p.error]
        if ocr_capped:
            target = readable[0] if readable else (photos[0] if photos else None)   # El tope de OCR siempre deja marca
        else:
            # 29/10: entrega en la sala de paquetes de un apartamento: el número no se exige, así que dudas sin resolver sobre
            # otras fotos tampoco cambian el resultado y el tope del modelo no deja marca (un número en conflicto lo sigue
            # marcando check_address_number). En casas sí se marca: ahí estaban los errores reales.
            in_sala = any(_sala_photo_of_apartment(p, address) for p in photos)
            target = None if in_sala else (readable[0] if readable else (photos[0] if photos else None))
        if target is not None and (ocr_capped or not target.vision_error):
            target.vision_error = OCR_CAP_MSG if ocr_capped else "tope de consultas/tiempo del modelo: revisar a mano"
    stages.update(vision_llm.STATS)
    LAST_STAGES.clear()
    LAST_STAGES.update(stages)
    return photos


# Tiempos por etapa del último albarán analizado en este proceso (02/10: medir antes de optimizar)
LAST_STAGES: Dict[str, float] = {}


# 03/10: también cuando no se leyó ningún número o solo el edificio (verticales, de lado, bordillos de cabeza)
DOUBT_FOR_REREAD = ("near_match", "mismatch", "partial_read", "far_numbers", "not_visible", "partial",
                    "mismatch_unconfirmed", "two_doors_unconfirmed", "neighbor_digit")


def label_text_free(path: str) -> bool:
    """True si una lectura ampliada de la foto NO muestra texto de etiqueta (GOFO, SHIP TO, tracking GFUS…)."""
    from processing.ocr_address import LABEL_KEYWORDS, TRACKING_RE, GOFO_RE, _paddle_readtext
    try:
        text = " ".join(t for _, t, _ in _paddle_readtext(path, upscale=2)[0]).upper()
    except Exception:
        return False   # Sin poder comprobarlo, no se usa (precisión primero)
    return not (any(k in text for k in LABEL_KEYWORDS) or TRACKING_RE.search(text) or GOFO_RE.search(text))


STRIP_STATUSES = ("partial_read", "not_visible", "partial", "far_numbers")
# 08/10: la relectura girada con Paddle (~11-16 s por foto) era ~15 % del tiempo de la corrida. Medido con los 321 del
# 07/10: con número NO leído o solo carteles lejanos no cambió ningún resultado (la franja vertical y el modelo de visión
# ya cubren esos casos); sí sirve con un número casi igual o distinto (confirma la puerta vecina o corrige el OCR).
# Saltarla aquí nunca esconde un error: solo podía pasar un Media a Baja.
NO_REREAD_STATUSES = ("not_visible", "far_numbers")


def strip_vision_numbers(path: str, reader=None) -> List[str]:
    """Números que lee el modelo de visión en las franjas verticales de dígitos de la foto (digit_column_crops)."""
    import tempfile
    from processing.ocr_address import digit_column_crops
    if reader is None:
        from processing.vision_llm import read_photo as reader
    out: List[str] = []
    tmpdir = config.STORAGE_DIR / "tmp_reread"
    tmpdir.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=tmpdir) as td:
        for i, crop in enumerate(digit_column_crops(path)):
            f = os.path.join(td, f"franja{i}.jpg")
            crop.save(f, quality=95)
            r = reader(f)
            if not r.error:
                out += ["".join(ch for ch in str(n) if ch.isdigit()) for n in r.numbers]
    return [n for n in out if n]


def _sala_photo_of_apartment(photo: PhotoOCR, address) -> bool:
    """
    29/10: foto que el modelo ya clasificó como sala de paquetes o casillero, en una dirección con número de unidad (oficina de
    paquetes de un complejo). Ahí el número no se exige y esa foto ni cuenta para puntuarlo, así que releerla solo gasta el tope
    de consultas y deja una "revisión manual" falsa (6903 y 6919 State Highway 161, 24-37 s cada uno). En casas NO aplica: las 9
    entregas "en sala" reportadas como error real del historial eran casas sin unidad.
    """
    return config.SALA_APARTMENT_NO_CAP and bool(address.unit) and photo.photo_type in ("package_room", "locker")


def confirm_doubtful_number(photos: List[PhotoOCR], expected_address: str, rereader=None,
                            rotated_reader=None, strip_reader=None) -> List[PhotoOCR]:
    """
    Número dudoso (un dígito distinto, incompleto, otro número o carteles chicos): relee cada foto que no es etiqueta
    girada y ampliada (reread_numbers). Si alguna relectura da el número esperado, queda confirmado (lectura
    alternativa). Si las relecturas repiten con claridad el MISMO número distinto, se sube su confianza: es la casa
    vecina de verdad (caso 2603 -> la puerta dice 2607). Casos reales 01/10: 3229, 3122, 6645, 2024, 1552, 707, 3408.
    """
    from processing.ocr_address import _digits, match_numbers, parse_us_address, reread_numbers
    address = parse_us_address(expected_address)
    if not address.house_number:
        return photos
    m = match_numbers(address, photos)
    if m.status not in DOUBT_FOR_REREAD:
        return photos
    # Casillero/kiosco visible: el albarán se omite igual, no vale la pena releer (un Luxer tardó 15 min el 01/10)
    if any(any(k in (p.text or "").lower() for k in config.LOCKER_PHOTO_KEYWORDS) for p in photos):
        return photos
    target = address.expected_numbers()["unit" if address.is_apartment else "house"]
    one_off = lambda n: any(len(n) == len(t) and sum(a != b for a, b in zip(n, t)) == 1 for t in target)
    deadline = time.monotonic() + config.CONFIRM_MAX_SECONDS
    rereader = rereader or reread_numbers
    for p in photos:
        if _sala_photo_of_apartment(p, address):
            continue
        # Foto que SOLO el modelo de visión llamó "etiqueta" (sin QR ni texto de etiqueta): puede ser el número pintado en
        # el cordón (caso 05/10: 2704 Meadow Creek). Se relee, pero solo vale si no aparece texto de etiqueta.
        vision_only_label = p.is_label and getattr(p, "vision_label", False) and not p.label_tracking
        if (p.is_label and not vision_only_label) or p.error:
            continue
        # 06/10: dígitos apilados en vertical que el OCR lee incompletos (casos 05/10: 6644 con el último 4 más chico,
        # 3121 con los dígitos muy separados): franja vertical alrededor de cada dígito suelto, leída derecha por el
        # modelo de visión. Solo confirma el número esperado (el modelo no lo conoce) y nunca en una etiqueta.
        # Va ANTES de la relectura girada (~20 s por foto): con el 3121 la franja de la 2.ª foto llegaba tarde al tope.
        if (not vision_only_label and m.status in STRIP_STATUSES and config.VISION_ENABLED and config.STRIP_VISION_ENABLED
                and time.monotonic() < deadline):
            strip_hits = [n for n in (strip_reader or strip_vision_numbers)(p.path) if n in target]
            if strip_hits and label_text_free(p.path):
                p.alt_numbers = list(p.alt_numbers or []) + [strip_hits[0]]
                continue
        if m.status in NO_REREAD_STATUSES and not vision_only_label:
            # 08/10: ver NO_REREAD_STATUSES (relectura girada ~11-16 s por foto sin cambiar el resultado). Las fotos que
            # SOLO el modelo llamó "etiqueta" se releen igual: número pintado en el cordón (caso 05/10: 2704 Meadow Creek)
            continue
        if time.monotonic() > deadline:
            # 12/10: la relectura ampliada de Paddle (11-16 s por foto) no respetaba el tope: confirmaciones de 50-60 s.
            # Cortarla no esconde nada: el número queda dudoso (Media), nunca Baja
            continue
        reads = rereader(p.path)
        hits = [n for n, _ in reads if n in target or n.lstrip("0") in target]
        if hits and vision_only_label and not label_text_free(p.path):
            continue   # Es una etiqueta de verdad: leyó la dirección impresa
        if hits:
            p.alt_numbers = list(p.alt_numbers or []) + [hits[0]]
            continue
        if vision_only_label:
            continue
        # Número distinto leído SOLO por el modelo (ej. 2607 vertical): se le pregunta otra vez con la foto girada.
        # Si en 2 de 3 giros repite exactamente ese número, es una lectura confiable (casa vecina).
        # Solo números a UN dígito del esperado (posible casa vecina): un albarán tardó 22 min preguntando por todos.
        # Tope de tiempo por albarán (02/10: uno tardó 25 min con la GPU llena)
        for n in list(p.vision_numbers or []):
            if n in target or not one_off(n) or time.monotonic() > deadline:
                continue
            if config.VISION_ENABLED and _vision_repeats(p.path, n, rotated_reader, expected=target):
                p.vision_numbers.remove(n)
                p.number_conf[n] = max(p.number_conf.get(n, 0.0), config.OCR_STRONG_CONFIDENCE)
        for n, c in reads:
            if n in m.seen and c >= config.OCR_STRONG_CONFIDENCE and any(len(n) == len(t) for t in target):
                # La relectura confirma con claridad el número distinto que ya se había leído
                p.number_conf[n] = max(p.number_conf.get(n, 0.0), c)
                if n not in p.numbers:
                    p.numbers.append(n)
                if n in (p.vision_numbers or []):
                    p.vision_numbers.remove(n)   # Ya no lo lee "solo el modelo": el OCR lo confirmó
    return photos


PACKAGE_NUMBER_STATUSES = ("mismatch", "two_doors", "wrong_building", "two_doors_unconfirmed", "mismatch_unconfirmed",
                           "neighbor_digit")


NOT_A_DOOR = ("package", "label", "bin", "vehicle")


def drop_numbers_on_packages(photos: List[PhotoOCR], expected_address: str, asker=None, max_asks: int = 3) -> List[PhotoOCR]:
    """
    06/10: un número que no concuerda (y haría Alta) puede estar ESCRITO EN UNA CAJA o en una etiqueta, no en la casa
    (casos: "113" a mano en la caja de 610 Nightshade Dr; "XU-1340-…" impreso en la caja de 1935 Stamp Rd). Se le
    pregunta al modelo DÓNDE está ese número (puerta / pared / buzón / bordillo / caja / etiqueta / otro): 8 de 8 bien
    en la prueba (cajas, placas, puertas y buzones). Si está en una caja o etiqueta, deja de contar como puerta.
    """
    from processing.ocr_address import _digits, match_numbers, parse_us_address
    address = parse_us_address(expected_address)
    if not address.house_number or not config.VISION_ENABLED:
        return photos
    if match_numbers(address, photos).status not in PACKAGE_NUMBER_STATUSES:
        return photos
    if asker is None:
        from processing.vision_llm import number_location as asker
    expected = set().union(*address.expected_numbers().values())
    asks = 0
    for p in photos:
        if p.is_label or p.error:
            continue
        for n in list(p.numbers or []):
            d = _digits(n)
            if len(d) < 2 or d in expected or asks >= max_asks:
                continue
            asks += 1
            # 30/10: también en un contenedor de basura o un vehículo (pregunta sin tope de consultas)
            if asker(p.path, d) in NOT_A_DOOR:
                logger.info(f"{p.path}: el número {d} está escrito en una caja/etiqueta/contenedor/vehículo, no es una puerta")
                p.numbers = [x for x in p.numbers if _digits(x) != d]
                p.number_conf.pop(d, None)
                if d in (p.vision_numbers or []):
                    p.vision_numbers.remove(d)
                p.vision_all = [x for x in (p.vision_all or []) if x != d]
    return photos


def _escalate_to_fallback_model(photos: List[PhotoOCR], checked: List[PhotoOCR], address, fallback_reader) -> None:
    """
    25/10 (cascada): el modelo normal ya miró y el número sigue sin confirmarse (no se ve, casi coincide, no concuerda...).
    Solo entonces se vuelve a leer con el modelo mayor. Sus números se SUMAN a lo que ya había leído el normal (nunca
    reemplazan ni quitan nada) y la clasificación de la foto (etiqueta, etc.) la sigue decidiendo el primero.
    """
    from processing.ocr_address import match_numbers
    from processing import vision_llm
    if match_numbers(address, photos).status not in DOUBTFUL_STATUSES:
        return
    for p, c in zip(photos, checked):
        if c.is_label or p.is_label or p.error or p.photo_type == "label":
            continue
        vision_llm.STATS["escalaciones"] += 1
        v = fallback_reader(p.path)
        if v.error:
            logger.warning(f"Modelo mayor no disponible para {p.path}: {v.error}")
            continue
        p.vision_used = True
        for n in v.numbers:
            key = "".join(ch for ch in n if ch.isdigit())
            if n not in p.numbers:
                p.numbers.append(n)
                p.vision_numbers.append(n)
            if key and key not in (p.vision_all or []):
                p.vision_all = list(p.vision_all or []) + [key]
            if key:
                p.number_conf[key] = max(p.number_conf.get(key, 0.0), config.VISION_NUMBER_CONFIDENCE)
        if match_numbers(address, photos).status not in DOUBTFUL_STATUSES:
            return   # Ya se confirmó: no hace falta gastar el modelo mayor en las demás fotos


def add_vision_opinion(photos: List[PhotoOCR], expected_address: str, reader=None,
                       rotated_reader=None, fallback_reader=None) -> List[PhotoOCR]:
    """Solo para casos dudosos: el modelo de visión lee números (incluso verticales) y clasifica las fotos."""
    from processing.ocr_address import match_numbers, parse_us_address
    address = parse_us_address(expected_address)
    if not address.house_number:
        return photos
    # Igual que el score: una foto con el nombre de la calle impreso es una etiqueta aunque no se haya
    # detectado su QR. Sin esto, el número impreso en la etiqueta "confirmaba" la dirección y no se pedía
    # la segunda opinión (caso real: "1808" en la etiqueta amarilla; el del bordillo solo lo lee el modelo).
    from processing.scoring import _as_label_if_address_text
    checked = [_as_label_if_address_text(p, address) for p in photos]
    if match_numbers(address, checked).status not in DOUBTFUL_STATUSES:
        return photos
    if reader is None:
        from processing.vision_llm import read_photo as reader
        rotated_reader = rotated_reader or (lambda path, angle: reader(path, angle=angle))
        if fallback_reader is None and config.VISION_FALLBACK_MODEL:
            fallback_reader = lambda path: reader(path, model=config.VISION_FALLBACK_MODEL,
                                                  url=config.VISION_FALLBACK_URL or None)
    for p, c in zip(photos, checked):
        if c.is_label or p.error:
            continue
        v = reader(p.path)
        if v.error:
            logger.warning(f"Modelo de visión no disponible para {p.path}: {v.error}")
            p.vision_error = v.error  # El score lo manda a revisión manual (Media)
            continue
        p.vision_used = True
        if v.photo_type == "label" and _is_painted_house_number(p, v.numbers, address.house_number):
            # Número pintado en la acera / placa blanca: el modelo lo confunde con una etiqueta impresa
            logger.info(f"{p.path}: el modelo dijo 'etiqueta' pero es el número {address.house_number} pintado")
            v.photo_type = "other"
        if (rotated_reader and v.photo_type != "label" and v.numbers
                and _confirmed_by_rotation(p.path, v.numbers, address.house_number, rotated_reader)):
            # Foto muy inclinada: derecha lee mal ("80750"), girada lee el número de la casa varias veces
            logger.info(f"{p.path}: {v.numbers} corregido a {address.house_number} leyendo la foto girada")
            v.numbers = [address.house_number]
        p.photo_type = v.photo_type
        p.vision_all = ["".join(ch for ch in n if ch.isdigit()) for n in v.numbers]
        if v.photo_type == "label":
            p.is_label = True          # Sus números son la dirección impresa: no cuentan
            p.vision_label = True
            p.numbers = []
            continue
        for n in v.numbers:
            if n not in p.numbers:
                p.numbers.append(n)
                p.vision_numbers.append(n)
            # Confianza moderada: una lectura del modelo a 1 dígito queda en "casi coincide", no "vecina"
            key = "".join(ch for ch in n if ch.isdigit())
            if key:
                p.number_conf[key] = max(p.number_conf.get(key, 0.0), config.VISION_NUMBER_CONFIDENCE)
    if fallback_reader:
        _escalate_to_fallback_model(photos, checked, address, fallback_reader)
    return photos


def skip_analysis(pod: PODRecord) -> bool:
    """Tipos de entrega que la operación no revisa: no vale la pena gastar OCR ni modelo de visión."""
    from processing.scoring import is_handover_delivery, is_locker_delivery, is_portal_flagged_false_pod
    return (is_handover_delivery(pod) or is_locker_delivery(pod)) and not is_portal_flagged_false_pod(pod)


def _vision_repeats(path: str, number: str, rotated_reader=None, expected=()) -> bool:
    """
    El modelo repite el número distinto en 2 de 3 giros. 06/10: se miran TODOS los giros y, si en alguno lee el número
    esperado, hay contradicción y no se confirma (caso 4205 Hampshire St: placa en relieve leída 4805, 4205, 4205,
    4206; salió Alta "casa vecina" y era la casa correcta).
    """
    if rotated_reader is None:
        from processing.vision_llm import read_photo
        rotated_reader = lambda pth, angle: read_photo(pth, angle=angle)
    digits = lambda s: "".join(ch for ch in str(s) if ch.isdigit())
    hits, fails = 0, 0
    for angle in config.VISION_ROTATION_ANGLES:
        r = rotated_reader(path, angle)
        if r.error:
            fails += 1
            if fails >= 2:
                return False   # El modelo no responde con esta foto: no seguir esperando
            continue
        seen = {digits(x) for x in r.numbers}
        if any(digits(e) in seen for e in expected or ()):
            return False
        if number in seen:
            hits += 1
    return hits >= config.VISION_ROTATION_MIN_AGREE


def _stage_deadline(function):
    """29/10: la etapa no pasa de HANDOFF_BUDGET_S ni por una consulta ya iniciada. Cortarla solo deja el Alta/Media como estaba."""
    import functools

    @functools.wraps(function)
    def wrapped(*args, **kwargs):
        from processing import vision_llm
        vision_llm.set_deadline(config.HANDOFF_BUDGET_S)
        try:
            return function(*args, **kwargs)
        finally:
            vision_llm.clear_deadline()
    return wrapped


@_stage_deadline
def detect_handoff(pod: PODRecord, photos: List[PhotoOCR], asker=None, reception_asker=None) -> bool:
    """
    Solo para albaranes que quedaron Alta/Media: si una foto muestra a una PERSONA recibiendo el paquete,
    es una entrega en mano aunque el portal diga "En la puerta" (regla de la operación: se omite).
    Caso real GFUS01075278137095: la caja en manos de alguien en una oficina (Suite 150).
    """
    from processing.scoring import is_handover_delivery, is_locker_delivery
    if not config.VISION_ENABLED or pod.priority not in ("Alta", "Media"):
        return False
    if _ocr_capped(photos):   # 29/10: lecturas incompletas por el tope de tiempo: no se puede concluir "entrega en mano" (Baja)
        return False
    if is_handover_delivery(pod) or is_locker_delivery(pod):
        return False
    default_asker = asker is None
    if asker is None:
        from processing.vision_llm import person_receiving_confirmed as asker
    if reception_asker is None and default_asker:
        from processing.vision_llm import reception_desk_confirmed as reception_asker
    from processing.ocr_address import parse_us_address
    from processing.scoring import _as_label_if_address_text, _has_label_text
    address = parse_us_address(pod.expected_address)
    business_or_building = address.is_apartment or bool(re.search(
        r"\b(apt|apartment|unit|ste|suite|pmb|bldg|building|office|lobby|front desk|reception)\b|#",
        pod.expected_address or "", re.I))
    started = time.perf_counter()
    hits = []   # (n.º de foto, confirmada por la pregunta de recepción)
    for i, p in enumerate(photos, 1):
        if config.HANDOFF_BUDGET_S and time.perf_counter() - started > config.HANDOFF_BUDGET_S:
            # 12/10: tope de tiempo. Dejar de preguntar no esconde nada: el albarán queda en su Alta/Media
            pod.portal_meta["handoff_tope"] = True
            return False
        # La mano del repartidor sosteniendo la etiqueta no es un cliente (caso real 02/10: trailer 3813 vs 3824).
        # 04/10: lo que SOLO el modelo llamó "etiqueta" (paquete sobre un mostrador con la etiqueta a la vista) sí se
        # pregunta: ahí estaba la persona de la recepción (casos reales 03/10: Sandra, 6350 Winter Park Dr)
        real_label = p.is_label and (not getattr(p, "vision_label", False) or p.label_tracking
                                     or _has_label_text(p.text))
        if real_label or p.error or (not p.is_label and _as_label_if_address_text(p, address).is_label):
            continue
        # 29/10: hacen falta HANDOFF_MIN_PHOTOS fotos DISTINTAS que lo confirmen (antes bastaba una). Con una sola, el modelo de 3B
        # tomaba por "persona recibiendo" la mano del repartidor con la etiqueta, su reflejo en un vidrio o un paquete solo: en 62
        # albaranes con marca válida, 1 foto omitía 7 de 12 errores reales; 2 fotos, 0 de 12 (a cambio de ~24 de 36 falsas alarmas).
        if asker(p.path):
            hits.append((i, False))
        # La pregunta de recepción SOLO en direcciones de edificio/negocio y nunca en una foto de puerta: el modelo de 3B
        # dijo "recepción" ante la puerta de una casa con un tapete (error real reportado, 4009 Westwind Dr, 04/10)
        elif (reception_asker and business_or_building and p.photo_type != "door"
                and reception_asker(p.path)):
            # Paquete entregado en un mostrador de recepción/oficina/tienda con una persona atendiendo (04/10)
            hits.append((i, True))
        if len(hits) >= max(1, config.HANDOFF_MIN_PHOTOS):
            first, reception = hits[0]
            pod.portal_meta["handoff_photo"] = first
            pod.portal_meta["handoff_confirmed"] = True   # El asker por defecto pide doble confirmación
            if reception:
                pod.portal_meta["handoff_reception"] = True
            if len(hits) > 1:
                pod.portal_meta["handoff_photos"] = [h[0] for h in hits]
            return True
    return False


@_stage_deadline
def detect_package_room(pod: PODRecord, photos: List[PhotoOCR], asker=None, max_photos: int = 3) -> bool:
    """
    06/10: Alta/Media por el número en una SALA de paquetes que no se nombra con palabras (estantes con muchos paquetes;
    caso 3549 Medical Center Dr 3204, cartel de papel "BUILDING 3"). Si el modelo reconoce la sala, esa foto pasa a
    "package_room" y se vuelve a puntuar: la regla de sala la omite, pero un número que no concuerda en las OTRAS fotos
    sigue siendo error (check_address_number excluye solo la foto de la sala).
    """
    from processing.scoring import is_amazon_hub, is_handover_delivery, is_package_room_delivery
    if not config.VISION_ENABLED or pod.priority not in ("Alta", "Media"):
        return False
    if _ocr_capped(photos):   # 29/10: igual que en detect_handoff
        return False
    if is_handover_delivery(pod) or is_amazon_hub(pod, photos) or is_package_room_delivery(pod, photos):
        return False
    number = next((r for r in pod.check_results or [] if r.get("check") == "numero_direccion"), {})
    if not (number.get("applicable", True) and number.get("score", 0) > 0):
        return False   # El Alta/Media es por otra cosa (duplicado, GPS, POD falso): la sala no lo explica
    if asker is None:
        from processing.vision_llm import package_room_confirmed as asker
    asked = 0
    for p in photos:
        if p.is_label or p.error or p.photo_type == "door" or asked >= max_photos:
            continue
        asked += 1
        if asker(p.path):
            p.photo_type = "package_room"
            pod.portal_meta["package_room_photo"] = str(p.path)
            return True
    return False


def _confirmed_by_rotation(path: str, numbers: List[str], house_number: str, rotated_reader) -> bool:
    """
    El modelo leyó un número que NO es el de la casa: se relee la foto girada. Solo se acepta el número de
    la casa si al menos VISION_ROTATION_MIN_AGREE giros lo leen EXACTO (al modelo nunca se le dice cuál es).
    Caso real "8750 Rodeo Dr": derecha "80750"; girada 45/-45/90 grados "8750".
    """
    digits = lambda s: "".join(ch for ch in str(s) if ch.isdigit())
    house = digits(house_number)
    read = {digits(n) for n in numbers}
    if not house or house in read or not any(len(r) >= len(house) - 1 for r in read):
        return False
    hits = 0
    for angle in config.VISION_ROTATION_ANGLES:
        r = rotated_reader(path, angle)
        if not r.error and house in {digits(n) for n in r.numbers}:
            hits += 1
            if hits >= config.VISION_ROTATION_MIN_AGREE:
                return True
    return False


def _is_painted_house_number(photo: PhotoOCR, vision_numbers: List[str], house_number: str) -> bool:
    """
    El modelo leyó EXACTAMENTE el número de la casa y el OCR casi no ve texto en la foto. Una etiqueta real
    deja mucho texto en el OCR (barcode, tracking, remitente: ~30 tokens aunque esté girada), así que
    con pocos tokens es un número pintado o una placa, no una etiqueta.
    """
    digits = lambda s: "".join(ch for ch in str(s) if ch.isdigit())
    if not house_number or digits(house_number) not in {digits(n) for n in vision_numbers}:
        return False
    return not photo.label_tracking and len((photo.text or "").split()) <= config.PAINTED_NUMBER_MAX_OCR_TOKENS


def warm_up_ocr() -> None:
    """Carga el modelo de OCR en el proceso del worker (~30-90 s en frío) antes del primer albarán."""
    if config.OCR_ENGINE == "easyocr":
        from processing.ocr_address import _easyocr_reader
        _easyocr_reader()
    elif config.OCR_ENGINE == "paddle":
        from processing.ocr_address import ensure_paddle_server
        ensure_paddle_server()


def _timed_ocr(ocr_fn, paths: List[str], expected_address: Optional[str]):
    """Corre en el worker: devuelve (fotos, segundos de análisis, tiempos por etapa) sin contar la espera en la cola."""
    if config.ANALYSIS_POOL_DB:
        from automation.gpu_dispatch import gpu_slot
        with gpu_slot(config.ANALYSIS_POOL_DB,[f'analysis-{i}' for i in range(config.ANALYSIS_POOL_SIZE)],600):
            return _run_timed_ocr(ocr_fn,paths,expected_address)
    return _run_timed_ocr(ocr_fn,paths,expected_address)


def _run_timed_ocr(ocr_fn,paths,expected_address):
    LAST_STAGES.clear()
    started = time.perf_counter()
    photos = ocr_fn(paths, expected_address)
    return photos, time.perf_counter() - started, dict(LAST_STAGES)


def format_stages(tracking: str, total: float, stages: Dict[str, float]) -> str:
    parts = [f"{k} {stages[k]:.1f}s" for k in ("ocr", "vision", "confirmacion", "entrega_mano") if k in stages]
    if stages.get("cache_reutilizada"):
        parts.append(f"{int(stages['cache_reutilizada'])} fotos reutilizadas de caché")
    if stages.get("llamadas_vision"):
        parts.append(f"{int(stages['llamadas_vision'])} llamadas a visión ({stages.get('segundos_vision', 0):.1f}s)")
    for k, label in (("sin_gramatica", "reintentos sin gramática"), ("recargas", "recargas del modelo"),
                     ("fallos_servicio", "fallas de Ollama"), ("otra_gpu", "repetidas en la otra GPU")):
        if stages.get(k):
            parts.append(f"{int(stages[k])} {label}")
    return f"Tiempos {tracking}: total {total:.1f}s | " + " | ".join(parts)


class ScoringPipeline:
    """
    submit(pod) encola el OCR; collect() finaliza los que ya terminaron; drain() espera todos.
    on_scored(pod) se llama en el proceso principal con el POD ya validado y puntuado.
    """

    def __init__(
        self,
        validator,
        on_scored: Callable[[PODRecord], None],
        workers: int = None,
        executor=None,
        ocr_fn: Callable[[List[str]], List[PhotoOCR]] = ocr_photos,
        max_pending: int = None,
        tracker=None,
    ):
        self.validator = validator
        self.on_scored = on_scored
        self.ocr_fn = ocr_fn
        self.tracker = tracker
        workers = config.OCR_WORKERS if workers is None else workers
        self.executor = executor or ProcessPoolExecutor(max_workers=max(1, workers))
        if executor is None and ocr_fn is ocr_photos:
            # El modelo se carga mientras la extracción consulta repartidores y listas del portal
            self.executor.submit(warm_up_ocr)
        self.max_pending = max_pending or max(4, workers * 4)
        self.pending: Dict[Future, PODRecord] = {}
        self.stage_totals: Dict[str, float] = {}
        self.analyzed = 0

    def submit(self, pod: PODRecord) -> None:
        # Contrapresión: si el OCR va atrasado, esperar a que se libere lugar. También los omitidos esperan detrás
        # del OCR anterior, así que se limitan ambos caminos.
        while len(self.pending) >= self.max_pending:
            self.collect(block=True)
        if pod.processing_status == ProcessingStatusEnum.FAILED or not pod.photo_paths or skip_analysis(pod):
            # Sala de correo / casillero / punto de recogida / entrega en mano: se omiten al instante, sin OCR
            # ni modelo de visión (el hash de las fotos igual se registra para detectar copias entre albaranes).
            # 25/10: si hay albaranes en OCR delante, este espera su turno (se finaliza en el mismo orden que llegó)
            done = Future()
            done.set_result(None)
            self.pending[done] = pod
            self.collect(block=False)
            return
        self.pending[self.executor.submit(_timed_ocr, self.ocr_fn, list(pod.photo_paths), pod.expected_address)] = pod
        self.collect(block=False)

    def collect(self, block: bool = False) -> int:
        """
        Finaliza los albaranes YA terminados, siempre en el orden en que se enviaron (25/10): con varios procesos de OCR
        terminan en desorden y las comparaciones entre albaranes (fotos repetidas, etiquetas del mismo lugar) daban un
        resultado distinto en cada corrida. El OCR sigue corriendo en paralelo; solo la puntuación espera su turno.
        """
        if not self.pending:
            return 0
        if block:
            wait([next(iter(self.pending))], timeout=None)   # El primero de la fila (el más antiguo)
        n = 0
        while self.pending:
            fut = next(iter(self.pending))
            if not fut.done():
                break
            pod = self.pending.pop(fut)
            n += 1
            try:
                result = fut.result()
                if result is None:   # Se omite sin OCR
                    photos = []
                else:
                    photos, secs, stages = result
                    pod._stages = dict(stages, total=secs)
                    if self.tracker:
                        self.tracker.record(pod.tracking_number, secs, "ANALYZED", stage="analisis")
            except Exception as e:
                logger.warning(f"OCR falló para {pod.tracking_number}: {e}")
                photos = [PhotoOCR(path=p, error=f"OCR falló: {e}") for p in pod.photo_paths]
            self._finalize(pod, photos)
        return n

    def drain(self) -> None:
        while self.pending:
            self.collect(block=True)

    def close(self) -> None:
        self.drain()
        self.executor.shutdown(wait=True)
        self.log_stage_summary()

    def log_stage_summary(self) -> None:
        if not self.analyzed:
            return
        t = self.stage_totals
        parts = [f"{k} {t[k] / self.analyzed:.1f}s" for k in ("total", "ocr", "vision", "confirmacion", "entrega_mano")
                 if k in t]
        logger.info(f"Promedio por albarán analizado ({self.analyzed}): " + " | ".join(parts)
                    + f" | {int(t.get('escalaciones', 0))} lecturas con el modelo mayor, "
                    + f"{int(t.get('llamadas_vision', 0))} llamadas a visión, "
                      f"{int(t.get('sin_gramatica', 0))} reintentos sin gramática, {int(t.get('recargas', 0))} recargas")

    def _finalize(self, pod: PODRecord, photos: List[PhotoOCR]) -> None:
        self.validator.validate_pod(pod, ocr_results=photos)
        from processing import vision_llm
        vision_llm.reset_stats()
        t = time.perf_counter()
        if detect_handoff(pod, photos):
            from processing.scoring import score_pod
            score_pod(pod, photos)   # Vuelve a puntuar: ahora se omite como entrega en mano
        elif detect_package_room(pod, photos):
            from processing.scoring import score_pod
            score_pod(pod, photos)   # 06/10: sala de paquetes reconocida por la escena
        stages = getattr(pod, "_stages", None)
        if stages is not None:
            stages["entrega_mano"] = time.perf_counter() - t
            for k, v in vision_llm.STATS.items():
                stages[k] = stages.get(k, 0) + v
            stages["total"] = stages.get("total", 0) + stages["entrega_mano"]
            for k, v in stages.items():
                self.stage_totals[k] = self.stage_totals.get(k, 0) + v
            self.analyzed += 1
            logger.info(format_stages(pod.tracking_number, stages["total"], stages))
            if self.analyzed % 50 == 0:
                self.log_stage_summary()
        pod._photo_readings = photos   # 30/10: lecturas finales, para el detalle que se manda al portal (portal_sync.detail_blob)
        self.on_scored(pod)
