"""
OCR de las fotos del POD y comparación contra la dirección esperada del albarán.

- parse_us_address(): extrae número de casa y unidad del formato del portal
  ("CIUDAD CIUDAD 505 E Exchange Pkwy Apt 6105 Gate code: 1500# ...").
- ocr_photo(): Tesseract (pytesseract + PIL) sobre la foto; también a 180° para detectar
  etiquetas giradas. Clasifica la foto como etiqueta (label) si encuentra texto típico.
- match_numbers(): compara los números leídos (fuera de etiquetas) contra casa/unidad.

TODO(inspect): cuando se conozca el rol real de cada foto, el OCR de número debería
priorizar la foto de puerta. Hoy se corre sobre todas y se usa el mejor match.
"""

import os
import re
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set

import numpy as np
from PIL import Image, ImageOps, ImageStat

import config
from storage.analysis_cache import cached_photo_reading, track_read_failures

try:
    import cv2
    _QR = cv2.QRCodeDetector()
    _BARCODE = cv2.barcode.BarcodeDetector() if hasattr(cv2, "barcode") else None
    HAS_CV2 = True
except ImportError:  # pragma: no cover
    HAS_CV2 = False

try:
    import pytesseract
    if config.TESSERACT_CMD:
        pytesseract.pytesseract.tesseract_cmd = config.TESSERACT_CMD
    HAS_TESSERACT = True
except ImportError:  # pragma: no cover
    HAS_TESSERACT = False

UNIT_DESIGNATORS = {"apt", "apartment", "unit", "#", "ste", "suite", "bldg", "building", "lot", "rm", "room", "no"}
# Teléfono con "+1" delante y extensión detrás ("+1 210-728-4548 ext. 56399", caso real 03/10: la extensión se tomaba
# como unidad y la casa pasaba a tratarse como apartamento)
PHONE_RE = re.compile(r"(?:\+\s?1[\s.\-]*)?(?:\(?\b\d{3}\)?[\s.\-]\d{3}[\s.\-]\d{4}\b|\b\d{10}\b)"
                      r"(?:\s*(?:ext\.?|extension|x)\s*\d{1,6}\b)?", re.I)
# Códigos postales de Texas (750xx-799xx): leídos en carteles o etiquetas, no son números de casa
TX_ZIP_RE = re.compile(r"^7[5-9]\d{3}$")
# Marcas impresas de la etiqueta de GOFO (12/10): una foto con este texto muestra la etiqueta aunque no se haya marcado así
LABEL_MARK_RE = re.compile(r"GOFO|GFUS\d{6,}|SHIP\s*TO|DFW\.?H|DFW0\d")
NOTE_MARKERS = re.compile(
    r"\b(gate|code|do not|don'?t|leave|call|text|please|deliver|door ?code|access|buzz|front desk|office)\b",
    re.I,
)
LABEL_KEYWORDS = ("SHIP TO", "SHIP FROM", "GOFO", "WEIGHT", "REF:", "GFUS", "FULFILLMENT")
TRACKING_RE = re.compile(r"GFUS\d{10,16}", re.I)
# Letras que el OCR confunde con dígitos dentro de un número

OCR_DIGIT_FIX = str.maketrans({"O": "0", "o": "0", "D": "0", "Q": "0", "I": "1", "l": "1", "|": "1",
                               "i": "1", "S": "5", "s": "5", "B": "8", "Z": "2", "z": "2", "G": "6"})


@dataclass
class ParsedAddress:
    raw: str
    house_number: Optional[str] = None
    unit: Optional[str] = None
    street: str = ""
    # Otro número suelto tras la unidad ("Apt 1102 5203", caso real 09/10: la puerta dice 5203): también vale
    alt_units: List[str] = field(default_factory=list)

    @property
    def is_apartment(self) -> bool:
        return bool(self.unit)

    def expected_numbers(self) -> Dict[str, Set[str]]:
        """Formas aceptadas (solo dígitos) para casa y unidad. '7-205' acepta '7205' y '205'."""
        out: Dict[str, Set[str]] = {"house": set(), "unit": set()}
        if self.house_number:
            out["house"].add(_digits(self.house_number))
        if self.unit:
            out["unit"].add(_digits(self.unit))
            out["unit"].add(_digits(self.unit).lstrip("0"))   # "02" (dirección) == "2" (puerta)
            parts = re.split(r"[-/]", self.unit)
            if len(parts) > 1 and _digits(parts[-1]):
                out["unit"].add(_digits(parts[-1]))
            if "/" in self.unit:
                # "Ste107/502": cualquiera de las dos suites vale (caso real 04/10: la placa dice 107)
                out["unit"].update(_digits(x) for x in parts if len(_digits(x)) >= 2)
            if re.fullmatch(r"\d+[iIl]", self.unit.strip()):
                # "5i" = 51: una i/l escrita en lugar del 1 (caso 06/10: 2413 Meadow Park Cir "#5i 5i", la puerta dice 51)
                out["unit"].add(_digits(self.unit) + "1")
        for alt in self.alt_units:
            out["unit"].add(_digits(alt).lstrip("0"))
        return {k: {v for v in s if v} for k, s in out.items()}


def _digits(s: str) -> str:
    return re.sub(r"\D", "", s or "")


# Vías que llevan número como nombre (zonas rurales de Texas): ese número no es una unidad
# "i": Interstate ("121 E I 20" = I-20; caso real 02/10 hotel de Arlington: el 20 se tomaba como unidad)
ROAD_NUMBER_WORDS = {"cr", "fm", "highway", "hwy", "sh", "us", "ih", "i", "interstate", "route", "rte", "rt", "loop",
                     "spur", "pr", "rr", "tx", "state"}
ROAD_WORDS_NEED_PREFIX = {"road", "rd"}                       # Solo "County Road", "Private Rd", "Ranch Road"...
ROAD_PREFIXES = {"county", "co", "cty", "cnty", "private", "ranch", "farm", "market"}   # "Co Rd 2316" (02/10)
HIGHWAY_WORDS = {"highway", "hwy"}
HIGHWAY_PREFIXES = {"state", "us", "sh", "tx", "business", "bus", "fm", "farm", "ranch"}


def _is_road_number(tokens: List[str], i: int) -> bool:
    prev = tokens[i - 1].lower().rstrip(".") if i > 0 else ""
    before = tokens[i - 2].lower().rstrip(".") if i > 1 else ""
    if prev in HIGHWAY_WORDS:
        # "Hwy 80", "S State Highway 360", "US Hwy 287": numeran la vía. Tras un nombre propio ("6864 N President
        # George Bush Hwy 8403", caso real 10/10) el número final es la unidad
        return not before or before in DIRECTIONALS or before in HIGHWAY_PREFIXES or bool(re.search(r"\d", before))
    if prev in ROAD_NUMBER_WORDS:
        return True
    if not (prev in ROAD_WORDS_NEED_PREFIX and before in ROAD_PREFIXES):
        return False
    # 20/10: "County Road N" siempre numera la vía, aunque la preceda la sigla del condado ("1200 Vz County Road 3119",
    # VZ = Van Zandt; el 3119 se tomaba como unidad y daba Media). El caso "Murray Farm Rd 619" es solo con "farm"
    if before in {"county", "co", "cty", "cnty"}:
        return True
    # El prefijo tiene que EMPEZAR el nombre de la calle ("County Road 889", "E Farm Rd 12"). En "Murray Farm Rd 619"
    # (caso real 05/10) "Farm" es parte de un nombre propio y el 619 es la unidad
    first = tokens[i - 3].lower().rstrip(".") if i > 2 else ""
    return not first or first in DIRECTIONALS or bool(re.search(r"\d", first))


DIRECTIONALS = {"n", "s", "e", "w", "ne", "nw", "se", "sw", "north", "south", "east", "west", "old"}


def _all_zeros(token: str) -> bool:
    d = _digits(token)
    return bool(d) and set(d) == {"0"}


def _address_tokens(text: str) -> List[str]:
    return re.findall(r"[A-Za-z0-9][A-Za-z0-9\-/]*|#", text)


def _first_house_token(tokens: List[str]) -> Optional[int]:
    return next((i for i, t in enumerate(tokens) if re.match(r"^\d+[A-Za-z]?$", t) and not _all_zeros(t)), None)


def parse_us_address(raw: str) -> ParsedAddress:
    """Número de casa = primer token numérico; unidad = tras Apt/Unit/# o número final de la calle."""
    parsed = ParsedAddress(raw=raw or "")
    full = PHONE_RE.sub(" ", raw or "")   # Teléfono escrito en la dirección ("... Ct 214-226-8813"): no es la unidad
    # Número pegado a la calle ("15890Hwy80", caso real 02/10): se separa. No toca los ordinales ("100th", "3rd").
    full = re.sub(r"\b(\d{3,6})(?!st\b|nd\b|rd\b|th\b)([A-Za-z]{2,})", r"\1 \2", full)
    # 25/10: "Apt 316 150 W Main St; Apt 316": la unidad escrita ANTES de la casa. La casa es el segundo número (150) y la
    # unidad el primero (316). Antes se tomaba 316 como casa y el 150 de la foto daba "no concuerda" (Alta 80).
    # Solo si el designador abre la dirección (ningún dígito antes) y tras el segundo número viene la calle (una palabra).
    pre = re.search(r"(?<![A-Za-z0-9])(?:apt|apartment|unit|ste|suite)\.?\s*#?\s*(\d{1,5}[A-Za-z]?)\s+(\d{1,6})\s+(?=[A-Za-z])",
                    full, re.I)
    if (pre and not re.search(r"\d", full[:pre.start()]) and not _all_zeros(pre.group(1))
            and not TX_ZIP_RE.match(pre.group(2))):
        sin_pre = full[:pre.start()] + pre.group(2) + " " + full[pre.end():]
        alt = parse_us_address(sin_pre)
        alt.raw = raw or ""
        if alt.house_number == pre.group(2):
            if not alt.unit:
                alt.unit = pre.group(1)
            elif _digits(alt.unit) != _digits(pre.group(1)) and pre.group(1) not in alt.alt_units:
                alt.alt_units.append(pre.group(1))
            return alt
    text = full
    note = NOTE_MARKERS.search(text)
    if note:
        text = text[:note.start()]
    tokens = _address_tokens(text)
    start = _first_house_token(tokens)
    if start is None and note:
        # Nota del cliente ANTES del número (caso real: "MAKE SURE TO DELIVER TO COURT NOT DRIVE 6513 MEADOW LAKES CT"):
        # la dirección está después de la nota
        tokens = _address_tokens(full[note.start():])
        start = _first_house_token(tokens)
    if start is None:
        return parsed
    parsed.house_number = tokens[start]
    rest = tokens[start + 1:]
    # "Building 4" / "Bldg 4" es el EDIFICIO, no la unidad (caso real 03/10: "4701 14th St 4305, Building 4" -> la unidad
    # es 4305 y se tomaba el 4). Se quita para que la unidad salga del resto de la dirección.
    for i in range(len(rest) - 1, -1, -1):
        if rest[i].lower().rstrip(".") in ("building", "bldg") and i + 1 < len(rest) and re.search(r"\d", rest[i + 1]):
            others = [t for t in rest[:i] if re.search(r"\d", t)] + [t for t in rest[i + 2:] if re.search(r"\d", t)]
            if others:
                rest = rest[:i] + rest[i + 2:]

    for i, t in enumerate(rest):
        if t.lower().rstrip(".") in UNIT_DESIGNATORS and i + 1 < len(rest):
            # "Apt 000 315": un número de solo ceros no significa nada (regla de la operación); vale el siguiente
            cands = [c for c in rest[i + 1:i + 3] if re.search(r"\d", c) and not _all_zeros(c)]
            if cands and re.search(r"\d", rest[i + 1]):
                parsed.unit = cands[0]
                parsed.street = " ".join(rest[:i])
                tail = rest[rest.index(cands[0], i + 1) + 1:]
                if tail and all(re.fullmatch(r"\d{1,5}", t) for t in tail):
                    parsed.alt_units = [t for t in tail if not _all_zeros(t) and not TX_ZIP_RE.match(t)
                                        and t != parsed.house_number]
                return parsed

    # Sin designador: último token con dígitos después de al menos una palabra de la calle,
    # salvo el número de una vía numerada ("County Road 249", "FM 1388", "State Hwy 360"): es la calle
    seen_word = False
    last_num_idx = None
    for i, t in enumerate(rest):
        if re.search(r"[A-Za-z]", t) and not re.search(r"\d", t):
            seen_word = True
        elif (seen_word and re.search(r"\d", t) and not _is_road_number(rest, i) and not _all_zeros(t)
              and not TX_ZIP_RE.match(t)):   # "1914 Cartwright St 75062": el código postal no es la unidad
            last_num_idx = i
    if last_num_idx is not None:
        # "Highway 5 31": el 5 es parte de la calle; la unidad es el último número
        parsed.unit = rest[last_num_idx]
        parsed.street = " ".join(rest[:last_num_idx])
    else:
        parsed.street = " ".join(rest)
    return parsed


@dataclass
class PhotoOCR:
    path: str
    text: str = ""
    numbers: List[str] = field(default_factory=list)  # Tokens numéricos con confianza suficiente
    is_label: bool = False
    label_tracking: Optional[str] = None
    error: str = ""
    # Textos chicos/lejanos (posibles carteles de número) que no se pudieron leer con seguridad
    far_text: List[str] = field(default_factory=list)
    # Confianza (0-100) de cada número leído, por dígitos
    number_conf: Dict[str, float] = field(default_factory=dict)
    # Segunda opinión del modelo de visión local (solo en casos dudosos)
    vision_used: bool = False
    vision_numbers: List[str] = field(default_factory=list)  # Leídos solo por el modelo de visión (no por el OCR)
    photo_type: str = ""            # door | building | label | locker | package_room | other
    vision_error: str = ""          # El modelo de visión no pudo leer esta foto (p. ej. entra en bucle)
    # Lecturas alternativas que solo sirven para CONFIRMAR el número esperado (nunca para "otro número"):
    # "7/08" -> "7108" (el "1" angosto leído como barra), dígitos apilados leídos en otra pasada, etc.
    alt_numbers: List[str] = field(default_factory=list)
    # TODOS los números que leyó el modelo de visión en esta foto (también los que el OCR ya tenía): sirven para
    # CONFIRMAR "otra puerta" / "casa vecina" antes de mandar a Alta (02/10)
    vision_all: List[str] = field(default_factory=list)
    # El modelo de visión dijo "etiqueta" (no el QR ni el texto): puede ser un cartel o el paquete en el piso (02/10)
    vision_label: bool = False
    # Números con la LETRA de la unidad tal como se leen ("1334B" de una placa "1334-B"; 03/10). En `numbers` la
    # letra final se convierte en dígito (B->8), así que aquí se guardan aparte, en mayúsculas y sin guion.
    unit_letters: List[str] = field(default_factory=list)
    # Cajas del texto de la pasada OCR original, en pixeles del lienzo ocr_size.
    # rotation indica el giro de ese lienzo respecto de la foto orientada por EXIF.
    text_regions: List[dict] = field(default_factory=list)
    ocr_size: List[int] = field(default_factory=list)  # [ancho, alto]; [] si el motor no lo informa

    def __setstate__(self, state):
        # Compatibilidad con las lecturas .pkl guardadas antes de conservar las cajas.
        self.__dict__.update(state)
        self.__dict__.setdefault("text_regions", [])
        self.__dict__.setdefault("ocr_size", [])


def _prepare(img: Image.Image, max_side: int) -> Image.Image:
    g = ImageOps.exif_transpose(img).convert("L")
    scale = max_side / max(g.size)
    if scale < 1:
        g = g.resize((int(g.width * scale), int(g.height * scale)))
    return ImageOps.autocontrast(g)


# Placa de carro: 3 letras + guion/punto/espacio + 4 dígitos ("TYG-5837", caso real 02/10: 5506 Londonderry Ct) o
# pegadas ("TYG5837"). No se aplica a abreviaturas de dirección ("APT 605", "STE 100", "BLD 1234").
# Separador: guion, punto, espacio o la estrella de las placas de Texas, que Paddle lee "+" ("TYG+5837")
PLATE_RE = re.compile(r"(?!APT|STE|BLD|UNI|SUI|LOT|RM|NO)[A-Z]{3}[-\s·.+*★☆]?\d{4}"
                      # La placa con un carácter mal leído entre las letras ("NJ3C-7401" por NJC-7401; caso real 05/10,
                      # 6609 Hickory Pl): 3-4 caracteres con al menos 2 letras, guion y 4 dígitos
                      r"|(?!APT|STE|BLD|UNI|SUI|LOT|RM|NO)(?=[A-Z0-9]*[A-Z][A-Z0-9]*[A-Z])[A-Z0-9]{3,4}[-·.]\d{4}")


def _numeric_tokens(data: Dict[str, list], min_conf: float, conf_out: Optional[Dict[str, float]] = None) -> List[str]:
    nums = []
    for word, conf in zip(data.get("text", []), data.get("conf", [])):
        w = unicodedata.normalize("NFKC", word or "").strip().strip(".,:;'\"()[]")
        if PLATE_RE.fullmatch(w.upper()):
            continue  # Placa de carro ("TYG-5837", caso real 02/10: 5506 Londonderry Ct)
        if re.search(r"[A-Za-z]{2,}-\d{2,}-[A-Za-z]", w):
            continue  # Código de producto impreso en la caja ("XU-1340-Create…"; caso 06/10: 1935 Stamp Rd, "dos puertas")
        try:
            c = float(conf)
        except (TypeError, ValueError):
            c = -1
        if not w or c < min_conf:
            continue
        # "T1370" = 11370: el 1 con base ancha de las placas sale "T" (caso real 02/10, 11370 Co Rd 2316)
        w = re.sub(r"^[Tt](?=\d{3,}$)", "1", w)
        fixed = w.translate(OCR_DIGIT_FIX) if sum(ch.isdigit() for ch in w) >= max(1, len(w) // 2) else w
        # Números tipo "1903", "7-205", "12B"
        for m in re.findall(r"\d+(?:-\d+)?[A-Za-z]?", fixed):
            if _digits(m):
                nums.append(m)
                if conf_out is not None:
                    conf_out[_digits(m)] = max(conf_out.get(_digits(m), 0.0), c)
    return nums


def detect_label_cv(path: str) -> "tuple[bool, Optional[str], str]":
    """
    Detecta una etiqueta de envío por su QR / código de barras (más fiable que el OCR).
    Devuelve (es_etiqueta, tracking_decodificado, motivo). Calibrado con fotos reales de GOFO:
    un QR "detectado" con forma deformada suele ser una ventana o baranda (falso positivo),
    por eso sin decodificación se exige un cuadrilátero casi cuadrado y de tamaño de etiqueta.
    """
    if not HAS_CV2:
        return False, None, ""
    g = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
    if g is None:
        return False, None, ""
    full_pts = None
    for scale in (1.0, 0.5):
        gg = g if scale == 1.0 else cv2.resize(g, None, fx=scale, fy=scale)
        text, pts, _ = _QR.detectAndDecode(gg)
        if text:
            trk = TRACKING_RE.search(text.upper())
            return True, trk.group(0) if trk else None, "qr_decodificado"
        if scale == 1.0:
            full_pts = pts  # Misma detección que _QR.detect(g): se reutiliza en vez de repetirla
    if _BARCODE is not None:
        r = _BARCODE.detectAndDecode(g)
        vals = r[0] if not isinstance(r[0], bool) else r[1]
        vals = [v for v in (vals if isinstance(vals, (list, tuple)) else [vals]) if v]
        if vals:
            trk = next((TRACKING_RE.search(v.upper()) for v in vals if TRACKING_RE.search(v.upper())), None)
            return True, trk.group(0) if trk else None, "barcode_decodificado"
    if full_pts is not None:
        quad = full_pts.reshape(-1, 2).astype(np.float32)
        h, w = g.shape
        area = cv2.contourArea(quad) / float(h * w)
        sides = [float(np.linalg.norm(quad[i] - quad[(i + 1) % 4])) for i in range(4)]
        squareness = min(sides) / max(sides) if max(sides) > 0 else 0
        if squareness >= config.LABEL_QR_MIN_SQUARENESS and 0.004 <= area <= 0.06:
            return True, None, "qr_cuadrado"
    return False, None, ""


_EASYOCR_READER = None


def _paddle_url(route: str) -> str:
    return f"http://127.0.0.1:{config.pick_for_worker(config.PADDLE_OCR_PORTS)}{route}"


def _paddle_alive() -> bool:
    import urllib.request
    try:
        with urllib.request.urlopen(_paddle_url("/health"), timeout=3) as r:
            return r.status == 200
    except Exception:
        return False


def ensure_paddle_server() -> None:
    """Arranca el servicio local de PaddleOCR (venv_paddle) si no está corriendo y espera a que cargue el modelo."""
    import subprocess
    import time
    if _paddle_alive():
        return
    # 03/10: con la GPU ocupada el /health a veces tarda más de 3 s y se abría OTRO servicio cada vez (llegó a haber 5
    # cargados a la vez, ocupando ~4 GB de GPU). Si el puerto ya está tomado, se espera al que existe.
    import socket
    with socket.socket() as s:
        s.settimeout(1)
        busy = s.connect_ex(("127.0.0.1", config.PADDLE_OCR_PORT)) == 0
    if busy:
        deadline = time.time() + config.PADDLE_START_TIMEOUT_S
        while time.time() < deadline:
            if _paddle_alive():
                return
            time.sleep(2)
        raise RuntimeError("El servicio de PaddleOCR está ocupado y no responde (ver storage/paddle_ocr_server.log)")
    if not config.PADDLE_PYTHON.exists():
        raise RuntimeError(f"No está instalado PaddleOCR ({config.PADDLE_PYTHON})")
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    logs = config.STORAGE_DIR / "paddle_ocr_server.log"
    with open(logs, "ab") as log:
        subprocess.Popen([str(config.PADDLE_PYTHON), str(config.PROJECT_ROOT / "tools" / "paddle_ocr_server.py"),
                          "--port", str(config.PADDLE_OCR_PORT)], cwd=str(config.PROJECT_ROOT),
                         stdout=log, stderr=log, creationflags=flags)
    deadline = time.time() + config.PADDLE_START_TIMEOUT_S
    while time.time() < deadline:
        if _paddle_alive():
            return
        time.sleep(2)
    raise RuntimeError("El servicio de PaddleOCR no arrancó a tiempo (ver storage/paddle_ocr_server.log)")


_LAST_PADDLE_WIDTH = {"w": 0}   # Ancho de la imagen que leyó Paddle (para ubicar zonas)
_LAST_OCR_SIZE = {"width": 0, "height": 0}
OCR_DEADLINE = {"t": 0.0}   # time.perf_counter() límite de la lectura inicial del albarán en curso (0 = sin tope)


def _paddle_timeout(default: float = 120.0) -> float:
    """El tiempo que se espera a Paddle no pasa del que le queda al albarán (mínimo 10 s para no cortar lecturas normales)."""
    if not OCR_DEADLINE["t"]:
        return default
    import time
    return max(10.0, min(default, OCR_DEADLINE["t"] - time.perf_counter()))


@track_read_failures
def _paddle_readtext(path: str, upscale: float = 1.0):
    """[(caja, texto, confianza 0-1)] y alto de la imagen que leyó Paddle (servicio local)."""
    import json as _json
    import urllib.request
    body = _json.dumps({"path": str(path), "upscale": upscale}).encode()
    for attempt in (1, 2):
        ensure_paddle_server()
        req = urllib.request.Request(_paddle_url("/ocr"), data=body, headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=_paddle_timeout()) as r:
                data = _json.loads(r.read().decode("utf-8"))
            break
        except (ConnectionError, urllib.error.URLError) as e:
            # 12/10: el servicio se cierra solo al pasar su límite de memoria; se vuelve a abrir y se reintenta una vez
            if attempt == 2 or isinstance(e, urllib.error.HTTPError):
                raise
            import time
            time.sleep(3)
    if "error" in data:
        raise RuntimeError(data["error"])
    # Paddle a veces devuelve dígitos de ancho completo ("１０４"): NFKC los vuelve "104" (caso real 02/10)
    dets = [(d["box"], unicodedata.normalize("NFKC", d["text"] or ""), d["conf"]) for d in data["detections"]]
    _LAST_PADDLE_WIDTH["w"] = data.get("width", 0)
    return dets, data["height"]


def _readtext(path: str, max_side: int):
    """Detecciones del motor configurado: [(caja, texto, confianza 0-1)] y alto de la imagen leída."""
    if config.OCR_ENGINE == "paddle":
        detections, height = _paddle_readtext(path)
        _LAST_OCR_SIZE.update(width=_LAST_PADDLE_WIDTH.get("w", 0), height=height)
        return detections, height
    with Image.open(path) as im:
        img = np.array(_prepare(im, max_side))
    det = _easyocr_reader().readtext(img, detail=1, paragraph=False, canvas_size=config.OCR_CANVAS_SIZE)
    _LAST_OCR_SIZE.update(width=img.shape[1], height=img.shape[0])
    return det, img.shape[0]


def _easyocr_reader():
    """Un lector por proceso (carga el modelo una sola vez; usa la GPU si está disponible)."""
    global _EASYOCR_READER
    if _EASYOCR_READER is None:
        import easyocr
        import torch
        _EASYOCR_READER = easyocr.Reader(["en"], gpu=config.OCR_USE_GPU and torch.cuda.is_available(),
                                         verbose=False)
    return _EASYOCR_READER


def _ocr_photo_easyocr(path: str, result: PhotoOCR, min_conf: float, max_side: int) -> PhotoOCR:
    cv_label, cv_trk, why = detect_label_cv(path)
    # Un código de barras decodificado SIN tracking puede ser un falso positivo (persianas, ladrillos):
    # se confirma con el OCR más abajo. Con tracking o QR decodificado, la etiqueta es segura.
    doubtful_barcode = why == "barcode_decodificado" and not cv_trk
    if why in ("qr_decodificado", "barcode_decodificado") and not doubtful_barcode:
        # Etiqueta segura: sus números no cuentan y su texto no se usa. Ahorra la pasada de EasyOCR (~2 s)
        result.is_label, result.label_tracking = True, cv_trk
        return result
    _LAST_OCR_SIZE.update(width=0, height=0)
    detections, img_h = _readtext(path, max_side)
    if _LAST_OCR_SIZE["width"] and _LAST_OCR_SIZE["height"]:
        result.ocr_size = [int(_LAST_OCR_SIZE["width"]), int(_LAST_OCR_SIZE["height"])]
    result.text_regions = [
        {"box": [[float(x), float(y)] for x, y in box], "text": str(text),
         "confidence": float(conf), "rotation": 0}
        for box, text, conf in detections
    ]
    words = [(txt, float(conf) * 100.0) for _, txt, conf in detections]
    result.text = " ".join(w for w, _ in words)
    upper = result.text.upper()
    hits = sum(1 for k in LABEL_KEYWORDS if k in upper)
    if doubtful_barcode and len(result.text.split()) < config.BARCODE_LABEL_MIN_OCR_TOKENS:
        # Caso real: casa 1513 (persianas leídas como barcode "21152146"); el OCR solo vio "1515".
        # Una etiqueta real deja 39-68 tokens de texto en el OCR aunque esté girada.
        cv_label = False
    # Paddle (02/10) lee con claridad el tracking impreso "GFUS…" de la etiqueta: señal segura de etiqueta. Las capturas
    # del chat también lo muestran, pero sus números tampoco son de la puerta.
    result.is_label = cv_label or hits >= 2 or (config.OCR_ENGINE == "paddle" and bool(TRACKING_RE.search(upper)))
    # Solo el tracking DECODIFICADO del QR es confiable (el OCR confunde 0/8 en 18 dígitos)
    result.label_tracking = cv_trk
    if not result.is_label:
        result.numbers = _numeric_tokens(
            {"text": [w for w, _ in words], "conf": [c for _, c in words]}, min_conf, result.number_conf)
        result.far_text = _far_candidates(detections, img_h, min_conf)
        result.alt_numbers = _slash_as_one(w for w, _ in words)
        result.unit_letters = unit_letter_tokens(w for w, _ in words)
        stacked = _stacked_digits(detections) + _row_digits(detections)
        for num, c in stacked:
            # Dígitos apilados en vertical (6-6-4-5, 3-2-2-9): el OCR los lee sueltos y los descartaba
            if num not in result.numbers:
                result.numbers.append(num)
                result.number_conf[num] = max(result.number_conf.get(num, 0.0), c)
    return result


UNIT_LETTER_RE = re.compile(r"^(\d{1,6})\s?[-–]?\s?([A-Za-z])$")


def unit_letter_tokens(words) -> List[str]:
    """"1334-B", "1334 B", "34B" -> "1334B", "34B" (número + letra de la unidad, 03/10)."""
    out = []
    for w in words:
        m = UNIT_LETTER_RE.match(unicodedata.normalize("NFKC", w or "").strip().strip(".,:;'\"()[]"))
        if m:
            out.append(m.group(1) + m.group(2).upper())
    return out


SLASH_ONE_RE = re.compile(r"(?<=\d)\s?[/|lI\\]\s?(?=\d)")


def _slash_as_one(words) -> List[str]:
    """"7/08" -> "7108": el "1" angosto pegado a un poste o borde sale como barra. Solo como lectura alternativa."""
    out = []
    for w in words:
        if SLASH_ONE_RE.search(w or ""):
            d = _digits(SLASH_ONE_RE.sub("1", w))
            if 3 <= len(d) <= 6:
                out.append(d)
    return out


def _digit_boxes(detections) -> List[dict]:
    boxes = []
    for bbox, txt, conf in detections:
        t = re.sub(r"\s", "", unicodedata.normalize("NFKC", txt or "")).translate(OCR_DIGIT_FIX)
        if not re.fullmatch(r"\d{1,2}", t):
            continue
        xs = [p[0] for p in bbox]; ys = [p[1] for p in bbox]
        boxes.append({"t": t, "x0": min(xs), "x1": max(xs), "cx": (min(xs) + max(xs)) / 2, "w": max(xs) - min(xs),
                      "y0": min(ys), "y1": max(ys), "cy": (min(ys) + max(ys)) / 2, "h": max(ys) - min(ys),
                      "c": float(conf) * 100.0})
    return boxes


def _chains(boxes: List[dict], follows, order_key) -> List[tuple]:
    """Une dígitos sueltos en cadenas (cada uno sigue al anterior según `follows`); devuelve [(número, conf)]."""
    idx = sorted(range(len(boxes)), key=lambda i: order_key(boxes[i]))
    out, used = [], set()
    for k, i in enumerate(idx):
        if i in used:
            continue
        chain = [i]
        for j in idx[k + 1:]:
            if j in used or j in chain:
                continue
            last, c = boxes[chain[-1]], boxes[j]
            if max(last["h"], c["h"]) / max(1.0, min(last["h"], c["h"])) < 1.8 and follows(last, c):
                chain.append(j)
        num = "".join(boxes[x]["t"] for x in chain)
        if len(chain) >= 2 and 3 <= len(num) <= 6:
            used.update(chain)
            out.append((num, min(boxes[x]["c"] for x in chain)))
    return out


def _stacked_digits(detections) -> List[tuple]:
    """
    Dígitos sueltos alineados en COLUMNA (uno debajo del otro, tamaño parecido) se leen de arriba hacia abajo como un
    solo número. Casos reales 01/10: "6645", "3229", "3122", "3813". 03/10: más tolerancia (separación de hasta 2,6
    alturas, columna inclinada o escalonada, cajas que se tocan) y sin perder dígitos repetidos ("1111", "1102",
    "1003", "314", "1504").
    """
    boxes = _digit_boxes(detections)

    def below(last, c):
        avg_w = max(1.0, (last["w"] + c["w"]) / 2)
        avg_h = max(1.0, (last["h"] + c["h"]) / 2)
        return (abs(c["cx"] - last["cx"]) < 1.3 * avg_w and -0.35 * avg_h <= c["y0"] - last["y1"] < 2.6 * avg_h
                and c["cy"] > last["cy"])
    return _chains(boxes, below, lambda b: b["y0"])


def _row_digits(detections) -> List[tuple]:
    """
    Dígitos sueltos en FILA o en diagonal/escalonados (números de metal separados en la pared: "5 4 1", "7 2 4",
    "2 1 1 4"; casos reales 03/10) se leen de izquierda a derecha como un solo número.
    """
    boxes = _digit_boxes(detections)

    def right(last, c):
        avg_w = max(1.0, (last["w"] + c["w"]) / 2)
        avg_h = max(1.0, (last["h"] + c["h"]) / 2)
        return (-0.3 * avg_w <= c["x0"] - last["x1"] < 2.5 * avg_w and abs(c["cy"] - last["cy"]) < 1.1 * avg_h
                and c["cx"] > last["cx"])
    return _chains(boxes, right, lambda b: b["x0"])


def _far_candidates(detections, img_height: int, min_conf: float) -> List[str]:
    """
    "Números lejanos": textos cortos con algún dígito cuya caja mide menos de
    FAR_TEXT_MAX_HEIGHT_RATIO de la altura de la foto, o que se leyeron con baja confianza.
    Son carteles que probablemente muestran el número pero demasiado chicos para confiar.
    """
    out = []
    for bbox, txt, conf in detections:
        t = (txt or "").strip()
        if not t or len(t) > 8 or not re.search(r"\d", t):
            continue
        h = (max(p[1] for p in bbox) - min(p[1] for p in bbox)) / float(img_height or 1)
        if h < config.FAR_TEXT_MAX_HEIGHT_RATIO or float(conf) * 100.0 < min_conf:
            out.append(t)
    return out


def reread_screenshot_text(path: str) -> str:
    """
    Texto de una captura de pantalla leída ampliada al doble. Caso real 04/10 (723 Griffith Ave en Google Maps): a
    tamaño normal Paddle leía "Griffith Ave" sin el número; ampliada, "723 Griffith Ave". "" si no se puede leer.
    """
    import os
    if config.OCR_ENGINE != "paddle" or not path or not os.path.exists(path):
        return ""
    try:
        dets, _ = _paddle_readtext(path, upscale=2.0)
    except Exception as e:
        import logging
        logging.getLogger("PODAutomation.OCR").warning(f"Relectura de la captura {path} falló: {e}")
        return ""
    return " ".join(t for _, t, _ in dets)


@cached_photo_reading
def ocr_photo(path: str, min_conf: float = None, max_side: int = None) -> PhotoOCR:
    """OCR de una foto con el motor configurado (OCR_ENGINE: 'easyocr' o 'tesseract')."""
    min_conf = config.OCR_MIN_CONFIDENCE if min_conf is None else min_conf
    max_side = config.OCR_MAX_SIDE if max_side is None else max_side
    result = PhotoOCR(path=str(path))
    if config.OCR_ENGINE in ("easyocr", "paddle"):
        try:
            return _ocr_photo_easyocr(path, result, min_conf, max_side)
        except ImportError:
            result.error = f"{config.OCR_ENGINE} no disponible"
            return result
        except Exception as e:
            result.error = str(e)
            return result
    if not HAS_TESSERACT:
        result.error = "pytesseract no disponible"
        return result
    try:
        cv_label, cv_trk, _ = detect_label_cv(path)
        with Image.open(path) as im:
            base = _prepare(im, max_side)
        result.ocr_size = [base.width, base.height]
        texts, numbers = [], []
        for angle in ((0,) if cv_label else (0, 180)):
            img = base if angle == 0 else base.rotate(180)
            data = pytesseract.image_to_data(
                img, lang=config.OCR_LANG, config="--psm 11",
                output_type=pytesseract.Output.DICT,
            )
            words = [w for w in data["text"] if w and w.strip()]
            # Reutilizar las posiciones de image_to_data, sin otra llamada a Tesseract.
            for index, word in enumerate(data["text"]):
                if not word or not word.strip() or not all(k in data for k in ("left", "top", "width", "height")):
                    continue
                x, y = int(data["left"][index]), int(data["top"][index])
                w, h = int(data["width"][index]), int(data["height"][index])
                result.text_regions.append({"box": [[x,y],[x+w,y],[x+w,y+h],[x,y+h]],
                                            "text": word, "confidence": float(data["conf"][index])/100,
                                            "rotation": angle})
            texts.append(" ".join(words))
            if angle == 0:
                numbers = _numeric_tokens(data, min_conf)
            joined = " ".join(texts).upper()
            if any(k in joined for k in LABEL_KEYWORDS) or TRACKING_RE.search(joined):
                break  # Ya es etiqueta; no hace falta otra rotación
        result.text = " | ".join(texts)
        upper = result.text.upper()
        hits = sum(1 for k in LABEL_KEYWORDS if k in upper)
        trk = TRACKING_RE.search(upper)
        result.is_label = cv_label or hits >= 2 or bool(trk)
        # Solo el tracking DECODIFICADO del QR es confiable (el OCR confunde 0/8 en 18 dígitos)
        result.label_tracking = cv_trk
        result.numbers = [] if result.is_label else numbers
    except Exception as e:
        result.error = str(e)
    return result


RANGE_RE = re.compile(r"(\d{2,5})\s*[-\u2013\u2014.~_]+\s*(\d{2,5})")


def unit_ranges(text: str, floors: bool = False) -> List[tuple]:
    """
    Rangos de unidades de un cartel de edificio ("1811-1818", "1821 - 1828").
    Se aceptan solo pares con la misma cantidad de dígitos y un rango chico (<= 60),
    para no confundir fechas, teléfonos o códigos. Tolera un carácter basura pegado.
    floors=True acepta además carteles de varios pisos ("1101-1330" = pisos 11 a 13, hasta 3 pisos de diferencia).
    """
    out = []
    for a, b in RANGE_RE.findall(text or ""):
        if len(a) != len(b):
            # OCR suele pegar un carácter al inicio ("821-1828" por "1821-1828"): completar
            if len(b) == len(a) + 1 and b[1:].startswith(a[: len(a) - 1][:1]):
                a = b[0] + a
            else:
                continue
        lo, hi = int(a), int(b)
        if lo < hi <= lo + 60:
            out.append((lo, hi))
        elif floors and len(a) >= 3 and 1 <= hi // 100 - lo // 100 <= 3:
            out.append((lo, hi))
    return out


# Cómo se ve cada dígito girado 180°. Un "2" leído de cabeza puede ser un 7 (el 7 invertido parece un 2).
# 02/10: el 7 de cabeza también sale "4" (197 -> "461", 2107 -> "4012") y el 3 de cabeza sale "2" (6803 -> "2089").
_UPSIDE_DOWN = {"0": "0", "1": "1", "2": "273", "4": "7", "5": "5", "6": "9", "8": "8", "9": "6"}


def upside_down_of(read: str, target: str) -> bool:
    """True si `read` es `target` visto de cabeza ("919" = 616, "2169" = 6917). Solo 3+ dígitos y la misma cantidad."""
    if len(read) != len(target) or len(read) < 3 or read == target:
        return False
    return all(c in _UPSIDE_DOWN and t in _UPSIDE_DOWN[c] for c, t in zip(reversed(read), target))


def misread_of_plate(read: str, target: str, same_digits: bool = True) -> bool:
    """
    `read` es la MISMA placa `target` mal leída por el OCR (casos reales 02/10, primer día con Paddle), no otra puerta:
    - de cabeza: "919" = 616, "2169" = 6917, "461" = 197;
    - dígitos en otro orden (número vertical armado al revés o desordenado): "214" = 412, "1880" = 1808,
      "9011" = 1108 (al revés con un dígito dudoso). `same_digits=False` no acepta los MISMOS dígitos en otro orden:
      sin el número correcto en ninguna foto, "6150" para la unidad 6105 puede ser otra unidad de verdad;
    - dígitos lejanos/borrosos leídos como 0: "1000" = 1800, "2100" = 2109, "3600" = 3629, "000" = 900.
    """
    if len(read) != len(target) or len(read) < 3 or read == target:
        return False
    if upside_down_of(read, target):
        return True
    diff = [(a, b) for a, b in zip(read, target) if a != b]
    if diff and all({a, b} == {"1", "7"} for a, b in diff):
        return True   # 7 cursivo leído como 1 (o al revés): "2111" por 2717 (03/10)
    if same_digits and sorted(read) == sorted(target):
        return True
    direct = sum(a != b for a, b in zip(read, target))
    # Al revés con un dígito dudoso: solo 4+ dígitos y si NO es ya un número a un dígito (1231 vs 1221 puede ser vecina)
    if len(read) >= 4 and direct >= 2 and sum(a != b for a, b in zip(reversed(read), target)) <= 1:
        return True
    return all(a == b or a == "0" for a, b in zip(read, target))


# "GOFO" impreso en la etiqueta, como lo lee el OCR cuando la etiqueta se ve de lejos o torcida ("GOEO", "GOFD", "G0F0")
GOFO_RE = re.compile(r"\bG[O0][FE][O0D]\b")


def _is_locker_text(text: str) -> bool:
    """
    Pantalla de un casillero (Luxer, Parcel Pending, Amazon Hub): sus números (unidad del residente, teclado) no son
    puertas. El Amazon Hub se reporta igual por su propio chequeo (check_amazon_hub), no por "dos puertas" (03/10).
    """
    if re.search(config.LOCKER_KEYPAD_RE, text or "") or re.search(config.AMAZON_LOCKER_SIZES_RE, text or ""):
        return True
    t = re.sub(r"\s", "", (text or "").lower())
    return any(re.sub(r"\s", "", k) in t for k in config.LOCKER_PHOTO_KEYWORDS + config.AMAZON_HUB_KEYWORDS)


@dataclass
class NumberMatch:
    status: str  # "match" | "near_match" | "mismatch" | "wrong_building" | "far_numbers" | "not_visible" | "partial"
    matched: List[str] = field(default_factory=list)
    seen: List[str] = field(default_factory=list)
    detail: str = ""


def match_numbers(address: ParsedAddress, photos: List[PhotoOCR]) -> NumberMatch:
    """
    Compara los números leídos en fotos que NO son etiqueta contra casa/unidad.
    - match: aparece el número esperado (unidad si es apartamento; casa si no).
    - partial: apartamento donde solo aparece el número del edificio, no el de la unidad.
    - mismatch: se leen números plausibles pero ninguno concuerda con la dirección.
    - not_visible: no se lee ningún número plausible.
    """
    exp = address.expected_numbers()
    house, unit = exp["house"], exp["unit"]
    target = unit if address.is_apartment else house
    lengths = {len(x) for x in (house | unit)}
    seen: List[str] = []
    for p in photos:
        if p.is_label or p.error:
            continue
        if _is_locker_text(p.text):
            continue  # Pantalla de casillero (Parcel Pending, Luxer): sus números no son puertas (02/10)
        if GOFO_RE.search((p.text or "").upper()):
            continue  # Se ve la etiqueta GOFO del paquete (entrega en mano, caso real 02/10: "238 GOEO 2eA"): no es puerta
        # Un número que empieza con 0 no es un número de casa ("000" = calabazas apiladas, "054", "0610"; 02/10),
        # salvo que sin los ceros sea el esperado ("0355" = unidad 355)
        digits = [d for d in (_digits(n) for n in p.numbers)
                  if d and (not d.startswith("0") or any((d.lstrip("0") or d) == t.lstrip("0") for t in target))]
        # Número de la casa leído DE CABEZA (02/10, primer día con Paddle: 616 leído "919", 6917 pintado en el bordillo
        # leído "2169"): cuenta como el número correcto, y los demás números de esa foto salen de la misma lectura
        # invertida, así que no se usan (no son "otra puerta").
        flipped = [t for d in digits for t in target if d not in target and upside_down_of(d, t)]
        if flipped:
            digits = [d for d in digits if d in target] + flipped
        # 25/10: número vertical leído de abajo hacia arriba ("3004" por 4003, Windy Meadow Ct): el reverso exacto del
        # esperado (3+ dígitos, no palíndromo) cuenta como el número correcto. NO vale cualquier permutación de dígitos.
        # A diferencia de "de cabeza", los demás números de la foto se conservan.
        rev = [t for d in digits for t in target if d not in target and len(t) >= 3 and d == t[::-1] != t]
        digits = digits + [t for t in rev if t not in digits]
        for d in digits:
            if TX_ZIP_RE.match(d or "") and d not in (house | unit):
                continue  # Caso real: "75063" (código postal) contra 1905 W Walnut St
            if d and d not in seen:
                seen.append(d)

    def same_or_one_extra(d: str, t: str) -> bool:
        # Ceros a la izquierda ("0355" = 355) y un carácter de más al inicio o al final del cartel,
        # típico del OCR al tomar un borde o tornillo ("13014" o "11301" por "1301", "1119" por "119")
        d0 = d.lstrip("0") or d
        if d0 == t or (t and d0 == t.lstrip("0")):
            return True
        if len(t) >= 3 and len(d0) == len(t) + 2 and d0[0] == "1" and d0[-1] == "1" and d0[1:-1] == t:
            return True   # "170361" por "7036": los dos bordes de la placa leídos como "1"
        return len(t) >= 3 and len(d0) == len(t) + 1 and (d0.startswith(t) or d0.endswith(t))

    # Las relecturas de una foto con texto de la etiqueta GOFO no cuentan: leen la dirección impresa (caso real 03/10:
    # "3525" releído en la etiqueta dañada de 3525 Twin Lakes Way, foto de los buzones 3529/3525 aparte)
    alts = [a for p in photos if not p.is_label and not p.error and not GOFO_RE.search((p.text or "").upper())
            for a in (p.alt_numbers or [])]
    # Foto que SOLO el modelo de visión llamó "etiqueta" (no hay QR ni texto de etiqueta) pero en la que el modelo leyó
    # el número esperado: es la placa (caso real 03/10: placa "060" de la unidad 60 tomada como etiqueta)
    alts += [n for p in photos if getattr(p, "vision_label", False) and not p.label_tracking
             and not GOFO_RE.search((p.text or "").upper()) for n in (p.vision_all or [])
             if any((n.lstrip("0") or n) == t.lstrip("0") for t in target)]
    # Lo mismo con la RELECTURA de esa foto (caso 05/10: "2704" pintado en el cordón tomado por etiqueta). La relectura
    # solo se guarda si la foto no tiene texto de etiqueta (pipeline.confirm_doubtful_number)
    alts += [a for p in photos if p.is_label and getattr(p, "vision_label", False) and not p.label_tracking
             and not GOFO_RE.search((p.text or "").upper()) for a in (p.alt_numbers or [])]
    # Unidad con LETRA (regla del usuario 03/10, "1334 Sherrye Dr Apt 34B"): son correctos "1334-B", "1334B", "34B";
    # la misma casa con OTRA letra ("1334-C") es otra unidad.
    letter = re.search(r"([A-Za-z])$", address.unit or "")
    if letter and _digits(address.unit):
        L = letter.group(1).upper()
        ok_forms = {h + L for h in house} | {u + L for u in unit}
        read = [t for p in photos if not p.is_label and not p.error for t in (p.unit_letters or [])]
        good = [t for t in read if t in ok_forms]
        if good:
            return NumberMatch("match", good, seen, f"Unidad {good[0]} visible y concuerda")
        other = [t for t in read if t[:-1] in (house | unit) and t[-1] != L]
        if other:
            status = "mismatch" if any(other[0][:-1] in (p.vision_all or []) for p in photos) else "mismatch_unconfirmed"
            return NumberMatch(status, [], seen,
                               f"Se lee {other[0]} y la unidad es {address.unit}: otra unidad del mismo edificio")
    matched_target = [d for d in seen + alts if any(same_or_one_extra(d, t) for t in target)]
    matched_house = [d for d in seen if d in house]
    # El modelo de visión leyó este número en alguna foto: solo así "otra puerta" / "casa vecina" / "no concuerda"
    # llega a Alta (02/10: ~25 falsos Alta en un día por lecturas del OCR que el modelo no veía)
    vision_saw = lambda d: any(d in (p.vision_all or []) for p in photos if not p.is_label and not p.error)
    if matched_target:
        # Lecturas equivocadas de la MISMA placa (de cabeza, desordenada, con ceros) no son otra puerta
        seen = [d for d in seen if not any(misread_of_plate(d, t) for t in target)]
        # Regla n.º 17 (01/10): fotos de DOS puertas distintas -> Alta para verificar. Otra lectura SEGURA del OCR con la
        # misma cantidad de dígitos que la unidad/casa, que no es el número de la casa ni del edificio ni un CP.
        strong = {}
        for p in photos:
            if not p.is_label and not p.error:
                for d, c in (p.number_conf or {}).items():
                    if d not in (p.vision_numbers or []):
                        strong[d] = max(strong.get(d, 0.0), c)
        exp_all = {x for t in (house | unit) for x in (t, t.lstrip("0"))}
        # Fotos donde se ve el número correcto. Una lectura a UN dígito de distancia en esa MISMA foto es la misma placa
        # mal leída ("210" y "218" de una sola placa). En OTRA foto cuenta como otra puerta (vecina 2607 vs 2603).
        target_photos = {id(p) for p in photos if not p.is_label and not p.error
                         and any(same_or_one_extra(_digits(n), t) for n in (p.numbers or []) + (p.alt_numbers or [])
                                 for t in target)}
        one_off = lambda d, t: len(d) == len(t) and sum(x != y for x, y in zip(d, t)) == 1
        def same_plate_misread(d):
            return any(id(p) in target_photos and d in [_digits(n) for n in p.numbers]
                       and any(one_off(d, t) for t in target) for p in photos)
        # Muy distinto (2817 vs 4224): basta TWO_DOORS_MIN_CONF. A un solo dígito ("106" vs "306") suele ser la misma
        # placa mal leída en otra foto: solo cuenta con una lectura segura (OCR_STRONG_CONFIDENCE).
        # El número correcto se lee con claridad (OCR seguro): el otro número también tiene que leerse con claridad y no
        # ser un texto chico (caja del paquete, tapete; casos reales 03/10: "7608" en la caja con 7207 en el bordillo,
        # "100" con 819 en la placa)
        target_strong = any(strong.get(t, 0.0) >= config.OCR_STRONG_CONFIDENCE for t in matched_target)
        small = {_digits(x) for p in photos if not p.is_label and not p.error for x in (p.far_text or [])}

        def door_conf_ok(d):
            near_target = any(one_off(d, t) for t in target)
            if target_strong and (d in small or strong.get(d, 0.0) < config.OCR_STRONG_CONFIDENCE):
                return False
            return strong.get(d, 0.0) >= (config.OCR_STRONG_CONFIDENCE if near_target else config.TWO_DOORS_MIN_CONF)
        # Los extremos de un cartel de rangos ("1325-1333") no son otra puerta (caso real 01/10: Apt 1327)
        # 30/10: en apartamentos también el cartel de varios pisos ("1101-1330" con la puerta 1202 a la vista, 8025 Monty
        # Stratton Pkwy, descartado). Solo aquí: en casas un rango tan amplio confirmaría la casa (scoring.check_address_number)
        in_ranges = {str(x) for p in photos if not p.is_label and not p.error
                     for lo, hi in unit_ranges(p.text, floors=address.is_apartment) for x in (lo, hi)}
        # Una foto con 3+ números del largo de la unidad es el cartel del edificio con la lista de unidades, no una
        # puerta (caso real: "2426 1325 1333 2325.2333", el OCR no leyó los guiones)
        tlen = {len(t) for t in target}
        for p in photos:
            same_len = {_digits(n) for n in (p.numbers or []) if len(_digits(n)) in tlen}
            if not p.is_label and len(same_len) >= 3:
                in_ranges |= same_len
        # Apartamento: el número que se lee en la foto del EDIFICIO (cartel del complejo, "800") no es otra puerta de
        # unidad (caso real 03/10: 818 W Royal Ln 367)
        # Regla del usuario 03/10: en edificios solo importa el número de la PUERTA. Si la unidad correcta se ve, los
        # números de las otras fotos (edificio, estacionamiento, carteles) no la contradicen.
        # Salvo que el otro número sea OTRA PUERTA confirmada por el modelo de visión (caso real 01/10: puertas 2817 y 4224)
        other_doors = {_digits(n) for p in photos if not p.is_label and not p.error and p.photo_type == "door"
                       and id(p) not in target_photos for n in (p.vision_all or [])}
        # Solo cuando el modelo YA revisó las otras fotos con números del largo de la unidad: si no, se le pregunta primero
        # (caso real 01/10 re-evaluado el 04/10: sin esto el 2817/4224 quedaba "concuerda" sin consultar al modelo)
        unchecked_other = any(not p.vision_used and id(p) not in target_photos
                              and any(len(_digits(n)) == len(t) for n in (p.numbers or []) for t in unit)
                              for p in photos if not p.is_label and not p.error)
        if address.is_apartment and any(t in unit for t in matched_target) and not unchecked_other and not (
                other_doors - unit - house - {t.lstrip("0") for t in unit}):
            return NumberMatch("match", matched_target, seen, "Número de la unidad visible y concuerda")
        # Otro número en la MISMA foto que el correcto: buzones o placas lado a lado (caso real 03/10: buzones 3529 y
        # 3525 juntos), no "dos puertas"
        in_ranges |= {_digits(n) for p in photos if id(p) in target_photos for n in (p.numbers or [])}
        if address.is_apartment:
            building_nums = {_digits(n) for p in photos if p.photo_type == "building" for n in (p.numbers or [])}
            door_nums = {_digits(n) for p in photos if p.photo_type != "building" for n in (p.numbers or [])}
            in_ranges |= building_nums - door_nums
        # Solo números de 3+ dígitos: con 1-2 dígitos hay demasiado ruido (caso real 02/10: unidad "2" y un "1" suelto)
        others = [d for d in seen if len(d) >= 3 and door_conf_ok(d) and d not in in_ranges
                  and d not in exp_all and not any(same_or_one_extra(d, t) for t in target)
                  and not same_plate_misread(d)
                  and any(len(d) == len(t) for t in target) and not TX_ZIP_RE.match(d)]
        # 12/10: un número leído SOLO en fotos con texto de la etiqueta de GOFO (girada o tapada, no marcada como etiqueta)
        # es el número escrito a mano con marcador, una calcomanía o un código de la etiqueta, no otra puerta (605 S
        # Holiday Dr "673", 5418 Independence Ave "3401"; historial: 5 descartados, 0 reportados). Vale también si el
        # modelo lo confirma: en 2665 Forest Trail Dr el "3526" de una calcomanía sobre el paquete daba "dos puertas" (Alta)
        label_like = lambda p: bool(LABEL_MARK_RE.search((p.text or "").upper()))
        def only_on_label(d):
            where = [p for p in photos if not p.error
                     and d in [_digits(n) for n in (p.numbers or []) + (p.vision_all or []) + (p.vision_numbers or [])]]
            return bool(where) and all(p.is_label or label_like(p) for p in where)
        others = [d for d in others if not only_on_label(d)]
        confirmed = [d for d in others if vision_saw(d)]
        if confirmed:
            return NumberMatch("two_doors", matched_target, seen,
                               f"Fotos de dos puertas distintas ({confirmed[0]} y {matched_target[0]}): verificar")
        # El modelo de visión SÍ revisó la foto de ese otro número y no lo vio: el OCR lo inventó (casos reales 02/10:
        # 409 claro y "540", 1500 claro y "1347", 2680 claro y "2407") -> concuerda. Solo queda en duda si el modelo no
        # pudo revisar esa foto.
        unchecked = [d for d in others
                     if any(d in [_digits(n) for n in p.numbers] and not p.vision_used
                            for p in photos if not p.is_label and not p.error)
                     and not any(one_off(d, t) or misread_of_plate(d, t) for t in target)
                     and not only_on_label(d)]
        # 30/10: casa con el número leído claro y el otro número sin revisar (tope del modelo) que no puede ser la casa de
        # al lado: misma acera = misma paridad y a 20 o menos (4899 en el buzón y "7274" en el contenedor de basura).
        # Historial de la PC: 11 casas así, todas descartadas; las dos puertas reales de casas fueron 1999/1997 y 3011/3009
        neighbor = lambda d: any(len(d) == len(t) and abs(int(d) - int(t)) <= 20 and int(d) % 2 == int(t) % 2
                                 for t in target)
        if (unchecked and not address.is_apartment and not any(neighbor(d) for d in unchecked)
                and (target_strong or any(vision_saw(t) for t in matched_target))):
            return NumberMatch("match", matched_target, seen,
                               f"Se ve {matched_target[0]} claro y concuerda; el {unchecked[0]} de otra foto no es una casa "
                               f"vecina (sin revisar por el modelo de visión)")
        if unchecked:
            return NumberMatch("two_doors_unconfirmed", matched_target, seen,
                               f"Se ve {matched_target[0]} (concuerda); en otra foto el OCR leyó {unchecked[0]}, que el "
                               f"modelo de visión no pudo revisar: verificar")
        return NumberMatch("match", matched_target, seen, "Número esperado visible en la foto")
    # En apartamentos solo cuenta el número del apartamento (regla n.º 6, 01/10): un cartel con rangos de unidades
    # que no incluyen la unidad ya no manda a Alta; si la puerta no se ve, queda para revisar (Media).
    if address.is_apartment and address.unit:
        unit_num = int(_digits(address.unit) or 0)
        ranges = [r for p in photos if not p.is_label and not p.error for r in unit_ranges(p.text)]
        comparable = [r for r in ranges if len(str(r[0])) in (len(str(unit_num)), len(str(unit_num)) + 1)]
        if comparable and unit_num and not any(lo <= unit_num <= hi for lo, hi in comparable):
            shown = ", ".join(f"{lo}-{hi}" for lo, hi in comparable[:3])
            return NumberMatch("far_numbers", [], seen,
                               f"No se ve la puerta de la unidad {address.unit} (el cartel indica {shown}): verificar")
    far_any = [t for p in photos if not p.is_label and not p.error for t in p.far_text]
    if address.is_apartment and matched_house and far_any:
        return NumberMatch("far_numbers", matched_house, seen,
                           f"Números lejanos: se ve el edificio pero la unidad está en carteles chicos ({', '.join(far_any[:3])})")
    if address.is_apartment and matched_house:
        return NumberMatch("partial", matched_house, seen, "Se ve el número del edificio pero no el de la unidad")

    def one_digit_off(a: str, b: str) -> bool:
        if len(a) == len(b) >= 3:
            return sum(x != y for x, y in zip(a, b)) == 1
        # Un dígito menos leído ("121" en un cartel de "1211"): posible lectura incompleta
        return len(a) >= 3 and len(a) == len(b) - 1 and (b.startswith(a) or b.endswith(a))

    conf = {}
    for p in photos:
        if not p.is_label and not p.error:
            for d, c in (p.number_conf or {}).items():
                conf[d] = max(conf.get(d, 0.0), c)
    misread = [d for d in seen for t in target if misread_of_plate(d, t, same_digits=False) and not upside_down_of(d, t)]
    if misread:
        wanted = "/".join(sorted(target))
        return NumberMatch("near_match", misread, seen,
                           f"Se lee {misread[0]} y se espera {wanted}: probable lectura equivocada de la misma placa "
                           f"(dígitos borrosos, desordenados o de cabeza): verificar")
    near = [d for d in seen for t in target if one_digit_off(d, t)]
    truncated = [d for d in near if any(len(d) == len(t) - 1 for t in target)]
    if near and len(truncated) == len(near):
        wanted = "/".join(sorted(target))
        return NumberMatch("partial_read", near, seen,
                           f"Número leído incompleto ({near[0]} de {wanted}): verificar")
    # Solo con la MISMA cantidad de dígitos una lectura segura indica otra casa;
    # un dígito de menos puede ser un cartel leído a medias.
    # "Casa vecina" (Alta) necesita que el modelo de visión haya podido revisar esa foto: si falló, la lectura del OCR
    # queda sin confirmar y va a revisión (caso real 01/10: placa 3122 leída "5122" con 98 %, el modelo falló).
    unconfirmed = {d for p in photos if p.vision_error for d in (p.numbers or [])}
    # Fila de buzones: la foto muestra VARIOS números de casa del mismo largo (caso real 03/10: buzones 3529 y 3525
    # juntos, el de la casa leído mal). El vecino visible ahí no prueba que se entregó en la casa vecina -> Media.
    def in_mailbox_row(d):
        return any(d in [_digits(n) for n in p.numbers]
                   and len({_digits(n) for n in p.numbers if len(_digits(n)) == len(d)}) >= 2
                   for p in photos if not p.is_label and not p.error)
    # 12/10 (pedido del usuario): "casa vecina" (Alta) solo si difiere el ÚLTIMO dígito (3704/3708). Si difiere otro
    # (2903 leído 2913, 6932 leído 5932, 2841 leído 2811: placas decorativas) va a Media. Historial 03–11/10: último
    # dígito 6 reales / 1 descartado; otro dígito 4 reales / 10 descartados
    def last_digit_only(d):
        return any(len(d) == len(t) and d[:-1] == t[:-1] and d[-1] != t[-1] for t in target)
    clear = [d for d in near if conf.get(d, 0.0) >= config.OCR_STRONG_CONFIDENCE
             and any(len(d) == len(t) for t in target) and d not in unconfirmed and vision_saw(d)
             and not in_mailbox_row(d)]
    sure = [d for d in clear if last_digit_only(d)]
    if sure:
        wanted = "/".join(sorted(target))
        return NumberMatch("mismatch", [], seen,
                           f"Se lee {sure[0]} con claridad y la dirección es {wanted}: casa/puerta vecina")
    if clear:
        # Media, pero sigue siendo un problema fuerte: una entrega en mano/casillero deducida de la foto no lo tapa
        wanted = "/".join(sorted(target))
        return NumberMatch("neighbor_digit", [], seen,
                           f"Se lee {clear[0]} con claridad y la dirección es {wanted} (difiere un dígito que no es el "
                           f"último: placa decorativa mal leída o casa vecina): verificar")
    if near:
        wanted = "/".join(sorted(target))
        return NumberMatch("near_match", near, seen,
                           f"Se lee {near[0]} y se espera {wanted}: error de OCR o puerta vecina")

    # Números "plausibles" como otra dirección: misma cantidad de dígitos que la esperada o uno más.
    # Un número más corto no puede ser la dirección completa (ruido, fechas, "12" de un cartel): se ignora.
    target_lengths = {len(t) for t in target} or lengths or {3}
    plausible = [d.lstrip("0") or d for d in seen
                 if len(d) >= 2 and any(L <= len(d.lstrip("0") or d) <= L + 1 for L in target_lengths)]
    if plausible:
        wanted = "/".join(sorted(target)) or "?"
        # 25/10: apartamento y TODO lo que se lee es un número escrito en la propia dirección del recibo (calle, edificio):
        # es el edificio, no otra puerta. Queda en Media "falta la unidad" (partial), no en "no concuerda".
        addr_nums = {t.lstrip("0") or t for t in re.findall(r"\d+", address.raw or "")}
        if address.is_apartment and all(d in addr_nums for d in plausible):
            return NumberMatch("partial", plausible, seen, "Se ve el número del edificio pero no el de la unidad")
        if any(vision_saw(d) for d in plausible):
            return NumberMatch("mismatch", [], seen, f"Números en foto {plausible[:5]} no concuerdan con {wanted}")
        return NumberMatch("mismatch_unconfirmed", [], seen,
                           f"El OCR lee {plausible[:5]} (no concuerdan con {wanted}) pero el modelo de visión no los "
                           f"confirma (bordillo gastado, foto borrosa o inclinada): verificar")
    far = [t for p in photos if not p.is_label and not p.error for t in p.far_text]
    if far:
        return NumberMatch("far_numbers", [], seen,
                           f"Números lejanos: hay carteles chicos ({', '.join(far[:3])}) que no se leen con seguridad")
    return NumberMatch("not_visible", [], seen, "No se lee el número de casa/unidad en ninguna foto")


STREET_SUFFIXES = {"n", "s", "e", "w", "north", "south", "east", "west", "st", "street", "dr", "drive", "ln", "lane",
                   "ave", "avenue", "rd", "road", "pkwy", "parkway", "blvd", "boulevard", "ct", "court", "cir", "circle",
                   "way", "trl", "trail", "pl", "place", "ter", "terrace", "hwy", "highway", "cv", "cove", "loop"}


DIRECTIONS = {"n", "s", "e", "w", "north", "south", "east", "west"}
UNIT_WORDS = {"apt", "apartment", "apartamento", "departamento", "departamneto", "depto", "dpto", "apto", "unit",
              "unidad", "edificio", "building", "bldg", "suite", "ste", "room", "rm", "lot", "space", "spc"}


def building_key(address: str):
    """
    (número, nombre de la calle sin espacios ni tipo de vía): '1400 Andrews Pkwy' == '1400 ANDREWS PARKWAY' y
    '1104 Greenacres Ln' == '1104 Green Acres Lane' (caso real: la misma casa escrita de dos formas en el portal).
    """
    a = parse_us_address(address or "")
    if not a.house_number:
        # Dirección que no se pudo interpretar ("15890Hwy80", caso real 02/10): se compara el texto tal cual (sin
        # espacios ni signos). Dos albaranes con el MISMO texto son la misma casa, no "otra dirección".
        raw = re.sub(r"[^a-z0-9]", "", (address or "").lower())
        return ("texto", raw) if raw else None
    # El nombre de la calle termina en el tipo de vía o en la palabra de la unidad: lo que sigue ("Apartamento 727",
    # ",Grand Prairie Clayton Apartment- unit 611", "Edificio 5 apto 511") no identifica al edificio.
    words = []
    for w in re.findall(r"[a-z0-9]+", (a.street or "").lower()):
        if w in UNIT_WORDS or (w in STREET_SUFFIXES and words and w not in DIRECTIONS):
            break
        if w not in DIRECTIONS:
            words.append(w)
    return (a.house_number, "".join(words))


def same_building_key(a, b) -> bool:
    """
    Misma casa/edificio: claves iguales, o mismo número y un nombre de calle que termina en el otro (la ciudad metida
    en la calle; caso real 04/10: "1516 North Main Street" == "1516 N Euless Main St" -> 'main' / 'eulessmain').
    """
    if not a or not b:
        return False
    if a == b:
        return True
    if a[0] != b[0] or a[0] == "texto":
        return False
    short, long_ = sorted((a[1], b[1]), key=len)
    return len(short) >= 3 and long_.endswith(short)


def _read_tokens(det) -> List[tuple]:
    out = list(_stacked_digits(det)) + list(_row_digits(det))
    for _, txt, conf in det:
        for n in _numeric_tokens({"text": [txt], "conf": [float(conf) * 100.0]}, config.OCR_MIN_CONFIDENCE):
            out.append((_digits(n), float(conf) * 100.0))
    return out


def _paddle_reread(path: str) -> List[tuple]:
    """
    Relectura con Paddle de una foto dudosa (03/10; antes solo se ampliaba al doble):
    - ampliada al doble (dígitos sueltos de números apilados, placas chicas);
    - girada 90°, 270° y 180°: números verticales o de lado quedan en fila, y los pintados en el bordillo (fotografiados
      desde la calle) quedan derechos;
    - cada zona con dígitos recortada, ampliada 3x y con más contraste (placas chicas o lejanas: 819, 5621, 724).
    """
    import tempfile
    out: List[tuple] = []
    try:
        det, det_h = _paddle_readtext(path, upscale=2)
    except Exception:
        return out
    det_w = _LAST_PADDLE_WIDTH.get("w", 0)
    out += _read_tokens(det)
    try:
        with Image.open(path) as im:
            base = ImageOps.exif_transpose(im).convert("RGB")
    except Exception:
        return [(n, c) for n, c in out if n]
    if max(base.size) > 1600:
        # Fotos giradas a tamaño completo llenaban la GPU (04/10): 1600 px alcanza para leer números de la puerta
        k = 1600 / max(base.size)
        base = base.resize((int(base.width * k), int(base.height * k)), Image.LANCZOS)
    tmpdir = config.STORAGE_DIR / "tmp_reread"
    tmpdir.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=tmpdir) as td:
        for angle in (90, 270, 180):
            f = os.path.join(td, f"rot{angle}.jpg")
            base.rotate(angle, expand=True).save(f, quality=95)
            try:
                out += _read_tokens(_paddle_readtext(f)[0])
            except Exception:
                pass
        # Zonas con dígitos (coordenadas de la lectura ampliada al doble)
        W, H = base.size
        zones = [d for d in det if re.search(r"\d", d[1] or "")][:6]
        sx = W / max(1.0, det_w) if det_w else 0.5
        sy = H / max(1.0, det_h) if det_h else 0.5
        for k, (bbox, _, _) in enumerate(zones):
            xs = [p[0] * sx for p in bbox]; ys = [p[1] * sy for p in bbox]
            w, h = max(xs) - min(xs), max(ys) - min(ys)
            box = (max(0, int(min(xs) - w)), max(0, int(min(ys) - 1.5 * h)), min(W, int(max(xs) + w)),
                   min(H, int(max(ys) + 1.5 * h)))
            crop = base.crop(box)
            if crop.width < 8 or crop.height < 8:
                continue
            crop = ImageOps.autocontrast(crop.resize((crop.width * 3, crop.height * 3), Image.LANCZOS), cutoff=1)
            f = os.path.join(td, f"zona{k}.jpg")
            crop.save(f, quality=95)
            try:
                out += _read_tokens(_paddle_readtext(f)[0])
            except Exception:
                pass
        # 06/10 (casos 05/10: 6644, 3121, 4309, 2314 verticales/diagonales; 6528 con un dígito de menos; 4102 oscura):
        extra = []
        # - la COLUMNA/fila completa de dígitos con margen amplio: entra el dígito más chico o separado del borde
        if zones:
            xs = [p[0] * sx for b, _, _ in zones for p in b]; ys = [p[1] * sy for b, _, _ in zones for p in b]
            uw, uh = max(xs) - min(xs), max(ys) - min(ys)
            pad = max(uw, uh) * 0.6
            col = base.crop((max(0, int(min(xs) - pad)), max(0, int(min(ys) - pad)),
                             min(W, int(max(xs) + pad)), min(H, int(max(ys) + pad))))
            if col.width >= 8 and col.height >= 8:
                k = min(3.0, 1600 / max(col.size))
                col = ImageOps.autocontrast(col.resize((int(col.width * k), int(col.height * k)), Image.LANCZOS), cutoff=1)
                extra += [("columna0", col), ("columna90", col.rotate(90, expand=True)),
                          ("columna270", col.rotate(270, expand=True))]
        # - girada en diagonal (números pintados en ángulo)
        extra += [("diag45", base.rotate(45, expand=True)), ("diag315", base.rotate(315, expand=True))]
        # - foto oscura: con el contraste ecualizado
        if ImageStat.Stat(base.convert("L")).mean[0] < 90:
            extra.append(("ecualizada", ImageOps.equalize(base)))
        for name, img in extra:
            f = os.path.join(td, f"{name}.jpg")
            img.save(f, quality=95)
            try:
                out += _read_tokens(_paddle_readtext(f)[0])
            except Exception:
                pass
    return [(n, c) for n, c in out if n]


def digit_column_crops(path: str, max_zones: int = 4) -> List["Image.Image"]:
    """
    Franjas verticales (06/10) alrededor de cada dígito suelto que encuentra Paddle (textos de 1 a 3 dígitos): angostas
    (1,2 veces el dígito a cada lado) y altas (5 veces arriba y abajo), para que entre toda la columna de un número
    apilado. Se devuelven derechas y ampliadas a ~700 px de alto para el modelo de visión. Casos 05/10: el poste del
    6644 (Paddle solo veía un "4") y la pared del 3121.
    """
    if config.OCR_ENGINE != "paddle":
        return []
    try:
        det, det_h = _paddle_readtext(path, upscale=2)
        det_w = _LAST_PADDLE_WIDTH.get("w", 0)
        with Image.open(path) as im:
            base = ImageOps.exif_transpose(im).convert("RGB")
    except Exception:
        return []
    W, H = base.size
    sx = W / max(1.0, det_w) if det_w else 0.5
    sy = H / max(1.0, det_h) if det_h else 0.5
    out = []
    zones = [d for d in det if re.fullmatch(r"\d{1,3}", re.sub(r"\s", "", d[1] or ""))][:max_zones]
    for bbox, _, _ in zones:
        xs = [p[0] * sx for p in bbox]; ys = [p[1] * sy for p in bbox]
        s = max(max(xs) - min(xs), max(ys) - min(ys))
        crop = base.crop((max(0, int(min(xs) - 1.2 * s)), max(0, int(min(ys) - 5 * s)),
                          min(W, int(max(xs) + 1.2 * s)), min(H, int(max(ys) + 5 * s))))
        if crop.width < 8 or crop.height < 8:
            continue
        k = max(1.0, 700 / crop.height)
        out.append(crop.resize((int(crop.width * k), int(crop.height * k)), Image.LANCZOS))
    return out


def reread_numbers(path: str) -> List[tuple]:
    """
    Segunda lectura del OCR para números dudosos (regla 01/10): la foto girada 90° y 270° (dígitos apilados en vertical
    pasan a ser una fila: "3229", "6645", "2607", "3813") y cada zona con dígitos ampliada 3x (placas chicas: "2024",
    "707", "6711"). Devuelve [(número, confianza 0-100)].
    """
    out: List[tuple] = []
    if config.OCR_ENGINE == "paddle":
        return _paddle_reread(path)
    try:
        with Image.open(path) as im:
            base = _prepare(im, config.OCR_MAX_SIDE)
        reader = _easyocr_reader()
        # Imagen ampliada al doble con umbrales más bajos: aparecen los dígitos sueltos de los números apilados
        big = base.resize((base.width * 2, base.height * 2), Image.LANCZOS)
        det = reader.readtext(np.array(big), detail=1, paragraph=False, canvas_size=2560, text_threshold=0.5,
                              low_text=0.3)
        out.extend(_stacked_digits(det))
        for _, txt, conf in det:
            for n in _numeric_tokens({"text": [txt], "conf": [float(conf) * 100.0]}, config.OCR_MIN_CONFIDENCE):
                out.append((_digits(n), float(conf) * 100.0))
        arr = np.array(base)
        H, W = arr.shape[:2]
        for bbox, txt, _ in reader.readtext(arr, detail=1, paragraph=False, canvas_size=config.OCR_CANVAS_SIZE):
            if not re.search(r"\d", txt or ""):
                continue
            xs = [p[0] for p in bbox]; ys = [p[1] for p in bbox]
            w, h = max(xs) - min(xs), max(ys) - min(ys)
            box = (max(0, int(min(xs) - w)), max(0, int(min(ys) - h)), min(W, int(max(xs) + w)), min(H, int(max(ys) + h)))
            crop = base.crop(box)
            if crop.width < 8 or crop.height < 8:
                continue
            crop = crop.resize((crop.width * 3, crop.height * 3), Image.LANCZOS)
            for _, t2, c2 in reader.readtext(np.array(crop), detail=1, paragraph=False):
                for n in _numeric_tokens({"text": [t2], "conf": [float(c2) * 100.0]}, config.OCR_MIN_CONFIDENCE):
                    out.append((_digits(n), float(c2) * 100.0))
    except Exception:
        return out
    return [(n, c) for n, c in out if n]
