"""
Módulo de Detección de Imágenes Duplicadas / Reutilizadas en Comprobantes POD (Fase 6).

Implementa:
1. Hash exacto SHA-256 para archivos binariamente idénticos.
2. Perceptual Hashing (dHash y pHash con imagehash) para imágenes visualmente similares.
3. Comparación configurable mediante threshold (distancia de Hamming).
4. Clasificación formal estricta:
   - "Exact Duplicate"
   - "Possible Visual Duplicate"
   - "Unique"
5. Registro de auditoría persistente de qué fotografías fueron comparadas.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any
from pathlib import Path
from collections import defaultdict

from config import DUPLICATE_THRESHOLD
from models.pod import DuplicateStatusEnum
from processing.image_analysis import ImageQualityAnalyzer


@dataclass
class DuplicateCheckResult:
    """Resultado detallado de la comprobación de duplicados con información de auditoría."""
    classification: str = DuplicateStatusEnum.UNIQUE.value
    is_duplicate: bool = False
    reason: Optional[str] = None
    matched_tracking: Optional[str] = None
    matched_driver: Optional[str] = None
    matched_photo_path: Optional[str] = None
    hash_type: Optional[str] = None
    hamming_distance: Optional[int] = None
    threshold_used: int = DUPLICATE_THRESHOLD
    comparisons_log: List[Dict[str, Any]] = field(default_factory=list)
    registry_size: int = 0
    candidates_evaluated: int = 0

    def __iter__(self):
        """Permite desempaquetar como tupla (is_duplicate, reason) para retrocompatibilidad total."""
        yield self.is_duplicate
        yield self.reason


class _HashIndex:
    """Árbol BK: consulta exacta por radio de Hamming, sin aproximar candidatos."""
    def __init__(self):
        self.root = None

    def add(self, value, index):
        if self.root is None:
            self.root = [value, [index], {}]
            return
        node = self.root
        while True:
            distance = (value ^ node[0]).bit_count()
            if distance == 0:
                node[1].append(index)
                return
            child = node[2].get(distance)
            if child is None:
                node[2][distance] = [value, [index], {}]
                return
            node = child

    def search(self, value, radius):
        found = set()
        stack = [self.root] if self.root is not None else []
        while stack:
            node = stack.pop()
            distance = (value ^ node[0]).bit_count()
            if distance <= radius:
                found.update(node[1])
            stack.extend(child for edge, child in node[2].items() if distance-radius <= edge <= distance+radius)
        return found


def _hash_number(value):
    try:
        return int(value,16) if value else None
    except (ValueError,TypeError):
        return None


class DuplicateImageDetector:
    """Rastreador y comparador de evidencias fotográficas para auditoría de duplicados."""

    def __init__(self, max_hamming_distance: Optional[int] = None):
        self.max_hamming_distance = (
            max_hamming_distance
            if max_hamming_distance is not None
            else DUPLICATE_THRESHOLD
        )
        # Lista histórica de registros de la sesión
        self.registry: List[Dict[str, Any]] = []
        self._sha = defaultdict(list)
        self._exact = {kind:defaultdict(list) for kind in ('dhash','phash')}
        self._trees = {kind:_HashIndex() for kind in ('dhash','phash')}
        self._nonmetric = False

    def _remember(self, record):
        index=len(self.registry)
        self.registry.append(record)
        if record['sha256']:
            self._sha[record['sha256']].append(index)
        for kind in ('dhash','phash'):
            number=_hash_number(record[kind])
            if number is not None and number >= 0:
                self._exact[kind][number].append(index)
                self._trees[kind].add(number,index)
            elif number is not None:
                self._nonmetric=True


    def check_duplicate(
        self,
        tracking: str,
        driver: str,
        file_path: str,
        dhash: str = "",
        sha256: str = "",
        phash: str = "",
        threshold: Optional[int] = None,
    ) -> DuplicateCheckResult:
        """
        Consulta índices exactos y perceptuales. Conserva prioridad y orden de coincidencias
        del recorrido exhaustivo, con trazas acotadas a 24 candidatos.
        """
        max_dist = threshold if threshold is not None else self.max_hamming_distance
        comparisons: List[Dict[str, Any]] = []

        if not dhash and not sha256 and not phash:
            return DuplicateCheckResult(
                classification=DuplicateStatusEnum.UNIQUE.value,
                is_duplicate=False,
                reason=None,
                threshold_used=max_dist,
                comparisons_log=comparisons,
            )

        detected_exact: Optional[DuplicateCheckResult] = None
        detected_visual: Optional[DuplicateCheckResult] = None

        size=len(self.registry)
        evaluated=0
        numbers={'dhash':_hash_number(dhash),'phash':_hash_number(phash)}
        metric=not self._nonmetric and all(n is None or n >= 0 for n in numbers.values())
        exact=set(self._sha.get(sha256,()))
        for kind,number in numbers.items():
            if number is not None:
                exact.update(self._exact[kind].get(number,()))
        exact={i for i in exact if self.registry[i]['tracking']!=tracking}
        if metric and exact:
            candidates=[min(exact)]
        elif metric and max_dist < 64:
            possible=set()
            for kind,number in numbers.items():
                if number is not None and max_dist >= 0:
                    possible.update(self._trees[kind].search(number,max_dist))
            possible={i for i in possible if self.registry[i]['tracking']!=tracking}
            candidates=[min(possible)] if possible else []
        else:
            # Umbrales extremos o hashes no métricos conservan el comportamiento histórico.
            candidates=range(size)
        selected_entry=None
        for index in candidates:
            record=self.registry[index]
            # Fotos del mismo tracking corresponden a ángulos legítimos del mismo paquete
            if record["tracking"] == tracking:
                continue

            evaluated+=1
            # 1. Comparación SHA-256 (Archivos idénticos bit a bit)
            sha_match = bool(sha256 and record.get("sha256") and record["sha256"] == sha256)

            # 2. Comparación Perceptual Hash (dHash y pHash)
            d_dist = 64
            p_dist = 64
            if dhash and record.get("dhash"):
                d_dist = ImageQualityAnalyzer.hamming_distance(dhash, record["dhash"])
            if phash and record.get("phash"):
                p_dist = ImageQualityAnalyzer.hamming_distance(phash, record["phash"])

            min_perceptual_dist = min(d_dist, p_dist)

            # Guardar metadatos de qué fotografía se comparó
            comparison_entry = {
                "compared_tracking": record["tracking"],
                "compared_driver": record["driver"],
                "compared_file": record["file_path"],
                "sha256_match": sha_match,
                "dhash_distance": d_dist,
                "phash_distance": p_dist,
                "min_distance": min_perceptual_dist,
                "threshold": max_dist,
                "evaluated_at": Path(file_path).name if file_path else "memory",
            }
            if len(comparisons)<24:
                comparisons.append(comparison_entry)

            # A. Evaluación de Duplicado Exacto
            if sha_match or min_perceptual_dist == 0:
                if not detected_exact:
                    selected_entry=comparison_entry
                    match_type = "SHA-256" if sha_match else "Perceptual Hamming 0"
                    reason = (
                        f"FOTO IDÉNTICA ({match_type}): Coincide exactamente con entrega "
                        f"'{record['tracking']}' (Repartidor: {record['driver']})."
                    )
                    detected_exact = DuplicateCheckResult(
                        classification=DuplicateStatusEnum.EXACT_DUPLICATE.value,
                        is_duplicate=True,
                        reason=reason,
                        matched_tracking=record["tracking"],
                        matched_driver=record["driver"],
                        matched_photo_path=record["file_path"],
                        hash_type=match_type,
                        hamming_distance=0 if not sha_match else min_perceptual_dist,
                        threshold_used=max_dist,
                        comparisons_log=comparisons,
                    )
            # B. Evaluación de Duplicado Visual Similar
            elif min_perceptual_dist <= max_dist:
                if not detected_visual and not detected_exact:
                    selected_entry=comparison_entry
                    reason = (
                        f"FOTO PERCEPTUALMENTE DUPLICADA (Distancia {min_perceptual_dist}/{max_dist}): "
                        f"Similar a entrega '{record['tracking']}' (Repartidor: {record['driver']})."
                    )
                    detected_visual = DuplicateCheckResult(
                        classification=DuplicateStatusEnum.POSSIBLE_VISUAL_DUPLICATE.value,
                        is_duplicate=True,
                        reason=reason,
                        matched_tracking=record["tracking"],
                        matched_driver=record["driver"],
                        matched_photo_path=record["file_path"],
                        hash_type="Perceptual Hash",
                        hamming_distance=min_perceptual_dist,
                        threshold_used=max_dist,
                        comparisons_log=comparisons,
                    )

        if selected_entry is not None and selected_entry not in comparisons:
            if len(comparisons)>=24: comparisons.pop()
            comparisons.append(selected_entry)
        for result in (detected_exact,detected_visual):
            if result:
                result.registry_size=size
                result.candidates_evaluated=evaluated
        # Si se detectó duplicado exacto, tiene prioridad máxima
        if detected_exact:
            detected_exact.comparisons_log = comparisons
            return detected_exact

        # Si se detectó duplicado visual, tiene segunda prioridad
        if detected_visual:
            detected_visual.comparisons_log = comparisons
            return detected_visual

        # Si no coincidió con ninguna imagen previa en otros albaranes, registrar para futuros contrastes
        self._remember({
            "tracking": tracking,
            "driver": driver,
            "sha256": sha256,
            "dhash": dhash,
            "phash": phash,
            "file_path": file_path,
        })

        return DuplicateCheckResult(
            classification=DuplicateStatusEnum.UNIQUE.value,
            is_duplicate=False,
            reason=None,
            threshold_used=max_dist,
            comparisons_log=comparisons,
            registry_size=size,
            candidates_evaluated=evaluated,
        )

    def register_and_check(
        self,
        tracking: str,
        driver: str,
        file_path: str,
        dhash: str = "",
        sha256: str = "",
        phash: str = "",
        threshold: Optional[int] = None,
    ) -> DuplicateCheckResult:
        """
        Método unificado compatible con versiones anteriores.
        Retorna DuplicateCheckResult que se puede desempaquetar como (is_duplicate, reason).
        """
        return self.check_duplicate(
            tracking=tracking,
            driver=driver,
            file_path=file_path,
            dhash=dhash,
            sha256=sha256,
            phash=phash,
            threshold=threshold,
        )

    def clear(self):
        """Reinicia el registro para una nueva sesión de consulta."""
        self.__init__(self.max_hamming_distance)
