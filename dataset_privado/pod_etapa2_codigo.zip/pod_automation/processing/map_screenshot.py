"""
Capturas de pantalla de un mapa (Apple Maps / Google Maps) subidas como foto de POD.

El repartidor las usa para mostrar que estaba en la dirección correcta, así que no son error por sí
solas: se compara la dirección que muestra la captura (leída por el OCR) con la del paquete.
Caso real: la misma captura de "The Gio Apartments, 1800 E Spring Creek Pkwy" subida en 6 albaranes;
5 eran de ese edificio (correcto) y 1 de "5000 K Ave" (otra dirección: error).
"""

import re
from typing import Optional

MAP_KEYWORDS = (
    "reportar un problema", "report an issue", "horario", "sitio web", "website", "indicaciones",
    "directions", "anclar", "foursquare", "estados unidos", "united states", "apple maps", "google maps",
    "direccion", "dirección", "telefono", "teléfono", "abierto", "cerrado", "open now", "closed",
    # Google Maps
    "buscar aqui", "buscar aquí", "search here", "como llegar", "cómo llegar", "iniciar", "guardar", "compartir",
    "edificio multiusos", "start", "save", "share",
    # OCR confunde "ll" con "Il" ("Como Ilegar"); pantalla de navegación de Google Maps (caso 6510 Josephine Dr)
    "ilegar", "llegar", "llegaste a", "you have arrived", "reiniciar", "a pie", "navegacion", "navegación",
    "guardar el estacionamiento", "como estuvo",
    # App de GOFO del repartidor (mapa de la parada con la dirección abajo; caso real 02/10: 105 Stonebriar Way)
    "pendiente", "firmado", "excepcion", "excepción", "direccion incorrecta", "dirección incorrecta",
    "agregar paquete",
    # 11/10: mapa de Google Maps sin ficha ("Buscar aquí … Explorar Tú Contribuir"), "Historial POD" de la app de GOFO
    # y Street View ("Aérea", "Hace 5 meses - Ver más fechas"); casos 2318 Village Green Dr, 601 Rose Hill Rd, 2816 W Aspen Ct
    "explorar", "contribuir", "historial pod", "comprobantes de entrega", "aerea", "ver mas fechas", "street view",
    "see more dates",
)
MIN_KEYWORDS = 3

STREET_STOPWORDS = {"street", "st", "drive", "dr", "avenue", "ave", "lane", "ln", "road", "rd", "north", "south",
                    "east", "west", "n", "s", "e", "w", "apt", "unit", "building", "bldg", "suite", "ste", "pkwy",
                    "parkway", "blvd", "boulevard", "court", "ct", "way", "circle", "cir", "trail", "trl", "hwy"}

# "1800 E Spring Creek" / "5000 K Ave": número de 2 a 6 dígitos seguido de una palabra de calle
# Número de 3 a 6 dígitos + calle de 4+ letras: "56 Ilil" (basura del OCR en la captura) no cuenta como dirección
ADDRESS_RE = re.compile(r"\b(\d{3,6})\s+((?:[NSEW]\.?\s+)?[A-Za-z]{4,}(?:\s+[A-Za-z]{2,})?)")


def _norm(text: str) -> str:
    t = (text or "").lower()
    for a, b in (("á", "a"), ("é", "e"), ("í", "i"), ("ó", "o"), ("ú", "u")):
        t = t.replace(a, b)
    return t


# Nombres de calles del mapa en mayúsculas ("SPRING CREEK DR", "LENT OAK LN"). Apple Maps casi no tiene botones con
# texto: caso real 04/10 (1506 Spring St) solo leía "ICA", "Address" y las calles del mapa
MAP_STREET_LABEL_RE = re.compile(r"\b[A-Z]{3,} (?:ST|DR|RD|LN|CT|AVE|BLVD|PKWY|WAY|CIR|TRL|PL|LOOP|ROAD|STREET|DRIVE|LANE)\b")


def is_map_screenshot(text: str) -> bool:
    t = _norm(text)
    if sum(1 for k in MAP_KEYWORDS if _norm(k) in t) >= MIN_KEYWORDS:
        return True
    labels = set(MAP_STREET_LABEL_RE.findall(text or ""))
    phone_screen = bool(re.match(r"\s*\d{1,2}:\d{2}(?!\d)", text or "")) or re.search(r"\b(address|ica|aqi)\b", t)
    if len(labels) >= 3 and phone_screen:
        return True
    # 11/10: Street View de Google Maps ("enero de 2024 Aérea 2816 W Aspen Ct"; "Ver más fechas" no siempre se lee)
    if re.search(r"\b(ver mas fechas|see more dates)\b", t) or (
            re.match(r"\s*\d{1,2}:\d{2}(?!\d)", text or "") and re.search(r"\baerea\b", t)
            and re.search(r"\b(enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|octubre|noviembre|diciembre)"
                          r" de 20\d\d\b", t)):
        return True
    # 06/10: pantalla de llegada de Google Maps ("Llegaste a <dirección>") con la hora del teléfono: a tamaño normal
    # el OCR solo leía "Llegaste a × 81 05" (caso 2816 Wateridge Ct) y no se releía ampliada
    if re.match(r"\s*\d{1,2}:\d{2}(?!\d)", text or "") and re.search(r"\b(llegaste a|you have arrived)\b", t):
        return True
    # Apple Maps: botón "3D" + hora de la barra de estado (caso real 05/10: pin "6741 County Road 889"; solo se leían
    # las calles del mapa, todas "COUNTY ROAD")
    return bool(re.match(r"\s*\d{1,2}:\d{2}(?!\d)", text or "")) and bool(re.search(r"\b3D\b", text or ""))


def _street_words(street: str) -> set:
    words = re.findall(r"[a-z]{3,}", _norm(street))
    return {w for w in words if w not in STREET_STOPWORDS}


CHAT_RE = re.compile(r"\d{1,2}:\d{2}(:\d{2})?\s*\d{1,2}/\d{1,2}/\d{2,4}")   # "10:42:55 09/30/2026" de cada mensaje
STATUS_BAR_RE = re.compile(r"^\s*\d{1,2}[:.]\d{2}(?!\d)")   # Hora de la barra de estado del teléfono


CHAT_DATE_RE = re.compile(r"(?<!\d)\d{1,2}\s?[/.\-]\s?\d{1,2}\s?[/.\-]\s?20\d{2}(?!\d)")  # "09/30/2026" (con espacios del OCR)
CHAT_WORDS = ("mensajes enviados", "actualizar", "please provide the correct address", "messages sent")


def is_chat_screenshot(text: str) -> bool:
    """Captura del chat con el cliente (mensajes con fecha y hora). Caso real: 2410 Finley Apt 306."""
    t = text or ""
    return (len(CHAT_RE.findall(t)) >= 2 or len(CHAT_DATE_RE.findall(t)) >= 3
            or (sum(w in _norm(t) for w in CHAT_WORDS) >= 1 and len(CHAT_DATE_RE.findall(t)) >= 1))


def is_phone_screenshot(text: str) -> bool:
    """Cualquier captura de pantalla del teléfono (mapa o chat): no se evalúa por calidad de imagen."""
    return is_map_screenshot(text) or is_chat_screenshot(text)


# 11/10: ficha de un lugar en Google Maps ("Magnolia Grove Apartments": opiniones, "Acerca de", dirección). El repartidor
# la sube igual en todos los albaranes del complejo (caso real 551 Crossroads Pkwy, unidades 7305 y 5204)
PLACE_CARD_KEYWORDS = ("calificar y opinar", "ver todas las opiniones", "agregar fotos y videos", "de la empresa",
                       "acerca de", "opiniones", "rate and review", "see all reviews", "add photos", "from the owner",
                       "reviews", "reservar", "llamar")


def is_place_card(text: str) -> bool:
    t = _norm(text)
    return sum(1 for k in PLACE_CARD_KEYWORDS if _norm(k) in t) >= 3


def chat_addresses(text: str) -> list:
    """Direcciones "número + calle" escritas en el chat (ej. la dirección corregida por el cliente)."""
    clean = CHAT_DATE_RE.sub(" ", CHAT_RE.sub(" ", text or ""))   # Sin fechas/horas de los mensajes
    return [f"{a.group(1)} {a.group(2)}" for a in ADDRESS_RE.finditer(clean)]


# Palabras de la pantalla del mapa que siguen a un número y NO son una calle ("859 Visitados recientemente", "4.8
# reseñas", "1 min"; caso real 03/10: "3570 FM 859" leído como otra dirección "859 Visitados")
NOT_STREET_WORDS = {"visitados", "visitado", "recientemente", "visited", "recently", "min", "mins", "minutos", "horas",
                    "hours", "resenas", "reseñas", "reviews", "estrellas", "stars", "millas", "miles", "pies", "feet",
                    # 11/10: categorías de Google Maps ("769 Edificio multiusos", caso 1003 West St, McKinney)
                    "edificio", "multiusos", "restaurantes", "compras", "cafeterias", "tiendas"}


def screenshot_address(text: str) -> Optional[str]:
    """Primera dirección "número + calle" que aparece después de "Dirección"/"Address" (o en todo el texto)."""
    t = text or ""
    m = re.search(r"(direcci[oó]n|address|llegaste a|you have arrived( at)?)", t, flags=re.IGNORECASE)
    tail = t[m.end():] if m else t
    for a in ADDRESS_RE.finditer(tail):
        # El código postal seguido de texto no es una dirección (caso real 04/10: "75160 Edificio multiusos")
        if re.fullmatch(r"7[5-9]\d{3}", a.group(1)):
            continue
        # 06/10: "274 GFUS01075830767360" en la app de GOFO es la parada + el albarán, no una dirección
        if _norm(a.group(2).split()[0]) not in NOT_STREET_WORDS and not a.group(2).upper().startswith("GFUS"):
            return f"{a.group(1)} {a.group(2)}"
    return None


def screenshot_address_status(text: str, house_number: str, street: str) -> tuple:
    """
    ("match" | "mismatch" | "unknown", dirección leída).
    match: el número de la casa y alguna palabra del nombre de la calle aparecen juntos en la captura.
    """
    found = screenshot_address(text)
    t = _norm(text)
    # 11/10: "West St" queda sin palabras propias (todas son genéricas) y "1003 West St" salía como otra dirección
    words = _street_words(street) or {w for w in re.findall(r"[a-z]{3,}", _norm(street))}
    # Carreteras rurales: "3570 FM 859", "1444 County Road 303" -> el número de la vía también identifica la calle
    words |= set(re.findall(r"\b\d{2,5}\b", street or ""))
    # "FM148" pegado (caso 06/10: 8974 FM148, Terrell): la vía entera como palabra, sin espacios
    words |= {w for w in re.findall(r"[a-z]+\d+", _norm(street)) if len(w) >= 3}
    if house_number and re.search(rf"\b{re.escape(house_number)}\b", t) and words:
        # La palabra de calle debe estar cerca del número (misma línea de dirección)
        for m in re.finditer(rf"\b{re.escape(house_number)}\b", t):
            # Sin espacios: "Springcreek" (paquete) == "Spring Creek" (mapa)
            window = re.sub(r"[^a-z0-9]", "", t[m.end(): m.end() + 40])
            if any(w in window for w in words):
                return "match", found or house_number
    if found:
        # 11/10: en el MAPA de la app de GOFO los números son las casas dibujadas y los nombres son las calles: el OCR
        # junta "6350" con "Ridge Rd" (caso 7112 Mitchell Dr, el pin estaba en 7112). Si la calle esperada aparece en
        # la captura, no es "otra dirección": queda para revisar
        if _is_gofo_map(t) and words and any(w in re.sub(r"[^a-z0-9]", "", t) for w in words if not w.isdigit()):
            return "unknown", found
        return "mismatch", found
    return "unknown", None


def _is_gofo_map(t: str) -> bool:
    return "mapbox" in t or sum(k in t for k in ("pendiente", "firmado", "excepcion", "agregar paquete")) >= 2
