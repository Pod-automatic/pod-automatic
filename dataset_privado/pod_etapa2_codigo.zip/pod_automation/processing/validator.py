"""
Módulo Validador Central de POD (Fase 4: Motor de Validación Configurable).

Orquesta el análisis de calidad de imagen, detección de duplicados y evaluación
secuencial de reglas de negocio para clasificar cada entrega en:
- VALID / LIKELY VALID
- REVIEW REQUIRED
- POSSIBLE ISSUE
- ERROR

Garantiza que ninguna entrega sea rechazada automáticamente, dejando el control
final en manos de un revisor humano.
"""

import re

import config
from typing import List, Optional, Any
from models.pod import (
    PODRecord,
    VerdictEnum,
    ValidationClassification,
    AnomalyCode,
    PODMemoryStorage,
)
from processing.image_analysis import ImageQualityAnalyzer
from processing.duplicate_detection import DuplicateImageDetector
from processing.scoring import score_pod
from processing.ocr_address import parse_us_address, building_key, same_building_key  # noqa: F401 (building_key: compatibilidad)


from processing.rules import (
    BaseRule,
    MissingPhotoRule,
    UnreadableImageRule,
    BasicInfoCompletenessRule,
    DuplicatePhotoRule,
    ImageQualityRule,
    PlatformIncidentRule,
    RuleEvaluationResult,
)


def _site(pod: PODRecord):
    meta = pod.portal_meta or {}
    try:
        return (parse_us_address(pod.expected_address or "").is_apartment,
                float(meta.get("pod_lat")), float(meta.get("pod_lng")))
    except (TypeError, ValueError):
        return None


def same_apartment_complex(a, b) -> bool:
    """
    Dos albaranes de APARTAMENTO cuyos POD se tomaron a menos de DUPLICATE_SAME_COMPLEX_M: el mismo complejo
    aunque las calles sean distintas (caso real "Parks at Treepoint": Ridgetree, Overview, Treepoint, Wild Holly;
    la foto repetida es el cartel de la entrada). En casas NO aplica: ahí una foto repetida en otra dirección es error.
    """
    import math
    if not a or not b or not (a[0] and b[0]):
        return False
    dlat = math.radians(b[1] - a[1])
    dlng = math.radians(b[2] - a[2]) * math.cos(math.radians((a[1] + b[1]) / 2))
    return 6371000 * math.hypot(dlat, dlng) <= config.DUPLICATE_SAME_COMPLEX_M


class PODValidator:
    """Motor de clasificación de entregas POD para asistencia a la decisión humana."""

    def __init__(
        self,
        image_analyzer: Optional[ImageQualityAnalyzer] = None,
        duplicate_detector: Optional[DuplicateImageDetector] = None,
        rules: Optional[List[BaseRule]] = None,
        run_ocr: bool = True,
    ):
        # run_ocr: si validate_pod no recibe resultados de OCR, ejecutarlo en línea
        self.run_ocr = run_ocr
        # tracking -> clave de edificio (número + calle), para distinguir duplicados legítimos
        self._building_keys = {}
        # tracking -> (es apartamento, lat, lng) del POD: una foto repetida dentro del mismo complejo es normal
        self._sites = {}
        self.image_analyzer = image_analyzer or ImageQualityAnalyzer()
        self.duplicate_detector = duplicate_detector or DuplicateImageDetector()
        self.rules: List[BaseRule] = rules or [
            UnreadableImageRule(),
            MissingPhotoRule(),
            BasicInfoCompletenessRule(),
            ImageQualityRule(),
            DuplicatePhotoRule(),
            PlatformIncidentRule(),
        ]

    def validate_pod(self, pod: PODRecord, ocr_results: Optional[List[Any]] = None) -> PODRecord:
        """
        Audita una entrega individual:
        1. Analiza imágenes locales mediante Computer Vision (nitidez, brillo, contraste, dHash).
        2. Registra y verifica duplicidad cross-tracking.
        3. Ejecuta el conjunto de reglas configurables.
        4. Asigna la clasificación preliminar para triaje humano.
        """
        # 1. Analizar imágenes locales
        self._building_keys[pod.tracking_number] = building_key(pod.expected_address)
        self._sites[pod.tracking_number] = _site(pod)
        pod.image_metrics.clear()
        for local_path in pod.photo_paths:
            metrics = self.image_analyzer.analyze_image(local_path)
            if metrics:
                pod.image_metrics.append(metrics)

                # 2. Detección de fotos duplicadas entre albaranes (Fase 6)
                dup_result = self.duplicate_detector.register_and_check(
                    tracking=pod.tracking_number,
                    driver=pod.driver_name,
                    file_path=local_path,
                    dhash=metrics.perceptual_hash,
                    sha256=metrics.sha256,
                    phash=getattr(metrics, "phash", ""),
                )
                search=pod.portal_meta.setdefault('duplicate_search',{'registry_size':0,'candidates_evaluated':0})
                search['registry_size']=max(search['registry_size'],dup_result.registry_size)
                search['candidates_evaluated']+=dup_result.candidates_evaluated
                if dup_result.is_duplicate:
                    pod.duplicate_status = dup_result.classification
                    pod.duplicate_matched_tracking = dup_result.matched_tracking
                    pod.duplicate_matched_photo = dup_result.matched_photo_path
                    mine = self._building_keys.get(pod.tracking_number)
                    same_building = same_building_key(mine, self._building_keys.get(dup_result.matched_tracking))
                    same_complex = same_apartment_complex(self._sites.get(pod.tracking_number),
                                                          self._sites.get(dup_result.matched_tracking))
                    pod.portal_meta["duplicate_same_building"] = same_building or same_complex
                    if same_complex and not same_building:
                        pod.portal_meta["duplicate_same_complex"] = True
                    if dup_result.reason:
                        pod.add_anomaly(
                            AnomalyCode.FOTO_DUPLICADA,
                            dup_result.reason,
                            penalty=50.0,
                        )
                if dup_result.comparisons_log:
                    # Solo las comparaciones más parecidas: guardar TODAS (contra cada foto del día) llevó la base de
                    # 3 GB a 27 GB el 04/10 (17 MB por albarán) y la corrida se cayó por falta de memoria
                    pod.duplicate_comparisons.extend(dup_result.comparisons_log)
                    pod.duplicate_comparisons = sorted(
                        pod.duplicate_comparisons,
                        key=lambda c: (not c.get("sha256_match"), c.get("min_distance", 64)))[:5]

        # 3. Evaluar reglas configurables
        triggered_results: List[RuleEvaluationResult] = []
        for rule in self.rules:
            result = rule.evaluate(pod)
            if result and result.triggered:
                triggered_results.append(result)
                if result.flag:
                    pod.add_flag(result.flag)

        # 4. Determinar clasificación por precedencia de severidad
        self._assign_classification(pod, triggered_results)

        # 5. Generar notas de auditoría legibles para el revisor
        if not pod.anomalies:
            pod.audit_notes = "Evidencia completa y nítida. Clasificada preliminarmente como válida."
        else:
            pod.audit_notes = " | ".join(pod.anomalies)

        # 6. Triaje por score de riesgo (0-100) y prioridad Alta/Media/Baja
        if ocr_results is None and self.run_ocr and pod.photo_paths:
            from processing.pipeline import ocr_photos
            ocr_results = ocr_photos(pod.photo_paths)
        score_pod(pod, ocr_results or [])

        return pod

    def _assign_classification(self, pod: PODRecord, results: List[RuleEvaluationResult]) -> None:
        """
        Asigna la clasificación respetando la precedencia:
        ERROR > POSSIBLE ISSUE > REVIEW REQUIRED > LIKELY VALID / VALID.
        Garantiza que el sistema NUNCA rechace automáticamente una entrega.
        """
        severities = [r.suggested_classification for r in results]

        if ValidationClassification.ERROR in severities:
            pod.classification = ValidationClassification.ERROR
            pod.verdict = VerdictEnum.SOSPECHOSO
            pod.abnormal_status = True

        elif ValidationClassification.POSSIBLE_ISSUE in severities:
            pod.classification = ValidationClassification.POSSIBLE_ISSUE
            pod.verdict = VerdictEnum.SOSPECHOSO
            pod.abnormal_status = True

        elif ValidationClassification.REVIEW_REQUIRED in severities:
            pod.classification = ValidationClassification.REVIEW_REQUIRED
            pod.verdict = VerdictEnum.REQUIERE_REVISION
            pod.abnormal_status = True

        else:
            # Si no hubo alertas críticas
            if pod.quality_score >= 85.0:
                pod.classification = ValidationClassification.VALID
            else:
                pod.classification = ValidationClassification.LIKELY_VALID
            pod.verdict = VerdictEnum.VALIDO
            pod.abnormal_status = False

    def validate_batch(self, pod_list: List[PODRecord]) -> List[PODRecord]:
        """Audita una lista por lotes de registros POD."""
        return [self.validate_pod(pod) for pod in pod_list]

    def validate_storage(self, storage: PODMemoryStorage) -> PODMemoryStorage:
        """Audita todos los registros contenidos en un PODMemoryStorage en memoria."""
        for pod in storage.get_all():
            self.validate_pod(pod)
        return storage
