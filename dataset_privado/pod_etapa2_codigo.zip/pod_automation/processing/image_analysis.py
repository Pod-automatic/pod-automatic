"""
Módulo de Computer Vision y Análisis de Calidad de Imagen para POD (Fase 5).

Implementa:
- Fachada y Administrador de Proveedores de Análisis de Imagen (`ImageAnalysisManager` e `ImageQualityAnalyzer`).
- Detección de resolución y aspect ratio.
- Detección de tamaño e integridad (archivos vacíos o corruptos).
- Detección de desenfoque/borrosidad (Varianza del Laplaciano con OpenCV y fallback NumPy).
- Detección de subexposición (imágenes oscuras/negras) y sobreexposición (quemadas por flash).
- Detección de lentes tapados o imágenes uniformes/planas.
- Cálculo de Perceptual Hash (dHash, pHash, aHash) e integridad SHA-256.

RESTRICCIÓN ÉTICA Y DE PRIVACIDAD:
El sistema NO implementa ni admitirá reconocimiento facial ni identificación
de personas. Solo audita calidad física del comprobante (POD) y evidencia objetiva.
"""

from pathlib import Path
from typing import Optional, Dict, Any, Union
import hashlib
from PIL import Image
import numpy as np

from config import (
    IMAGE_ANALYSIS_CONFIG,
    BLUR_THRESHOLD,
    MIN_BRIGHTNESS,
    MAX_BRIGHTNESS,
)
from models.pod import ImageQualityMetrics
from processing.providers.base import (
    BaseImageAnalysisProvider,
    ImageAnalysisResult,
    ImageSimilarityResult,
    ImageHashes,
)
from processing.providers.local_provider import LocalCVImageProvider
from processing.providers.multimodal_stub import MultimodalAIStubProvider


def get_image_provider(provider_type: Optional[str] = None, config_dict: Optional[Dict[str, Any]] = None) -> BaseImageAnalysisProvider:
    """Fábrica de proveedores de análisis de imágenes."""
    cfg = config_dict or IMAGE_ANALYSIS_CONFIG
    chosen_type = provider_type or cfg.get("PROVIDER", "local")

    if chosen_type == "multimodal":
        return MultimodalAIStubProvider(config_dict=cfg)
    return LocalCVImageProvider(config_dict=cfg)


class ImageAnalysisManager:
    """
    Administrador central de visión computacional y análisis de calidad de imágenes.
    
    Permite inyectar cualquier proveedor que cumpla con `BaseImageAnalysisProvider`
    o utiliza por defecto el proveedor local de OpenCV + Pillow + imagehash.
    """

    def __init__(
        self,
        provider: Optional[BaseImageAnalysisProvider] = None,
        config_dict: Optional[Dict[str, Any]] = None,
    ):
        self.config = config_dict or IMAGE_ANALYSIS_CONFIG
        self.provider = provider or get_image_provider(config_dict=self.config)

    def analyze_image(self, file_path: Union[str, Path]) -> Optional[ImageQualityMetrics]:
        """
        Analiza una imagen mediante el proveedor activo y retorna su métrica enriquecida.
        Mantiene 100% compatibilidad con el modelo de datos POD.
        """
        path = Path(file_path)
        if not path.exists() or not path.is_file():
            return None

        result: ImageAnalysisResult = self.provider.analyze(path)
        return result.to_metrics()

    def analyze_full(self, file_path: Union[str, Path]) -> ImageAnalysisResult:
        """Retorna el resultado completo ImageAnalysisResult."""
        return self.provider.analyze(Path(file_path))

    def compare_images(
        self,
        file_path1: Union[str, Path],
        file_path2: Union[str, Path],
        max_hamming_distance: Optional[int] = None,
    ) -> ImageSimilarityResult:
        """Compara dos imágenes locales determinando si son idénticas o muy similares."""
        return self.provider.compare_similarity(
            Path(file_path1),
            Path(file_path2),
            max_hamming_distance=max_hamming_distance,
        )

    def compute_hashes(self, file_path: Union[str, Path]) -> ImageHashes:
        """Calcula el conjunto completo de hashes (dHash, pHash, aHash, SHA-256)."""
        return self.provider.compute_hashes(Path(file_path))


class ImageQualityAnalyzer(ImageAnalysisManager):
    """
    Analizador de calidad de imagen para comprobantes de entrega (POD).
    
    Extiende ImageAnalysisManager preservando compatibilidad exacta con constructores
    y métodos estáticos de versiones anteriores.
    """

    def __init__(
        self,
        blur_threshold: float = BLUR_THRESHOLD,
        min_brightness: float = MIN_BRIGHTNESS,
        max_brightness: float = MAX_BRIGHTNESS,
        provider: Optional[BaseImageAnalysisProvider] = None,
    ):
        cfg = dict(IMAGE_ANALYSIS_CONFIG)
        cfg["BLUR_THRESHOLD"] = blur_threshold
        cfg["MIN_BRIGHTNESS"] = min_brightness
        cfg["MAX_BRIGHTNESS"] = max_brightness

        custom_provider = provider or LocalCVImageProvider(config_dict=cfg)
        super().__init__(provider=custom_provider, config_dict=cfg)
        self.blur_threshold = blur_threshold
        self.min_brightness = min_brightness
        self.max_brightness = max_brightness

    @staticmethod
    def calculate_dhash(image: Image.Image, hash_size: int = 8) -> str:
        """
        Calcula el Difference Hash (dHash) perceptual de 64 bits de una imagen.
        Resistente a cambios menores de escala, compresión JPEG y brillo.
        """
        resized = image.convert("L").resize((hash_size + 1, hash_size), Image.Resampling.BILINEAR)
        pixels = np.asarray(resized, dtype=np.float32)

        difference = pixels[:, 1:] > pixels[:, :-1]
        decimal_val = 0
        for bit in difference.flatten():
            decimal_val = (decimal_val << 1) | int(bit)

        return f"{decimal_val:016x}"

    @staticmethod
    def hamming_distance(hash1: str, hash2: str) -> int:
        """Calcula la distancia de Hamming (número de bits diferentes) entre dos hashes hexadecimales."""
        try:
            val1 = int(hash1, 16)
            val2 = int(hash2, 16)
            return bin(val1 ^ val2).count("1")
        except (ValueError, TypeError):
            return 64

    @staticmethod
    def compute_sha256(file_path: Path) -> str:
        """Calcula el hash criptográfico SHA-256 de un archivo para detectar duplicados idénticos bit a bit."""
        hasher = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                hasher.update(chunk)
        return hasher.hexdigest()
