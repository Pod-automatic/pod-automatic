"""
Módulo de Configuración Centralizada para POD Automation.

Gestiona las rutas absolutas, umbrales de Computer Vision, parámetros
de Playwright y configuración de reglas de negocio.
"""

from pathlib import Path
import os
from dotenv import load_dotenv

# Cargar variables de entorno si existe .env
load_dotenv()

# Rutas Base del Proyecto
PROJECT_ROOT = Path(__file__).resolve().parent
STORAGE_DIR = PROJECT_ROOT / os.getenv("STORAGE_DIR", "storage")
OUTPUT_DIR = PROJECT_ROOT / os.getenv("OUTPUT_DIR", "output")
SCREENSHOTS_DIR = STORAGE_DIR / "screenshots"
POD_IMAGES_DIR = STORAGE_DIR / "pod_images"
LOGS_DIR = STORAGE_DIR / "logs"
RUNTIME_STATE_DIR = STORAGE_DIR
GOFO_SESSION_GROUP = os.getenv('GOFO_SESSION_GROUP','').strip()
# 28/10: duracion del permiso de la sesion compartida (el portal devuelve la que concede). Mas largo = tolera cortes mayores
# del portal sin perder la exclusion; tras una caida de esta PC el permiso tarda eso en liberarse para otro worker.
GOFO_SESSION_LEASE_S = max(60,min(1800,int(os.getenv('GOFO_SESSION_LEASE_S','180'))))
# 28/10 (pedido del usuario): si el portal no responde en este tiempo, la PC (solo CLAIM_WORKER=pc) sigue sola con la
# sesion: el permiso de Kaggle ya vencio y Kaggle nunca sigue sin portal. 0 = esperar siempre.
# 29/10: 210 s (antes 360) = permiso de 180 s + 30 de margen, contados desde el primer fallo seguido. Es un minimo: si el
# portal dio un permiso mas largo, se espera ese permiso + 30 (session_guard.offline_wait_s).
GOFO_SESSION_OFFLINE_S = max(0,float(os.getenv('GOFO_SESSION_OFFLINE_S','210')))
CITY_DISPATCH_DB = os.getenv('CITY_DISPATCH_DB','').strip()
CITY_TURN_S = max(30,float(os.getenv('CITY_TURN_S','180')))
ASYNC_ANALYSIS = os.getenv('ASYNC_ANALYSIS','0').lower() in ('1','true')
ANALYSIS_QUEUE_SIZE = max(2,int(os.getenv('ANALYSIS_QUEUE_SIZE','8')))
ROUTE_LIST_CACHE_S = max(0,float(os.getenv('ROUTE_LIST_CACHE_S','0')))
EMPTY_ROUTE_CACHE_S = max(0,float(os.getenv('EMPTY_ROUTE_CACHE_S','120')))
GPU_DISPATCH_DB = os.getenv('GPU_DISPATCH_DB','').strip()
# 29/10: consultas simultaneas al modelo de vision por servicio Ollama; debe ser igual a OLLAMA_NUM_PARALLEL de ese servicio
# (benchmark 28/10 en la 4050: paralelo 2 con 2 clientes ~255 img/min contra ~158 con paralelo 1). 1 = como antes.
GPU_SLOTS_PER_URL = max(1,int(os.getenv('GPU_SLOTS_PER_URL','1')))
ANALYSIS_POOL_DB = os.getenv('ANALYSIS_POOL_DB','').strip()
ANALYSIS_POOL_SIZE = max(1,int(os.getenv('ANALYSIS_POOL_SIZE','4')))
SESSION_FILE = PROJECT_ROOT / os.getenv("SESSION_FILE", "storage/session_state.json")

# Perfil Persistente de Google Chrome
# 22/10: el proyecto corre también en Ubuntu (deploy/ubuntu): las rutas por defecto dependen del sistema
IS_WINDOWS = os.name == "nt"
CHROME_USER_DATA_DIR = os.getenv("CHROME_USER_DATA_DIR", r"C:\Users\luisv\AppData\Local\Google\Chrome\User Data"
                                 if IS_WINDOWS else str(Path.home() / ".config" / "google-chrome"))
CHROME_PROFILE_DIR = os.getenv("CHROME_PROFILE_DIR", "Default")

# Autenticación: el login de Google NUNCA se automatiza. Un humano inicia sesión una vez
# (`python main.py login`) y las corridas reutilizan el storage_state guardado.
#   AUTH_MODE=storage_state (defecto): Chromium propio + SESSION_FILE, apto para headless.
#   AUTH_MODE=cdp: modo legado, se conecta a un Chrome abierto a mano con el puerto de depuración.
AUTH_MODE = os.getenv("AUTH_MODE", "storage_state").lower()
BROWSER_PROFILE_DIR = PROJECT_ROOT / os.getenv("BROWSER_PROFILE_DIR", "storage/browser_profile")
CDP_PORT = int(os.getenv("CDP_PORT", "9222"))
CHROME_PATH = os.getenv("CHROME_PATH", "")  # Opcional; si está vacío se autodetecta
# Fragmentos de URL que indican que el portal redirigió a un login (sesión vencida)
LOGIN_URL_MARKERS = [
    m.strip().lower()
    for m in os.getenv("LOGIN_URL_MARKERS", "accounts.google.com,login,signin,oauth,sso").split(",")
    if m.strip()
]

# Asegurar directorios de almacenamiento
for folder in [STORAGE_DIR, OUTPUT_DIR, SCREENSHOTS_DIR, POD_IMAGES_DIR, LOGS_DIR]:
    folder.mkdir(parents=True, exist_ok=True)

# Portal Gofo Express
GOFO_PORTAL_URL = os.getenv("GOFO_PORTAL_URL", "https://dms.gofoexpress.com/gofo-report/report/reportCenter/siteDashboardUs")
GOFO_DASHBOARD_PATH = os.getenv("GOFO_DASHBOARD_PATH", "/dsp/dashboard")

# ==============================================================================
# FASE 9 & 13: CONFIGURACIÓN GENERAL Y MODO READ-ONLY
# ==============================================================================
# Navegador Playwright
HEADLESS = os.getenv("HEADLESS", "false").lower() in ("true", "1", "yes") # False por defecto (modo visible)
SLOW_MO = int(os.getenv("SLOW_MO", "100"))                               # 100 ms entre acciones
DEFAULT_TIMEOUT = int(os.getenv("DEFAULT_TIMEOUT", "30000"))              # 30,000 ms timeout
BROWSER_TIMEOUT_MS = DEFAULT_TIMEOUT
SLOW_MO_MS = SLOW_MO

# Resiliencia y almacenamiento
MAX_RETRIES = int(os.getenv("MAX_RETRIES", "3"))                         # 3 reintentos por POD
OUTPUT_DIRECTORY = PROJECT_ROOT / os.getenv("OUTPUT_DIRECTORY", "./output")
OUTPUT_DIR = OUTPUT_DIRECTORY
SCREENSHOT_ON_ERROR = os.getenv("SCREENSHOT_ON_ERROR", "true").lower() in ("true", "1", "yes")
DATE_FORMAT = os.getenv("DATE_FORMAT", "MM/DD/YYYY")
OPERATION_TIMEZONE = os.getenv("OPERATION_TIMEZONE", "America/Caracas")
# 30/10 (pedido del usuario, PC y Kaggle): pasada la medianoche se sigue con lo pendiente del día anterior hasta que el día
# nuevo tenga al menos DAY_CARRY_MIN_POD entregas con POD en GOFO (se mira cada DAY_CARRY_PROBE_S), el anterior se quede
# sin trabajo o lleguen las DAY_CARRY_UNTIL_H. Ver automation/day_carry.py. 0 = a las 00:00 se pasa al día nuevo (como antes).
DAY_CARRY_OVER = os.getenv("DAY_CARRY_OVER", "1").lower() in ("1", "true")
DAY_CARRY_UNTIL_H = int(os.getenv("DAY_CARRY_UNTIL_H", "12"))
DAY_CARRY_PROBE_S = float(os.getenv("DAY_CARRY_PROBE_S", "600"))
DAY_CARRY_MIN_POD = int(os.getenv("DAY_CARRY_MIN_POD", "20"))
CLOSING_BATCH_SIZE = max(1, int(os.getenv("CLOSING_BATCH_SIZE", "10")))
CLOSING_BUDGET_S = max(0.1, float(os.getenv("CLOSING_BUDGET_S", "5")))
CLOSING_IDLE_POLL_S = max(1, int(os.getenv("CLOSING_IDLE_POLL_S", "10")))
DUPLICATE_THRESHOLD = int(os.getenv("DUPLICATE_THRESHOLD", "5"))
MAX_HAMMING_DISTANCE = DUPLICATE_THRESHOLD

# Scraping respetuoso: un solo navegador, una pestaña, sin paralelismo.
RETRY_BASE_DELAY_S = float(os.getenv("RETRY_BASE_DELAY_S", "2.0"))    # Backoff: 2s, 4s, 8s... (+ jitter)
RETRY_MAX_DELAY_S = float(os.getenv("RETRY_MAX_DELAY_S", "60.0"))     # Tope de espera entre reintentos
REQUEST_DELAY_S = float(os.getenv("REQUEST_DELAY_S", "1.0"))          # Pausa entre albaranes
CONTINUOUS_POLL_INTERVAL_S = int(os.getenv("CONTINUOUS_POLL_INTERVAL_S", "300"))  # Espera entre pasadas en --continuous
DAILY_TARGET_PODS = int(os.getenv("DAILY_TARGET_PODS", "24000"))      # 2 ciudades x hasta 12.000/día
THROUGHPUT_LOG_PATH = STORAGE_DIR / "throughput.jsonl"                # Tiempo real por albarán (1 línea JSON c/u)

# Extracción: 'api' (API interna de solo lectura del portal) con respaldo 'ui' (recorrer la interfaz).
EXTRACTION_MODE = os.getenv("EXTRACTION_MODE", "api").lower()
# IDs internos de estación del portal, separados por coma. 1888 = DFW02-BAA, 297 = DFW-BAA.
GOFO_STATION_IDS = [int(x) for x in os.getenv("GOFO_STATION_IDS", "1888,297").split(",") if x.strip()]
# 14/10: IAH02-BAA (Houston, 1695; sale de /getInfo del portal). No está en GOFO_STATION_IDS: se revisa solo con
# --stations IAH02-BAA (o '_estaciones_solo_hoy' en drivers_config.json)
# 15/10: ORD-BAA (Chicago, 766; también de /getInfo), igual que IAH02: solo con --stations u '_estaciones_solo_hoy'
# 28/10: IAH-BAA (Houston, 444; de /getInfo), igual que IAH02: la revisa la sesión de Kaggle de la cuenta tracking
GOFO_STATION_NAMES = {1888: "DFW02-BAA", 297: "DFW-BAA", 1695: "IAH02-BAA", 444: "IAH-BAA", 766: "ORD-BAA"}
# Grupo de WhatsApp donde se reportan los errores de cada ciudad (estación del portal). Por ahora todas van al mismo;
# si se agregan ciudades o grupos, basta con una línea más aquí. Las ciudades que no están usan el grupo por defecto.
WHATSAPP_DEFAULT_GROUP = os.getenv("WHATSAPP_DEFAULT_GROUP", "GOFO DALLAS")
# 19/10 (pedido del usuario): una ciudad puede tener VARIOS grupos (lista): se envía primero al primero y después las
# mismas imágenes con su texto a los demás. Dallas va a "GOFO DALLAS" y también a "Paquetes (Reportes)".
WHATSAPP_GROUPS = {"DFW02-BAA": ["GOFO DALLAS", "Paquetes (Reportes)"], "DFW-BAA": ["GOFO DALLAS", "Paquetes (Reportes)"],
                   "IAH02-BAA": "Paquetes (Reportes)", "IAH-BAA": "Paquetes (Reportes)", "ORD-BAA": "Paquetes (Reportes)"}

# Portal web (05/10/2026): la corrida envía los Alta / Media a trackingint.com/portal y baja las marcas hechas allí.
# Sin PORTAL_URL y PORTAL_API_KEY (en .env; la clave se genera en el portal, Ajustes > Conexión con el script) no se envía nada.
PORTAL_URL = os.getenv("PORTAL_URL", "").rstrip("/")             # ej. https://trackingint.com/portal
PORTAL_API_KEY = os.getenv("PORTAL_API_KEY", "")
PORTAL_SYNC_ENABLED = bool(PORTAL_URL and PORTAL_API_KEY)
# 30/10 (pedido del usuario, PC y Kaggle): el registro de la corrida se ve en el portal (Auditoría > Registro), ver
# export/portal_log.py. Se manda cada PORTAL_LOG_EVERY_S, con un tope de líneas por minuto (los avisos y errores siempre pasan).
PORTAL_LOG = os.getenv("PORTAL_LOG", "1").strip().lower() in ("1", "true", "yes")
PORTAL_LOG_EVERY_S = max(5.0, float(os.getenv("PORTAL_LOG_EVERY_S", "20")))
PORTAL_LOG_MAX_PER_MIN = max(10, int(os.getenv("PORTAL_LOG_MAX_PER_MIN", "300")))
# 24/10: PORTAL_MODE=gpu (corrida en Kaggle): manda TODOS los albaranes (también Baja) a ingest_gpu.php, una tabla aparte para
# compararlos con la corrida local; no toca los envíos reales, ni baja marcas, ni latido, ni panel, ni control.
PORTAL_GPU = os.getenv("PORTAL_MODE", "").strip().lower() == "gpu"
PORTAL_PUSH_BATCH = int(os.getenv("PORTAL_PUSH_BATCH", "2"))        # albaranes por envío (cada uno lleva tarjetas + fotos originales)
PORTAL_PULL_INTERVAL_S = int(os.getenv("PORTAL_PULL_INTERVAL_S", "60"))
# 07/10: latido de la corrida al portal (heartbeat.php) para que avise por correo si se cae o se traba
PORTAL_HEARTBEAT_S = int(os.getenv("PORTAL_HEARTBEAT_S", "300"))
PORTAL_CARD_MAX_WIDTH = int(os.getenv("PORTAL_CARD_MAX_WIDTH", "1400"))
PORTAL_CARD_QUALITY = int(os.getenv("PORTAL_CARD_QUALITY", "80"))  # JPG: ~150 KB por albarán en vez de ~1 MB en PNG
PORTAL_PHOTO_MAX_SIDE = int(os.getenv("PORTAL_PHOTO_MAX_SIDE", "1600"))   # fotos originales para el zoom del portal
PORTAL_PHOTO_QUALITY = int(os.getenv("PORTAL_PHOTO_QUALITY", "80"))
PORTAL_OUTBOX_PATH = STORAGE_DIR / "portal_outbox.db"
# Repartidores: se revisan todos menos los de 'excluir' en este archivo
DRIVERS_CONFIG_PATH = PROJECT_ROOT / os.getenv("DRIVERS_CONFIG_PATH", "drivers_config.json")
API_TIMEOUT_MS = int(os.getenv("API_TIMEOUT_MS", "30000"))  # Límite por llamada a la API del portal
API_PAGE_SIZE = int(os.getenv("API_PAGE_SIZE", "50"))
# Las fotos se bajan de Amazon S3 (no del portal de GOFO), por eso se permite paralelizar.
IMAGE_DOWNLOAD_WORKERS = int(os.getenv("IMAGE_DOWNLOAD_WORKERS", "4"))
# 25/10: albaranes cuyas fotos se descargan en segundo plano mientras se pide el detalle del siguiente (0 = uno por uno, como antes)
EXTRACT_PREFETCH = int(os.getenv("EXTRACT_PREFETCH", "0"))
# 30/10 (pedido del usuario, solo Kaggle): detalles de albarán pedidos a GOFO a la vez, en una sola llamada del navegador y
# con UNA pausa por lote (antes uno por uno con REQUEST_DELAY_S tras cada uno). 1 = como antes. Si un lote falla o tarda,
# se vuelve a uno por uno durante GOFO_DETAIL_BRAKE_S (freno automático).
GOFO_DETAIL_CONCURRENCY = max(1, int(os.getenv("GOFO_DETAIL_CONCURRENCY", "1")))
GOFO_DETAIL_BRAKE_S = float(os.getenv("GOFO_DETAIL_BRAKE_S", "300"))
GOFO_DETAIL_SLOW_S = float(os.getenv("GOFO_DETAIL_SLOW_S", "8"))   # Lote más lento que esto por albarán = freno
IMAGE_HOST_ALLOWLIST = [h.strip() for h in os.getenv("IMAGE_HOST_ALLOWLIST", ".amazonaws.com").split(",") if h.strip()]

# FASE 13: POLÍTICA ESTRICTA READ-ONLY (Sólo lectura, prohibidas acciones destructivas)
READ_ONLY_MODE = True

# Rutas de almacenamiento adicional (Fase 8 y 12)
CHECKPOINT_DB_PATH = STORAGE_DIR / "pod_checkpoints.db"
INSPECTIONS_DIR = STORAGE_DIR / "inspections"
INSPECTIONS_DIR.mkdir(parents=True, exist_ok=True)

# `python main.py limpiar` (05/10/2026): de los días pasados solo quedan los casos guía (revisados o anotados).
# Estos días se guardan completos para medir cuántas alarmas da el modelo en un día entero.
HISTORY_REFERENCE_DAYS = [d.strip() for d in os.getenv("HISTORY_REFERENCE_DAYS", "2026-10-01").split(",") if d.strip()]

# Dimensiones de ventana
VIEWPORT_WIDTH = int(os.getenv("VIEWPORT_WIDTH", "1440"))
VIEWPORT_HEIGHT = int(os.getenv("VIEWPORT_HEIGHT", "900"))

# Computer Vision & Umbrales de Calidad de Imagen
BLUR_THRESHOLD = float(os.getenv("BLUR_THRESHOLD", "100.0"))
MIN_BRIGHTNESS = float(os.getenv("MIN_BRIGHTNESS", "30.0"))
MAX_BRIGHTNESS = float(os.getenv("MAX_BRIGHTNESS", "230.0"))
AUTO_DOWNLOAD_IMAGES = os.getenv("AUTO_DOWNLOAD_IMAGES", "true").lower() in ("true", "1", "yes")

# OCR: 'easyocr' (texto en escenas, recomendado; usa GPU si hay) o 'tesseract' (documentos)
# 02/10/2026: PaddleOCR (26 de 42 casos reales leídos vs 20 de EasyOCR, ~10x más rápido). Corre como servicio local
# en el entorno aparte venv_paddle (necesita numpy/OpenCV distintos a los del proyecto).
OCR_ENGINE = os.getenv("OCR_ENGINE", "paddle").lower()
PADDLE_OCR_PORT = int(os.getenv("PADDLE_OCR_PORT", "8770"))
# 24/10: varios servicios (uno por GPU, Kaggle T4 x2) para repartir el análisis entre los procesos del pool. Vacío = solo PADDLE_OCR_PORT.
PADDLE_OCR_PORTS = [int(x) for x in os.getenv("PADDLE_OCR_PORTS", "").replace(" ", "").split(",") if x] or [PADDLE_OCR_PORT]
PADDLE_PYTHON = Path(os.getenv("PADDLE_PYTHON", str(PROJECT_ROOT / "venv_paddle" / "Scripts" / "python.exe") if IS_WINDOWS
                               else str(PROJECT_ROOT / "venv_paddle" / "bin" / "python")))
PADDLE_START_TIMEOUT_S = int(os.getenv("PADDLE_START_TIMEOUT_S", "240"))
OCR_USE_GPU = os.getenv("OCR_USE_GPU", "true").lower() in ("true", "1", "yes")
TESSERACT_CMD = os.getenv("TESSERACT_CMD", r"C:\Program Files\Tesseract-OCR\tesseract.exe" if IS_WINDOWS else "tesseract")
OCR_LANG = os.getenv("OCR_LANG", "eng")
OCR_MIN_CONFIDENCE = float(os.getenv("OCR_MIN_CONFIDENCE", "30"))  # EasyOCR da confianzas bajas en carteles chicos
# Segunda opinión con modelo de visión LOCAL (Ollama) solo cuando el OCR no leyó el número.
VISION_ENABLED = os.getenv("VISION_ENABLED", "true").lower() in ("true", "1", "yes")
VISION_MODEL = os.getenv("VISION_MODEL", "qwen2.5vl:3b")
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://127.0.0.1:11434")
# 25/10: cascada. Si el modelo normal (3b) no logra leer el número de la casa, la foto se vuelve a leer con un modelo mayor
# (ej. qwen2.5vl:7b: en la prueba del 01/10 halló 52 de 53 errores reales contra 47 del 3b, pero ~3 veces más lento).
# Vacío = sin cascada (como antes). VISION_FALLBACK_URL: servicio de Ollama de ese modelo (vacío = el mismo de siempre).
VISION_FALLBACK_MODEL = os.getenv("VISION_FALLBACK_MODEL", "").strip()
VISION_FALLBACK_URL = os.getenv("VISION_FALLBACK_URL", "").strip()
OLLAMA_URLS = [x for x in os.getenv("OLLAMA_URLS", "").replace(" ", "").split(",") if x] or [OLLAMA_URL]


def pick_for_worker(options):
    """Servicio que le toca a este proceso del pool (reparto rotativo por orden de creación; el proceso principal usa el primero)."""
    import multiprocessing
    ident = getattr(multiprocessing.current_process(), "_identity", ()) or (0,)
    return options[ident[0] % len(options)]
VISION_MAX_SIDE = int(os.getenv("VISION_MAX_SIDE", "1024"))
VISION_NUMBER_CONFIDENCE = float(os.getenv("VISION_NUMBER_CONFIDENCE", "70"))  # < OCR_STRONG_CONFIDENCE
VISION_TIMEOUT_S = float(os.getenv("VISION_TIMEOUT_S", "60"))
# 06/10: tras N consultas seguidas cortadas por tiempo se descarga el modelo (runner trabado con la GPU llena)
VISION_TIMEOUTS_BEFORE_RELOAD = int(os.getenv("VISION_TIMEOUTS_BEFORE_RELOAD", "2"))
# Una respuesta normal ocupa ~30 tokens; con 400 una foto que hace "entrar en bucle" al modelo tardaba minutos
# (3 intentos x 400 tokens) y frenaba toda la cola (caso real: 40 min sin extraer el 01/10).
VISION_NUM_PREDICT = int(os.getenv("VISION_NUM_PREDICT", "150"))
VISION_ATTEMPTS = int(os.getenv("VISION_ATTEMPTS", "2"))             # Intento + reintento tras recargar el modelo
# 02/10: el modelo queda cargado entre albaranes (no se descarga a los 5 min de inactividad) y con contexto de 2048
# en vez de 4096: libera memoria de GPU para Paddle. La foto más grande ocupó 1257 tokens + 150 de respuesta.
VISION_KEEP_ALIVE = os.getenv("VISION_KEEP_ALIVE", "-1")
VISION_NUM_CTX = int(os.getenv("VISION_NUM_CTX", "2048"))
# 10/10: tope de consultas al modelo en la lectura/confirmación del número de UN albarán (09/10: el 16 % de los albaranes
# hacía 6+ consultas y se llevaba el 56 % del tiempo). Al llegar al tope sin resolver queda en Media "revisar a mano"
# (nunca Baja). 0 = sin tope. La detección de entrega en mano no cuenta (solo puede bajar la prioridad).
VISION_MAX_CALLS_PER_POD = int(os.getenv("VISION_MAX_CALLS_PER_POD", "5"))
# 12/10: además, tope de TIEMPO en esa misma etapa (consultas lentas: hasta 128 s en una confirmación). Pasado el tope
# no se hacen más consultas y queda en Media "revisar a mano", igual que el tope de consultas. 0 = sin tope.
# El 12/10 el 9 % de los albaranes (más de 30 s) se llevaba el 48 % del tiempo.
VISION_POD_BUDGET_S = float(os.getenv("VISION_POD_BUDGET_S", "35"))
# 29/10: piso del tiempo de espera de una consulta cuando al albarán le queda poco del tope de arriba (no cortar consultas normales de ~2 s)
VISION_MIN_CALL_S = float(os.getenv("VISION_MIN_CALL_S", "10"))
# 12/10: tope de tiempo de la detección de entrega en mano (hasta 12 consultas y 51 s). Al pasarlo deja de preguntar y
# el albarán queda como estaba (Alta/Media): cortar esta etapa nunca esconde un error, solo deja de omitir.
HANDOFF_BUDGET_S = float(os.getenv("HANDOFF_BUDGET_S", "20"))
# 29/10: fotos distintas que deben confirmar la entrega en mano para omitir el albarán. 1 = como antes. Con 1, la mano del repartidor
# con la etiqueta o su reflejo en un vidrio bajaban errores reales a Baja; con 2, ninguno de 12 en la prueba (tools/probar_entrega_mano.py).
HANDOFF_MIN_PHOTOS = int(os.getenv("HANDOFF_MIN_PHOTOS", "2"))
# 10/10: vigilante de Ollama. Si la mediana de las últimas N consultas pasa de X s, se descarga y recarga el modelo
# (09/10 19:13-19:46: 30-213 s por consulta sin llegar al corte de 60 s; la recarga por cortes no saltaba)
VISION_SLOW_WINDOW = int(os.getenv("VISION_SLOW_WINDOW", "6"))
VISION_SLOW_MEDIAN_S = float(os.getenv("VISION_SLOW_MEDIAN_S", "15"))
# 30/10 (pedido del usuario, solo Kaggle): con dos GPU, una consulta que Ollama corta con error HTTP se repite en la OTRA
# GPU, y esas fallas del servicio no gastan el tope de consultas del albarán (antes: «tope de 5 consultas» y Media
# «revisar a mano» sin que el modelo hubiera mirado la foto). 0 = como antes.
VISION_FAILOVER = os.getenv("VISION_FAILOVER", "0").lower() in ("1", "true")
# 30/10: si la gramática JSON falla seguido (respuesta vacía con gramática y correcta sin ella), se pregunta primero sin
# gramática durante VISION_GRAMMAR_PAUSE_S: ahorra una consulta perdida por foto. 0 = como antes.
VISION_GRAMMAR_ADAPTIVE = os.getenv("VISION_GRAMMAR_ADAPTIVE", "0").lower() in ("1", "true")
VISION_GRAMMAR_FAILS = int(os.getenv("VISION_GRAMMAR_FAILS", "3"))        # Fallas en VISION_GRAMMAR_WINDOW_S para pausarla
VISION_GRAMMAR_WINDOW_S = float(os.getenv("VISION_GRAMMAR_WINDOW_S", "600"))
VISION_GRAMMAR_PAUSE_S = float(os.getenv("VISION_GRAMMAR_PAUSE_S", "600"))

# Lectura "segura": un número a 1 dígito de la dirección leído con esta confianza es OTRA casa (vecina),
# no un error del OCR. Por debajo queda como "casi coincide" (Media).
OCR_STRONG_CONFIDENCE = float(os.getenv("OCR_STRONG_CONFIDENCE", "85"))
OCR_CANVAS_SIZE = int(os.getenv("OCR_CANVAS_SIZE", "1280"))            # 2560 (defecto EasyOCR) es 40% más lento sin mejora
OCR_MAX_SIDE = int(os.getenv("OCR_MAX_SIDE", "1400"))
LABEL_QR_MIN_SQUARENESS = float(os.getenv("LABEL_QR_MIN_SQUARENESS", "0.75"))
# Procesos de OCR. Con el modelo de visión activo se usa 1: dos procesos de EasyOCR (~0.9 GB c/u) más el
# modelo (~3.5 GB) llenaban los 6 GB de la GPU y Ollama respondía vacío. Con 1 proceso sobra velocidad.
# 03/10: se probó 2 a la vez y fue PEOR (53 vs 86 analizados en 14 min): Paddle y el modelo de visión comparten la GPU
# de 6 GB y se estorban (OCR de 3-4 s a 7-15 s, cada llamada a visión de 2-4 s a ~7 s). Se queda en 1.
OCR_WORKERS = int(os.getenv("OCR_WORKERS", "1"))
# 29/10: tope de TIEMPO para la lectura inicial (OCR) de las fotos de UN albarán. En 4.306 albaranes (25-28/10) el p99 del OCR
# fue 38 s pero 27 pasaron de 60 s (hasta 302 s, y uno de 5 h) y sumaron el 61 % del tiempo total de OCR. Pasado el tope no se
# leen más fotos ni se consulta al modelo: queda en Media "revisar a mano" (nunca Baja). 0 = sin tope.
OCR_POD_BUDGET_S = float(os.getenv("OCR_POD_BUDGET_S", "90"))
# Por bloques (pedido del usuario 03/10): en cada pasada, como máximo esta cantidad de albaranes nuevos por repartidor;
# así todos avanzan parejo en vez de terminar uno entero antes de pasar al siguiente. 0 = sin límite.
MAX_PER_DRIVER_PER_PASS = int(os.getenv("MAX_PER_DRIVER_PER_PASS", "30"))
# 25/10: reparto del trabajo entre corridas (PC y GPU en la nube) con el portal como repartidor (api/claim.php): cada una pide
# un bloque, el portal se lo reserva y la otra lo salta. Cada corrida necesita su CLAIM_WORKER (ej. "pc", "gpu"). Sin portal
# o sin respuesta, cada una revisa todo (no se para).
CLAIM_WORK = os.getenv("CLAIM_WORK", "").lower() in ("1", "true", "yes")
CLAIM_WORKER = os.getenv("CLAIM_WORKER", "pc")
CLAIM_LEASE_S = int(os.getenv("CLAIM_LEASE_S", "600"))       # La reserva vence si el otro se cae
CLAIM_DENY_TTL_S = int(os.getenv("CLAIM_DENY_TTL_S", "30"))   # Reconsultar al servidor; nunca quitarle una reserva vigente
# 28/10: el reparto y los turnos de sesión usan un tiempo de espera corto (los envíos siguen con 60 s). El 28/10, con el
# portal caído o rechazando la clave, cada bloque de 5 esperaba hasta 60 s y la corrida bajó a ~27/h
PORTAL_COORD_TIMEOUT_S = float(os.getenv("PORTAL_COORD_TIMEOUT_S", "10"))
# Tras un fallo del reparto, no se vuelve a preguntar al portal durante este tiempo: se revisa todo sin esperar
CLAIM_BACKOFF_S = float(os.getenv("CLAIM_BACKOFF_S", "120"))
CLAIM_BATCH_SIZE = max(1, int(os.getenv("CLAIM_BATCH_SIZE", "5")))
# 29/10: reparto mejorado. Requiere el portal con api/claims_done.php y api/route_claim.php; con el anterior sigue el reparto
# de siempre. Candidatos por pedido (el portal concede los primeros libres y avisa cuales ya tiene o hizo otra corrida).
CLAIM_CANDIDATES = max(1, min(100, int(os.getenv("CLAIM_CANDIDATES", "50"))))
CLAIMS_DONE_REFRESH_S = float(os.getenv("CLAIMS_DONE_REFRESH_S", "300"))   # Lista de hechos del dia (todas las corridas)
# Reparto por repartidor: cada ruta la lista y revisa una sola corrida a la vez (antes las tres listaban las mismas rutas).
# Apagado hasta probarlo en una corrida real (ROUTE_CLAIMS=1 para activarlo); el resto del reparto mejorado no depende de esto.
ROUTE_CLAIMS = os.getenv("ROUTE_CLAIMS", "0").lower() in ("1", "true", "yes")
ROUTE_LEASE_S = int(os.getenv("ROUTE_LEASE_S", "900"))
ROUTE_HOLD_MAX = max(1, int(os.getenv("ROUTE_HOLD_MAX", "4")))   # Rutas con pendientes a la vez por corrida
# Donde empieza cada corrida dentro de una ruta (0 = primera parada; Kaggle Luis 0.34, Tracking 0.67): no chocan al empezar
ROUTE_START_FRACTION = min(0.99, max(0.0, float(os.getenv("ROUTE_START_FRACTION", "0"))))
# 26/10: verificación cruzada. Cuando OTRA corrida (PC o GPU) marca un albarán como Alta/Media, esta lo analiza por su cuenta y
# manda su resultado al portal (api/verify.php) para ver si coinciden. Cada VERIFY_EVERY_S segundos pide hasta VERIFY_BATCH.
# VERIFY_PRIORITIES: qué marcas de la otra corrida se verifican; VERIFY_ONLY_REPORTED: solo las que ya reportaste en Revisión.
VERIFY_WORK = os.getenv("VERIFY_WORK", "").lower() in ("1", "true", "yes")
VERIFY_BATCH = int(os.getenv("VERIFY_BATCH", "4"))
VERIFY_EVERY_S = float(os.getenv("VERIFY_EVERY_S", "30"))
VERIFY_PRIORITIES = os.getenv("VERIFY_PRIORITIES", "Alta,Media")
VERIFY_ONLY_REPORTED = os.getenv("VERIFY_ONLY_REPORTED", "").lower() in ("1", "true", "yes")
# 25/10: en la corrida de GPU (PORTAL_MODE=gpu) mandar también las fotos originales de los Alta/Media, para poder acercarlas en Comparar GPU y para
# "Pasar a revisión" de lo que solo vio la GPU. 26/10: ahora SIEMPRE (sin ellas el zoom de Comparar GPU / Revisión abre la tarjeta, de mala resolución, en vez de la foto); apagar con GPU_SEND_PHOTOS=0.
GPU_SEND_PHOTOS = os.getenv("GPU_SEND_PHOTOS", "1").lower() in ("1", "true", "yes")
# 07/10: el 06/10 quedaron ~800 de DFW-BAA sin revisar: cada pasada iba en orden fijo (todo DFW, luego DFW02) y cada
# reinicio volvía al primer repartidor. Ahora la pasada lista primero las rutas de las dos ciudades y atiende los
# bloques por ATRASO (el repartidor con más entregados sin revisar primero). Cada PASS_REFRESH_MIN se vuelve a listar
# para sumar lo entregado mientras tanto.
PASS_REFRESH_MIN = float(os.getenv("PASS_REFRESH_MIN", "45"))
# Rutas al día (entregas con POD del resumen = ya revisadas) no se vuelven a listar antes de estos minutos; se relistan
# igual de vez en cuando para ver cambios de estado (anulado, POD rehecho)
FULL_RELIST_MIN = float(os.getenv("FULL_RELIST_MIN", "120"))
# 22/10 (pedido del usuario): estando al día (nada pendiente en lo listado), cada estos minutos se vuelve a pedir la
# lista completa de rutas para sumar lo que se entregó mientras tanto
AL_DIA_REFRESH_MIN = float(os.getenv("AL_DIA_REFRESH_MIN", "5"))
# Para no saltar de ciudad a cada bloque: se queda en la ciudad actual mientras su más atrasado tenga al menos esta
# fracción de los pendientes del más atrasado de la otra.
STATION_STAY_RATIO = float(os.getenv("STATION_STAY_RATIO", "0.5"))
# 12/10: rutas que se listan por cada bloque procesado (antes 1)
ROUTES_PER_BLOCK = int(os.getenv("ROUTES_PER_BLOCK", "3"))
# 07/10 (pedido del usuario): primero los repartidores con más errores REALES confirmados en los últimos
# PRIORITY_DAYS días (al menos PRIORITY_MIN_ERRORS; los PRIORITY_MAX con más errores + los PRIORITY_PER_STATION_MIN
# primeros de cada ciudad). Se recalcula al empezar cada día. PRIORITY_MAX=0 lo desactiva.
PRIORITY_DAYS = int(os.getenv("PRIORITY_DAYS", "14"))
PRIORITY_MIN_ERRORS = int(os.getenv("PRIORITY_MIN_ERRORS", "5"))
PRIORITY_MAX = int(os.getenv("PRIORITY_MAX", "10"))
PRIORITY_PER_STATION_MIN = int(os.getenv("PRIORITY_PER_STATION_MIN", "3"))
# 09/10: 1 de cada N bloques va a los repartidores SIN prioridad (0 o 1 = solo prioridad mientras les quede algo)
PRIORITY_SHARE_EVERY = int(os.getenv("PRIORITY_SHARE_EVERY", "4"))
# Faltantes de la corrida (lo lee la página local y el resumen): total, por ciudad, más atrasados y estimado
BACKLOG_PATH = Path(os.getenv("BACKLOG_PATH", str(STORAGE_DIR / "faltantes.json")))
# 15/10: control de paquetes (`main.py control`). Regla de los dueños: devolver a la estación el MISMO día del fallo
# (o del paquete que cerró el día sin entrega ni fallo); GOFO lo marca perdido al día siguiente. La estación escanea
# las devoluciones solo de mañana (5 a 13 h), así que el plazo es el día siguiente a las RETURN_DEADLINE_HOUR.
RETURN_DEADLINE_DAYS = int(os.getenv("RETURN_DEADLINE_DAYS", "1"))
RETURN_DEADLINE_HOUR = int(os.getenv("RETURN_DEADLINE_HOUR", "13"))

# ==============================================================================
# TRIAJE POR SCORE DE RIESGO (0 = sin riesgo, 100 = riesgo alto)
# total = max(promedio_ponderado, SCORE_MAX_WEIGHT_FACTOR × score_máximo)
# ==============================================================================
SCORE_MAX_WEIGHT_FACTOR = float(os.getenv("SCORE_MAX_WEIGHT_FACTOR", "0.8"))
PRIORITY_HIGH_THRESHOLD = float(os.getenv("PRIORITY_HIGH_THRESHOLD", "60"))
PRIORITY_MEDIUM_THRESHOLD = float(os.getenv("PRIORITY_MEDIUM_THRESHOLD", "30"))
CHECK_WEIGHTS = {
    "pod_falso_portal": 3.0,
    "numero_direccion": 3.0,
    "fotos_etiqueta": 2.0,
    "fotos_edificio": 2.0,
    "fotos_duplicadas": 2.0,
    "distancia_gps": 2.0,
    "cantidad_fotos": 1.0,
    "calidad_imagen": 1.0,
    "incumplimiento_portal": 1.0,
    "vision_fallida": 1.0,
    "captura_mapa": 2.0,
    "amazon_hub": 2.0,
}
MIN_EXPECTED_PHOTOS = int(os.getenv("MIN_EXPECTED_PHOTOS", "3"))
MAX_EXPECTED_PHOTOS = int(os.getenv("MAX_EXPECTED_PHOTOS", "5"))
# Regla: número de casa/unidad no visible en ninguna foto -> reportar siempre (prioridad Alta)
# "Números lejanos": cartel con número demasiado chico para leerlo con seguridad -> revisión manual
FAR_TEXT_MAX_HEIGHT_RATIO = float(os.getenv("FAR_TEXT_MAX_HEIGHT_RATIO", "0.04"))  # caja < 4% del alto de la foto
FAR_NUMBERS_SCORE = float(os.getenv("FAR_NUMBERS_SCORE", "50"))                  # 50 = prioridad Media
# "Media baja" (06/10): lecturas dudosas que casi nunca son error (05/10: 93 descartados por 4 reportados entre
# casi igual, incompleta, lejanos, sin confirmar, solo el modelo de visión y unidad no leída). Siguen en Media
# (40 x 0,8 = 32) pero van al final de la lista, después de "número no leído" (18 % de acierto).
WEAK_NUMBER_SCORE = float(os.getenv("WEAK_NUMBER_SCORE", "40"))
# Foto que el modelo de visión llama "etiqueta" pero donde lee el número de la casa: si el OCR ve como mucho
# estos tokens, es un número pintado en la acera o una placa (una etiqueta real deja ~30 tokens de texto).
# Una placa de casa con número y calle tiene pocas palabras ("2806 Stafford St"); una etiqueta, muchas
PLATE_MAX_TOKENS = int(os.getenv("PLATE_MAX_TOKENS", "5"))
PAINTED_NUMBER_MAX_OCR_TOKENS = int(os.getenv("PAINTED_NUMBER_MAX_OCR_TOKENS", "3"))
# Si el modelo lee un número distinto al de la casa, se relee la foto girada (fotos muy inclinadas):
# se acepta el número de la casa solo si al menos VISION_ROTATION_MIN_AGREE giros lo leen exacto.
VISION_ROTATION_ANGLES = [int(a) for a in os.getenv("VISION_ROTATION_ANGLES", "45,-45,90").split(",") if a.strip()]
VISION_ROTATION_MIN_AGREE = int(os.getenv("VISION_ROTATION_MIN_AGREE", "2"))
# Código de barras decodificado sin tracking: es etiqueta solo si el OCR ve al menos estos tokens
# (medido en fotos reales: etiquetas 39-68 tokens; casas confundidas por persianas/ladrillos 1-4).
BARCODE_LABEL_MIN_OCR_TOKENS = int(os.getenv("BARCODE_LABEL_MIN_OCR_TOKENS", "15"))
# false (decisión del revisor): "no se lee el número" -> Media "Número no leído / posible número lejano".
# true: reportar siempre como error.
NUMBER_NOT_VISIBLE_FORCES_REPORT = os.getenv("NUMBER_NOT_VISIBLE_FORCES_REPORT", "false").lower() in ("true", "1", "yes")
# Excepción de edificio: entrega en oficina/sala/casillero de paquetería
PACKAGE_ROOM_BILLING_KEYWORDS = ("casillero", "sala de paquet", "sala de correo", "punto de recogida", "recogida", "pickup", "correo", "mail room", "post office", "oficina", "mailroom", "package room", "parcel locker", "front desk", "recepci")
# Casillero/kiosco visto en la FOTO (regla 01/10, caso Luxer One con facturación "En la puerta")
LOCKER_PHOTO_KEYWORDS = ("luxer", "select a locker", "locker size", "parcel pending", "package concierge",
                         "parcel locker", "package locker",
                         # Pantalla del kiosco Luxer One (caso real 02/10: 1703 Rockhill Rd Apt 1211)
                         "find recipient", "recipient not listed",
                         # El mismo kiosco en español (casos reales 03/10: 9590 Eden Rd, 8170 Hornisher Way)
                         "luxerone", "coincidencia de destinatario", "seleccione la coincidencia", "no listado",
                         # 06/10 (casos 05/10): Parcel Pending "by Quadient" (complejo alesio) y pantallas de Luxer One
                         # ("Select Recipient Match", "Please Place Package in Locker", "Now Opening 76")
                         "quadient", "select recipient match", "place package in locker", "now opening",
                         # 06/10: kiosco "Deposit Package" (1156 Hidden Ridge, Irving; 8 Alta falsos de Carla Colina):
                         # "Close Door and Press Package Deposited Button", "Package too large", "Wrong customer"
                         "deposit package", "package deposited", "press package", "wrong customer",
                         "package too large")
# Carta de correo de la casa (publicidad, "OR CURRENT RESIDENT"): prueba de la dirección, no la etiqueta de GOFO (03/10)
MAIL_PIECE_KEYWORDS = ("current resident", "ecrwss", "prsrt std", "postal customer", "or current")
# Amazon Hub: se REPORTA, agrupado por repartidor (regla 01/10; reemplaza la del 30/09 de quitar ese chequeo)
AMAZON_HUB_KEYWORDS = ("amazon hub", "hub locker", "amazon locker", "amazonhub",
                       # Pantalla del Amazon Hub Apartment Locker: lista de residentes + "Other resident" (caso real
                       # 03/10: 818 W Royal Ln 367, el OCR no lee la palabra "Amazon")
                       "other resident")
# Pantalla de tamaños del Amazon Hub Apartment Locker ("Back / Help / Small 13 available / Medium 5 available";
# caso real 03/10, 818 W Royal Ln 367): tamaños + "available" + Back/Help, sin marca de otro casillero
AMAZON_LOCKER_SIZES_RE = r"(?is)(?=.*\b(small|medium|large)\b)(?=.*\bava[il1]{2}ab)(?=.*\b(help|back)\b)"
# Teclado numérico de la pantalla de un casillero ("123 456 789"): sus números no son puertas
LOCKER_KEYPAD_RE = r"\b1\s?2\s?3[A-Za-z]?\s+4\s?5\s?6\s+7\s?8\s?9\b"
PACKAGE_ROOM_OCR_KEYWORDS = ("package room", "mail room", "mailroom", "parcel locker", "package locker", "leasing office", "luxer", "package concierge",
                             # Recepción de hotel / oficina (caso real 02/10: "At The Hotel Reception Desk 121 E I 20")
                             "reception desk", "front desk", "hotel reception", "lobby",
                             # Sala de paquetes del complejo (caso 05/10: "SPECIAL DELIVERIES", Iron Horse Blvd)
                             "special deliveries", "special delivery", "parcel room", "package center", "mail center")
# Tiendas de buzones privados (The UPS Store, "24 Hour Mailbox"): el paquete queda en el mostrador o el buzón de la
# tienda; se tratan como casillero (casos 05/10: 4843 Colleyville Blvd 251-126, 391 Las Colinas Blvd E 130-425)
MAILBOX_STORE_KEYWORDS = ("the ups store", "ups store", "24 hour mailbox", "24hr mailbox", "mailbox rental",
                          "mailboxes", "pack & ship", "pack and ship", "postal annex", "pak mail", "postnet",
                          "mail boxes etc", "private mailbox")
# Dirección de un negocio con recepción (hotel, restaurante): el paquete se deja en el mostrador y no hay número de
# puerta que fotografiar (casos 05/10: Hampton Inn & Suites de Grapevine, Wendy's de Walnut Hill Ln)
RECEPTION_ADDRESS_KEYWORDS = ("hotel", "motel", "hampton inn", "holiday inn", "residence inn", "marriott", "hilton",
                              "la quinta", "courtyard", "extended stay", "comfort inn", "comfort suites", "best western",
                              "wendy", "mcdonald", "chick-fil", "starbucks", "taco bell", "whataburger", "restaurant")
# Entrega en mano: no se exige número visible
HANDOVER_BILLING_KEYWORDS = ("reunirse con el cliente", "miembro autorizado", "in person", "handed")
# Distancia GPS del POD (signDistance del portal; en la muestra real lo normal es 5-30): (límite, score si se supera)
# Calibrado con 110 entregas reales: mediana ~15-30, p90 ~110; complejos grandes llegan a 150-250.
# Regla 01/10: muchos repartidores dejan los paquetes, toman las fotos y suben todo al final de la calle.
# Menos de 800 m no cuenta; más de 800 m va a revisión (Media), nunca Alta por sí sola.
GPS_DISTANCE_SCORES = [(800, 50)]
# Borrosidad para el score: bajo este valor de Laplaciano la foto está borrosa de verdad.
# (El umbral de 100 marcaba paredes lisas perfectamente legibles.)
SCORE_BLUR_THRESHOLD = float(os.getenv("SCORE_BLUR_THRESHOLD", "30"))
# Foto repetida entre albaranes del MISMO edificio (varios paquetes, sala/casillero): riesgo bajo
DUPLICATE_SAME_BUILDING_SCORE = float(os.getenv("DUPLICATE_SAME_BUILDING_SCORE", "0"))  # Regla 01/10: no suma ni se muestra
# Foto repetida entre dos APARTAMENTOS con POD a menos de estos metros: mismo complejo (cartel de la entrada).
# "Parks at Treepoint" (Arlington) tiene entregas hasta a ~500 m del cartel.
DUPLICATE_SAME_COMPLEX_M = float(os.getenv("DUPLICATE_SAME_COMPLEX_M", "600"))
# 29/10: foto repetida con otro albarán pero tomada a menos de esto (m) de la dirección de ESTE albarán = entrega múltiple de unidades
# vecinas, no una foto de otra casa. 0 = sin esta excepción. El único error real del historial estaba a 759 m.
DUPLICATE_NEAR_ADDRESS_M = float(os.getenv("DUPLICATE_NEAR_ADDRESS_M", "50"))

# 29/10: el 28/10 entre las 11:41 y las 11:46 se escribieron 5.073 marcas de golpe en report_status (1.174 reportado y 3.899 descartado,
# 660 en un minuto) de albaranes del 05 al 27/10. El usuario confirmó que esa ráfaga es un error: no se usa como verdad al evaluar.
REPORT_STATUS_TRUSTED_SQL = "NOT (updated_at >= '2026-10-28T11:40:00' AND updated_at < '2026-10-28T11:47:00')"

# 29/10: salas de paquetes en apartamentos: no se relee la foto de la sala ni el tope del modelo deja "revisión manual" (caso 6903 y
# 6919 State Highway 161). SIN evidencia validada: las marcas de reportado de casas eran de la ráfaga inválida del 28/10. Para
# apagarla: SALA_APARTMENT_NO_CAP=0.
SALA_APARTMENT_NO_CAP = os.getenv("SALA_APARTMENT_NO_CAP", "1").lower() in ("1", "true", "yes")

# Nombre por defecto del reporte Excel
DEFAULT_EXCEL_FILENAME = "resultados_pod.xlsx"

# ==============================================================================
# FASE 4: CONFIGURACIÓN CENTRALIZADA DEL MOTOR DE REGLAS (RULE ENGINE)
# El sistema NO rechaza automáticamente. Clasifica para triaje y revisión humana.
# ==============================================================================
VALIDATION_RULES_CONFIG = {
    # Principio rector: Ninguna entrega se rechaza automáticamente
    "ALLOW_AUTO_REJECT": False,

    # 1. Regla: Ausencia de fotografías
    "RULE_NO_PHOTOS": {
        "enabled": True,
        "classification": "REVIEW REQUIRED",
        "penalty": 30.0,
        "description": "No se encontraron fotografías de comprobante adjuntas.",
    },

    # 2. Regla: Archivo de fotografía no analizable / corrupto
    "RULE_UNREADABLE_IMAGE": {
        "enabled": True,
        "classification": "ERROR",
        "penalty": 50.0,
        "description": "El archivo de imagen no pudo ser leído o analizado por el motor CV.",
    },

    # 3. Regla: Información básica incompleta
    "RULE_BASIC_INFO_COMPLETENESS": {
        "enabled": True,
        "classification": "REVIEW REQUIRED",
        "penalty": 20.0,
        "min_address_length": 6,
        "description": "Información esencial de entrega incompleta (dirección o tracking).",
    },

    # 4. Regla: Detección de fotos idénticas / duplicadas entre albaranes
    "RULE_DUPLICATE_PHOTOS": {
        "enabled": True,
        "classification": "POSSIBLE ISSUE",
        "tag": "POSSIBLE DUPLICATE",
        "max_hamming_distance": MAX_HAMMING_DISTANCE,
        "penalty": 50.0,
        "description": "Fotografía similar o idéntica reutilizada en múltiples albaranes.",
    },

    # 5. Regla: Calidad de imagen baja / extremadamente borrosa
    "RULE_BLURRY_IMAGE": {
        "enabled": True,
        "classification": "REVIEW REQUIRED",
        "tag": "LOW IMAGE QUALITY",
        "blur_threshold": BLUR_THRESHOLD,
        "penalty": 25.0,
        "description": "Imagen con desenfoque o movimiento excesivo.",
    },

    # 6. Regla: Exposición extrema (cámara tapada / sobreexpuesta)
    "RULE_EXPOSURE": {
        "enabled": True,
        "classification": "REVIEW REQUIRED",
        "tag": "LOW IMAGE QUALITY",
        "min_brightness": MIN_BRIGHTNESS,
        "max_brightness": MAX_BRIGHTNESS,
        "penalty": 25.0,
        "description": "Imagen muy oscura (subexpuesta) o quemada (sobreexpuesta).",
    },

    # 7. Regla: Cámara obstruida o encuadre plano (dedo en lente)
    "RULE_OBSTRUCTED_LENS": {
        "enabled": True,
        "classification": "POSSIBLE ISSUE",
        "tag": "LOW IMAGE QUALITY",
        "std_contrast_threshold": 6.0,
        "penalty": 40.0,
        "description": "Contraste extremadamente bajo indicando lente tapado u objetivo cubierto.",
    },

    # 8. Regla: Incumplimiento ya reportado por la plataforma DSP
    "RULE_PLATFORM_INCIDENTS": {
        "enabled": True,
        "classification": "REVIEW REQUIRED",
        "penalty": 20.0,
        "description": "La plataforma de Gofo Express ya marcó una no conformidad previa.",
    },
}

# ==============================================================================
# CONFIGURACIÓN DE ANÁLISIS DE IMÁGENES Y COMPUTER VISION (FASE 5)
# ==============================================================================
IMAGE_ANALYSIS_CONFIG = {
    # Proveedor activo: 'local' (OpenCV + Pillow + imagehash) o 'multimodal' (futuros modelos IA)
    "PROVIDER": "local",

    # Resolución mínima esperada para un comprobante POD legible
    "MIN_IMAGE_WIDTH": 640,
    "MIN_IMAGE_HEIGHT": 480,
    "MIN_MEGAPIXELS": 0.3,

    # Tamaño de archivo en disco
    "MIN_FILE_SIZE_BYTES": 10240,       # 10 KB (menos de esto suele ser archivo incompleto/avatar)
    "MAX_FILE_SIZE_BYTES": 15 * 1024 * 1024, # 15 MB límite preventivo

    # Umbrales de iluminación y contraste
    "MIN_BRIGHTNESS": MIN_BRIGHTNESS,   # 25.0 (por debajo = oscura/negra)
    "MAX_BRIGHTNESS": MAX_BRIGHTNESS,   # 235.0 (por encima = sobreexpuesta/quemada)
    "MIN_CONTRAST_STD": 6.0,            # Por debajo = lente tapado / encuadre plano

    # Umbral de nitidez (Varianza del Laplaciano)
    "BLUR_THRESHOLD": BLUR_THRESHOLD,   # 100.0 (por debajo = borrosa)

    # Detección de duplicados y similitud perceptual
    "MAX_HAMMING_DISTANCE_SIMILAR": MAX_HAMMING_DISTANCE, # Distancia <= 5 se considera muy similar
    "ENABLE_DHASH": True,
    "ENABLE_PHASH": True,
    "ENABLE_AHASH": True,

    # Restricciones éticas y de privacidad estrictas:
    # PROHIBIDO reconocimiento facial o identificación biométrica de personas.
    "ALLOW_FACIAL_RECOGNITION": False,
}

# Página de reportes: albaranes en Baja elegidos al azar cada día para revisar lo que se escapa
BAJA_SAMPLE_SIZE = int(os.getenv("BAJA_SAMPLE_SIZE", "20"))
# Regla "dos puertas" (01/10): confianza mínima del OCR para tomar otro número de puerta como segunda puerta.
# Caso real: la placa "2817" se leyó con 77 % (el umbral general de 85 % la dejaba pasar).
TWO_DOORS_MIN_CONF = float(os.getenv("TWO_DOORS_MIN_CONF", "60"))

# Tope de tiempo por albarán para la confirmación con el modelo de visión (02/10: uno tardó 25 min).
# 12/10: 90 -> 30 s y ahora también corta las relecturas de Paddle (confirmaciones de 50-60 s)
CONFIRM_MAX_SECONDS = int(os.getenv("CONFIRM_MAX_SECONDS", "30"))
# 06/10: franja vertical de dígitos leída por el modelo de visión (números apilados: 6644, 3121 del 05/10)
STRIP_VISION_ENABLED = os.getenv("STRIP_VISION_ENABLED", "true").lower() in ("true", "1", "yes")

# Lecturas reutilizables por contenido; nunca se reutiliza el puntaje final del albarán.
ANALYSIS_CACHE_ENABLED = os.getenv('ANALYSIS_CACHE_ENABLED','true').lower() in ('true','1','yes')
ANALYSIS_CACHE_PATH = Path(os.getenv('ANALYSIS_CACHE_PATH',str(STORAGE_DIR / 'analysis_cache.db')))
ANALYSIS_CACHE_EPOCH = os.getenv('ANALYSIS_CACHE_EPOCH','1')
ANALYSIS_CACHE_MAX_ENTRIES = int(os.getenv('ANALYSIS_CACHE_MAX_ENTRIES','10000'))
ANALYSIS_CACHE_TTL_DAYS = float(os.getenv('ANALYSIS_CACHE_TTL_DAYS','7'))
