"""
Verificación cruzada (26/10/2026): cuando una corrida (PC o GPU) marca un albarán como Alta/Media, la OTRA lo analiza por su
cuenta y manda su resultado al portal (api/verify.php) para ver si los dos coinciden.

- El portal decide qué albaranes le toca verificar a cada corrida (los marcados por la otra y aún sin verificar).
- Corre en el hilo principal, entre bloques de la extracción (el navegador no admite otros hilos).
- Nunca frena la corrida: si el portal no responde o un albarán falla, se sigue.
- El resultado NO se guarda como un albarán normal (no entra a la base de la corrida ni a la revisión): solo se envía.
"""

import logging
import time
from typing import Callable, Dict, List, Optional

import config
from automation.portal_api import WaybillSummary

logger = logging.getLogger("PODAutomation.Verifier")


class CrossVerifier:
    def __init__(self, fetch_fn: Callable[[int], List[Dict]], report_error_fn: Optional[Callable[[Dict, str], None]] = None,
                 interval_s: float = None, batch: int = None, clock: Callable[[], float] = time.monotonic):
        self.fetch_fn = fetch_fn
        self.report_error_fn = report_error_fn
        self.interval_s = config.VERIFY_EVERY_S if interval_s is None else interval_s
        self.batch = config.VERIFY_BATCH if batch is None else batch
        self.clock = clock
        self._last = -1e9
        self.done = 0

    def run_some(self, extractor, pipeline, day: str) -> int:
        """Pide al portal hasta `batch` albaranes por verificar y los manda al análisis. Devuelve cuántos mandó."""
        if self.clock() - self._last < self.interval_s:
            return 0
        self._last = self.clock()
        try:
            items = list(self.fetch_fn(self.batch) or [])
        except Exception as e:
            logger.warning(f"Verificación cruzada: el portal no respondió ({e}); se sigue sin verificar")
            return 0
        sent = 0
        for item in items[: self.batch]:
            try:
                if self._verify_one(extractor, pipeline, item, day):
                    sent += 1
            except Exception as e:   # Un albarán que falla no frena a los demás ni a la corrida
                logger.warning(f"Verificación cruzada de {item.get('tracking')}: {type(e).__name__}: {e}")
                self._error(item, f"{type(e).__name__}: {e}")
        self.done += sent
        return sent

    def _verify_one(self, extractor, pipeline, item: Dict, day: str) -> bool:
        tracking = str(item.get("tracking") or "").strip()
        if not tracking:
            return False
        sign_id = extractor.api.latest_sign_id(tracking)
        if not sign_id:
            self._error(item, "sin POD en GOFO")
            return False
        w = WaybillSummary(waybill_no=tracking, sign_id=sign_id, driver_name=item.get("driver") or "",
                           sign_distance=_s(item.get("sign_distance")), pod_lat=_s(item.get("pod_lat")),
                           pod_lng=_s(item.get("pod_lng")))
        courier = {"driverName": item.get("driver") or "", "userId": item.get("driver_id") or "",
                   "siteName": item.get("station") or ""}
        pod = extractor._process(courier, w, item.get("date") or day)
        pod.portal_meta["verify_of"] = item.get("flagged_by") or "otra corrida"
        pod.portal_meta["verify_day"] = item.get("date") or day
        pipeline.submit(pod)
        return True

    def _error(self, item: Dict, message: str) -> None:
        if self.report_error_fn:
            try:
                self.report_error_fn(item, message)
            except Exception as e:
                logger.debug(f"Verificación cruzada: no se pudo avisar el error ({e})")


def _s(value) -> Optional[str]:
    return None if value in (None, "") else str(value)
