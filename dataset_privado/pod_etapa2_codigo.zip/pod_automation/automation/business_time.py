"""Dia operativo independiente del huso horario del servidor."""
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

import config


def operation_now(instant=None):
    instant = instant or datetime.now(timezone.utc)
    if instant.tzinfo is None:
        raise ValueError('El instante debe incluir su zona horaria.')
    return instant.astimezone(ZoneInfo(config.OPERATION_TIMEZONE))


def operation_day(instant=None):
    return operation_now(instant).strftime('%Y-%m-%d')
