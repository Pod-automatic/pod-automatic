"""Exclusion de cambios de ciudad entre maquinas que reutilizan la MISMA sesion GOFO.

El lease vive en el portal, nunca en cookies ni en el reloj compartido de los equipos.
Un fallo de coordinacion impide consultar GOFO; no hay fallback sin proteccion.

28/10 (pedido del usuario): con el portal sin responder GOFO_SESSION_OFFLINE_S, la PC sigue sola (modo sin portal) y
reintenta el turno cada pocos segundos; si al volver el portal el turno lo tiene otro, se detiene. Kaggle siempre espera.

28/10: un corte del portal ya no pierde el permiso. La renovacion reintenta mientras el lease siga vigente y solo se da
por perdido si el portal dice que lo tiene otro proceso, rechaza la clave (401/403) o el lease vence de verdad. Asi se
mantiene la exclusion (nadie mas puede tomarlo antes de su vencimiento en el portal) sin parar la corrida por un corte.

29/10: el modo sin portal cuenta la espera desde el PRIMER fallo seguido (antes, desde el ultimo contacto: tras un rato sin
pedir turno, un solo fallo bastaba), solo acepta cortes de red/5xx (un bloqueo del hosting a la PC no es un portal caido
para Kaggle), espera el permiso mas largo que haya dado el portal + margen, y se detiene si GOFO cambia de ciudad sin que
la PC lo pida (otra corrida usa la sesion). Tras eso no vuelve a seguir sola hasta hablar de nuevo con el portal.
"""
import logging
import threading
import time
import uuid

import config

logger = logging.getLogger('PODAutomation.SessionGuard')


class SessionCoordinationError(RuntimeError):
    pass


def classify_failure(error):
    """'auth' (clave rechazada: hay que arreglarla), 'network' (corte o portal caido: reintentar) u 'other'."""
    text = str(error)
    if text.startswith(('HTTP 401', 'HTTP 403')):
        return 'auth'
    if text.startswith('HTTP 5') or 'sin conexión' in text or 'sin conexion' in text:
        return 'network'
    if isinstance(error, (TimeoutError, ConnectionError, OSError)):
        return 'network'
    return 'other'


_last_log = {}
_log_lock = threading.Lock()


def log_throttled(key, message, every_s=600, level=logging.WARNING):
    """Un mismo aviso como mucho cada `every_s` segundos (el 28/10 hubo 43 iguales seguidos que ocultaban la causa)."""
    now = time.monotonic()
    with _log_lock:
        if now - _last_log.get(key, -1e9) < every_s:
            return False
        _last_log[key] = now
    logger.log(level, message)
    return True


class _Wait:
    """Segundos que la corrida espera por la coordinacion (para distinguir 'bloqueada' de 'lenta')."""

    def __init__(self):
        self.total = 0.0; self.lock = threading.Lock()

    def add(self, seconds):
        with self.lock:
            self.total += float(seconds)

    def reset(self):
        with self.lock:
            self.total = 0.0


WAIT = _Wait()

# Ultima vez que el portal respondio a la coordinacion (cualquier respuesta, concedida o no)
LAST_CONTACT = [time.monotonic()]
# Inicio de la racha actual de fallos seguidos (None = el ultimo pedido tuvo respuesta)
OUTAGE_SINCE = [None]
# Permiso mas largo que dio el portal (propio o del que tenia el turno): el otro deja GOFO como mucho eso tras su ultima
# renovacion. El portal concede entre 120 y 300 s.
SEEN_LEASE = [0]
# Motivo por el que no se puede seguir sin portal hasta volver a hablar con el (otra corrida uso la sesion)
CONFLICT = [None]
OFFLINE_MARGIN_S = 30


def _contact(result):
    LAST_CONTACT[0] = time.monotonic(); OUTAGE_SINCE[0] = None; CONFLICT[0] = None
    for key in ('lease_s', 'holder_lease_s'):
        try: SEEN_LEASE[0] = max(SEEN_LEASE[0], int(result.get(key) or 0))
        except (TypeError, ValueError): pass


def offline_wait_s():
    """Segundos de portal caido antes de seguir sola: el permiso mas largo conocido + margen (minimo GOFO_SESSION_OFFLINE_S)."""
    lease = max(min(300, max(120, config.GOFO_SESSION_LEASE_S)), SEEN_LEASE[0])
    return max(config.GOFO_SESSION_OFFLINE_S, lease + OFFLINE_MARGIN_S)


def offline_fallback_allowed(error):
    """True si la PC puede seguir sin portal: corte de red/5xx sin interrupcion durante offline_wait_s()."""
    return (config.CLAIM_WORKER == 'pc' and config.GOFO_SESSION_OFFLINE_S > 0 and CONFLICT[0] is None
            and classify_failure(error) == 'network' and OUTAGE_SINCE[0] is not None
            and time.monotonic() - OUTAGE_SINCE[0] >= offline_wait_s())


class SessionGuard:
    """29/10 (pedido del usuario): con `cities` (codigos 'DFW-BAA'...) la corrida COMPARTE la ciudad en curso con las demas
    del grupo (el portal dice cual en `city` y cuanto queda del turno en `turn_s`). Sin `cities`, reserva exclusiva como
    antes (cierre del dia, portal anterior). Con un portal anterior `city` queda en None y todo sigue como antes."""

    def __init__(self, client, group, worker, renew_s=20, retry_s=3, cities=None, turn_s=None):
        self.client = client; self.group = group; self.worker = worker
        self.renew_s = renew_s; self.retry_s = retry_s
        self.token = uuid.uuid4().hex; self.until = 0; self.error = None; self.failures = 0
        self.stop = threading.Event(); self.thread = None
        self.offline = False
        self.cities = list(cities) if cities else None
        self.turn_s = turn_s
        self.city = None          # Ciudad en la que se puede trabajar (modo compartido)
        self.turn_left = None     # Segundos que le quedan al turno de esa ciudad al concederse

    @property
    def lease_s(self):
        return config.GOFO_SESSION_LEASE_S

    def request(self, action, shared=True, empty=False):
        started = time.monotonic()
        body = {'group': self.group, 'worker': self.worker, 'token': self.token, 'action': action, 'lease_s': self.lease_s}
        if self.cities and shared:
            body.update(cities=self.cities, turn_s=int(self.turn_s or config.CITY_TURN_S))
        if empty:
            body['empty'] = True
        try:
            result = self.client.call('session_guard.php', body)
        except Exception:
            if OUTAGE_SINCE[0] is None: OUTAGE_SINCE[0] = started
            raise
        _contact(result)
        if action != 'release':
            self.until = started + float(result.get('lease_s', 0)) if result.get('granted') else 0
            if action == 'acquire' and result.get('granted'):
                self.city = result.get('city') if self.cities and shared else None
                self.turn_left = result.get('turn_s') if self.city else None
        return bool(result.get('granted'))

    def acquire(self):
        if not self.request('acquire'): return False
        self.thread = threading.Thread(target=self.heartbeat, daemon=True, name='gofo-session-lease')
        self.thread.start()
        return True

    def start_offline(self):
        """Sigue sin permiso (portal caido) y pide el turno cada retry_s hasta que el portal vuelva."""
        self.offline = True
        self.thread = threading.Thread(target=self.heartbeat, daemon=True, name='gofo-session-lease')
        self.thread.start()

    def foreign_switch(self, detail):
        """GOFO cambio de ciudad sin que esta corrida lo pidiera. Sin portal eso es otra corrida con la sesion: se para y no
        se vuelve a seguir sola hasta hablar con el portal. Devuelve True si se detuvo (con permiso, se corrige como antes)."""
        if not self.offline:
            return False
        self.error = CONFLICT[0] = f'Sin portal, otra corrida cambio la ciudad de la sesion ({detail}); se espera al portal.'
        log_throttled('guard-conflict', 'Coordinacion de sesion: ' + self.error, every_s=60, level=logging.ERROR)
        return True

    def heartbeat(self):
        wait = self.retry_s if self.offline else self.renew_s
        while not self.stop.wait(wait):
            if self.offline:
                try:
                    # Exclusiva: sin portal la PC pudo estar en cualquier ciudad; no se comparte hasta la siguiente pasada
                    granted = self.request('acquire', shared=False)
                except Exception:
                    wait = self.retry_s
                    continue
                if not granted:
                    self.error = 'Al volver el portal, la sesion la tenia otra corrida.'
                    return
                self.offline = False
                log_throttled('guard-back', 'Coordinacion de sesion: volvio el portal; la PC retoma los turnos.', level=logging.INFO)
                wait = self.renew_s
                continue
            try:
                granted = self.request('renew')
            except Exception as error:
                kind = classify_failure(error)
                if kind == 'auth':
                    self.error = f'El portal rechazo la clave ({error}); no se puede coordinar la sesion.'
                    log_throttled('guard-auth', f'Coordinacion de sesion: {error}. Revisa PORTAL_API_KEY en .env.',
                                  level=logging.ERROR)
                    return
                self.failures += 1
                left = max(0, int(self.until - time.monotonic()))
                log_throttled('guard-renew-' + kind, f'Coordinacion de sesion: no se pudo renovar ({error}); '
                              f'se reintenta, el permiso vigente dura {left} s mas.')
                wait = self.retry_s
                continue
            if not granted:
                self.error = 'La sesion fue concedida a otro proceso.'
                return
            self.failures = 0
            wait = self.renew_s

    def check(self, request_timeout_s=30):
        if self.offline and not self.error:
            return
        if self.error or time.monotonic() + request_timeout_s + 10 >= self.until:
            raise SessionCoordinationError(self.error or 'Reserva de sesion no vigente; no se consulta GOFO.')

    def close(self, empty=False):
        """empty=True: la ciudad compartida no tenia trabajo; el portal la salta un rato y cambia de ciudad enseguida."""
        self.stop.set()
        if self.thread:
            self.thread.join(timeout=getattr(self.client, 'timeout', 30) + 1)
            if self.thread.is_alive(): return
        if self.until:
            try: self.request('release', empty=bool(empty and self.city))
            finally: self.until = 0
