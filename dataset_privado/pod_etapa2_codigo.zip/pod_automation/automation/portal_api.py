"""
Cliente de SOLO LECTURA para la API interna del portal de GOFO (la misma que usa su web).

Las llamadas se ejecutan con fetch() DENTRO de la página del portal ya logueada, así viajan
exactamente con la misma sesión que el navegador. El token (localStorage 'Admin-Token') se lee
dentro del navegador y nunca pasa por Python ni por los logs.

Seguridad:
- Lista blanca de endpoints de lectura (ALLOWED_ENDPOINTS). Cualquier otro se rechaza.
- No se usa el endpoint que "desencripta" direcciones ocultas (privacy/.../decode).
- Respuesta 401 o redirección a login -> SessionExpiredError (nunca se re-loguea).
- Reintentos con backoff + jitter y pausa entre llamadas (automation.politeness).
"""

import logging
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional

import config
from automation.browser import SessionExpiredError
from automation.session_guard import SessionCoordinationError
from automation.login import SESSION_EXPIRED_MESSAGE
from automation.politeness import retry_with_backoff

logger = logging.getLogger("PODAutomation.PortalAPI")

API_BASE = "https://dms.gofoexpress.com/prod-api"

# Endpoints permitidos (todos de lectura, observados en `inspect`)
EP_COURIERS = "/dbu_report/common/dateTime/magic/siteCheckin/getPodDetailsGroupUP_v3"
EP_WAYBILLS = "/dbu_report/common/dashboard/magic/courier/waybill/list/desensitize"
EP_SIGN_INFO = "/system/sign/getInfoBySignId"
EP_COMPLIANCE = "/system/misWaybillPodCompliance/selectInfoBySignId"
EP_LIST_SIGN = "/system/sign/listSign"  # Firmas de un albarán (lo usa el modal del portal)
# 15/10: historial de escaneos de varios albaranes (Calidad del servicio > Consulta de seguimiento). No depende de la
# ciudad activa: se puede pedir con la corrida andando.
EP_TRACK = "/waybill/track/private/list"
ALLOWED_ENDPOINTS = {EP_COURIERS, EP_WAYBILLS, EP_SIGN_INFO, EP_COMPLIANCE, EP_LIST_SIGN, EP_TRACK}
# Albaranes por llamada. Probado 15/10: 100 en ~6 s, pero con la corrida andando una de 100 pasó los 30 s de límite
TRACK_BATCH = 50
# Cambiar de ciudad (lo mismo que el selector de arriba a la derecha). El portal trabaja con UNA ciudad a la vez por
# cuenta: el detalle y las fotos de un albarán de otra estación dan "El usuario actual no tiene permiso". No modifica
# datos de entregas; cambia la ciudad activa de la cuenta (también en el navegador del usuario).
EP_SWITCH_ORG = "/switch-org/"

_FETCH_JS = """async ({url, method, body, timeoutMs}) => {
    const ls = window.localStorage;
    const token = ls.getItem('Admin-Token');
    // Mismos encabezados que agrega el frontend del portal (sin ellos algunos endpoints
    // responden code=500003).
    const off = -new Date().getTimezoneOffset();
    const pad = n => String(Math.floor(Math.abs(n))).padStart(2, '0');
    const headers = {
        'Content-Type': 'application/json;charset=UTF-8',
        'channel-id': 'us',
        'lang': ls.getItem('lang') || 'es',
        'timezone': 'GMT' + (off >= 0 ? '+' : '-') + pad(off / 60) + pad(off % 60),
        'user-time-zone': ls.getItem('UserTimeZone') || Intl.DateTimeFormat().resolvedOptions().timeZone,
        'date-time-format': ls.getItem('DATETIME_FORMAT') || 'MM/dd/yyyy HH:mm:ss',
    };
    if (token) headers['Authorization'] = 'Bearer ' + token;
    // Tiempo límite: una respuesta colgada del portal no debe frenar la corrida (se reintenta con backoff)
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
        const resp = await fetch(url, {method, headers, credentials: 'include', signal: ctrl.signal,
                                       body: body === null ? undefined : JSON.stringify(body)});
        const text = await resp.text();
        return {status: resp.status, url: resp.url, text};
    } catch (e) {
        return {status: 0, url, text: '', error: String(e)};
    } finally {
        clearTimeout(timer);
    }
}"""


# 30/10: varios GET a la vez (hasta `concurrency` en vuelo) con los mismos encabezados que _FETCH_JS. Un resultado por URL,
# en el mismo orden; un fallo de uno no corta a los demás.
_FETCH_MANY_JS = """async ({urls, timeoutMs, concurrency}) => {
    const ls = window.localStorage;
    const token = ls.getItem('Admin-Token');
    const off = -new Date().getTimezoneOffset();
    const pad = n => String(Math.floor(Math.abs(n))).padStart(2, '0');
    const headers = {
        'Content-Type': 'application/json;charset=UTF-8',
        'channel-id': 'us',
        'lang': ls.getItem('lang') || 'es',
        'timezone': 'GMT' + (off >= 0 ? '+' : '-') + pad(off / 60) + pad(off % 60),
        'user-time-zone': ls.getItem('UserTimeZone') || Intl.DateTimeFormat().resolvedOptions().timeZone,
        'date-time-format': ls.getItem('DATETIME_FORMAT') || 'MM/dd/yyyy HH:mm:ss',
    };
    if (token) headers['Authorization'] = 'Bearer ' + token;
    const out = new Array(urls.length);
    let next = 0;
    const one = async (url) => {
        const ctrl = new AbortController();
        const timer = setTimeout(() => ctrl.abort(), timeoutMs);
        try {
            const resp = await fetch(url, {method: 'GET', headers, credentials: 'include', signal: ctrl.signal});
            return {status: resp.status, url: resp.url, text: await resp.text()};
        } catch (e) {
            return {status: 0, url, text: '', error: String(e)};
        } finally {
            clearTimeout(timer);
        }
    };
    const lane = async () => { while (next < urls.length) { const i = next++; out[i] = await one(urls[i]); } };
    await Promise.all(Array.from({length: Math.min(concurrency, urls.length)}, lane));
    return out;
}"""


class PortalAPIError(RuntimeError):
    """Respuesta inesperada de la API (se reintenta con backoff)."""


@dataclass
class WaybillSummary:
    """Albarán según la lista por conductor (sin abrir el detalle)."""
    waybill_no: str
    sign_id: Optional[str]
    driver_name: str
    post_code: str = ""
    to_street: str = ""
    stop_index: str = ""
    pod_time: str = ""
    order_status: str = ""
    delivery_status_code: str = ""
    pod_compliance: Optional[int] = None
    sign_distance: Optional[str] = None
    pod_lat: Optional[str] = None
    pod_lng: Optional[str] = None
    thumbnail_urls: List[str] = field(default_factory=list)
    raw: Dict[str, Any] = field(default_factory=dict)

    @property
    def status_signature(self) -> str:
        """
        Firma del estado en el portal. Si cambia tras revisado (ej. Anulado, POD rehecho) se revisa de nuevo.
        La hora del POD va al final: al rehacer el POD la lista conserva el signId viejo y solo cambia la hora (caso
        real 04/10, GFUS01075192499842: firma de 15:17:28 con 3 fotos y otra de 15:18:16 con 4).
        """
        return f"{self.order_status}|{self.delivery_status_code}|{self.sign_id or ''}|{pod_clock(self.pod_time)}"


def pod_clock(text: str) -> str:
    """Hora "HH:MM:SS" de una fecha del portal ("10/277/2026 15:18:16", "15:17:28 04/10/2026", "2026-10-04 15:18:16")."""
    m = re.search(r"\b(\d{1,2}:\d{2}:\d{2})\b", text or "")
    return m.group(1) if m else ""


def same_status(old: Optional[str], new: str) -> bool:
    """Firmas guardadas antes del 04/10 no tienen la hora: se comparan solo las tres primeras partes."""
    if old is None or old == new:
        return True
    old_parts, new_parts = old.split("|"), new.split("|")
    return len(old_parts) == 3 and old_parts == new_parts[:3]


class PortalAPI:
    """Lectura de conductores, albaranes y detalle de firma vía la API interna del portal."""

    def __init__(self, page, sleep=time.sleep, request_delay_s: float = None):
        self.page = page
        self.sleep = sleep
        self.request_delay_s = config.REQUEST_DELAY_S if request_delay_s is None else request_delay_s
        self.calls = 0
        self.session_guard = None

    def _check_session_guard(self):
        if self.session_guard:
            self.session_guard.check(config.API_TIMEOUT_MS / 1000)

    # ------------------------------------------------------------------ transporte
    def _call(self, method: str, endpoint: str, body: Optional[dict] = None, query: str = "") -> Any:
        if endpoint not in ALLOWED_ENDPOINTS:
            raise ValueError(f"Endpoint no permitido (solo lectura): {endpoint}")
        url = API_BASE + endpoint + (f"?{query}" if query else "")

        def once():
            self._check_session_guard()
            result = self.page.evaluate(_FETCH_JS, {"url": url, "method": method, "body": body,
                                                    "timeoutMs": config.API_TIMEOUT_MS})
            self.calls += 1
            return self._parse(result, endpoint)

        data = retry_with_backoff(once, sleep=self.sleep)
        if self.request_delay_s > 0:
            self.sleep(self.request_delay_s)
        return data

    @staticmethod
    def _parse(result: Dict[str, Any], endpoint: str) -> Any:
        import json

        status = result.get("status")
        if status == 401 or "/login" in (result.get("url") or ""):
            raise SessionExpiredError(SESSION_EXPIRED_MESSAGE)
        if status == 0:
            raise PortalAPIError(f"{endpoint}: sin respuesta ({result.get('error') or 'tiempo agotado'})")
        if status != 200:
            raise PortalAPIError(f"{endpoint}: HTTP {status}")
        try:
            payload = json.loads(result.get("text") or "")
        except ValueError:
            raise PortalAPIError(f"{endpoint}: respuesta no JSON")
        code = payload.get("code")
        if code == 401:
            raise SessionExpiredError(SESSION_EXPIRED_MESSAGE)
        if code not in (200, "200", None):
            raise PortalAPIError(f"{endpoint}: code={code} {payload.get('msg') or payload.get('message')}")
        return payload

    def switch_station(self, station_id: int) -> None:
        """Abre la ciudad `station_id` (ej. 1888 = DFW02-BAA, 297 = DFW-BAA), como el selector del portal."""
        # 29/10: con la ciudad compartida, abrir OTRA ciudad le cambiaria la ciudad a las demas corridas de la cuenta
        shared = getattr(self.session_guard, 'city', None)
        if shared and config.GOFO_STATION_NAMES.get(int(station_id)) != shared:
            raise SessionCoordinationError(f'La sesion compartida esta en {shared}; no se abre otra ciudad.')
        url = API_BASE + EP_SWITCH_ORG + str(int(station_id))

        def once():
            self._check_session_guard()
            result = self.page.evaluate(_FETCH_JS, {"url": url, "method": "GET", "body": None,
                                                    "timeoutMs": config.API_TIMEOUT_MS})
            self.calls += 1
            return self._parse(result, EP_SWITCH_ORG)

        retry_with_backoff(once, sleep=self.sleep)
        self.current_station = int(station_id)
        if self.request_delay_s > 0:
            self.sleep(self.request_delay_s)

    # ------------------------------------------------------------------ lecturas
    def list_couriers(self, station_id: int, date_iso: str) -> List[Dict[str, Any]]:
        payload = self._call("POST", EP_COURIERS, {"stationId": station_id, "deliveryDate": date_iso})
        return payload.get("data") or []

    def iter_waybills(
        self, station_id: int, date_iso: str, courier: Dict[str, Any], page_size: int = 50,
    ) -> Iterator[WaybillSummary]:
        """Recorre todas las páginas de albaranes de un conductor."""
        page_num = 1
        while True:
            body = {
                "pickupDate": date_iso, "stationIds": [station_id], "searchType": "waybillNo",
                "driverName": courier.get("driverName", ""), "warnThreshold": 0, "inputValue": "",
                "userId": str(courier.get("userId", "")), "postCode": "", "waybillNo": "", "toStreet": "",
                "orderStatusStr": "", "exceptionStr": "", "pageNum": page_num, "pageSize": page_size,
            }
            data = self._call("POST", EP_WAYBILLS, body).get("data") or {}
            records = data.get("records") or []
            for r in records:
                yield WaybillSummary(
                    waybill_no=r.get("waybillNo", ""),
                    sign_id=r.get("signId"),
                    driver_name=courier.get("driverName", ""),
                    post_code=r.get("postCode") or "",
                    to_street=r.get("toStreet") or "",
                    stop_index=r.get("stopIndex") or "",
                    pod_time=r.get("podTime") or "",
                    order_status=r.get("orderStatus") or "",
                    delivery_status_code=str(r.get("waybillDeliveryStatus") or ""),
                    pod_compliance=r.get("podCompliance"),
                    sign_distance=r.get("signDistance"),
                    pod_lat=r.get("podPositionLat"),
                    pod_lng=r.get("podPositionLng"),
                    thumbnail_urls=list(r.get("podImgUrlList") or []),
                    raw=r,
                )
            total = int(data.get("total") or 0)
            if not records or page_num * page_size >= total:
                return
            page_num += 1

    def get_sign_info(self, sign_id: str) -> Dict[str, Any]:
        """Detalle del POD (lo mismo que muestra el modal): fotos completas, dirección, tipo, etc."""
        return self._call("GET", EP_SIGN_INFO, query=f"signId={sign_id}").get("data") or {}

    def get_sign_infos(self, sign_ids: List[str], concurrency: int) -> Dict[str, Any]:
        """
        30/10: detalle de varios POD en UNA llamada del navegador, hasta `concurrency` a la vez, y una sola pausa al final.
        Devuelve {signId: detalle} y, para los que fallaron, {signId: excepción} (quien llama los pide de nuevo de a uno, con
        sus reintentos). Sesión vencida se lanza enseguida, como en _call.
        """
        self._check_session_guard()
        urls = [API_BASE + EP_SIGN_INFO + f"?signId={s}" for s in sign_ids]
        results = self.page.evaluate(_FETCH_MANY_JS, {"urls": urls, "timeoutMs": config.API_TIMEOUT_MS,
                                                      "concurrency": max(1, int(concurrency))})
        self.calls += len(urls)
        out: Dict[str, Any] = {}
        for sign_id, result in zip(sign_ids, results or []):
            try:
                out[sign_id] = self._parse(result or {}, EP_SIGN_INFO).get("data") or {}
            except SessionExpiredError:
                raise
            except Exception as e:
                out[sign_id] = e
        if self.request_delay_s > 0:
            self.sleep(self.request_delay_s)
        return out

    def latest_sign_id(self, waybill_no: str) -> Optional[str]:
        """signId del POD más reciente del albarán (el "Última" del modal del portal)."""
        rows = [r for r in self.list_signs(waybill_no) if r.get("id")]
        if not rows:
            return None
        return max(rows, key=lambda r: str(r.get("signTime") or "")).get("id")

    def list_signs(self, waybill_no: str) -> List[Dict[str, Any]]:
        """Firmas/POD de un albarán por tracking (incluye la marca de POD falso sospechoso)."""
        payload = self._call("POST", EP_LIST_SIGN, {"waybillNo": waybill_no}, query="pageNum=1&pageSize=20")
        return payload.get("rows") or []

    def get_compliance(self, sign_id: str) -> Dict[str, Any]:
        return self._call("GET", EP_COMPLIANCE, query=f"signId={sign_id}").get("data") or {}

    def get_tracks(self, waybill_nos: List[str]) -> List[Dict[str, Any]]:
        """Historial de escaneos (quién, cuándo, código) de hasta TRACK_BATCH albaranes por llamada."""
        out = []
        for i in range(0, len(waybill_nos), TRACK_BATCH):
            body = {"orderNos": list(waybill_nos[i:i + TRACK_BATCH]), "queryType": "1", "delStatus": "0"}
            out += self._call("POST", EP_TRACK, body).get("data") or []
        return out

    def download_image(self, url: str, dest: Path) -> Optional[Path]:
        """Descarga una foto (URL S3 prefirmada) con reintentos."""
        dest.parent.mkdir(parents=True, exist_ok=True)

        def once():
            resp = self.page.context.request.get(url, timeout=30000)
            if resp.status != 200:
                raise PortalAPIError(f"imagen HTTP {resp.status}")
            dest.write_bytes(resp.body())
            return dest

        try:
            return retry_with_backoff(once, sleep=self.sleep)
        except (SessionExpiredError, SessionCoordinationError):
            raise
        except Exception as e:
            logger.warning(f"No se pudo descargar la foto {dest.name}: {e}")
            return None
