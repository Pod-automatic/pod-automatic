"""
Módulo de Extracción de Datos y Evidencias POD (Scraper Robusto).

Diseñado específicamente para entornos web empresariales dinámicos:
- Soporte para tablas virtualizadas (scroll progresivo en contenedores).
- Paginación multi-página con esperas inteligentes.
- Extracción de datos completos (incluyendo textos ocultos por overflow/ellipsis).
- Descarga tolerante a fallos de fotografías (Playwright request con fallback a screenshot de elemento).
- Manejo síncrono y robusto de modales (esperas explícitas de visibilidad y cierre completo).
- CERO dependencias de time.sleep() para sincronización.
"""

import logging
import time
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Set, Dict, Any
from playwright.sync_api import Page, ElementHandle
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
from rich.console import Console
from rich.panel import Panel

from config import (
    POD_IMAGES_DIR,
    AUTO_DOWNLOAD_IMAGES,
    SCREENSHOTS_DIR,
    SCREENSHOT_ON_ERROR,
    MAX_RETRIES,
    REQUEST_DELAY_S,
    THROUGHPUT_LOG_PATH,
    GOFO_PORTAL_URL,
)
from models.pod import PODRecord, ProcessingStatusEnum
from automation.selectors import Selectors
from automation.browser import BrowserManager, SessionExpiredError
from automation.login import looks_logged_out, SESSION_EXPIRED_MESSAGE
from automation.politeness import retry_with_backoff, ThroughputTracker

logger = logging.getLogger("PODAutomation.Scraper")
console = Console()


class PODScraper:
    """Extractor de comprobantes POD con alta resiliencia y esperas inteligentes de Playwright."""

    def __init__(
        self,
        browser_manager: BrowserManager,
        throughput: Optional[ThroughputTracker] = None,
        sleep=time.sleep,
        portal_url: str = GOFO_PORTAL_URL,
    ):
        self.bm = browser_manager
        self.page: Page = browser_manager.page
        self.processed_trackings: Set[str] = set()
        self.throughput = throughput or ThroughputTracker(log_path=THROUGHPUT_LOG_PATH)
        self.sleep = sleep
        self.portal_url = portal_url

    def ensure_session_alive(self) -> None:
        """Si el portal redirigió a un login, detiene la corrida (SessionExpiredError)."""
        if looks_logged_out(self.page.url, self.portal_url):
            self.bm.session_valid = False
            raise SessionExpiredError(SESSION_EXPIRED_MESSAGE)

    def _get_scrollable_table_element(self) -> Optional[ElementHandle]:
        """Localiza el contenedor con scroll activo de la tabla."""
        for selector in Selectors.SCROLLABLE_CONTAINER.selectors:
            try:
                elem = self.page.query_selector(selector)
                if elem and elem.is_visible():
                    return elem
            except Exception:
                continue
        return None

    def get_currently_visible_rows(self) -> List[ElementHandle]:
        """Obtiene las filas actualmente presentes en el DOM visible."""
        for selector in Selectors.TABLE_ROWS.selectors:
            try:
                rows = self.page.query_selector_all(selector)
                if rows:
                    return [r for r in rows if r.is_visible()]
            except Exception:
                continue
        return []

    def get_table_rows(self) -> List[ElementHandle]:
        """Alias compatible para obtener las filas visibles de la tabla."""
        return self.get_currently_visible_rows()

    def extract_full_text(self, element: ElementHandle) -> str:
        """
        Extrae el texto completo de un elemento, incluso si está oculto por
        estilos CSS (text-overflow: ellipsis, white-space: nowrap) o en atributos title/aria-label.
        """
        try:
            # 1. Comprobar si hay tooltip o texto completo en atributo title
            title_attr = element.get_attribute("title")
            if title_attr and title_attr.strip():
                return title_attr.strip()

            aria_label = element.get_attribute("aria-label")
            if aria_label and aria_label.strip():
                return aria_label.strip()

            # 2. Extraer mediante textContent (incluye texto desbordado no visible por layout)
            text_content = element.evaluate("el => el.textContent || el.innerText || ''")
            return text_content.strip()
        except Exception:
            return ""

    def extract_row_summary(self, row: ElementHandle) -> PODRecord:
        """Extrae de manera segura los datos visibles en las columnas de una fila de entrega."""
        cells = row.query_selector_all("td, div[role='cell'], .cell")
        cell_values = [self.extract_full_text(c) for c in cells]

        # Tracking / Albarán
        tracking = ""
        trk_elem = row.query_selector("a, .tracking-number, [data-field='tracking'], .waybill")
        if trk_elem:
            tracking = self.extract_full_text(trk_elem)

        if not tracking and len(cell_values) >= 1:
            tracking = cell_values[0]

        # Stop number (Número de parada)
        stop_number = None
        for sel in Selectors.STOP_NUMBER.selectors:
            stop_el = row.query_selector(sel)
            if stop_el:
                stop_number = self.extract_full_text(stop_el)
                break

        # Station (Estación DSP)
        station = ""
        for sel in Selectors.STATION_CODE.selectors:
            st_el = row.query_selector(sel)
            if st_el:
                station = self.extract_full_text(st_el)
                break

        # Asignación de celdas estándar
        driver = cell_values[1] if len(cell_values) >= 2 else "Desconocido"
        direccion = cell_values[2] if len(cell_values) >= 3 else ""
        estado = cell_values[3] if len(cell_values) >= 4 else "Entregado"
        fecha_hora = cell_values[4] if len(cell_values) >= 5 else ""
        tipo_entrega = cell_values[5] if len(cell_values) >= 6 else "Estándar"

        return PODRecord(
            tracking_number=tracking.strip() or f"UNKNOWN_{len(self.processed_trackings)+1}",
            stop_number=stop_number.strip() if stop_number else None,
            driver_name=driver.strip(),
            station=station.strip(),
            address=direccion.strip(),
            delivery_status=estado.strip(),
            delivery_datetime=fecha_hora.strip(),
            delivery_type=tipo_entrega.strip(),
            processing_status=ProcessingStatusEnum.PROCESSING,
        )

    def open_pod_detail(self, row: ElementHandle) -> Optional[ElementHandle]:
        """
        Abre el detalle o modal del POD con esperas inteligentes:
        1. Hace scroll para asegurar visibilidad del botón de apertura.
        2. Hace clic en el disparador.
        3. Espera a que el modal alcance el estado 'visible'.
        4. Espera a que finalicen las llamadas de red o spinners internos del modal.
        """
        opened = False
        for sel in Selectors.BTN_VIEW_POD.selectors:
            btn = row.query_selector(sel)
            if btn and btn.is_visible():
                try:
                    btn.scroll_into_view_if_needed(timeout=3000)
                    btn.click()
                    opened = True
                    break
                except Exception:
                    continue

        if not opened:
            # Si no hay botón explícito, intentar clic en el albarán
            link = row.query_selector("a")
            if link and link.is_visible():
                try:
                    link.scroll_into_view_if_needed(timeout=3000)
                    link.click()
                    opened = True
                except Exception:
                    pass

        if not opened:
            return None

        # Espera inteligente de aparición del modal (sin sleep)
        modal = self.bm.wait_for_modal_state(visible=True, timeout_ms=8000)
        if modal:
            # Esperar a que se completen datos o peticiones del modal
            self.bm.wait_for_spinners_to_disappear(timeout_ms=10000)
            return modal

        return None

    def close_pod_detail(self) -> None:
        """
        Cierra el modal de detalle y espera de forma determinista
        a que el elemento y sus backdrops desaparezcan del DOM.
        """
        closed = False
        # Intentar clic en botón de cierre
        for sel in Selectors.MODAL_CLOSE_BUTTON.selectors:
            btn = self.page.query_selector(sel)
            if btn and btn.is_visible():
                try:
                    btn.click()
                    closed = True
                    break
                except Exception:
                    continue

        if not closed:
            # Contingencia: presionar tecla Escape
            self.page.keyboard.press("Escape")

        # Espera inteligente de desaparición total del modal
        self.bm.wait_for_modal_state(visible=False, timeout_ms=6000)

    def download_or_capture_image(
        self,
        img_elem: ElementHandle,
        dest_folder: Path,
        filename: str,
    ) -> Optional[str]:
        """
        Guarda la fotografía del comprobante de manera ultra robusta:
        1. Espera a que la imagen se renderice en el navegador (complete=True).
        2. Intenta descarga directa HTTP usando cookies autenticadas de sesión.
        3. Si la URL remota falla, tiene CORS o es un blob inaccesible, realiza
           una captura directa (screenshot) del elemento en el canvas/DOM.
        """
        dest_folder.mkdir(parents=True, exist_ok=True)
        file_path = dest_folder / filename

        # 1. Espera inteligente a que la imagen termine de cargar
        self.bm.wait_for_image_ready(img_elem, timeout_ms=4000)

        # 2. Obtener URL de la imagen
        src = (
            img_elem.get_attribute("src")
            or img_elem.get_attribute("data-src")
            or img_elem.get_attribute("data-original")
        )

        # Intentar descarga por HTTP con el contexto autenticado
        if src and src.startswith("http"):
            try:
                response = self.bm.context.request.get(src, timeout=10000)
                if response.status == 200:
                    with open(file_path, "wb") as f:
                        f.write(response.body())
                    return str(file_path)
            except Exception as e:
                logger.warning(f"Descarga HTTP de imagen falló ({e}). Aplicando fallback por captura de elemento...")

        # 3. Fallback Infalible: Screenshot directo del elemento renderizado
        try:
            img_elem.scroll_into_view_if_needed(timeout=2000)
            img_elem.screenshot(path=str(file_path))
            return str(file_path)
        except Exception as e:
            logger.warning(f"No fue posible capturar evidencia fotográfica: {e}")
            return None

    def extract_modal_details(self, modal: ElementHandle, pod: PODRecord, query_date: str) -> None:
        """Extrae fotografías, firma digital y motivos de no conformidad del modal activo."""
        dest_folder = POD_IMAGES_DIR / query_date / pod.albaran

        # 1. Localizar y descargar fotografías de entrega
        img_elements = []
        for sel in Selectors.MODAL_POD_IMAGES.selectors:
            found = modal.query_selector_all(sel)
            if found:
                img_elements = [img for img in found if img.is_visible()]
                if img_elements:
                    break

        for idx, img_elem in enumerate(img_elements, 1):
            src = img_elem.get_attribute("src") or ""
            if src.startswith("data:image/svg"):
                continue  # Ignorar iconos de interfaz SVG

            pod.fotos_urls.append(src)
            if AUTO_DOWNLOAD_IMAGES:
                local_path = self.download_or_capture_image(
                    img_elem=img_elem,
                    dest_folder=dest_folder,
                    filename=f"pod_foto_{idx}.jpg",
                )
                if local_path:
                    pod.fotos_locales.append(local_path)

        # 2. Localizar y descargar firma si existe
        for sig_sel in Selectors.MODAL_SIGNATURE.selectors:
            sig_elem = modal.query_selector(sig_sel)
            if sig_elem and sig_elem.is_visible():
                pod.tiene_firma = True
                sig_src = sig_elem.get_attribute("src") or ""
                pod.firma_url = sig_src
                if AUTO_DOWNLOAD_IMAGES:
                    sig_path = self.download_or_capture_image(
                        img_elem=sig_elem,
                        dest_folder=dest_folder,
                        filename="firma_digital.jpg",
                    )
                    if sig_path:
                        pod.firma_local = sig_path
                break

        # 2b. Extraer fecha/hora de la firma si está disponible
        for st_sel in Selectors.MODAL_SIGNATURE_TIME.selectors:
            st_elem = modal.query_selector(st_sel)
            if st_elem and st_elem.is_visible():
                pod.signature_datetime = self.extract_full_text(st_elem)
                break

        # 3. Extraer motivos de incumplimiento o razones de rechazo
        for r_sel in Selectors.MODAL_REJECTION_REASON.selectors:
            reason_elem = modal.query_selector(r_sel)
            if reason_elem and reason_elem.is_visible():
                reason_text = self.extract_full_text(reason_elem)
                if reason_text:
                    pod.non_compliance_reason = reason_text
                    pod.abnormal_status = True
                    break

        # Sincronizar cantidad de fotos y estado de procesamiento
        pod.sync_photo_count()
        pod.processing_status = ProcessingStatusEnum.PROCESSED

    def _scroll_next_batch(self, container: Optional[ElementHandle]) -> bool:
        """
        Realiza scroll controlado en la tabla para cargar nuevos elementos
        en listas virtualizadas. Retorna True si el scroll avanzó efectivamente.
        """
        if container:
            try:
                moved = container.evaluate("""el => {
                    const prev = el.scrollTop;
                    el.scrollTop += Math.floor(el.clientHeight * 0.75);
                    return el.scrollTop > prev;
                }""")
                if moved:
                    # Esperar a que el motor virtualizado inyecte los nuevos nodos en el DOM
                    self.page.wait_for_load_state("domcontentloaded", timeout=2000)
                    return True
            except Exception:
                pass

        # Scroll alternativo en la ventana principal
        return self.page.evaluate("""() => {
            const prev = window.scrollY;
            window.scrollBy(0, 500);
            return window.scrollY > prev;
        }""")

    def _go_to_next_page(self) -> bool:
        """Detecta y presiona el botón de página siguiente si existe."""
        for next_sel in Selectors.BTN_NEXT_PAGE.selectors:
            btn = self.page.query_selector(next_sel)
            if btn and btn.is_visible() and btn.is_enabled():
                try:
                    logger.info(f"Navegando a la siguiente página mediante selector: {next_sel}")
                    btn.scroll_into_view_if_needed(timeout=3000)
                    btn.click()

                    # Espera inteligente de recarga de tabla
                    self.page.wait_for_load_state("networkidle", timeout=12000)
                    self.bm.wait_for_spinners_to_disappear(timeout_ms=15000)
                    return True
                except Exception as e:
                    logger.warning(f"Error al cambiar de página: {e}")
        return False

    def scrape_all_pods(
        self,
        query_date: str,
        max_records: Optional[int] = None,
        audit_logger: Optional[Any] = None,
        checkpoint_manager: Optional[Any] = None,
        session_id: Optional[str] = None,
        preloaded_records: Optional[List[PODRecord]] = None,
        on_pod_processed: Optional[Any] = None,
    ) -> List[PODRecord]:
        """
        Orquesta el recorrido completo de entregas con alta resiliencia:
        - Soporte para reanudación de checkpoints SQLite (evita duplicados).
        - Aislamiento de fallos y reintentos por POD (Fase 7).
        - Captura de screenshots ante errores sin abortar el lote.
        - Notificación en vivo del progreso (Fase 10).
        """
        records: List[PODRecord] = list(preloaded_records or [])
        self.processed_trackings = {p.albaran for p in records}

        # Esperar a que la tabla se estabilice
        self.bm.wait_for_spinners_to_disappear(timeout_ms=15000)
        scroll_container = self._get_scrollable_table_element()

        consecutive_empty_scrolls = 0
        current_page = 1
        total_estimate = max_records or 100

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
        ) as progress:
            task = progress.add_task("[cyan]Auditando PODs en plataforma...", total=total_estimate)

            while True:
                visible_rows = self.get_currently_visible_rows()
                new_rows_in_this_view = 0

                for row in visible_rows:
                    if max_records and len(records) >= max_records:
                        break

                    try:
                        pod_summary = self.extract_row_summary(row)
                        if pod_summary.albaran in self.processed_trackings:
                            continue

                        # Registrar albarán para evitar reprocesamiento en listas virtualizadas
                        self.processed_trackings.add(pod_summary.albaran)
                        new_rows_in_this_view += 1
                        pod_index = len(records) + 1

                        if audit_logger:
                            audit_logger.start_pod(pod_index, total_estimate, pod_summary.albaran)

                        progress.update(task, description=f"[cyan]Procesando albarán: {pod_summary.albaran}")

                        # La sesión puede vencer a mitad de la corrida: se detiene, nunca se re-loguea
                        self.ensure_session_alive()
                        started = time.monotonic()

                        # Reintentos con backoff exponencial + jitter (Fase 7)
                        last_err: Optional[Exception] = None

                        def attempt_once():
                            modal = self.open_pod_detail(row)
                            if modal:
                                self.extract_modal_details(modal, pod_summary, query_date)
                                self.close_pod_detail()
                            else:
                                self.ensure_session_alive()
                                logger.debug(f"Detalle modal no requerido o no disponible para {pod_summary.albaran}")

                        def on_retry(attempt, err, delay):
                            if audit_logger:
                                audit_logger.log_retry(pod_index, pod_summary.albaran, attempt, MAX_RETRIES, f"{err} (esperando {delay:.1f}s)")
                            try:
                                self.close_pod_detail()
                            except Exception:
                                pass
                            self.ensure_session_alive()

                        try:
                            retry_with_backoff(attempt_once, max_attempts=MAX_RETRIES, sleep=self.sleep, on_retry=on_retry)
                        except SessionExpiredError:
                            raise
                        except Exception as final_err:
                            last_err = final_err

                        if last_err:
                            # 1. Registrar el error
                            pod_summary.processing_status = ProcessingStatusEnum.FAILED
                            pod_summary.error_message = str(last_err)
                            pod_summary.abnormal_status = True

                            # 2. Guardar screenshot de diagnóstico si es útil
                            screenshot_path = None
                            if SCREENSHOT_ON_ERROR:
                                try:
                                    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
                                    safe_trk = "".join(c for c in pod_summary.albaran if c.isalnum() or c in "-_")
                                    err_shot = SCREENSHOTS_DIR / f"error_{safe_trk}_{ts}.png"
                                    self.page.screenshot(path=str(err_shot))
                                    screenshot_path = str(err_shot)
                                except Exception as ss_err:
                                    logger.warning(f"No se pudo guardar screenshot de error: {ss_err}")

                            if audit_logger:
                                audit_logger.log_pod_error(pod_index, pod_summary.albaran, last_err, screenshot_path)

                        # Guardar en memoria y en checkpoint SQLite (Fase 8)
                        records.append(pod_summary)
                        if checkpoint_manager and session_id:
                            checkpoint_manager.save_pod_checkpoint(session_id, pod_summary)

                        elapsed = time.monotonic() - started
                        self.throughput.record(pod_summary.albaran, elapsed, str(pod_summary.processing_status.value))
                        logger.info(f"Albarán {pod_summary.albaran} procesado en {elapsed:.2f}s")

                        if on_pod_processed:
                            on_pod_processed(pod_index, total_estimate, pod_summary)

                        progress.update(task, advance=1)

                        # Pausa de cortesía entre albaranes (no saturar el portal)
                        if REQUEST_DELAY_S > 0:
                            self.sleep(REQUEST_DELAY_S)

                    except SessionExpiredError:
                        raise
                    except Exception as row_err:
                        logger.warning(f"Error procesando fila de entrega: {row_err}")
                        try:
                            self.close_pod_detail()
                        except Exception:
                            pass

                if max_records and len(records) >= max_records:
                    logger.info(f"Límite solicitado de {max_records} entregas alcanzado.")
                    break

                # Si no hubo filas nuevas en la vista actual, intentar scroll
                if new_rows_in_this_view == 0:
                    consecutive_empty_scrolls += 1
                    scroll_success = self._scroll_next_batch(scroll_container)

                    if not scroll_success or consecutive_empty_scrolls >= 3:
                        # Si llegamos al final del scroll, comprobar si hay paginación
                        if self._go_to_next_page():
                            current_page += 1
                            consecutive_empty_scrolls = 0
                            logger.info(f"Avanzando a página {current_page}...")
                            continue
                        else:
                            logger.info("Fin de registros alcanzado (sin más scroll ni páginas).")
                            break
                else:
                    consecutive_empty_scrolls = 0
                    self._scroll_next_batch(scroll_container)

        console.print(f"[bold green][OK] Proceso de extracción finalizado: {len(records)} entregas recolectadas.[/bold green]")
        return records
