"""
30/10 (pedido del usuario, PC y Kaggle): seguir con el día anterior pasada la medianoche.

A las 00:00 la corrida pasaba al día nuevo, que en GOFO todavía no tiene entregas, y dejaba atrás lo pendiente del anterior
(29/10: ~16.700 albaranes y Kaggle quieto con «Sin trabajo disponible»). Ahora, de madrugada, sigue con el día anterior hasta
que el día nuevo tenga entregas con POD (se consulta cada DAY_CARRY_PROBE_S), el anterior se quede sin trabajo o llegue
DAY_CARRY_UNTIL_H. Recién entonces cambia de día (y se encola el cierre del anterior, como siempre).
"""
import logging
import time
from datetime import timedelta
from typing import Callable, Optional, Set

import config
from automation.business_time import operation_now

logger = logging.getLogger("PODAutomation.DayCarry")


class DayCarry:
    def __init__(self, has_work: Callable[[str], bool], now=None, clock=time.monotonic):
        self.has_work = has_work          # (día) -> True si GOFO ya tiene entregas con POD ese día
        self.now = now or operation_now
        self.clock = clock
        self.carry: Optional[str] = None  # Día anterior que se sigue trabajando
        self.ended: Set[str] = set()      # Días nuevos para los que ya terminó (o no corresponde) el arrastre
        self.next_probe = 0.0

    def pick(self, current_day: Optional[str], previous_ok: Callable[[str], bool]) -> str:
        """
        El día a trabajar. current_day = el de la pasada anterior (None al arrancar). previous_ok(día) = ese día se puede
        seguir en este equipo (su sesión no está cerrada).
        """
        now = self.now()
        real = now.strftime("%Y-%m-%d")
        if not config.DAY_CARRY_OVER or real in self.ended:
            return real
        prev = (now - timedelta(days=1)).strftime("%Y-%m-%d")
        if self.carry != prev:
            self.carry = None
            if now.hour >= config.DAY_CARRY_UNTIL_H or current_day not in (None, prev) or not previous_ok(prev):
                self.ended.add(real)
                return real
            self.carry, self.next_probe = prev, 0.0
            logger.info(f"Pasada la medianoche: se sigue con lo pendiente del {prev} hasta que el {real} tenga entregas")
        if now.hour >= config.DAY_CARRY_UNTIL_H:
            return self.stop(f"son más de las {config.DAY_CARRY_UNTIL_H}:00")
        if self.clock() >= self.next_probe:
            self.next_probe = self.clock() + config.DAY_CARRY_PROBE_S
            try:
                ready = self.has_work(real)
            except Exception as e:   # Sin dato: seguir con el anterior y volver a mirar en el próximo intervalo
                logger.warning(f"No se pudo consultar si el {real} ya tiene entregas ({type(e).__name__}: {e})")
                ready = False
            if ready:
                return self.stop(f"el {real} ya tiene entregas")
        return prev

    def stop(self, why: str) -> str:
        """Termina el arrastre y devuelve el día de hoy."""
        real = self.now().strftime("%Y-%m-%d")
        if self.carry:
            logger.info(f"Fin del día {self.carry} pasada la medianoche: {why}; se pasa al {real}")
        self.carry = None
        self.ended.add(real)
        return real

    def active(self, day: str) -> bool:
        return self.carry is not None and day == self.carry
