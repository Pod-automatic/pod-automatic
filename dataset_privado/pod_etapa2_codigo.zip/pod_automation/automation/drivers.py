"""
Selección de repartidores: se revisan todos MENOS los de la lista de excluidos (drivers_config.json).

- Los nombres se comparan normalizados (sin mayúsculas ni espacios dobles: el portal a veces
  trae "Mirielys  Hermoso"). También se puede excluir por ID interno del portal.
- Un repartidor nunca visto antes se revisa igual y queda marcado como "nuevo" para que se
  decida si va a la lista de excluidos.
"""

import json
import re
from pathlib import Path
from typing import Dict, Iterable, List, Optional

import config

TEMPLATE = {
    "_instrucciones": (
        "Se revisan TODOS los repartidores excepto los de 'excluir'. Escribí el nombre tal como "
        "aparece en el portal (mayúsculas y espacios dobles no importan) o su ID interno. "
        "'catalogo' es solo de referencia: lo actualiza `python main.py drivers`."
    ),
    "excluir": [],
    "prioridad": [],
    "catalogo": [],
}


def normalize_name(name: str) -> str:
    return re.sub(r"\s+", " ", (name or "").strip()).casefold()


def sampling_for(day: str, path: Path = None) -> Optional[int]:
    """
    07/10: 'muestreo' de drivers_config.json ({"fecha": "AAAA-MM-DD", "porcentaje": 30}): ese día, a los repartidores
    SIN prioridad se les revisa solo ese % al azar (los de prioridad, siempre el 100 %). Otro día: None (todo).
    """
    p = Path(path or config.DRIVERS_CONFIG_PATH)
    try:
        m = json.loads(p.read_text(encoding="utf-8")).get("muestreo") or {}
        pct = int(m.get("porcentaje"))
    except (OSError, ValueError, TypeError, AttributeError):
        return None
    return pct if str(m.get("fecha")) == day and 0 < pct < 100 else None


def manual_priority(path: Path = None) -> set:
    """
    07/10: 'prioridad' de drivers_config.json, repartidores que el usuario quiere revisados primero (nombre o ID).
    Se lee en cada pasada: agregar o quitar nombres no requiere reiniciar la corrida.
    """
    p = Path(path or config.DRIVERS_CONFIG_PATH)
    try:
        items = json.loads(p.read_text(encoding="utf-8")).get("prioridad") or []
    except (OSError, ValueError):
        return set()
    return {str(x).strip() if str(x).strip().isdigit() else normalize_name(str(x)) for x in items if str(x).strip()}


def day_exclusions(data: dict, day: str = None) -> list:
    """
    12/10: '_excluir_solo_hoy' ({"fecha": "AAAA-MM-DD", "ids": [...]}): excluidos SOLO ese día (pedido del usuario: "hoy no
    veas a ..."). Otro día se ignoran solos, sin tener que acordarse de sacarlos de 'excluir' al cerrar la jornada.
    """
    from datetime import date
    m = data.get("_excluir_solo_hoy") or {}
    if not isinstance(m, dict) or str(m.get("fecha")) != (day or date.today().isoformat()):
        return []
    return [str(x).strip() for x in m.get("ids") or [] if str(x).strip()]


class DriverSelection:
    def __init__(self, path: Path = None, only: Optional[Iterable[str]] = None,
                 stations: Optional[Iterable[str]] = None, skip: Optional[Iterable[str]] = None,
                 extra: Optional[Iterable[str]] = None):
        self.path = Path(path or config.DRIVERS_CONFIG_PATH)
        data = self._load()
        excl = (data.get("excluir") or []) + day_exclusions(data)
        self.excluded_names = {normalize_name(x) for x in excl if not str(x).strip().isdigit()}
        self.excluded_ids = {str(x).strip() for x in excl if str(x).strip().isdigit()}
        # `--skip-drivers`: excluidos solo en esta corrida (ej. "hoy a estos los reviso yo"), sin tocar el archivo
        skip = [str(x).strip() for x in (skip or []) if str(x).strip()]
        self.excluded_names |= {normalize_name(x) for x in skip if not x.isdigit()}
        self.excluded_ids |= {x for x in skip if x.isdigit()}
        # `--extra-drivers`: revisar también a estos aunque sean de otra estación (ej. un repartidor de DFW-BAA)
        extra = [str(x).strip() for x in (extra or []) if str(x).strip()]
        self.extra_names = {normalize_name(x) for x in extra if not x.isdigit()}
        self.extra_ids = {x for x in extra if x.isdigit()}
        # `--drivers`: revisar SOLO estos (nombre exacto normalizado o ID interno); None = todos
        only = [str(x).strip() for x in (only or []) if str(x).strip()]
        self.only = bool(only)
        # `--stations`: revisar solo repartidores de estas estaciones (siteName del portal, ej. "DFW02-BAA")
        self.stations = {normalize_name(s).replace(" ", "") for s in stations or [] if str(s).strip()}
        self.only_names = {normalize_name(x) for x in only if not x.isdigit()}
        self.only_ids = {x for x in only if x.isdigit()}

    def _load(self) -> Dict:
        if not self.path.exists():
            return dict(TEMPLATE)
        return json.loads(self.path.read_text(encoding="utf-8"))

    def should_review(self, courier: Dict) -> bool:
        is_extra = (str(courier.get("userId") or "") in self.extra_ids
                    or normalize_name(courier.get("driverName", "")) in self.extra_names)
        # La ciudad que cuenta es donde aparece la ruta hoy (lista del portal de esa estación); si no se sabe, la de
        # registro del repartidor (siteName). Los repartidores se cambian entre DFW-BAA y DFW02-BAA (03/10).
        city = courier.get("_listed_station") or courier.get("siteName", "")
        if self.stations and not is_extra and normalize_name(city).replace(" ", "") not in self.stations:
            return False
        if self.only:
            return (str(courier.get("userId") or "") in self.only_ids
                    or normalize_name(courier.get("driverName", "")) in self.only_names)
        if str(courier.get("userId") or "") in self.excluded_ids:
            return False
        return normalize_name(courier.get("driverName", "")) not in self.excluded_names

    def update_catalog(self, couriers_by_station: Dict[str, List[Dict]]) -> Path:
        """Escribe/actualiza el archivo con el catálogo de repartidores (conserva 'excluir')."""
        data = self._load()
        data.setdefault("_instrucciones", TEMPLATE["_instrucciones"])
        data.setdefault("excluir", [])
        # Se acumula: correr el comando en distintos días suma repartidores sin perder los anteriores
        catalog = {(c.get("id") or c.get("nombre")): c for c in data.get("catalogo") or []}
        for station, couriers in couriers_by_station.items():
            for c in couriers:
                key = str(c.get("userId") or "") or c.get("driverName")
                catalog[key] = {
                    "nombre": re.sub(r"\s+", " ", c.get("driverName", "")).strip(),
                    "id": str(c.get("userId") or ""),
                    "estacion": station,
                }
        for c in catalog.values():
            c["excluido"] = not self.should_review({"driverName": c["nombre"], "userId": c["id"]})
        data["catalogo"] = sorted(catalog.values(), key=lambda x: (x["estacion"], x["nombre"].casefold()))
        self.path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        return self.path
