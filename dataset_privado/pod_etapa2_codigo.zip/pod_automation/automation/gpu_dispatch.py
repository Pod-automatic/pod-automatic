"""Una cola compartida por servicio GPU, entre los dos pools de analisis."""
from contextlib import contextmanager
from pathlib import Path
import sqlite3
import time
import uuid


def _keys(url,capacity):
    """El hueco 0 conserva la clave de siempre (compatible con bases ya creadas); los demas llevan '#n'."""
    return [url]+[f'{url}#{n}' for n in range(1,capacity)]


@contextmanager
def gpu_slot(path,urls,timeout,capacity=1):
    """capacity = consultas simultaneas por servicio (igual a OLLAMA_NUM_PARALLEL de ese servicio). 1 = como antes."""
    capacity=max(1,int(capacity))
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    token=uuid.uuid4().hex
    end=time.monotonic()+timeout
    owner={k:url for url in urls for k in _keys(url,capacity)}
    chosen=None
    with sqlite3.connect(path,timeout=10) as db:
        db.execute('CREATE TABLE IF NOT EXISTS gpu_slots(url TEXT PRIMARY KEY,token TEXT,until REAL,last_used REAL)')
    while chosen is None:
        with sqlite3.connect(path,timeout=10) as db:
            db.execute('BEGIN IMMEDIATE')
            for key in owner:
                db.execute('INSERT OR IGNORE INTO gpu_slots VALUES (?,NULL,0,0)',(key,))
            available=[r for r in db.execute('SELECT url,last_used FROM gpu_slots WHERE until<=?',(time.time(),)) if r[0] in owner]
            if available:
                free={}
                for key,_ in available: free[owner[key]]=free.get(owner[key],0)+1
                # Primero el servicio con mas huecos libres (reparte la carga); a igualdad, el menos usado hace rato.
                chosen=min(available,key=lambda r:(-free[owner[r[0]]],r[1]))[0]
                db.execute('UPDATE gpu_slots SET token=?,until=?,last_used=? WHERE url=?',
                           (token,time.time()+timeout+30,time.time(),chosen))
        if chosen is None:
            if time.monotonic()>=end: raise TimeoutError('Servicios GPU ocupados; se agoto la espera de la cola.')
            time.sleep(.05)
    try:
        yield owner[chosen]
    finally:
        with sqlite3.connect(path,timeout=10) as db:
            db.execute('UPDATE gpu_slots SET token=NULL,until=0 WHERE url=? AND token=?',(chosen,token))
