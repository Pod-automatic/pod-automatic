"""
Extracción de albaranes vía la API interna del portal (modo por defecto, EXTRACTION_MODE=api).

Recorrido por pasada: se listan las rutas (conductores -> albaranes paginados; primero los de prioridad) intercalando
con bloques del conductor más atrasado de los ya listados (detalle de firma + fotos).
Solo se procesan albaranes con POD (signId) que aún no estén en el checkpoint.

Cortesía con el portal: las llamadas al portal son secuenciales, con pausa y backoff
(PortalAPI). Las fotos se descargan de Amazon S3 (no del portal) en paralelo.
"""

import hashlib
import logging
import re
import threading
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Optional, Set
from urllib.parse import urlparse

import config
from automation.browser import SessionExpiredError
from automation.session_guard import SessionCoordinationError
from automation.drivers import normalize_name
from automation.politeness import ThroughputTracker, retry_with_backoff
from automation.portal_api import PortalAPI, WaybillSummary, pod_clock, same_status
from models.pod import PODRecord, ProcessingStatusEnum
from storage.checkpoint_manager import needs_retry

logger = logging.getLogger("PODAutomation.APIExtractor")


def _is_allowed_image_host(url: str) -> bool:
    host = (urlparse(url).hostname or "").lower()
    return any(host.endswith(suffix.lstrip("*")) for suffix in config.IMAGE_HOST_ALLOWLIST)


def _fetch_to_file(url: str, dest: Path, timeout: float = 30.0) -> Path:
    # URL S3 prefirmada: no lleva cookies ni tokens del portal
    with urllib.request.urlopen(url, timeout=timeout) as resp:
        if resp.status != 200:
            raise IOError(f"HTTP {resp.status}")
        dest.write_bytes(resp.read())
    return dest


def download_images_parallel(
    urls: List[str],
    dest_dir: Path,
    workers: int = None,
    fetch: Callable[[str, Path], Path] = _fetch_to_file,
    sleep=time.sleep,
    errors: Optional[List[str]] = None,
) -> List[Optional[str]]:
    """
    Descarga las fotos de un albarán en paralelo (solo hosts de IMAGE_HOST_ALLOWLIST).
    Devuelve una lista alineada con `urls` (None si esa foto falló o su host no está permitido).
    22/10: el motivo de cada foto fallida se agrega a `errors` (para reintentar el albarán si fue un corte de red).
    """
    workers = config.IMAGE_DOWNLOAD_WORKERS if workers is None else workers
    dest_dir.mkdir(parents=True, exist_ok=True)

    def one(idx_url):
        idx, url = idx_url
        if not _is_allowed_image_host(url):
            logger.warning(f"Host de imagen no permitido, se omite: {urlparse(url).hostname}")
            return None
        dest = dest_dir / f"foto_{idx}.jpg"
        try:
            return str(retry_with_backoff(lambda: fetch(url, dest), sleep=sleep))
        except Exception as e:
            logger.warning(f"No se pudo descargar {dest.name}: {e}")
            if errors is not None:
                errors.append(str(e))
            return None

    items = list(enumerate(urls, 1))
    if workers <= 1 or len(items) <= 1:
        return [one(it) for it in items]
    with ThreadPoolExecutor(max_workers=min(workers, len(items))) as pool:
        return list(pool.map(one, items))


def backlog_summary(routes: List[Dict], top: int = 5) -> Dict:
    """Faltantes de la pasada: total, por ciudad y los repartidores más atrasados."""
    by_station: Dict[str, int] = {}
    drivers = []
    for r in routes:
        n = len(r["pending"]) if "pending" in r else max(0, r.get("estimate") or 0)
        name = config.GOFO_STATION_NAMES.get(r["station_id"], str(r["station_id"]))
        by_station[name] = by_station.get(name, 0) + n
        if n:
            drivers.append({"driver": r["courier"].get("driverName") or "?", "station": name, "pending": n})
    drivers.sort(key=lambda d: -d["pending"])
    return {"total": sum(by_station.values()), "by_station": by_station, "top": drivers[:top]}



def _pending_share(courier: Dict, pending: Optional[int]) -> float:
    """12/10: parte de las entregas del repartidor que falta revisar (1 = no se vio nada). Sin dato de entregas: 1."""
    try:
        delivered = int(courier.get("podPieces") or 0)
    except (TypeError, ValueError):
        delivered = 0
    if pending is None:
        return 1.0
    if delivered <= 0:
        return 1.0 if pending > 0 else 0.0
    return max(0.0, min(1.0, pending / delivered))

class ApiPODExtractor:
    """Convierte la API del portal en PODRecords listos para validar y guardar."""

    def __init__(
        self,
        api: PortalAPI,
        images_dir: Path = None,
        tracker: Optional[ThroughputTracker] = None,
        downloader: Callable[[List[str], Path], List[Optional[str]]] = download_images_parallel,
        on_backlog: Optional[Callable[[Dict], None]] = None,
    ):
        self.api = api
        self.images_dir = images_dir or config.POD_IMAGES_DIR
        self.tracker = tracker or ThroughputTracker()
        self.downloader = downloader
        self.on_backlog = on_backlog  # Recibe backlog_summary() tras listar y tras cada bloque
        # IDs (userId) y nombres normalizados (minúsculas, espacios simples) de los repartidores a revisar primero
        self.priority_drivers: Set[str] = set()
        # driver_id -> albaranes ya guardados hoy (para estimar faltantes sin listar la ruta). Lo asigna la corrida.
        self.reviewed_counts: Optional[Callable[[], Dict[str, int]]] = None
        # (estación, repartidor) -> cuándo se listó su ruta (monotonic). La corrida lo conserva entre pasadas.
        self.route_cache: Dict = {}
        self.route_lists: Dict = {}
        self._unlisted: List = []
        # 29/10: con la ciudad compartida, lo que queda del turno de esa ciudad (lo da el portal); None = CITY_TURN_S
        self.turn_s: Optional[float] = None
        # 29/10: con UNA sola ciudad y sin sesion compartida no hay a donde rotar: la pasada no se corta por turno
        self.rotate = True
        # 29/10: albaranes que tiene otra corrida (negados por el reparto), por repartidor. Cuentan como vistos para
        # elegir repartidor; si no, la corrida que llega despues vuelve siempre a los mismos (caso Tracking en DFW02)
        self._taken: Dict[str, Set[str]] = {}
        # 29/10: con el portal nuevo. claim_some_fn(candidatos, hechos, n) -> (concedidos, tomados); done_elsewhere = revisados
        # hoy por cualquier corrida; route_claim_fn(ciudad, repartidores, n) -> (concedidos, de otra corrida)
        self.claim_some_fn = None
        self.done_elsewhere: Set[str] = set()
        self.route_claim_fn = None
        self.route_release_fn = None
        self.sample_pct: Optional[int] = None   # Muestreo del día para los sin prioridad (None = revisar todo)
        # 11/10: panel de rutas de la página local. on_couriers(estación, repartidores) tras cada resumen y
        # on_exception(estación, repartidor, albarán crudo) por cada albarán de una ruta listada. Nunca frenan la corrida.
        self.on_couriers: Optional[Callable[[str, List[Dict]], None]] = None
        self.on_exception: Optional[Callable[[str, Dict, Dict], None]] = None
        # 15/10: control de paquetes. on_route_listed(estación, repartidor, albaranes) con TODOS los albaranes de la
        # ruta (entregados o no), para revisar después su historial de escaneos. Nunca frena la corrida.
        self.on_route_listed: Optional[Callable[[str, Dict, List[WaybillSummary]], None]] = None
        # 25/10: reparto del trabajo con otra corrida (PC + GPU en la nube). claim_fn(albaranes, ya_hechos) devuelve los que le
        # tocan a ESTA corrida; el resto lo toma la otra. Sin claim_fn se revisa todo (como siempre).
        self.claim_fn: Optional[Callable[[List[str], List[str]], Iterable[str]]] = None
        self._denied: Dict[str, float] = {}     # albarán -> cuándo se lo quedó la otra corrida (monotonic)
        self._claim_done: List[str] = []        # revisados aquí, aún sin avisar al repartidor del trabajo
        self.defer_claim_done = False  # En main se confirma tras guardar el score, no tras descargar.
        self.reservation_info = None
        # 26/10: verificación cruzada: se llama entre bloques (en el hilo principal) para analizar lo que marcó la otra corrida
        self.verify_fn: Optional[Callable[[], None]] = None
        # 25/10: descargar las fotos de un albarán en segundo plano mientras se pide el detalle del siguiente (0 = como antes)
        self.prefetch: int = config.EXTRACT_PREFETCH
        self.stage_s: Dict[str, float] = {}
        self._stage_lock = threading.Lock()
        # 30/10: detalles pedidos por lote (GOFO_DETAIL_CONCURRENCY > 1): signId -> detalle, hasta que se procesa el albarán
        self.detail_concurrency: int = config.GOFO_DETAIL_CONCURRENCY
        self._infos: Dict[str, Dict] = {}
        self._brake_until = 0.0

    def _claim(self, trackings: List[str]) -> Set[str]:
        """Los albaranes que le tocan a esta corrida. Si el portal no responde se revisan todos (mejor repetir que parar)."""
        done = list(self._claim_done)
        self._claim_done.clear()   # En el mismo lugar: la corrida conserva esta lista entre pasadas
        try:
            granted = set(self.claim_fn(trackings, done))
            for taken in self._taken.values():
                taken.difference_update(granted)
            return granted
        except Exception as e:
            self._claim_done.extend(done)
            # 28/10: con el reparto en pausa este aviso salía en cada bloque de 5
            from automation.session_guard import log_throttled
            log_throttled('claim-down', f"Reparto del trabajo: sin respuesta del portal ({e}); se revisan todos", every_s=300)
            return set(trackings)

    def _claim_some(self, trackings: List[str], n: int):
        """29/10: (concedidos, tomados por otra) en un pedido; None si falla (se usa el pedido anterior)."""
        done = list(self._claim_done)
        self._claim_done.clear()
        try:
            granted, taken = self.claim_some_fn(trackings, done, n)
        except Exception as e:
            self._claim_done.extend(done)
            from automation.session_guard import log_throttled
            log_throttled('claim-some-down', f"Reparto del trabajo: sin respuesta del portal ({e}); se usa el pedido anterior",
                          every_s=300)
            return None
        granted = set(granted)
        for held in self._taken.values():
            held.difference_update(granted)
        return granted, set(taken)

    @staticmethod
    def _drop(route: Dict, item) -> None:
        pending = route["pending"]
        for i, x in enumerate(pending):
            if x is item:
                del pending[i]
                return

    def _next_block(self, route: Dict, n: int):
        """
        Los proximos albaranes (hasta n) de la ruta que le tocan a esta corrida. Lo que ya hizo o tiene otra sale de la ruta.
        None = nada concedido ni descartado (no insistir en esta ruta en este turno).
        """
        pending = route["pending"]
        if not self.claim_fn:
            return pending[:n]
        granted = taken = None
        cands = pending[:config.CLAIM_CANDIDATES]
        if self.claim_some_fn:
            result = self._claim_some([w.waybill_no for w, _ in cands], n)
            if result is not None:
                granted, taken = result
        if granted is None:
            cands = pending[:n]
            granted = self._claim([w.waybill_no for w, _ in cands])
            taken = {w.waybill_no for w, _ in cands} - granted
        removed = False
        driver = str(route["courier"].get("userId") or "")
        for item in list(cands):
            if item[0].waybill_no in taken:
                self._states['not_granted'].add(item[0].waybill_no)
                self._drop(route, item)
                self._denied[item[0].waybill_no] = time.monotonic()
                self._taken.setdefault(driver, set()).add(item[0].waybill_no)
                removed = True
        block = [item for item in cands if item[0].waybill_no in granted][:n]
        if not block and not removed:
            return None
        return block

    @staticmethod
    def _driver_key(courier: Dict) -> str:
        return str(courier.get("userId") or courier.get("driverName") or "")[:80]

    def _can_hold_more(self, routes: List[Dict]) -> bool:
        """29/10: con reparto por repartidor, pocas rutas a la vez: las demas quedan libres para las otras corridas."""
        if not self.route_claim_fn:
            return True
        return sum(1 for r in routes if r.get("held") and r["pending"]) < config.ROUTE_HOLD_MAX

    def _pick_route(self, to_list: List, i: int):
        """
        29/10: la proxima ruta a listar que el portal le da a esta corrida (preferida: to_list[i]). Las que tiene otra corrida
        salen de la lista de esta pasada. Devuelve (entrada, reservada) o None si no quedo ninguna libre entre las consultadas.
        """
        if not self.route_claim_fn:
            return to_list.pop(i), False
        order = [to_list[i]] + to_list[:i] + to_list[i + 1:]
        station = order[0][0]
        cands = [e for e in order if e[0] == station][:50]
        keys = [self._driver_key(e[1]) for e in cands]
        try:
            granted, held = self.route_claim_fn(config.GOFO_STATION_NAMES.get(station, str(station)), keys, 1)
        except Exception as e:
            from automation.session_guard import log_throttled
            log_throttled('route-claim-down', f"Reparto por repartidor: sin respuesta del portal ({e}); se sigue sin el",
                          every_s=300)
            return to_list.pop(i), False
        granted, held = set(granted), set(held)
        if not granted and not held:
            return to_list.pop(i), False   # Respuesta vacia: no frenar la corrida
        pick = None
        for entry, key in zip(cands, keys):
            if key in held:
                self._states['route_held'].add(key)
                to_list[:] = [e for e in to_list if e is not entry]
            elif pick is None and key in granted:
                pick = entry
        if pick is None:
            return None
        to_list[:] = [e for e in to_list if e is not pick]
        return pick, True

    def _denied_recently(self, tracking: str) -> bool:
        t = self._denied.get(tracking)
        return t is not None and time.monotonic() - t < config.CLAIM_DENY_TTL_S

    def build_record(self, courier: Dict, w: WaybillSummary, date_iso: str) -> PODRecord:
        return self._assemble(courier, w, date_iso, *self._fetch_info(courier, w, date_iso))

    def _tick(self, stage: str, seconds: float) -> None:
        """Tiempo acumulado por etapa (detalle del POD / descarga de fotos): se guarda cada 20 albaranes para ver el cuello de botella."""
        with self._stage_lock:
            self.stage_s[stage] = self.stage_s.get(stage, 0.0) + seconds
            if stage == "descarga":
                self.stage_s["n"] = self.stage_s.get("n", 0) + 1
                if self.stage_s["n"] % 20 == 0:
                    try:
                        import json
                        n = self.stage_s["n"]
                        # 30/10: también listado de rutas, reparto con el portal y espera a la cola de análisis (para ver
                        # el cuello de botella sin adivinar)
                        data = {"albaranes": n, "prefetch": self.prefetch, "detalles_a_la_vez": self.detail_concurrency}
                        data.update({f"{k}_s_por_albaran": round(v / n, 2) for k, v in self.stage_s.items() if k != "n"})
                        (config.STORAGE_DIR / "etapas_extraccion.json").write_text(json.dumps(data), encoding="utf-8")
                        if n % 100 == 0:
                            logger.info("Etapas de extracción por albarán: " + ", ".join(
                                f"{k} {v / n:.2f}s" for k, v in sorted(self.stage_s.items()) if k != "n"))
                    except Exception as e:   # Es solo una medición: nunca frena la corrida
                        logger.debug(f"Etapas de extracción: {e}")

    def _fetch_info(self, courier: Dict, w: WaybillSummary, date_iso: str):
        """Detalle del POD en la API del portal (usa la página del navegador: SOLO en el hilo principal)."""
        started = time.monotonic()
        try:
            return self._fetch_info_inner(courier, w, date_iso)
        finally:
            self._tick("detalle", time.monotonic() - started)

    def _prefetch_infos(self, block) -> None:
        """
        30/10: pide a GOFO el detalle de todo el bloque a la vez (hasta detail_concurrency en vuelo, una pausa por lote). Lo
        que falle se vuelve a pedir de a uno al procesar el albarán, con sus reintentos. Un lote con fallas o lento frena a
        uno por uno durante GOFO_DETAIL_BRAKE_S. Solo en el hilo principal (usa la página del navegador).
        """
        if self.detail_concurrency <= 1 or not hasattr(self.api, "get_sign_infos") or time.monotonic() < self._brake_until:
            return
        ids = list(dict.fromkeys(w.sign_id for w, _ in block if w.sign_id and w.sign_id not in self._infos))
        if len(ids) < 2:
            return
        if len(self._infos) > 500:   # Detalles de bloques cortados (max_records): no crecer sin límite
            self._infos.clear()
        started = time.monotonic()
        try:
            got = self.api.get_sign_infos(ids, self.detail_concurrency)
        except (SessionExpiredError, SessionCoordinationError):
            raise
        except Exception as e:
            got = {i: e for i in ids}
        elapsed = time.monotonic() - started
        self._tick("detalle", elapsed)
        failed = {i: e for i, e in got.items() if isinstance(e, Exception)}
        for i, info in got.items():
            if i not in failed:
                self._infos[i] = info
        # «Sin permiso» es la ciudad activa (lo resuelve el pedido de a uno), no GOFO limitando: no frena
        limited = [e for e in failed.values() if "permiso" not in str(e).lower()]
        if limited or elapsed / len(ids) > config.GOFO_DETAIL_SLOW_S:
            self._brake_until = time.monotonic() + config.GOFO_DETAIL_BRAKE_S
            from automation.session_guard import log_throttled
            why = f"{len(limited)} de {len(ids)} fallaron ({limited[0]})" if limited else f"{elapsed:.0f} s para {len(ids)}"
            log_throttled('detail-brake', f"Detalles a la vez: {why}; uno por uno durante {config.GOFO_DETAIL_BRAKE_S:.0f} s",
                          every_s=60)

    def _fetch_info_inner(self, courier: Dict, w: WaybillSummary, date_iso: str):
        info = self._infos.pop(w.sign_id, None) if w.sign_id else None
        try:
            if info is None:
                info = self.api.get_sign_info(w.sign_id)
        except Exception as e:
            # 03/10: la ciudad activa de la cuenta cambió a mitad de la corrida (otra pestaña del portal) y el detalle
            # respondía "no tiene permiso" (36 albaranes de Noel Torres Legra perdidos). Se vuelve a la ciudad del
            # repartidor y se reintenta una vez.
            station = getattr(self.api, "current_station", None)
            if "permiso" not in str(e).lower() or station is None or not hasattr(self.api, "switch_station"):
                raise
            # 29/10: en modo sin portal no se pelea la ciudad con otra corrida: la PC se detiene
            guard = getattr(self.api, "session_guard", None)
            if guard is not None and guard.foreign_switch(f"sin permiso para {w.waybill_no}"):
                raise SessionCoordinationError(guard.error) from e
            logger.warning(f"Sin permiso para {w.waybill_no}: vuelvo a cambiar a la estación {station} y reintento")
            self.api.switch_station(station)
            info = self.api.get_sign_info(w.sign_id)
        sign_id = w.sign_id
        list_clock, info_clock = pod_clock(w.pod_time), pod_clock(info.get("signTime") or "")
        if list_clock and info_clock and list_clock != info_clock and hasattr(self.api, "latest_sign_id"):
            # POD rehecho: la lista trae el signId del primero pero la hora del último (caso real 04/10: 3 fotos en
            # vez de 4). Se toma el POD más reciente, el que muestra el portal como "Última".
            latest = self.api.latest_sign_id(w.waybill_no)
            if latest and latest != w.sign_id:
                logger.info(f"{w.waybill_no}: POD rehecho ({info_clock} -> {list_clock}), se usa el último")
                sign_id, info = latest, self.api.get_sign_info(latest)
        # dict.fromkeys: deduplica conservando el orden (el carrusel del portal repite fotos)
        urls = list(dict.fromkeys(info.get("imageList") or w.thumbnail_urls))
        return info, sign_id, urls

    def _assemble(self, courier: Dict, w: WaybillSummary, date_iso: str, info: Dict, sign_id, urls: List[str]) -> PODRecord:
        """Descarga las fotos y arma el albarán. No toca el navegador: puede correr en un hilo aparte."""
        download_errors: List[str] = []
        started = time.monotonic()
        try:
            results = self.downloader(urls, self.images_dir / date_iso / w.waybill_no, errors=download_errors)
        except TypeError:   # Descargadores de prueba sin el parámetro errors
            results = self.downloader(urls, self.images_dir / date_iso / w.waybill_no)
        self._tick("descarga", time.monotonic() - started)
        paths = [p for p in results if p]
        address = (info.get("toAddress") or "").strip()

        pod = PODRecord(
            tracking_number=w.waybill_no,
            stop_number=w.stop_index or None,
            driver_name=info.get("courierName") or courier.get("driverName") or "Desconocido",
            station=info.get("delivery") or courier.get("siteName") or "",
            address=address or f"{w.to_street} {w.post_code}".strip(),
            receipt_address=address or None,
            delivery_status="Entregado",
            delivery_datetime=info.get("signTime") or w.pod_time,
            signature_datetime=info.get("signTime"),
            signed_by=info.get("courierName"),  # En el portal "Entregado" = conductor que entregó
            billing_type=info.get("signTypeName"),
            delivery_type=info.get("signTypeName") or "Estándar",
            non_compliance_reason=info.get("reasonNoCompliance") or info.get("dspReasonNoCompliance"),
            photo_urls=urls,
            photo_paths=paths,
            processing_status=ProcessingStatusEnum.PROCESSED,
            portal_meta={
                "sign_id": sign_id,
                "station_id": getattr(self.api,'current_station',None),
                "station_date": date_iso,
                "sign_distance": w.sign_distance,
                "pod_lat": w.pod_lat,
                "pod_lng": w.pod_lng,
                "pod_compliance": info.get("podCompliance", w.pod_compliance),
                "false_signature": info.get("falseSignature"),
                "whether_reported": info.get("whetherReported"),
                "package_received": info.get("packageReceivedFlagName"),
                "portal_status": w.status_signature,
                "driver_id": str(courier.get("userId") or ""),
                "courier_list_name": courier.get("driverName"),
                "photos_expected": len(urls),
                "photos_downloaded": len(paths),
            },
        )
        if len(paths) < len(urls):
            # 22/10: con el motivo, para que un corte de red (DNS, tiempo agotado) se reintente en la pasada siguiente
            # (caso GFUS01078769112322: 1 de 5 fotos guardada y el albarán quedaba "Media, solo 1 foto")
            why = f" ({download_errors[0]})" if download_errors else ""
            pod.error_message = f"{len(urls) - len(paths)} de {len(urls)} fotos no se pudieron descargar{why}"
        return pod

    def run_pass(
        self,
        station_ids: Iterable[int],
        date_iso: str,
        processed,
        on_record: Callable[[PODRecord], None],
        max_records: Optional[int] = None,
        on_status_change: Optional[Callable[[str, Optional[str], str], None]] = None,
        on_route: Optional[Callable[[int, Dict, Dict], None]] = None,
        should_review: Optional[Callable[[Dict], bool]] = None,
    ) -> int:
        """
        Una pasada completa. La clave de "ya procesado" es SIEMPRE el tracking (nunca la parada:
        los conductores entregan fuera de orden). Por conductor: paradas con POD - ya procesadas.

        processed: set de trackings, o dict tracking -> firma de estado del portal. Con dict,
        un albarán ya procesado cuya firma cambió (ej. pasó a Anulado o se rehizo el POD) se
        informa a on_status_change y, si todavía tiene POD, se vuelve a extraer y puntuar.
        on_route(station_id, courier, stats) recibe el avance de cada ruta en esta pasada.
        Devuelve cuántos albaranes se procesaron (nuevos + re-revisados).
        """
        known = processed if isinstance(processed, dict) else {t: None for t in processed}
        count = 0
        cap = config.MAX_PER_DRIVER_PER_PASS
        self.capped = False   # True si quedaron albaranes para la próxima pasada (corte por tiempo o max_records)
        self._states = {name: set() for name in ('not_granted','without_pod','sampled_out','already_reviewed','route_held')}
        self._excluded_estimate = 0
        station_ids = list(station_ids)
        self._scope_stations = [config.GOFO_STATION_NAMES.get(s,str(s)) for s in station_ids]

        # 1) Repartidores de todas las ciudades (1 llamada por ciudad). Su resumen trae cuántas entregas tienen POD
        # (podPieces): menos lo ya revisado en la base = faltantes ESTIMADOS, sin listar la ruta (cada ruta son ~4
        # llamadas de ~10 s). 07/10: listar las ~100 rutas costaba ~80 min por pasada.
        reviewed = dict(self.reviewed_counts() if self.reviewed_counts else {})
        for driver, taken in self._taken.items():
            reviewed[driver] = reviewed.get(driver, 0) + len(taken)
        to_list, up_to_date = [], []
        for station_id in station_ids:
            couriers = self.api.list_couriers(station_id, date_iso)
            if self.on_couriers:
                try:
                    self.on_couriers(config.GOFO_STATION_NAMES.get(station_id, ""), couriers)
                except Exception as e:
                    logger.warning(f"Panel de rutas: no se guardó el resumen ({e})")
            for c in couriers:
                # Ciudad donde aparece la ruta HOY (los repartidores se cambian entre DFW y DFW02; caso real 02/10:
                # María de los Ángeles registrada en una y entregando en la otra)
                c.setdefault("_listed_station", config.GOFO_STATION_NAMES.get(station_id, ""))
            for c in couriers:
                if should_review and not should_review(c):
                    try:
                        self._excluded_estimate += max(0,int(c.get('podPieces') or 0))
                    except (TypeError,ValueError):
                        pass
                    continue   # Excluidos: ni se piden sus paradas
                est = self._estimated_pending(c, reviewed)
                key = (station_id, str(c.get("userId") or c.get("driverName")))
                recent = time.monotonic() - self.route_cache.get(key, -1e9) < config.FULL_RELIST_MIN * 60
                if est is not None and est <= 0 and recent:
                    # Al día y listada hace poco: no se vuelve a pedir (el avance sale del resumen)
                    if on_route:
                        on_route(station_id, c, {"listed": c.get("checkOutPieces") or 0, "with_pod": c.get("podPieces")})
                    continue
                (up_to_date if est is not None and est <= 0 else to_list).append((station_id, c, est))
        # Primero prioridad; después los MENOS revisados en proporción (12/10, pedido del usuario: "que vaya viendo a
        # todos"; 30 de 69 repartidores seguían en 0 a las 19:30 porque iban primero los de más paquetes) y, a igual
        # proporción, los de más faltantes (sin dato: como si faltara todo)
        to_list.sort(key=lambda s: (not self._is_priority(s[1]), -_pending_share(s[1], s[2]),
                                    -(s[2] if s[2] is not None else 10 ** 6)))

        def list_route(station_id, courier):
            self._open_station(station_id)  # Una ciudad a la vez: la lista y el detalle de otra no se abren sin cambiar
            stats = {"listed": 0, "with_pod": 0, "new": 0, "status_changed": 0}
            pending = []
            listed = []
            cache_key = (date_iso, station_id, str(courier.get('userId') or courier.get('driverName')))
            cached = self.route_lists.get(cache_key)
            now = time.monotonic()
            summary = (courier.get('podPieces'), courier.get('checkOutPieces'))
            reusable = (config.ROUTE_LIST_CACHE_S and cached and cached['summary'] == summary
                        and now - cached['at'] < cached['ttl'])
            source = cached['rows'] if reusable else self.api.iter_waybills(
                station_id, date_iso, courier, page_size=config.API_PAGE_SIZE)
            for w in source:
                listed.append(w)
                if not w.sign_id:
                    self._states['without_pod'].add(w.waybill_no)
                if self.claim_fn and self._denied_recently(w.waybill_no):
                    self._states['not_granted'].add(w.waybill_no)
                    stats["listed"] += 1
                    stats["with_pod"] += bool(w.sign_id)
                    continue   # Lo tiene la otra corrida (se vuelve a mirar al vencer su reserva)
                if w.waybill_no in self.done_elsewhere and w.waybill_no not in known:
                    # 29/10: ya lo reviso otra corrida (o esta misma antes de relanzarse): ni se pide ni cuenta como pendiente
                    self._states['already_reviewed'].add(w.waybill_no)
                    self._taken.setdefault(str(courier.get("userId") or ""), set()).add(w.waybill_no)
                    stats["listed"] += 1
                    stats["with_pod"] += bool(w.sign_id)
                    continue
                stats["listed"] += 1
                stats["with_pod"] += bool(w.sign_id)
                if not reusable and self.on_exception and (w.raw.get("deliveryIssueName") or w.raw.get("deliveryIssueRemark")):
                    try:
                        self.on_exception(config.GOFO_STATION_NAMES.get(station_id, ""), courier, w.raw)
                    except Exception as e:
                        logger.warning(f"Panel de rutas: no se guardó la excepción de {w.waybill_no} ({e})")
                status_change = None
                if w.waybill_no in known:
                    old = known[w.waybill_no]
                    if same_status(old, w.status_signature):
                        self._states['already_reviewed'].add(w.waybill_no)
                        continue  # Ya revisado y sin cambios
                    status_change = {"from": old, "to": w.status_signature}
                    stats["status_changed"] += 1
                    known[w.waybill_no] = w.status_signature
                    if on_status_change:
                        on_status_change(w.waybill_no, old, w.status_signature)
                    if not w.sign_id:
                        continue  # Ya no tiene POD (ej. anulado): queda marcado, no hay fotos nuevas
                elif not w.sign_id:
                    continue  # Todavía no entregado: se verá en una pasada siguiente
                elif not self._in_sample(courier, w):
                    self._states['sampled_out'].add(w.waybill_no)
                    stats["sampled_out"] = stats.get("sampled_out", 0) + 1
                    continue  # Muestreo del día: este no toca (se decide igual en cada pasada y tras un reinicio)
                pending.append((w, status_change))
            if config.ROUTE_START_FRACTION and len(pending) > 1:
                # 29/10: cada corrida empieza en otro punto de la ruta (PC al principio, Kaggle Luis a un tercio, Tracking a dos
                # tercios): antes las tres empezaban por la primera parada y chocaban siempre ahi
                k = int(len(pending) * config.ROUTE_START_FRACTION)
                pending = pending[k:] + pending[:k]
            if config.ROUTE_LIST_CACHE_S and not reusable:
                ttl = config.ROUTE_LIST_CACHE_S if any(w.sign_id for w in listed) else config.EMPTY_ROUTE_CACHE_S
                self.route_lists[cache_key] = dict(at=now, ttl=ttl, summary=summary, rows=listed)
                # Límite de memoria; al vencer se vuelve a consultar, nunca se marca un POD como revisado.
                if len(self.route_lists) > 256:
                    oldest = min(self.route_lists, key=lambda k: self.route_lists[k]['at'])
                    self.route_lists.pop(oldest, None)
            if self.on_route_listed and not reusable:
                try:
                    self.on_route_listed(config.GOFO_STATION_NAMES.get(station_id, ""), courier, listed)
                except Exception as e:
                    logger.warning(f"Control de paquetes: no se guardó la ruta de {courier.get('driverName')} ({e})")
            # 06/10: el conteo de entregados es el de la lista completa (antes se cortaba en el tope de 30 y
            # parecía que DFW-BAA estaba al día)
            if on_route:
                on_route(station_id, courier, stats)
            self.route_cache[(station_id, str(courier.get("userId") or courier.get("driverName")))] = time.monotonic()
            routes.append({"station_id": station_id, "courier": courier, "stats": stats, "pending": pending})

        # 2) Intercalado: listar una ruta (la de más faltantes estimados) y procesar un bloque del MÁS ATRASADO de las
        # ya listadas: la revisión empieza en minutos y nadie queda sin listar por horas. Las rutas al día se relistan
        # (por cambios de estado) solo cuando no queda nada más que hacer. Un reinicio no vuelve al primero de la
        # lista: el atraso sale de la base. Terminada la lista, cada PASS_REFRESH_MIN se corta la pasada para pedir
        # de nuevo los resúmenes y sumar lo entregado mientras tanto.
        routes = []
        self._unlisted = to_list
        started = time.monotonic()
        while True:
            turn = self.turn_s if self.turn_s is not None else config.CITY_TURN_S
            if (self.rotate and (config.CITY_DISPATCH_DB or config.GOFO_SESSION_GROUP)
                    and routes and time.monotonic()-started >= turn):
                self.capped = bool(to_list) or any(r['pending'] for r in routes)
                self._report_backlog(routes)
                break
            # 12/10: varias rutas por bloque (antes 1: con bloques de ~4 min, listar 69 rutas llevaba más de 4 h y cada
            # reinicio volvía a empezar por las mismas)
            for _ in range(max(1, config.ROUTES_PER_BLOCK)):
                if not to_list or not self._can_hold_more(routes):
                    break
                # Mismo grupo (prioridad o no): preferir una ruta de la ciudad abierta, para no cambiar a cada rato
                current = getattr(self.api, "current_station", None)
                first_prio = self._is_priority(to_list[0][1])
                tier = [i for i, s in enumerate(to_list[:5]) if self._is_priority(s[1]) == first_prio]
                i = next((i for i in tier if to_list[i][0] == current), 0)
                picked = self._pick_route(to_list, i)
                if picked is None:
                    continue   # Las consultadas las tiene otra corrida: salieron de la lista
                (station_id, courier, _est), held = picked
                listing = time.monotonic()
                list_route(station_id, courier)
                self._tick("listado", time.monotonic() - listing)
                if held and routes and routes[-1]["courier"] is courier:
                    routes[-1]["held"] = True
                self._report_backlog(routes)
            # 12/10 (pedido del usuario: "de 30 en 30 de cada repartidor, que no se quede ninguno sin ver"): turno
            # estricto. Si todos los listados ya tuvieron su bloque en esta pasada y quedan rutas sin listar, primero
            # se listan más: nadie recibe un 2.º bloque mientras otro no tuvo el 1.º
            if to_list and self._can_hold_more(routes) and all(r.get("blocks", 0) > 0 for r in routes if r["pending"]):
                continue
            route = self._most_behind(routes)
            if route is None:
                # 22/10 (pedido del usuario): al día con lo listado, cada AL_DIA_REFRESH_MIN se corta la pasada y se
                # vuelve a pedir el resumen completo, en vez de seguir listando rutas con el resumen viejo (con 130
                # revisados al día, GOFO ya marcaba más de 200 entregados)
                if config.AL_DIA_REFRESH_MIN and time.monotonic() - started >= config.AL_DIA_REFRESH_MIN * 60:
                    break
                if to_list:
                    continue
                if up_to_date:
                    to_list, up_to_date = up_to_date, []   # Nada más que hacer: relistar las que estaban al día
                    self._unlisted = to_list
                    continue
                break
            self._open_station(route["station_id"])
            route["blocks"] = route.get("blocks", 0) + 1
            # 28/10: con reparto, el turno de la ruta (hasta `cap`) se reserva y procesa de a CLAIM_BATCH_SIZE seguidos.
            # 29/10: lo que ya hizo o tiene otra corrida no gasta el turno: se sigue con lo que queda de la misma ruta, en vez
            # de listar otra (Tracking en DFW02: 3 concedidos y 299 negados)
            budget = min(cap, len(route["pending"])) if cap else len(route["pending"])
            step = config.CLAIM_BATCH_SIZE if self.claim_fn else max(1, budget)
            used = 0
            while route["pending"] and used < budget:
                claiming = time.monotonic()
                block = self._next_block(route, min(step, budget - used))
                self._tick("reparto", time.monotonic() - claiming)
                if block is None:
                    break
                used += len(block)
                self._prefetch_infos(block)

                def finalize(pod, w, status_change):
                    nonlocal count
                    if status_change:
                        pod.portal_meta["status_change"] = status_change
                    else:
                        route["stats"]["new"] += 1
                    if isinstance(processed, dict):
                        processed[w.waybill_no] = w.status_signature
                    else:
                        processed.add(w.waybill_no)
                    handing = time.monotonic()
                    on_record(pod)
                    self._tick("entrega_al_analisis", time.monotonic() - handing)
                    # 26/10: un albarán que falló por un corte de red (o quedó con fotos de menos) NO se avisa como hecho: se reintenta en
                    # una pasada siguiente, y si el portal lo diera por revisado ninguna corrida volvería a pedirlo
                    if self.claim_fn and not self.defer_claim_done and not needs_retry(str(pod.processing_status), pod.error_message):
                        self._claim_done.append(w.waybill_no)
                    count += 1

                if self.prefetch and len(block) > 1:
                    # Detalle en el hilo principal, descargas de fotos en hilos aparte (hasta `prefetch` albaranes en vuelo)
                    from collections import deque
                    flight = deque()
                    with ThreadPoolExecutor(max_workers=self.prefetch) as pool:
                        for item in block:
                            w, status_change = item
                            if max_records and count + len(flight) >= max_records:
                                break
                            self._drop(route, item)
                            fut, pod_started = self._process_async(route["courier"], w, date_iso, pool)
                            flight.append((fut, pod_started, w, status_change))
                            while len(flight) >= self.prefetch:
                                fut, pod_started, fw, fsc = flight.popleft()
                                finalize(self._finish_async(fut, pod_started, fw), fw, fsc)
                        while flight:
                            fut, pod_started, fw, fsc = flight.popleft()
                            finalize(self._finish_async(fut, pod_started, fw), fw, fsc)
                    if max_records and count >= max_records:
                        self.capped = bool(to_list) or any(r["pending"] for r in routes)
                        self._report_backlog(routes)
                        return count
                    block = []
                for item in block:
                    w, status_change = item
                    self._drop(route, item)
                    pod = self._process(route["courier"], w, date_iso)
                    finalize(pod, w, status_change)
                    if max_records and count >= max_records:
                        self.capped = bool(to_list) or any(r["pending"] for r in routes)
                        self._report_backlog(routes)
                        return count
            if route.get("held") and not route["pending"] and self.route_release_fn:
                # 29/10: ruta terminada: se suelta ya para que otra corrida la pueda tomar cuando entregue más
                route["held"] = False
                self.route_release_fn(config.GOFO_STATION_NAMES.get(route["station_id"], str(route["station_id"])),
                                      self._driver_key(route["courier"]))
            self._report_backlog(routes)
            if self.verify_fn:
                try:
                    self.verify_fn()
                except Exception as e:   # La verificación nunca frena la corrida
                    logger.warning(f"Verificación cruzada: {type(e).__name__}: {e}")
            if (config.PASS_REFRESH_MIN and not to_list and time.monotonic() - started >= config.PASS_REFRESH_MIN * 60
                    and any(r["pending"] for r in routes)):
                self.capped = True   # Seguir sin esperar: la próxima pasada vuelve a listar
                break
        return count

    def _estimated_pending(self, courier: Dict, reviewed: Dict[str, int]) -> Optional[int]:
        """Entregas con POD (resumen del portal) menos las ya revisadas de ese repartidor; None si no hay dato."""
        try:
            pod = int(courier.get("podPieces"))
        except (TypeError, ValueError):
            return None
        if self.sample_pct and not self._is_priority(courier):
            pod = round(pod * self.sample_pct / 100)   # Con muestreo, solo esa parte le toca
        return pod - reviewed.get(str(courier.get("userId") or ""), 0)

    def _in_sample(self, courier: Dict, w: WaybillSummary) -> bool:
        """
        07/10 (solo el día que pide el usuario): a los repartidores sin prioridad se les revisa un % al azar, fijo por
        tracking (el mismo en cada pasada y tras un reinicio). Siempre entran los de prioridad y los POD tomados lejos
        de la dirección (señal de riesgo que trae la lista del portal, sin abrir el detalle).
        """
        if not self.sample_pct or self._is_priority(courier):
            return True
        try:
            far = float(re.sub(r"[^0-9.]", "", str(w.sign_distance or "")) or 0) > config.GPS_DISTANCE_SCORES[0][0]
        except (ValueError, IndexError):
            far = False
        if far:
            return True
        return int(hashlib.md5(w.waybill_no.encode()).hexdigest()[:8], 16) % 100 < self.sample_pct

    def _open_station(self, station_id: int) -> None:
        if getattr(self.api, "current_station", None) != station_id and hasattr(self.api, "switch_station"):
            self.api.switch_station(station_id)

    def _most_behind(self, routes: List[Dict]) -> Optional[Dict]:
        """
        El repartidor con más albaranes sin revisar. Para no saltar de ciudad a cada bloque, se sigue en la ciudad
        actual mientras su más atrasado tenga al menos STATION_STAY_RATIO de los pendientes del más atrasado global.
        Empate: el orden en que vino la lista (estable).
        """
        live = [r for r in routes if r["pending"]]
        if not live:
            return None
        # 07/10: los repartidores con más errores reales van primero (entre ellos, el más atrasado)
        first = [r for r in live if self._is_priority(r["courier"])]
        # 09/10: con prioridad, 1 de cada PRIORITY_SHARE_EVERY bloques va al resto: el usuario quiere adelantar a
        # ciertos repartidores "en mayor medida" sin que los demás queden parados horas
        rest = [r for r in live if not self._is_priority(r["courier"])]
        self._blocks = getattr(self, "_blocks", 0) + 1
        every = config.PRIORITY_SHARE_EVERY
        if first and rest and every > 1 and self._blocks % every == 0:
            first = []
            live = rest
        live = first or live
        # 12/10: turno estricto, primero los que tuvieron menos bloques en esta pasada (de 30 en 30 a cada uno)
        fewest = min(r.get("blocks", 0) for r in live)
        live = [r for r in live if r.get("blocks", 0) == fewest]
        # 12/10: el MENOS revisado en proporción (pendientes / entregados), no el de más pendientes: con capacidad para
        # ~1/3 de las entregas del día, ir por el de más paquetes dejaba a 30 repartidores sin ver. A igual proporción,
        # el de más pendientes
        share = lambda r: (_pending_share(r["courier"], len(r["pending"])), len(r["pending"]))
        best = max(live, key=share)
        current = getattr(self.api, "current_station", None)
        here = [r for r in live if r["station_id"] == current]
        if here and best["station_id"] != current:
            best_here = max(here, key=share)
            if share(best_here)[0] >= config.STATION_STAY_RATIO * share(best)[0]:
                return best_here
        return best

    def _is_priority(self, courier: Dict) -> bool:
        if not self.priority_drivers:
            return False
        return (str(courier.get("userId") or "") in self.priority_drivers
                or normalize_name(courier.get("driverName") or "") in self.priority_drivers)

    def _report_backlog(self, routes: List[Dict]) -> None:
        if self.on_backlog:
            # Las rutas que faltan listar suman su estimado (entregados con POD - revisados)
            est = [{"station_id": s, "courier": c, "estimate": e or 0} for s, c, e in self._unlisted]
            states={name:len(values) for name,values in self._states.items()}
            states.update(available_listed=sum(len(r['pending']) for r in routes),
                          unlisted_estimated=sum(r['estimate'] for r in est),
                          excluded_estimated=self._excluded_estimate)
            if self.reservation_info:
                states.update(self.reservation_info())
            self.on_backlog(dict(backlog_summary(routes + est), unlisted=len(self._unlisted),
                                 sample_pct=self.sample_pct,states=states,scope_stations=self._scope_stations))

    def _process_async(self, courier: Dict, w: WaybillSummary, date_iso: str, pool: ThreadPoolExecutor):
        """Detalle ahora (hilo principal) y descarga en el pool: devuelve un futuro con el albarán listo."""
        started = time.monotonic()
        try:
            fetched = self._fetch_info(courier, w, date_iso)
        except (SessionExpiredError, SessionCoordinationError):
            raise
        except Exception as e:
            logger.warning(f"Albarán {w.waybill_no} falló tras reintentos: {e}")
            return pool.submit(lambda: self._failed_pod(courier, w, date_iso, e)), started

        def finish():
            try:
                return self._assemble(courier, w, date_iso, *fetched)
            except (SessionExpiredError, SessionCoordinationError):
                raise
            except Exception as e:
                logger.warning(f"Albarán {w.waybill_no} falló tras reintentos: {e}")
                return self._failed_pod(courier, w, date_iso, e)
        return pool.submit(finish), started

    def _finish_async(self, future, started: float, w: WaybillSummary) -> PODRecord:
        pod = future.result()
        elapsed = time.monotonic() - started
        self.tracker.record(w.waybill_no, elapsed, pod.processing_status.value)
        logger.info(f"Albarán {w.waybill_no} procesado en {elapsed:.2f}s")
        return pod

    def _failed_pod(self, courier: Dict, w: WaybillSummary, date_iso: str, e: Exception) -> PODRecord:
        return PODRecord(
            tracking_number=w.waybill_no,
            stop_number=w.stop_index or None,
            driver_name=courier.get("driverName") or "Desconocido",
            processing_status=ProcessingStatusEnum.FAILED,
            error_message=str(e),
            portal_meta={"sign_id": w.sign_id, "station_date": date_iso,
                         "portal_status": w.status_signature, "driver_id": str(courier.get("userId") or "")},
        )

    def _process(self, courier: Dict, w: WaybillSummary, date_iso: str) -> PODRecord:
        started = time.monotonic()
        try:
            pod = self.build_record(courier, w, date_iso)
        except (SessionExpiredError, SessionCoordinationError):
            raise
        except Exception as e:
            logger.warning(f"Albarán {w.waybill_no} falló tras reintentos: {e}")
            pod = PODRecord(
                tracking_number=w.waybill_no,
                stop_number=w.stop_index or None,
                driver_name=courier.get("driverName") or "Desconocido",
                processing_status=ProcessingStatusEnum.FAILED,
                error_message=str(e),
                portal_meta={"sign_id": w.sign_id, "station_date": date_iso,
                             "portal_status": w.status_signature, "driver_id": str(courier.get("userId") or "")},
            )
        elapsed = time.monotonic() - started
        self.tracker.record(w.waybill_no, elapsed, pod.processing_status.value)
        logger.info(f"Albarán {w.waybill_no} procesado en {elapsed:.2f}s")
        return pod
