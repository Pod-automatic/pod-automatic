"""
Módulo de Autenticación Asistida Interactiva (Zero-Password).

Permite el inicio de sesión manual seguro en el navegador y espera la confirmación
del usuario para certificar el acceso al Dashboard antes de continuar la automatización.
"""

import json
import logging
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

from rich.console import Console
from rich.panel import Panel
from playwright.sync_api import Page, sync_playwright

import config
from config import GOFO_PORTAL_URL
from automation.selectors import Selectors
from automation.browser import BrowserManager, SessionExpiredError

logger = logging.getLogger("PODAutomation.Login")
console = Console()

SESSION_EXPIRED_MESSAGE = (
    "La sesión guardada venció o no es válida. La corrida se detuvo y NO se intenta "
    "iniciar sesión automáticamente. Ejecuta: python main.py login"
)


def looks_logged_out(current_url: str, portal_url: str = GOFO_PORTAL_URL) -> bool:
    """
    True si la URL indica que el portal redirigió a un login: el host ya no es el del portal
    o la URL contiene alguno de config.LOGIN_URL_MARKERS (ej. accounts.google.com, /login).
    """
    url = (current_url or "").lower()
    if not url or url.startswith("about:"):
        return True
    if urlparse(url).hostname != (urlparse(portal_url).hostname or "").lower():
        return True
    return any(marker in url for marker in config.LOGIN_URL_MARKERS)


def find_chrome_executable() -> Optional[str]:
    """Localiza Google Chrome (CHROME_PATH, rutas típicas de Windows o PATH)."""
    candidates = [
        config.CHROME_PATH,
        os.path.expandvars(r"%ProgramFiles%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%LocalAppData%\Google\Chrome\Application\chrome.exe"),
        shutil.which("chrome") or "",
        shutil.which("google-chrome") or "",
        # 22/10: Ubuntu (deploy/ubuntu)
        shutil.which("google-chrome-stable") or "",
        shutil.which("chromium") or "",
        shutil.which("chromium-browser") or "",
    ]
    for c in candidates:
        if c and Path(c).exists():
            return c
    return None


# Solo lo necesario para llevar una sesión web a otro directorio de datos. NO se copian
# contraseñas guardadas (Login Data), historial, caché ni extensiones.
PROFILE_ESSENTIALS = (
    "Network",            # Cookies (Chrome moderno)
    "Cookies",            # Cookies (formato antiguo)
    "Local Storage",
    "Session Storage",
    "IndexedDB",
)
# Preferences / Secure Preferences NO se copian: referencian extensiones que no se copian
# y Chrome muestra "Error al cargar extensión". Chrome crea unas nuevas al abrir.
STALE_PROFILE_FILES = ("Preferences", "Secure Preferences")


def find_profile_dir_for_email(user_data_dir: Path, email: str) -> Optional[str]:
    """Devuelve el nombre de carpeta ('Default', 'Profile 3', ...) del perfil de Chrome con ese correo."""
    try:
        state = json.loads((Path(user_data_dir) / "Local State").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    for folder, info in state.get("profile", {}).get("info_cache", {}).items():
        if (info.get("user_name") or "").strip().lower() == email.strip().lower():
            return folder
    return None


def copy_profile_essentials(src_root: Path, profile_name: str, dest_root: Path) -> None:
    """
    Copia 'Local State' (clave de cifrado de cookies) y los datos web esenciales del perfil
    a dest_root. Chrome debe estar cerrado: si no, sus archivos están bloqueados.
    """
    src_root, dest_root = Path(src_root), Path(dest_root)
    dest_root.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src_root / "Local State", dest_root / "Local State")
    for stale in STALE_PROFILE_FILES:
        (dest_root / profile_name / stale).unlink(missing_ok=True)
    shutil.rmtree(dest_root / profile_name / "Extensions", ignore_errors=True)
    for item in PROFILE_ESSENTIALS:
        src = src_root / profile_name / item
        dest = dest_root / profile_name / item
        if not src.exists():
            continue
        dest.parent.mkdir(parents=True, exist_ok=True)
        if src.is_dir():
            shutil.copytree(src, dest, dirs_exist_ok=True)
        else:
            shutil.copy2(src, dest)


def _wait_for_human_login(context, portal_url: str, timeout_s: int) -> bool:
    """
    Modo desatendido: solo OBSERVA. Espera hasta timeout_s a que alguna pestaña quede en el
    portal (fuera de cualquier login) durante 2 revisiones seguidas. No toca ningún campo.
    """
    deadline = time.monotonic() + timeout_s
    stable = 0
    while time.monotonic() < deadline:
        logged_in = any(not looks_logged_out(p.url, portal_url) for p in context.pages)
        stable = stable + 1 if logged_in else 0
        if stable >= 2:
            return True
        time.sleep(3)
    return False


def run_manual_login(
    portal_url: str = GOFO_PORTAL_URL,
    account: Optional[str] = None,
    wait_seconds: int = 0,
    from_profile: Optional[str] = None,
) -> bool:
    """
    Login manual único (`python main.py login`).

    Abre un Chrome REAL, sin flags de automatización (Google bloquea los navegadores
    automatizados), con un perfil dedicado. El humano completa "Iniciar sesión con Google"
    y el 2FA. Después Playwright se conecta por CDP únicamente para exportar el storage_state
    a SESSION_FILE. No se automatiza ningún paso del login ni se guardan credenciales.

    account:      cuenta de Google con la que el humano debe iniciar sesión (solo se muestra).
    wait_seconds: 0 = espera ENTER en la terminal; >0 (o sin terminal interactiva) = observa
                  la ventana hasta detectar el dashboard, con ese tiempo máximo.
    """
    chrome = find_chrome_executable()
    if not chrome:
        console.print("[bold red]No se encontró Google Chrome. Define CHROME_PATH en .env.[/bold red]")
        return False

    unattended = wait_seconds > 0 or not sys.stdin.isatty()
    if unattended and wait_seconds <= 0:
        wait_seconds = 600

    config.BROWSER_PROFILE_DIR.mkdir(parents=True, exist_ok=True)
    profile_args = []
    if from_profile:
        # Chrome 136+ ignora el puerto de depuración en su carpeta de datos habitual, así que
        # se lleva la sesión web de ese perfil a la carpeta dedicada y se abre desde ahí.
        real_root = Path(config.CHROME_USER_DATA_DIR)
        folder = find_profile_dir_for_email(real_root, from_profile)
        if not folder:
            console.print(f"[bold red]No hay ningún perfil de Chrome con la cuenta {from_profile} en {real_root}.[/bold red]")
            return False
        try:
            copy_profile_essentials(real_root, folder, config.BROWSER_PROFILE_DIR)
        except OSError as e:
            console.print(
                f"[bold red]No se pudo copiar el perfil '{folder}': {e}\n"
                "Cierra TODAS las ventanas de Chrome (también en la bandeja del sistema) y repite.[/bold red]"
            )
            return False
        profile_args = [f"--profile-directory={folder}"]
        console.print(f"[green]Perfil '{folder}' ({from_profile}) copiado (solo cookies, storage y preferencias).[/green]")

    proc = subprocess.Popen([
        chrome,
        f"--remote-debugging-port={config.CDP_PORT}",
        f"--user-data-dir={config.BROWSER_PROFILE_DIR}",
        *profile_args,
        "--no-first-run",
        portal_url,
    ])

    who = f" con la cuenta [bold]{account}[/bold]" if account else ""
    if from_profile:
        who = " (si el portal ya abre logueado, no hace falta nada; si pide login, inicia sesión)"
    finish = (
        f"3. No hace falta hacer nada más: se detectará el dashboard (máx. {wait_seconds}s). NO cierres Chrome."
        if unattended else
        "3. Vuelve aquí y presiona [ENTER]. NO cierres Chrome antes."
    )
    console.print(Panel.fit(
        "[bold yellow]LOGIN MANUAL ÚNICO[/bold yellow]\n\n"
        f"1. En la ventana de Chrome que se abrió, inicia sesión con Google{who} (y 2FA si aplica).\n"
        "2. Espera a ver el dashboard del portal de GOFO.\n" + finish,
        border_style="yellow",
    ))

    if not unattended:
        try:
            input()
        except (EOFError, KeyboardInterrupt):
            console.print("[bold red]Cancelado.[/bold red]")
            proc.terminate()
            return False

    ok = False
    pw = sync_playwright().start()
    try:
        browser = None
        for _ in range(20):  # Chrome tarda unos segundos en abrir el puerto de depuración
            try:
                browser = pw.chromium.connect_over_cdp(f"http://127.0.0.1:{config.CDP_PORT}")
                break
            except Exception:
                time.sleep(1.5)
        if browser is None:
            raise RuntimeError("Chrome no abrió el puerto de depuración.")
        context = browser.contexts[0]

        if unattended and not _wait_for_human_login(context, portal_url, wait_seconds):
            console.print("[bold red]Tiempo agotado sin detectar sesión iniciada. No se guardó nada.[/bold red]")
            return False

        # Validación fresca: una pestaña restaurada puede parecer logueada sin estarlo
        # (SPA con contenido viejo). Solo cuenta lo que responde el servidor a una navegación nueva.
        page = context.new_page()
        page.goto(portal_url, wait_until="domcontentloaded")
        try:
            page.wait_for_load_state("networkidle", timeout=15000)
        except Exception:
            pass

        if looks_logged_out(page.url, portal_url):
            console.print(
                f"[bold red]No se detecta sesión iniciada (URL actual: {page.url}). "
                "No se guardó nada. Completa el login y repite.[/bold red]"
            )
        else:
            config.SESSION_FILE.parent.mkdir(parents=True, exist_ok=True)
            context.storage_state(path=str(config.SESSION_FILE))
            console.print(f"[bold green]✓ Sesión guardada en {config.SESSION_FILE}[/bold green]")
            ok = True
    except Exception as e:
        console.print(f"[bold red]No se pudo exportar la sesión: {e}[/bold red]")
    finally:
        try:
            pw.stop()
        except Exception:
            pass
        proc.terminate()
    return ok


class LoginManager:
    """Administrador de autenticación manual asistida y confirmación de Dashboard."""

    def __init__(self, browser_manager: BrowserManager):
        self.bm = browser_manager
        self.page: Page = browser_manager.page

    def is_dashboard_visible(self) -> bool:
        """Verifica mediante selectores si el Dashboard ya está renderizado en pantalla."""
        if not self.page:
            return False

        current_url = self.page.url.lower()
        if "login" in current_url or "signin" in current_url:
            return False

        # Comprobar indicadores de Dashboard con espera breve
        elem = self.bm.find_element(Selectors.DASHBOARD_INDICATORS, timeout_ms=2000)
        return elem is not None

    def require_valid_session(self, portal_url: str = GOFO_PORTAL_URL) -> None:
        """
        Modo desatendido: navega al portal y verifica que la sesión guardada siga vigente.
        Si el portal redirige a un login lanza SessionExpiredError. NUNCA intenta loguearse.
        """
        try:
            self.page.goto(portal_url, wait_until="domcontentloaded")
            self.page.wait_for_load_state("networkidle", timeout=15000)
        except Exception as e:
            logger.warning(f"Aviso en carga inicial de URL: {e}")

        if looks_logged_out(self.page.url, portal_url):
            self.bm.session_valid = False
            raise SessionExpiredError(SESSION_EXPIRED_MESSAGE)
        self.bm.session_valid = True
        logger.info("Sesión guardada válida.")

    def ensure_authenticated(self, portal_url: str = GOFO_PORTAL_URL) -> bool:
        """
        Garantiza que el operador esté autenticado:
        1. Navega a la URL configurada y aguarda carga de red.
        2. Si ya hay sesión persistente válida, la aprovecha inmediatamente.
        3. Si requiere credenciales, guía al usuario en pantalla y espera su confirmación por terminal.
        """
        logger.info(f"Navegando a portal: {portal_url}...")
        try:
            self.page.goto(portal_url, wait_until="domcontentloaded")
            # Esperar a que los recursos de red se estabilicen
            self.page.wait_for_load_state("networkidle", timeout=15000)
        except Exception as e:
            logger.warning(f"Aviso en carga inicial de URL: {e}")

        # 1. Comprobar si la sesión previa guardada sigue vigente
        if self.is_dashboard_visible():
            console.print("[bold green]✓ Sesión activa y válida detectada en el Dashboard.[/bold green]")
            self.bm.save_session()
            return True

        # 2. Instrucciones para autenticación manual del operador
        console.print(Panel.fit(
            "[bold yellow]INICIO DE SESIÓN MANUAL ASISTIDO[/bold yellow]\n\n"
            "1. La ventana del navegador está visible en su pantalla.\n"
            "2. Ingrese sus credenciales de Gofo Express (y 2FA si aplica).\n"
            "3. Ingrese al Dashboard de DSP.\n\n"
            "[bold cyan]>>> Cuando esté listo en el Dashboard, presione [ENTER] en esta terminal para continuar...[/bold cyan]",
            title="[bold blue]Autenticación Gofo Express DSP[/bold blue]",
            border_style="yellow"
        ))

        # 3. Esperar confirmación explícita del usuario en consola
        while True:
            try:
                input()
            except (EOFError, KeyboardInterrupt):
                console.print("[bold red]Operación cancelada por el usuario.[/bold red]")
                return False

            # Esperar a que desaparezcan posibles spinners de autenticación
            self.bm.wait_for_spinners_to_disappear(timeout_ms=5000)

            # Verificar si ya estamos en Dashboard o si el usuario necesita un momento más
            if self.is_dashboard_visible() or "login" not in self.page.url.lower():
                console.print("[bold green]✓ Confirmación recibida. Acceso a Dashboard verificado.[/bold green]")
                self.bm.save_session()
                return True
            else:
                console.print(
                    "[bold yellow]Aún parece estar en la pantalla de inicio de sesión o cargando.[/bold yellow]\n"
                    "Por favor complete el acceso en el navegador y presione [ENTER] nuevamente..."
                )
