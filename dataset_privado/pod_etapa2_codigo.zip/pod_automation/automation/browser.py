"""
Módulo de Gestión del Ciclo de Vida del Navegador Playwright.

Proporciona inicialización robusta, manejo de contexto persistente (storage_state),
detección de Chrome del sistema con fallback a Chromium, y métodos de sincronización
inteligente de Playwright (cero dependencia de time.sleep).
"""

from typing import Optional, List
from pathlib import Path
import json
import logging
from playwright.sync_api import sync_playwright, Playwright, Browser, BrowserContext, Page, ElementHandle, Locator

import config
from config import (
    HEADLESS,
    BROWSER_TIMEOUT_MS,
    VIEWPORT_WIDTH,
    VIEWPORT_HEIGHT,
    SLOW_MO_MS,
    SESSION_FILE,
    STORAGE_DIR,
)
from automation.selectors import SelectorStrategy, Selectors

logger = logging.getLogger("PODAutomation.Browser")


class SessionExpiredError(RuntimeError):
    """La sesión guardada no existe o venció. Requiere `python main.py login` (login manual)."""


def session_file_has_cookies(path: Path) -> bool:
    """True si el archivo de storage_state existe y contiene al menos una cookie."""
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return False
    return bool(data.get("cookies"))


class BrowserManager:
    """Gestiona el ciclo de vida del navegador con esperas inteligentes y contexto persistente."""

    def __init__(
        self,
        headless: bool = HEADLESS,
        slow_mo: Optional[int] = None,
        slow_mo_ms: Optional[int] = None,
        timeout_ms: int = BROWSER_TIMEOUT_MS,
        prefer_chrome: bool = True,
        user_data_dir: Optional[str] = None,
        profile_dir: Optional[str] = None,
        **kwargs,
    ):
        self.headless = headless
        self.slow_mo_ms = slow_mo if slow_mo is not None else (slow_mo_ms if slow_mo_ms is not None else SLOW_MO_MS)
        self.slow_mo = self.slow_mo_ms
        self.timeout_ms = timeout_ms
        self.prefer_chrome = prefer_chrome
        self.user_data_dir = user_data_dir or config.CHROME_USER_DATA_DIR
        self.profile_dir = profile_dir or config.CHROME_PROFILE_DIR
        self.playwright: Optional[Playwright] = None
        self.browser: Optional[Browser] = None
        self.context: Optional[BrowserContext] = None
        self.page: Optional[Page] = None
        # Solo se re-guarda el storage_state si se verificó que la sesión es válida,
        # para no pisar una sesión buena con una vencida.
        self.session_valid = False

    def start_browser(self, use_saved_session: bool = True) -> Page:
        """Alias para start()."""
        return self.start(use_saved_session=use_saved_session)

    def close_browser(self):
        """Alias para close()."""
        self.close()

    def start(self, use_saved_session: bool = True) -> Page:
        """
        Inicia el navegador según config.AUTH_MODE:
        - 'storage_state' (defecto): Chromium propio que reutiliza SESSION_FILE (sin CDP, apto headless).
        - 'cdp': se conecta a un Chrome abierto a mano con el puerto de depuración.
        """
        if config.AUTH_MODE != "cdp" and not session_file_has_cookies(SESSION_FILE):
            raise SessionExpiredError(
                "No hay una sesión guardada. Ejecuta primero: python main.py login"
            )
        self.playwright = sync_playwright().start()
        try:
            if config.AUTH_MODE == "cdp":
                self._start_cdp()
            else:
                self._start_with_storage_state()
        except Exception:
            self.playwright.stop()
            self.playwright = None
            raise

        self.context.set_default_timeout(self.timeout_ms)
        return self.page

    def _start_cdp(self) -> None:
        logger.info(f"Conectando con Google Chrome vía CDP (puerto {config.CDP_PORT})...")
        try:
            self.browser = self.playwright.chromium.connect_over_cdp(f"http://127.0.0.1:{config.CDP_PORT}")
            self.context = self.browser.contexts[0]
            self.page = self.context.pages[0] if len(self.context.pages) > 0 else self.context.new_page()
        except Exception as e:
            logger.error(f"Error al conectar con Chrome por CDP: {e}")
            raise

    def _start_with_storage_state(self) -> None:
        logger.info(f"Iniciando navegador con la sesión guardada en {SESSION_FILE} (headless={self.headless})")
        launch_kwargs = dict(headless=self.headless, slow_mo=self.slow_mo_ms)
        try:
            self.browser = self.playwright.chromium.launch(channel="chrome", **launch_kwargs)
        except Exception:
            logger.info("Chrome del sistema no disponible; usando Chromium de Playwright.")
            self.browser = self.playwright.chromium.launch(**launch_kwargs)
        self.context = self.browser.new_context(
            storage_state=str(SESSION_FILE),
            viewport={"width": VIEWPORT_WIDTH, "height": VIEWPORT_HEIGHT},
        )
        self.page = self.context.new_page()

    def save_session(self):
        """Guarda cookies y almacenamiento local de la sesión activa."""
        if self.context:
            SESSION_FILE.parent.mkdir(parents=True, exist_ok=True)
            self.context.storage_state(path=str(SESSION_FILE))
            logger.info(f"Estado de sesión guardado con éxito en {SESSION_FILE}")

    def find_element(self, strategy: SelectorStrategy, timeout_ms: int = 4000) -> Optional[ElementHandle]:
        """Busca secuencialmente entre los selectores de la estrategia con espera inteligente."""
        if not self.page:
            return None

        for selector in strategy.selectors:
            try:
                elem = self.page.wait_for_selector(selector, state="visible", timeout=timeout_ms)
                if elem:
                    return elem
            except Exception:
                continue
        return None

    def click_strategy(self, strategy: SelectorStrategy, timeout_ms: int = 5000) -> bool:
        """Localiza y hace clic en el primer elemento interactivo disponible de la estrategia."""
        elem = self.find_element(strategy, timeout_ms=timeout_ms)
        if elem:
            try:
                elem.scroll_into_view_if_needed(timeout=timeout_ms)
                elem.click()
                return True
            except Exception as e:
                logger.warning(f"Error al hacer clic en estrategia '{strategy.name}': {e}")
        return False

    def wait_for_spinners_to_disappear(self, timeout_ms: int = 15000) -> None:
        """
        Espera inteligente: detecta si hay alguna máscara o spinner de carga activo
        y espera hasta que se oculte o desmonte del DOM.
        """
        if not self.page:
            return

        for selector in Selectors.LOADING_SPINNERS.selectors:
            try:
                # Comprobar si el elemento está presente y visible
                spinner = self.page.query_selector(selector)
                if spinner and spinner.is_visible():
                    logger.debug(f"Esperando a que finalice indicador de carga: {selector}")
                    self.page.wait_for_selector(selector, state="hidden", timeout=timeout_ms)
            except Exception:
                pass

    def wait_for_modal_state(self, visible: bool = True, timeout_ms: int = 8000) -> Optional[ElementHandle]:
        """
        Espera inteligente: aguarda a que el modal aparezca (visible=True)
        o se cierre por completo (visible=False).
        """
        if not self.page:
            return None

        target_state = "visible" if visible else "hidden"
        for selector in Selectors.MODAL_CONTAINER.selectors:
            try:
                elem = self.page.wait_for_selector(selector, state=target_state, timeout=timeout_ms)
                if visible and elem:
                    return elem
                elif not visible:
                    return None
            except Exception:
                continue
        return None

    def wait_for_image_ready(self, img_elem: ElementHandle, timeout_ms: int = 5000) -> bool:
        """
        Espera inteligente de renderizado de imagen: comprueba que la etiqueta <img>
        haya finalizado su carga (complete=True) y tenga dimensiones naturales válidas.
        """
        try:
            is_ready = self.page.wait_for_function(
                "el => el && el.complete && el.naturalWidth > 0",
                arg=img_elem,
                timeout=timeout_ms,
            )
            return bool(is_ready)
        except Exception:
            return False

    def capture_screenshot(self, name: str) -> Path:
        """Toma una captura de pantalla de la vista completa para depuración y trazabilidad."""
        screenshots_dir = STORAGE_DIR / "screenshots"
        screenshots_dir.mkdir(parents=True, exist_ok=True)
        path = screenshots_dir / f"{name}.png"
        if self.page:
            try:
                self.page.screenshot(path=str(path), full_page=True)
                logger.debug(f"Captura guardada en {path}")
            except Exception as e:
                logger.warning(f"No se pudo capturar pantalla: {e}")
        return path

    def close(self):
        """Cierre ordenado de página, contexto, sesión y navegador."""
        try:
            if self.context:
                if self.session_valid:
                    self.save_session()
                self.context.close()
            if self.browser:
                self.browser.close()
            if self.playwright:
                self.playwright.stop()
            logger.info("Navegador cerrado ordenadamente.")
        except Exception as e:
            logger.warning(f"Excepción cerrando navegador: {e}")

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
