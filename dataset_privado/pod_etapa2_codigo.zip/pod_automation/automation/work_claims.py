"""Reservas pequenas, renovacion de trabajo activo y confirmaciones durables tras puntuar.

Usa el protocolo existente de claim.php. No toma reservas vigentes de otro worker.
"""
import logging
from contextlib import contextmanager
from pathlib import Path
import sqlite3
import threading
import time

import config

from export.portal_sync import claim_granted, claim_some, claims_done, route_claim

logger=logging.getLogger('PODAutomation.Claims')


class LeaseCoordinator:
    def __init__(self,client,worker,day,lease_s,state_path):
        self.client,self.worker,self.day=client,worker,day
        self.lease_s=max(30,min(3600,int(lease_s)))
        self.path=Path(state_path)
        self.active=set()
        self.lock=threading.RLock()
        self.rpc_lock=threading.Lock()
        self.stop_event=threading.Event()
        self.thread=None
        self.last_error=None
        self.closed=False
        self.down_until=0.0   # 28/10: tras un fallo del portal, no se le pregunta durante CLAIM_BACKOFF_S
        # 29/10: portal nuevo (lista de hechos, "max" y reparto por repartidor). None = sin probar todavia
        self.v2=None
        self.v2_checked=0.0
        self.done_cache=set()
        self.done_at=0.0
        self.routes_held={}   # (ciudad, repartidor) -> cuando se reservo o renovo (monotonic)
        with self.connection() as con:
            con.execute('''CREATE TABLE IF NOT EXISTS claim_done_outbox(
                day TEXT NOT NULL,worker TEXT NOT NULL,tracking TEXT NOT NULL,
                PRIMARY KEY(day,worker,tracking))''')

    @contextmanager
    def connection(self):
        con=sqlite3.connect(self.path,timeout=15)
        try:
            with con:
                yield con
        finally:
            con.close()

    def start(self):
        if self.thread is None:
            self.thread=threading.Thread(target=self._heartbeat,daemon=True,name='claim-renewal')
            self.thread.start()
        return self

    def complete(self,tracking):
        # El llamador ya guardo el resultado en su checkpoint.
        with self.lock:
            with self.connection() as con:
                con.execute('INSERT OR IGNORE INTO claim_done_outbox VALUES (?,?,?)',(self.day,self.worker,tracking))
            self.active.discard(tracking)

    def _done(self):
        with self.connection() as con:
            return [r[0] for r in con.execute('SELECT tracking FROM claim_done_outbox WHERE day=? AND worker=? ORDER BY tracking LIMIT 200',
                                             (self.day,self.worker))]

    def _acknowledge(self,done):
        with self.connection() as con:
            con.executemany('DELETE FROM claim_done_outbox WHERE day=? AND worker=? AND tracking=?',
                            [(self.day,self.worker,t) for t in done])

    def acquire(self,trackings,done=()):
        for tracking in done:
            self.complete(tracking)
        if time.monotonic()<self.down_until:
            raise RuntimeError('portal sin respuesta hace poco; reparto en pausa')
        with self.rpc_lock:
            finished=self._done()
            granted=self._rpc(list(trackings),finished,self.lease_s)
            self._acknowledge(finished)
            with self.lock:
                self.active.update(granted)
            self.last_error=None
            return granted

    def done_set(self):
        """29/10: lo revisado hoy por cualquier corrida (cache de CLAIMS_DONE_REFRESH_S). None con el portal anterior."""
        now=time.monotonic()
        if self.v2 and now-self.done_at<config.CLAIMS_DONE_REFRESH_S:
            return self.done_cache
        if self.v2 is False and now-self.v2_checked<600:
            return None
        if now<self.down_until:
            return self.done_cache if self.v2 else None
        try:
            with self.rpc_lock:
                rows=claims_done(self.client,self.day)
        except Exception as error:
            self.v2_checked=now
            if not self.v2:
                self.v2=False
                logger.info('Portal sin lista de hechos (%s): reparto de siempre.',error)
                return None
            return self.done_cache   # Se reintenta en la proxima pasada
        self.v2=True
        self.done_cache=rows
        self.done_at=now
        return rows

    def acquire_some(self,trackings,done=(),max_n=5):
        """29/10: los primeros max_n libres de los candidatos, en un pedido. Devuelve (concedidos, tomados por otra)."""
        for tracking in done:
            self.complete(tracking)
        if time.monotonic()<self.down_until:
            raise RuntimeError('portal sin respuesta hace poco; reparto en pausa')
        with self.rpc_lock:
            finished=self._done()
            try:
                granted,taken=claim_some(self.client,self.worker,self.day,list(trackings),finished,max_n,self.lease_s)
            except Exception:
                self.down_until=time.monotonic()+config.CLAIM_BACKOFF_S
                raise
            self._acknowledge(finished)
            with self.lock:
                self.active.update(granted)
            self.last_error=None
            return granted,taken

    def routes(self,station,drivers,max_n=1):
        """29/10: reserva (o renueva) repartidores de una ciudad. Devuelve (concedidos, los que tiene otra corrida)."""
        with self.rpc_lock:
            granted,held=route_claim(self.client,self.worker,self.day,station,list(drivers)[:50],max_n,config.ROUTE_LEASE_S)
        now=time.monotonic()
        with self.lock:
            for driver in granted:
                self.routes_held[(station,driver)]=now
            for driver in held:
                self.routes_held.pop((station,driver),None)
        return granted,held

    def release_route(self,station,driver):
        with self.lock:
            self.routes_held.pop((station,driver),None)
        try:
            with self.rpc_lock:
                route_claim(self.client,self.worker,self.day,station,[],1,config.ROUTE_LEASE_S,release=[driver])
        except Exception as error:
            logger.debug('Ruta %s se liberara por vencimiento: %s',driver,error)

    def release_routes(self):
        """Fin de pasada: suelta todas las rutas de esta corrida (al vencer el plazo se sueltan solas)."""
        with self.lock:
            had=bool(self.routes_held)
            self.routes_held.clear()
        if not had:
            return
        try:
            with self.rpc_lock:
                route_claim(self.client,self.worker,self.day,'',[],1,config.ROUTE_LEASE_S,release_all=True)
        except Exception as error:
            logger.warning('Las rutas reservadas se liberaran por vencimiento: %s',error)

    def _renew_routes(self):
        now=time.monotonic()
        due={}
        with self.lock:
            for (station,driver),at in self.routes_held.items():
                if now-at>=config.ROUTE_LEASE_S/3:
                    due.setdefault(station,[]).append(driver)
        for station,drivers in due.items():
            for i in range(0,len(drivers),50):
                part=drivers[i:i+50]
                self.routes(station,part,max_n=len(part))

    def tick(self,shorten=False):
        with self.rpc_lock:
            done=self._done()
            with self.lock:
                wanted=sorted(self.active-set(done))
            if not done and not wanted:
                return
            if time.monotonic()<self.down_until:
                return   # Las confirmaciones quedan en disco y se mandan cuando vuelva el portal
            granted=self._rpc(wanted,done,30 if shorten else self.lease_s)
            self._acknowledge(done)
            with self.lock:
                self.active.intersection_update(granted)
            self.last_error=None

    def _rpc(self,trackings,done,lease_s):
        try:
            return claim_granted(self.client,self.worker,self.day,trackings,done,lease_s)
        except Exception:
            self.down_until=time.monotonic()+config.CLAIM_BACKOFF_S
            raise

    def _heartbeat(self):
        while not self.stop_event.wait(min(30,self.lease_s/3)):
            try:
                self.tick()
            except Exception as error:
                self.last_error=str(error)
                logger.warning('No se pudo renovar/confirmar trabajo: %s',error)
            try:
                self._renew_routes()
            except Exception as error:
                logger.warning('No se pudo renovar las rutas reservadas: %s',error)

    def close(self):
        if self.closed:
            return
        self.closed=True
        self.stop_event.set()
        self.release_routes()
        if self.thread:
            self.thread.join(timeout=getattr(self.client,'timeout',30)+1)
            if self.thread.is_alive():
                logger.warning('Renovacion aun en curso; las reservas venceran por su plazo.')
                return
        try:
            # El servidor actual admite un minimo de 30 s: libera pronto el trabajo inconcluso.
            self.tick(shorten=True)
            with self.lock:
                self.active.clear()
        except Exception as error:
            self.last_error=str(error)
            logger.warning('Confirmaciones pendientes conservadas en disco: %s',error)

    def info(self):
        with self.lock:
            with self.connection() as con:
                done=con.execute('SELECT COUNT(*) FROM claim_done_outbox WHERE day=? AND worker=?',(self.day,self.worker)).fetchone()[0]
            return {'in_progress':len(self.active),'done_to_confirm':done,'last_error':self.last_error}
