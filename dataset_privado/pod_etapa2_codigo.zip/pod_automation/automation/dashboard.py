"""
Módulo de Interacción con el Dashboard DSP de Gofo Express.

Implementa selección inteligente de fecha y ejecución del botón 'Consulta'
mediante sincronización nativa de Playwright (cero time.sleep).
"""

import logging
from typing import Optional
from playwright.sync_api import Page
from rich.console import Console

from config import GOFO_PORTAL_URL, GOFO_DASHBOARD_PATH
from automation.selectors import Selectors
from automation.browser import BrowserManager

logger = logging.getLogger("PODAutomation.Dashboard")
console = Console()


class DashboardManager:
    """Controlador de filtros y consulta en el Dashboard DSP."""

    def __init__(self, browser_manager: BrowserManager):
        self.bm = browser_manager
        self.page: Page = browser_manager.page

    def navigate_to_dashboard(self) -> bool:
        """Asegura la ubicación en el Dashboard de entregas/POD."""
        logger.info("Navegando y asegurando vista en Dashboard DSP...")

        # 1. Intentar clic en menú de navegación
        if self.bm.click_strategy(Selectors.NAV_DSP_MENU, timeout_ms=3000):
            self.bm.wait_for_spinners_to_disappear(timeout_ms=10000)
            return True

        # 2. Si no hay menú visible, navegar por URL directa
        target_url = GOFO_PORTAL_URL.rstrip("/") + GOFO_DASHBOARD_PATH
        if self.page.url != target_url:
            try:
                self.page.goto(target_url, wait_until="domcontentloaded")
                self.page.wait_for_load_state("networkidle", timeout=10000)
            except Exception as e:
                logger.debug(f"Navegación directa a dashboard: {e}")

        self.bm.wait_for_spinners_to_disappear(timeout_ms=10000)
        return True

    def select_date(self, query_date: str) -> bool:
        """
        Ingresa la fecha en el filtro del dashboard utilizando eventos DOM reactivos
        (compatibles con frameworks Vue.js, React, Angular y Element/Ant Design).
        """
        logger.info(f"Seleccionando fecha de consulta: {query_date}")
        date_input = self.bm.find_element(Selectors.DATE_INPUT, timeout_ms=5000)

        if not date_input:
            logger.warning("No se localizó el campo de fecha mediante selectores conocidos.")
            return False

        try:
            date_input.scroll_into_view_if_needed(timeout=3000)
            date_input.click()

            # Rellenar con Playwright y disparar eventos de reactividad
            date_input.fill(query_date)
            date_input.evaluate("el => { el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); }")
            self.page.keyboard.press("Enter")

            # Si se abrió un calendario desplegable flotante, cerrarlo con Escape
            self.page.keyboard.press("Escape")
            return True
        except Exception as e:
            logger.error(f"Error al ingresar la fecha en el selector: {e}")
            return False

    def click_query(self) -> bool:
        """
        Presiona el botón 'Consulta' y sincroniza con esperas inteligentes:
        1. Espera a que termine cualquier petición pendiente.
        2. Espera a que cualquier máscara o spinner de carga finalice.
        3. Espera a que las filas de la tabla se rendericen.
        """
        logger.info("Presionando botón 'Consulta'...")
        clicked = self.bm.click_strategy(Selectors.BTN_QUERY, timeout_ms=5000)

        if not clicked:
            logger.warning("No se pudo pulsar el botón 'Consulta'.")
            return False

        # Sincronización inteligente de Playwright (sin time.sleep)
        try:
            # Aguardar inicio y finalización de peticiones AJAX/Fetch
            self.page.wait_for_load_state("networkidle", timeout=15000)
        except Exception:
            pass

        # Aguardar desaparición de máscaras de carga (.el-loading-mask, .ant-spin, etc.)
        self.bm.wait_for_spinners_to_disappear(timeout_ms=20000)

        # Aguardar que aparezca la tabla o filas
        for row_sel in Selectors.TABLE_ROWS.selectors:
            try:
                self.page.wait_for_selector(row_sel, state="attached", timeout=6000)
                break
            except Exception:
                continue

        logger.info("Consulta completada y DOM estabilizado.")
        return True

    def run_query(self, query_date: str) -> bool:
        """Flujo orquestado: Navegación -> Filtro de Fecha -> Consulta."""
        self.navigate_to_dashboard()
        if self.select_date(query_date):
            return self.click_query()
        return False
