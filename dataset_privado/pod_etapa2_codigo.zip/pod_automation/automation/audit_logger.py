"""
Módulo de Logging Profesional y Auditoría Segura para POD Automation (Fase 7).

Registra en storage/logs/:
- Hora de inicio de la sesión.
- POD ordinal actual y albarán/tracking en proceso.
- Tiempos de procesamiento por entrega y tiempo transcurrido total.
- Conteo y causas de reintentos.
- Registro detallado de excepciones y fallos.
- Veredicto y resultado final.

RESTRICCIÓN ESTRICTA DE PRIVACIDAD:
- CERO almacenamiento de credenciales, nombres de usuario o contraseñas.
- Sanitizador automático que enmascara información sensible.
"""

from pathlib import Path
from datetime import datetime
import logging
import time
import re
from typing import Optional, Dict, Any

from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from config import LOGS_DIR

console = Console()

# Patrones para sanitización automática de seguridad
SENSITIVE_PATTERNS = [
    re.compile(r"(password|pwd|pass|contrasena|contraseña)\s*[:=]\s*['\"]?[^'\"\s]+['\"]?", re.IGNORECASE),
    re.compile(r"(token|auth_token|bearer|jwt)\s*[:=]\s*['\"]?[^'\"\s]+['\"]?", re.IGNORECASE),
    re.compile(r"(cookie|session_id|session_state)\s*[:=]\s*['\"]?[^'\"\s]+['\"]?", re.IGNORECASE),
]


def sanitize_message(msg: str) -> str:
    """Enmascara automáticamente cualquier dato potencialmente confidencial o sensible."""
    sanitized = msg
    for pattern in SENSITIVE_PATTERNS:
        sanitized = pattern.sub(r"\1: [PROTECTED_CREDENTIAL]", sanitized)
    return sanitized


class SafeFormatter(logging.Formatter):
    """Formateador de logging con sanitización obligatoria contra credenciales."""
    def format(self, record: logging.LogRecord) -> str:
        original = super().format(record)
        return sanitize_message(original)


class AuditLogger:
    """
    Gestor de logs de auditoría profesional para el pipeline de procesamiento de PODs.
    """

    def __init__(self, session_id: Optional[str] = None, log_filename: Optional[str] = None):
        self.session_id = session_id or datetime.now().strftime("%Y%m%d_%H%M%S")
        self.start_time = datetime.now()
        self.start_monotonic = time.monotonic()
        self.current_pod_start: float = time.monotonic()

        LOGS_DIR.mkdir(parents=True, exist_ok=True)
        filename = log_filename or f"audit_{self.session_id}.log"
        self.log_file = LOGS_DIR / filename

        # Configurar logger dedicado
        self.logger = logging.getLogger(f"PODAudit.{self.session_id}")
        self.logger.setLevel(logging.INFO)
        self.logger.propagate = False

        # Evitar handlers duplicados
        if not self.logger.handlers:
            file_handler = logging.FileHandler(self.log_file, encoding="utf-8")
            file_handler.setLevel(logging.INFO)
            formatter = SafeFormatter(
                "%(asctime)s.%(msecs)03d [%(levelname)s] [%(name)s] %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S",
            )
            file_handler.setFormatter(formatter)
            self.logger.addHandler(file_handler)

        self.log_session_start()

    def log_session_start(self):
        """Registra el inicio formal de la sesión de verificación."""
        self.logger.info("=" * 80)
        self.logger.info("INICIO DE SESIÓN DE AUDITORÍA Y VERIFICACIÓN DE POD")
        self.logger.info(f"ID Sesión: {self.session_id}")
        self.logger.info(f"Hora de Inicio: {self.start_time.strftime('%Y-%m-%d %H:%M:%S')}")
        self.logger.info("Política de Seguridad: Modo READ-ONLY activo. Credenciales de usuario omitidas.")
        self.logger.info("=" * 80)

    def start_pod(self, current_index: int, total_pods: int, tracking: str):
        """Registra el inicio de procesamiento de un comprobante POD."""
        self.current_pod_start = time.monotonic()
        msg = f"[INICIANDO] POD {current_index} / {total_pods} | Tracking: {tracking}"
        self.logger.info(msg)

    def log_retry(self, current_index: int, tracking: str, attempt: int, max_retries: int, reason: str):
        """Registra un reintento ante una falla transitoria de red o DOM."""
        msg = (
            f"[REINTENTO {attempt}/{max_retries}] POD #{current_index} ({tracking}) | "
            f"Causa: {reason}"
        )
        self.logger.warning(msg)

    def end_pod(
        self,
        current_index: int,
        total_pods: int,
        tracking: str,
        photos_count: int,
        status: str,
        result: str,
        notes: str = "",
    ):
        """Registra la finalización exitosa de la auditoría de un POD con su tiempo transcurrido."""
        elapsed = round(time.monotonic() - self.current_pod_start, 2)
        total_elapsed = round(time.monotonic() - self.start_monotonic, 2)
        msg = (
            f"[COMPLETADO] POD {current_index} / {total_pods} | Tracking: {tracking} | "
            f"Fotos: {photos_count} | Estado: {status} | Resultado: {result} | "
            f"Tiempo POD: {elapsed}s | Acumulado: {total_elapsed}s"
        )
        if notes:
            msg += f" | Notas: {notes}"
        self.logger.info(msg)

    def log_pod_error(
        self,
        current_index: int,
        tracking: str,
        error: Exception,
        screenshot_path: Optional[str] = None,
    ):
        """Registra el fallo de un POD específico garantizando la continuidad del lote."""
        elapsed = round(time.monotonic() - self.current_pod_start, 2)
        msg = (
            f"[ERROR EN POD #{current_index}] Tracking: {tracking} | "
            f"Excepción: {type(error).__name__}: {str(error)} | Tiempo: {elapsed}s"
        )
        if screenshot_path:
            msg += f" | Screenshot Diagnóstico: {screenshot_path}"
        self.logger.error(msg)

    def log_session_summary(
        self,
        total_processed: int,
        total_valid: int,
        total_review: int,
        total_issues: int,
        total_errors: int,
    ):
        """Registra el resumen de cierre de la sesión de verificación."""
        total_elapsed = round(time.monotonic() - self.start_monotonic, 2)
        self.logger.info("=" * 80)
        self.logger.info("FINALIZACIÓN DE SESIÓN DE AUDITORÍA")
        self.logger.info(f"Tiempo Total de Procesamiento: {total_elapsed} segundos")
        self.logger.info(f"Total PODs Procesados: {total_processed}")
        self.logger.info(f"Válidos / Aprobados: {total_valid}")
        self.logger.info(f"Requieren Revisión: {total_review}")
        self.logger.info(f"Posibles Incidencias / Duplicados: {total_issues}")
        self.logger.info(f"Errores / Fallidos: {total_errors}")
        self.logger.info("=" * 80)
