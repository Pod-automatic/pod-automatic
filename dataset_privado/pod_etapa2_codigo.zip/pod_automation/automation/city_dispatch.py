"""Reparto local entre sesiones independientes: ciudades menos atendidas primero."""
import sqlite3
import time
from pathlib import Path


class CityDispatcher:
    def __init__(self,path,worker,stations):
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
        self.worker=worker; self.stations=list(stations)
        with self.connect() as db:
            db.executescript('''CREATE TABLE IF NOT EXISTS city_turns(
                day TEXT,station INTEGER,last_turn REAL DEFAULT 0,cooldown REAL DEFAULT 0,
                PRIMARY KEY(day,station));
                CREATE TABLE IF NOT EXISTS city_workers(worker TEXT PRIMARY KEY,station INTEGER,until REAL);''')

    def connect(self):
        return sqlite3.connect(self.path,timeout=15)

    def choose(self,day):
        now=time.time()
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            for station in self.stations:
                db.execute('INSERT OR IGNORE INTO city_turns(day,station) VALUES (?,?)',(day,station))
            busy={r[0] for r in db.execute('SELECT station FROM city_workers WHERE worker!=? AND until>?',(self.worker,now))}
            candidates=[r for r in db.execute('SELECT station,last_turn,cooldown FROM city_turns WHERE day=?',(day,))
                        if r[0] in self.stations and r[2]<=now]
            if not candidates: return None
            station=min(candidates,key=lambda r:(r[0] in busy,r[1],self.stations.index(r[0])))[0]
            db.execute('UPDATE city_turns SET last_turn=? WHERE day=? AND station=?',(now,day,station))
            db.execute('INSERT OR REPLACE INTO city_workers VALUES (?,?,?)',(self.worker,station,now+600))
            return station

    def finish(self,day,station,empty=False):
        with self.connect() as db:
            db.execute('UPDATE city_turns SET cooldown=? WHERE day=? AND station=?',
                       (time.time()+120 if empty else 0,day,station))
            db.execute('DELETE FROM city_workers WHERE worker=?',(self.worker,))

    def release(self):
        with self.connect() as db:
            db.execute('DELETE FROM city_workers WHERE worker=?',(self.worker,))
