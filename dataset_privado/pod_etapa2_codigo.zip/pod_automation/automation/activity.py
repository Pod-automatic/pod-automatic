"""Actividad reciente real; nunca presentar una mediana historica como ritmo actual."""
from datetime import datetime, timezone
import json
from pathlib import Path
import statistics


def recent_activity(path, window_s=300, now=None):
    if window_s <= 0:
        raise ValueError('La ventana debe ser positiva.')
    now = now or datetime.now(timezone.utc)
    if now.tzinfo is None:
        raise ValueError('now debe incluir zona horaria.')
    entries=[]
    path=Path(path)
    truncated=False
    if path.exists():
        with path.open('rb') as stream:
            stream.seek(0,2)
            size=stream.tell()
            start=max(0,size-2*1024*1024)
            stream.seek(start)
            if start:
                stream.readline()  # no interpretar una linea parcial
                truncated=True
            for raw in stream:
                try:
                    row=json.loads(raw)
                    stamp=datetime.fromisoformat(row['ts'].replace('Z','+00:00'))
                    # Compatibilidad con registros antiguos: hora local del host que los lee.
                    if stamp.tzinfo is None:
                        stamp=stamp.astimezone()
                    age=(now-stamp).total_seconds()
                    if age>=0:
                        entries.append((row,age))
                except (ValueError,KeyError,TypeError,UnicodeError):
                    continue
    has_analysis=any(r.get('stage')=='analisis' for r,age in entries)
    complete=lambda r: (r.get('stage')=='analisis' and r.get('status')=='ANALYZED') if has_analysis else (
        r.get('stage','extraccion')=='extraccion' and r.get('status')=='PROCESSED')
    completed=[(r,age) for r,age in entries if complete(r)]
    recent=[r for r,age in completed if age<=window_s]
    seconds=[float(r['seconds']) for r in recent if isinstance(r.get('seconds'),(int,float))]
    extracted=[r for r,age in entries if age<=window_s and r.get('stage','extraccion')=='extraccion' and r.get('status')=='PROCESSED']
    return {'window_s':window_s,'completed_recent':len(recent),
            'completed_unique_recent':len({r.get('tracking') for r in recent}),
            'extracted_recent':len(extracted),'actual_per_hour':round(len(recent)*3600/window_s,1),
            'median_seconds_recent':round(statistics.median(seconds),2) if seconds else None,
            'idle_seconds':round(min(age for r,age in completed),1) if completed else None,
            'completion_source':'analisis' if has_analysis else 'extraccion',
            'tail_limited':truncated,'as_of':now.isoformat(timespec='seconds')}
