"""
Scraping respetuoso con el portal de GOFO.

- Reintentos con backoff exponencial y jitter (no martillar al portal cuando falla).
- La sesión vencida NUNCA se reintenta: se propaga para detener la corrida.
- Medición del tiempo real por albarán y proyección de throughput diario.
"""

import json
import random
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, List, Optional, TypeVar

import config
from automation.session_guard import SessionCoordinationError
from automation.browser import SessionExpiredError

T = TypeVar("T")


def backoff_delay(
    attempt: int,
    base: float = None,
    cap: float = None,
    rng: Optional[random.Random] = None,
) -> float:
    """
    Espera antes del reintento `attempt` (1 = primer reintento), con "equal jitter":
    la mitad del backoff exponencial es fija y la otra mitad aleatoria. Así siempre se
    espera al menos base*2^(n-1)/2 y varios fallos no se sincronizan.
    """
    base = config.RETRY_BASE_DELAY_S if base is None else base
    cap = config.RETRY_MAX_DELAY_S if cap is None else cap
    rng = rng or random
    exp = min(cap, base * (2 ** (attempt - 1)))
    half = exp / 2.0
    return half + rng.uniform(0, half)


def retry_with_backoff(
    fn: Callable[[], T],
    max_attempts: int = None,
    sleep: Callable[[float], None] = time.sleep,
    on_retry: Optional[Callable[[int, Exception, float], None]] = None,
    rng: Optional[random.Random] = None,
) -> T:
    """
    Ejecuta fn con hasta max_attempts intentos. Entre intentos espera backoff_delay().
    SessionExpiredError se propaga de inmediato, sin reintentar ni esperar.
    """
    max_attempts = config.MAX_RETRIES if max_attempts is None else max_attempts
    last_err: Optional[Exception] = None
    for attempt in range(1, max_attempts + 1):
        try:
            return fn()
        except (SessionExpiredError, SessionCoordinationError):
            raise
        except Exception as err:
            last_err = err
            if attempt == max_attempts:
                break
            delay = backoff_delay(attempt, rng=rng)
            if on_retry:
                on_retry(attempt, err, delay)
            sleep(delay)
    raise last_err


@dataclass
class ThroughputTracker:
    """
    Registra el tiempo real por albarán y proyecta cuántos se procesan por día.
    Dos etapas: 'extraccion' (portal + descarga de fotos) y 'analisis' (OCR + visión, en otro proceso).
    El throughput real lo pone la etapa más lenta.
    """
    log_path: Optional[Path] = None
    durations: List[float] = field(default_factory=list)            # Extracción
    analysis_durations: List[float] = field(default_factory=list)   # OCR + visión, por albarán
    analysis_workers: int = field(default_factory=lambda: config.OCR_WORKERS)

    def record(self, tracking: str, seconds: float, status: str, stage: str = "extraccion") -> None:
        (self.analysis_durations if stage == "analisis" else self.durations).append(seconds)
        if self.log_path:
            self.log_path.parent.mkdir(parents=True, exist_ok=True)
            entry = {
                "ts": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                "tracking": tracking,
                "seconds": round(seconds, 3),
                "status": status,
            }
            if stage != "extraccion":
                entry["stage"] = stage
            with open(self.log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry) + "\n")

    @classmethod
    def from_log(cls, log_path: Path) -> "ThroughputTracker":
        tracker = cls(log_path=None)
        if Path(log_path).exists():
            for line in Path(log_path).read_text(encoding="utf-8").splitlines():
                try:
                    entry = json.loads(line)
                    target = tracker.analysis_durations if entry.get("stage") == "analisis" else tracker.durations
                    target.append(float(entry["seconds"]))
                except (ValueError, KeyError):
                    continue
        return tracker

    def projection(self, daily_target: int = None) -> dict:
        """albaranes/hora reales × 24 comparado contra la meta diaria."""
        daily_target = config.DAILY_TARGET_PODS if daily_target is None else daily_target
        n = len(self.durations)
        if n == 0:
            return {"samples": 0}
        avg = sum(self.durations) / n
        ordered = sorted(self.durations)
        per_hour = 3600.0 / avg
        analysis = {}
        if self.analysis_durations:
            a_avg = sum(self.analysis_durations) / len(self.analysis_durations)
            a_ord = sorted(self.analysis_durations)
            a_per_hour = 3600.0 * max(1, self.analysis_workers) / a_avg
            analysis = {
                "analysis_samples": len(a_ord),
                "analysis_avg_seconds": round(a_avg, 2),
                "analysis_p95_seconds": round(a_ord[min(len(a_ord) - 1, int(len(a_ord) * 0.95))], 2),
                "extraction_per_hour": round(per_hour, 1),
                "analysis_per_hour": round(a_per_hour, 1),
                "bottleneck": "análisis (OCR/visión)" if a_per_hour < per_hour else "extracción (portal)",
            }
            per_hour = min(per_hour, a_per_hour)
        per_day = per_hour * 24
        return {
            **analysis,
            "samples": n,
            "avg_seconds": round(avg, 2),
            "p50_seconds": round(ordered[n // 2], 2),
            "p95_seconds": round(ordered[min(n - 1, int(n * 0.95))], 2),
            "per_hour": round(per_hour, 1),
            "per_day": round(per_day),
            "daily_target": daily_target,
            "coverage_pct": round(100.0 * per_day / daily_target, 1),
            "sampling_needed": per_day < daily_target,
        }
