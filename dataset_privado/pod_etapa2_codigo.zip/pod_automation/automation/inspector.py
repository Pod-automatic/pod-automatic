"""
Módulo de Inspección de Plataforma Web (Fase 12).

Modo seguro de SÓLO LECTURA (READ-ONLY) ejecutado vía `python main.py inspect`:
1. Abre Chromium en modo visible.
2. Navega al portal y asiste el login manual del usuario.
3. Espera confirmación interactiva en consola.
4. Muestra instrucciones guiadas.
5. Captura y guarda en storage/inspections/:
   - HTML completo de la página activa (page_dump.html).
   - Captura de pantalla de alta resolución (screenshot_full.png).
   - Catálogo estructurado de elementos interactivos (elements_catalog.json).
   - Resumen para completar selectors.py (inspection_summary.md).

ESTRICTAMENTE NO DESTRUCTIVO: Cero envíos de formularios o mutación de datos.
"""

from pathlib import Path
from datetime import datetime
import json
import logging
from typing import Dict, Any, List, Optional

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.prompt import Prompt

from config import (
    GOFO_PORTAL_URL,
    INSPECTIONS_DIR,
    HEADLESS,
    BROWSER_TIMEOUT_MS,
    SLOW_MO,
)
import config
from automation.browser import BrowserManager, SessionExpiredError
from automation.login import LoginManager

logger = logging.getLogger("PODAutomation.Inspector")
console = Console()


class PlatformInspector:
    """Inspector de interfaz web para auditoría de estructura y selectores."""

    def __init__(self, browser_manager: Optional[BrowserManager] = None):
        self.bm = browser_manager or BrowserManager(
            headless=False,  # Siempre visible para inspección
            slow_mo_ms=SLOW_MO,
            timeout_ms=BROWSER_TIMEOUT_MS,
        )

    def inspect_current_page(self, session_folder: Path) -> Dict[str, Any]:
        """
        Extrae el HTML, captura pantalla e inspecciona elementos interactivos
        visibles en el DOM sin ejecutar ninguna acción destructiva.
        """
        page = self.bm.page
        session_folder.mkdir(parents=True, exist_ok=True)

        console.print("[yellow]Capturando información de la página actual...[/yellow]")

        # 1. Guardar HTML completo
        html_content = page.content()
        html_file = session_folder / "page_dump.html"
        html_file.write_text(html_content, encoding="utf-8")
        console.print(f"[green][OK] HTML guardado:[/green] {html_file.name}")
        for idx, frame in enumerate(page.frames[1:], 1):
            try:
                (session_folder / f"frame_{idx}.html").write_text(
                    f"<!-- frame url: {frame.url} -->\n" + frame.content(), encoding="utf-8")
            except Exception as e:
                logger.debug(f"No se pudo guardar el iframe {idx}: {e}")

        # 2. Guardar Screenshot
        screenshot_file = session_folder / "screenshot_full.png"
        page.screenshot(path=str(screenshot_file), full_page=True)
        console.print(f"[green][OK] Screenshot guardado:[/green] {screenshot_file.name}")

        # 3. Extraer catálogo de elementos interactivos
        elements_data = page.evaluate("""() => {
            const result = {
                inputs: [],
                buttons: [],
                tables: [],
                modals: [],
                dialogs: []
            };

            // Inputs y Selects
            document.querySelectorAll('input, select, textarea').forEach(el => {
                const rect = el.getBoundingClientRect();
                if (rect.width > 0 && rect.height > 0) {
                    result.inputs.push({
                        tag: el.tagName.toLowerCase(),
                        type: el.getAttribute('type') || 'text',
                        name: el.getAttribute('name') || '',
                        id: el.id || '',
                        placeholder: el.getAttribute('placeholder') || '',
                        data_testid: el.getAttribute('data-testid') || el.getAttribute('data-test') || '',
                        aria_label: el.getAttribute('aria-label') || '',
                        class_name: el.className || ''
                    });
                }
            });

            // Botones
            document.querySelectorAll('button, a[role="button"], input[type="button"], input[type="submit"], [role="button"]').forEach(el => {
                const rect = el.getBoundingClientRect();
                if (rect.width > 0 && rect.height > 0) {
                    result.buttons.push({
                        text: (el.textContent || el.innerText || '').trim().substring(0, 50),
                        id: el.id || '',
                        data_testid: el.getAttribute('data-testid') || el.getAttribute('data-test') || '',
                        aria_label: el.getAttribute('aria-label') || '',
                        class_name: el.className || ''
                    });
                }
            });

            // Tablas y Listas
            document.querySelectorAll('table, [role="table"], [role="grid"]').forEach(el => {
                result.tables.push({
                    id: el.id || '',
                    class_name: el.className || '',
                    rows_count: el.querySelectorAll('tr, [role="row"]').length
                });
            });

            // Modales o diálogos
            document.querySelectorAll('[role="dialog"], .modal, .dialog, .el-dialog, .ant-modal').forEach(el => {
                result.modals.push({
                    id: el.id || '',
                    class_name: el.className || '',
                    visible: window.getComputedStyle(el).display !== 'none'
                });
            });

            // Imágenes visibles (fotos del POD, firma, etc.)
            result.images = [];
            document.querySelectorAll('img').forEach(el => {
                const rect = el.getBoundingClientRect();
                if (rect.width > 40 && rect.height > 40) {
                    const dlg = el.closest('[role="dialog"], .el-dialog, .ant-modal, .modal, .el-drawer, .ant-drawer');
                    result.images.push({
                        src: (el.currentSrc || el.src || '').substring(0, 300),
                        alt: el.getAttribute('alt') || '',
                        class_name: el.className || '',
                        parent_class: (el.parentElement && el.parentElement.className) || '',
                        in_dialog: !!dlg,
                        width: Math.round(rect.width), height: Math.round(rect.height)
                    });
                }
            });

            // Encabezados de tablas (para mapear columnas)
            result.table_headers = [];
            document.querySelectorAll('th, [role="columnheader"]').forEach(el => {
                const t = (el.textContent || '').trim();
                if (t) result.table_headers.push({ text: t.substring(0, 60), class_name: el.className || '' });
            });

            // Pares etiqueta/valor visibles dentro de diálogos o drawers (campos del albarán)
            result.dialog_fields = [];
            document.querySelectorAll('[role="dialog"], .el-dialog, .ant-modal, .modal, .el-drawer, .ant-drawer').forEach(dlg => {
                if (window.getComputedStyle(dlg).display === 'none') return;
                dlg.querySelectorAll('label, dt, th, span, div').forEach(el => {
                    if (el.children.length > 0) return;
                    const t = (el.textContent || '').trim();
                    if (!t || t.length > 80) return;
                    const next = el.nextElementSibling;
                    result.dialog_fields.push({
                        text: t, tag: el.tagName.toLowerCase(), class_name: el.className || '',
                        next_text: next ? (next.textContent || '').trim().substring(0, 120) : ''
                    });
                });
            });

            return result;
        }""")

        # Guardar catálogo JSON
        json_file = session_folder / "elements_catalog.json"
        json_file.write_text(json.dumps(elements_data, indent=2, ensure_ascii=False), encoding="utf-8")
        console.print(f"[green][OK] Catálogo JSON de elementos interactivos:[/green] {json_file.name}")

        # 4. Generar informe resumen en Markdown
        summary_md = self._generate_markdown_summary(elements_data, session_folder)
        summary_file = session_folder / "inspection_summary.md"
        summary_file.write_text(summary_md, encoding="utf-8")
        console.print(f"[green][OK] Guía de selectores generada:[/green] {summary_file.name}")

        return elements_data

    def _generate_markdown_summary(self, data: Dict[str, Any], folder: Path) -> str:
        """Crea una guía en Markdown para que el usuario copie selectores en selectors.py."""
        lines = [
            f"# Informe de Inspección de Plataforma Web",
            f"**Fecha y Hora:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"**Directorio:** `{folder}`",
            "",
            "## 1. Campos de Entrada (Inputs / Fechas detectados)",
            "| Etiqueta / Placeholder | Tipo | ID | Name | data-testid | Selector Recomendado |",
            "|---|---|---|---|---|---|",
        ]
        for inp in data.get("inputs", [])[:15]:
            p = inp["placeholder"] or inp["aria_label"] or "(sin texto)"
            testid = inp["data_testid"]
            id_attr = inp["id"]
            if testid:
                rec = f'`[data-testid="{testid}"]`'
            elif id_attr:
                rec = f'`#{id_attr}`'
            elif inp["name"]:
                rec = f'`input[name="{inp["name"]}"]`'
            elif inp["placeholder"]:
                rec = f'`input[placeholder*="{inp["placeholder"][:15]}"]`'
            else:
                rec = f'`input[type="{inp["type"]}"]`'
            lines.append(f"| {p} | {inp['type']} | {id_attr} | {inp['name']} | {testid} | {rec} |")

        lines.extend([
            "",
            "## 2. Botones Detectados (Candidatos para 'Consulta' / 'Buscar')",
            "| Texto del Botón | ID | data-testid | Selector Recomendado |",
            "|---|---|---|---|",
        ])
        for btn in data.get("buttons", [])[:20]:
            txt = btn["text"].replace("\n", " ").strip()
            if not txt:
                continue
            testid = btn["data_testid"]
            if testid:
                rec = f'`[data-testid="{testid}"]`'
            elif btn["id"]:
                rec = f'`#{btn["id"]}`'
            else:
                rec = f'`button:has-text("{txt}")`'
            lines.append(f"| {txt} | {btn['id']} | {testid} | {rec} |")

        lines.extend([
            "",
            "## 3. Instrucciones para Completar `automation/selectors.py`",
            "Abre el archivo `automation/selectors.py` y sustituye los valores `None` en `SELECTORS` con los selectores recomendados arriba:",
            "```python",
            "SELECTORS = {",
            '    "date_input": "...",      # Selector del campo de fecha',
            '    "search_button": "...",   # Selector del botón Consulta / Buscar',
            '    "pod_list": "...",        # Contenedor de la tabla',
            '    "pod_card": "...",        # Fila o tarjeta de entrega',
            '    "tracking_number": "...", # Elemento con número de albarán',
            '    "pod_modal": "...",       # Modal de detalle',
            '    "pod_images": "...",      # Fotos del POD',
            '    "close_modal": "...",     # Botón cerrar modal',
            "}",
            "```",
        ])
        return "\n".join(lines)

    @staticmethod
    def _serialize_network(responses: list, max_body: int = 20000) -> List[Dict[str, Any]]:
        """
        Resumen de llamadas XHR/fetch: método, URL, estado y cuerpo JSON truncado.
        NO se guardan encabezados de la petición (cookies/tokens).
        """
        calls = []
        for resp in responses:
            try:
                ctype = resp.headers.get("content-type", "")
                entry = {
                    "method": resp.request.method,
                    "url": resp.url,
                    "status": resp.status,
                    "content_type": ctype,
                    "post_data": (resp.request.post_data or "")[:2000],
                }
                if "json" in ctype:
                    entry["body"] = resp.text()[:max_body]
                calls.append(entry)
            except Exception as e:
                calls.append({"url": getattr(resp, "url", "?"), "error": str(e)})
        return calls

    def run_inspect_mode(self, url: Optional[str] = None):
        """
        Inspección guiada y PASIVA: el humano navega (lista, modal abierto, etc.) y en cada
        ENTER se captura la pantalla actual. El bot no hace clic ni escribe nada.
        También registra las llamadas XHR/fetch que hace el portal.
        """
        target_url = url or GOFO_PORTAL_URL
        timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        session_folder = INSPECTIONS_DIR / f"inspection_{timestamp_str}"

        console.print(Panel(
            "[bold cyan]MODO INSPECCIÓN DE PLATAFORMA[/bold cyan]\n"
            "[italic white]Solo lectura: tú navegas, el inspector solo observa y captura.[/italic white]",
            border_style="cyan",
            title="[bold yellow]★ INSPECTOR POD ★[/bold yellow]"
        ))

        responses: list = []
        try:
            console.print("[cyan]Iniciando navegador visible con la sesión guardada...[/cyan]")
            self.bm.start_browser()
            self.bm.context.on(
                "response",
                lambda r: responses.append(r) if r.request.resource_type in ("xhr", "fetch") else None,
            )
            if config.AUTH_MODE == "cdp":
                self.bm.page.goto(target_url)
                self.bm.session_valid = True
            else:
                LoginManager(self.bm).require_valid_session(target_url)

            console.print(Panel(
                "[bold green]QUÉ CAPTURAR (en este orden):[/bold green]\n"
                "1. [bold]lista[/bold]: la pantalla donde se ven los albaranes (con una fecha que tenga datos).\n"
                "2. [bold]modal[/bold]: abre UN albarán para ver su detalle con las 4 fotos y los campos.\n"
                "3. Opcional: cualquier otra vista útil (paginación, filtros, foto ampliada).\n\n"
                "En cada pantalla: vuelve aquí, escribe un nombre corto (ej. [cyan]lista[/cyan]) y ENTER.\n"
                "Escribe [cyan]fin[/cyan] para terminar. [bold red]No apruebes ni rechaces nada.[/bold red]",
                border_style="green"
            ))

            n = 0
            while True:
                label = Prompt.ask("\n[bold cyan]Nombre de la captura (o 'fin')[/bold cyan]").strip() or f"captura{n + 1}"
                if label.lower() == "fin":
                    break
                n += 1
                safe = "".join(c for c in label if c.isalnum() or c in "-_")[:30] or "captura"
                # Si el usuario abrió una pestaña nueva, capturar la última
                pages = self.bm.context.pages
                if pages and pages[-1] is not self.bm.page:
                    self.bm.page = pages[-1]
                self.inspect_current_page(session_folder / f"{n:02d}_{safe}")

            session_folder.mkdir(parents=True, exist_ok=True)
            net_file = session_folder / "network_calls.json"
            net_file.write_text(
                json.dumps(self._serialize_network(responses), indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
            console.print(f"[green][OK] {len(responses)} llamadas XHR/fetch registradas:[/green] {net_file.name}")
            console.print(Panel(
                f"[bold green][OK] INSPECCIÓN COMPLETADA[/bold green] ({n} capturas)\n\n"
                f"Carpeta: [cyan]{session_folder}[/cyan]\n"
                "[yellow]Contiene datos reales de clientes (direcciones, nombres, fotos): no la compartas fuera.[/yellow]",
                border_style="green"
            ))

        except SessionExpiredError as e:
            console.print(Panel(f"[bold red]{e}[/bold red]", title="SESIÓN NO DISPONIBLE", border_style="red"))
        except Exception as e:
            console.print(f"[bold red]Error durante la inspección:[/bold red] {e}")
            logger.exception("Error en modo inspección")
        finally:
            console.print("[dim]Cerrando navegador...[/dim]")
            self.bm.close_browser()
