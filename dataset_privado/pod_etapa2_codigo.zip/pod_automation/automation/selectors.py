"""
Capa Centralizada de Selectores HTML para Gofo Express DSP (Fase 11).

IMPORTANTE:
La plataforma web es privada y sus selectores específicos deben identificarse
durante la inspección en el entorno real (usando `python main.py inspect`).
Por tanto, esta capa define placeholders `None` claramente identificados y métodos
seguros de resolución para evitar XPath frágiles o selectores inventados.

PRIORIDAD DE SELECTORES A UTILIZAR AL COMPLETAR:
1. Atributos data-testid:        ej. [data-testid="date-picker-input"]
2. Roles accesibles / aria:      ej. role=button[name="Consulta"], [aria-label="Cerrar"]
3. Labels y texto visible:       ej. label:has-text("Fecha") >> input, button:has-text("Consulta")
4. Selectores CSS estables:      ej. #date-input, .pod-table, .modal-dialog
5. EVITAR: XPath absoluto frágil (ej. /html/body/div[2]/div[1]/table/tbody/tr...)
"""

from typing import Dict, Optional, List


# ==============================================================================
# DICCIONARIO FORMAL DE SELECTORES (FASE 11)
# Modificar los valores None por los selectores reales de la plataforma.
# ==============================================================================
SELECTORS: Dict[str, Optional[str]] = {
    # 1. Input o selector de fecha de consulta
    "date_input": None,

    # 2. Botón para ejecutar la búsqueda / consulta
    "search_button": None,

    # 3. Contenedor principal de la lista o tabla de PODs
    "pod_list": None,

    # 4. Fila o tarjeta individual de un POD dentro de la lista
    "pod_card": None,

    # 5. Elemento o celda que contiene el número de albarán / tracking
    "tracking_number": None,

    # 6. Modal o ventana emergente con el detalle de la entrega
    "pod_modal": None,

    # 7. Elemento(s) img o contenedor con las fotografías del comprobante
    "pod_images": None,

    # 8. Botón o aspa (X) para cerrar el modal de detalle
    "close_modal": None,
}


def get_selector(key: str, fallback_heuristic: Optional[str] = None) -> Optional[str]:
    """
    Obtiene el selector configurado para una clave dada.
    Si está en None y se provee un fallback heurístico, retorna el fallback
    notificando que se usa un respaldo preventivo.
    """
    configured = SELECTORS.get(key)
    if configured and configured.strip():
        return configured.strip()
    return fallback_heuristic


def is_selector_configured(key: str) -> bool:
    """Indica si un selector específico ya ha sido completado y no es None."""
    val = SELECTORS.get(key)
    return bool(val and val.strip())


def get_unconfigured_selectors() -> List[str]:
    """Retorna la lista de selectores que aún permanecen con valor None."""
    return [k for k, v in SELECTORS.items() if not v or not v.strip()]


def validate_configured_selectors() -> Dict[str, bool]:
    """Retorna un diccionario indicando el estado de configuración de cada selector."""
    return {k: bool(v and v.strip()) for k, v in SELECTORS.items()}


# ==============================================================================
# CLASE SELECTORS CON FALLBACKS HEURÍSTICOS (Para Pruebas y Entornos Simulados)
# ==============================================================================
class SelectorStrategy:
    """Contenedor de selector con lista de alternativas de respaldo."""
    def __init__(self, name: str, key: str, fallbacks: List[str]):
        self.name = name
        self.key = key
        self.fallbacks = fallbacks

    @property
    def primary(self) -> str:
        configured = SELECTORS.get(self.key)
        if configured and configured.strip():
            return configured.strip()
        return self.fallbacks[0]

    @property
    def selectors(self) -> List[str]:
        configured = SELECTORS.get(self.key)
        if configured and configured.strip():
            return [configured.strip()] + self.fallbacks
        return self.fallbacks


class Selectors:
    """Fachada compatible con versiones previas basada en SelectorStrategy."""
    DATE_INPUT = SelectorStrategy("Filtro de Fecha", "date_input", [
        "input[type='date']",
        "input[name*='date']",
        "input[placeholder*='Fecha']",
        ".el-date-editor input",
        "#fecha-consulta",
    ])

    BTN_QUERY = SelectorStrategy("Botón Consulta", "search_button", [
        "button:has-text('Consulta')",
        "button:has-text('Consultar')",
        "button:has-text('Search')",
        "button[type='submit']",
        ".btn-query",
    ])

    TABLE_CONTAINER = SelectorStrategy("Contenedor de Lista POD", "pod_list", [
        "table tbody",
        ".el-table__body",
        ".pod-list",
        "[role='table']",
        "#pod-container",
    ])

    TABLE_ROWS = SelectorStrategy("Fila o Tarjeta POD", "pod_card", [
        "tr.el-table__row",
        "table tbody tr",
        ".pod-card",
        "[role='row']",
    ])

    STOP_NUMBER = SelectorStrategy("Número de Parada", "tracking_number", [
        ".stop-number",
        "[data-field='stop']",
        "td.col-stop",
    ])

    DETAIL_MODAL = SelectorStrategy("Modal Detalle POD", "pod_modal", [
        ".el-dialog",
        ".ant-modal",
        "[role='dialog']",
        ".pod-modal",
        ".modal-content",
    ])

    MODAL_IMAGES = SelectorStrategy("Fotografías POD", "pod_images", [
        ".pod-photo img",
        ".el-image img",
        ".evidence-photo",
        "[data-field='photo'] img",
        "img[src*='pod']",
    ])

    BTN_CLOSE_MODAL = SelectorStrategy("Botón Cerrar Modal", "close_modal", [
        ".el-dialog__headerbtn",
        ".ant-modal-close",
        "button:has-text('Cerrar')",
        "button:has-text('Close')",
        "[aria-label='Close']",
    ])

    STATION_CODE = SelectorStrategy("Estación DSP", "tracking_number", [
        ".station",
        "[data-field='station']",
        "td.col-station",
    ])

    BTN_VIEW_POD = SelectorStrategy("Ver Detalle POD", "pod_card", [
        "button:has-text('Ver')",
        "button:has-text('Detalle')",
        "button:has-text('POD')",
        "a.view-detail",
        ".btn-view",
        # SIN fallback genérico "button": en modo solo lectura no se hace clic en botones
        # desconocidos (podría ser "Aprobar"/"Rechazar" en el portal real).
    ])

    MODAL_PACKAGE_IMG = SelectorStrategy("Foto Paquete", "pod_images", [
        ".pod-photo img",
        ".package-img",
        "img[src*='pod']",
    ])

    # Elementos auxiliares
    DASHBOARD_INDICATORS = SelectorStrategy("Dashboard Indicators", "pod_list", [
        "text=Dashboard",
        "text=DSP",
        "text=Consulta",
        ".user-profile",
        "#dsp-dashboard",
    ])

    LOADING_SPINNERS = SelectorStrategy("Spinners de Carga", "pod_list", [
        ".el-loading-mask",
        ".ant-spin",
        ".is-loading",
        "[aria-busy='true']",
    ])

    SCROLLABLE_CONTAINER = SelectorStrategy("Contenedor Scroll", "pod_list", [
        ".el-table__body-wrapper",
        ".table-responsive",
        "div[style*='overflow']",
    ])

    MODAL_SIGNATURE_IMG = SelectorStrategy("Firma", "pod_images", [
        ".signature-img",
        "img[src*='sign']",
    ])

    MODAL_SIGNATURE_TIME = SelectorStrategy("Hora Firma", "pod_modal", [
        ".sign-time",
        "[data-field='sign_time']",
    ])

    MODAL_REJECTION_REASON = SelectorStrategy("Motivo Incumplimiento", "pod_modal", [
        ".rejection-reason",
        ".non-compliance",
        "[data-field='abnormal_reason']",
    ])

    BTN_NEXT_PAGE = SelectorStrategy("Página Siguiente", "search_button", [
        "button.btn-next",
        ".pagination-next",
        "button:has-text('Siguiente')",
    ])

    # Menú de navegación hacia el módulo DSP (sin clave en SELECTORS: solo heurísticas)
    NAV_DSP_MENU = SelectorStrategy("Menú DSP", "nav_dsp_menu", [
        "a:has-text('DSP')",
        "li:has-text('DSP')",
        "[role='menuitem']:has-text('DSP')",
    ])

    # Nombres usados por browser.py y pod_scraper.py: alias de las estrategias de arriba
    MODAL_CONTAINER = DETAIL_MODAL
    MODAL_POD_IMAGES = MODAL_IMAGES
    MODAL_CLOSE_BUTTON = BTN_CLOSE_MODAL
    MODAL_SIGNATURE = MODAL_SIGNATURE_IMG
