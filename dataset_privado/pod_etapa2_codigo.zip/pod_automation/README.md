# Gofo Express DSP — Sistema Automatizado de Verificación y Auditoría de POD

[![Python Version](https://img.shields.io/badge/Python-3.10%2B-blue.svg)](https://www.python.org/)
[![Playwright](https://img.shields.io/badge/Playwright-Automation-green.svg)](https://playwright.dev/)
[![OpenCV](https://img.shields.io/badge/OpenCV-Computer%20Vision-red.svg)](https://opencv.org/)
[![Status](https://img.shields.io/badge/Status-READ--ONLY%20Auditing-success.svg)]()
[![Tests](https://img.shields.io/badge/Tests-37%20Passed-brightgreen.svg)]()

Solución integral de **RPA (Robotic Process Automation)** con **Playwright**, **Computer Vision (OpenCV / Pillow / imagehash)**, motor de reglas heurísticas, sistema de checkpoints transaccional en **SQLite** y exportación ejecutiva a **Excel**.

Diseñado específicamente para auditoría de comprobantes de entrega (*Proof of Delivery - POD*) en empresas de reparto (DSP) operando con **Gofo Express**.

---

## 🔒 Política de Seguridad y Control (Fase 13 — Read-Only First)

El sistema ha sido construido bajo un estricto principio de **solo lectura e inocuidad**:

### ✅ Acciones Permitidas para el Bot:
- **Leer** el estado actual de las entregas y comprobantes.
- **Navegar** de forma controlada y segura por el portal DSP.
- **Abrir** modales de detalle de cada POD para inspección.
- **Descargar o guardar** fotografías accesibles para auditoría local.
- **Capturar capturas de pantalla** de evidencia y de diagnóstico de errores.
- **Exportar reportes y métricas** a Excel y registrar auditorías en SQLite y logs.

### 🚫 Acciones Estrictamente Prohibidas (El Bot NUNCA las realizará):
- **NO rechaza** automáticamente ningún POD.
- **NO aprueba** automáticamente ningún POD.
- **NO altera estados** de entrega ni flags en la plataforma.
- **NO envía formularios de decisión** ni peticiones destructivas.
- **NO elimina datos** ni cancela registros.
- **NO modifica información** en el portal bajo ninguna circunstancia.
- **NO realiza reconocimiento facial** ni perfilamiento biométrico de personas.

> [!IMPORTANT]
> Cualquier automatización futura que pueda modificar el estado de un POD requerirá confirmación explícita del usuario antes de cada lote y deberá implementarse en un módulo completamente separado del modo de solo lectura.

---

## 📋 Características Principales

1. **Interfaz CLI Interactiva y Modo Live:**
   - Menú interactivo con navegación simple (`1. Procesar fecha`, `2. Reanudar proceso`, `3. Ver configuración`, `4. Salir`).
   - Tarjeta en vivo en consola mostrando progreso en tiempo real (`Procesando POD X / Y`, `Tracking`, `Fotos`, `Estado`, `Resultado`).
2. **Acceso Asistido Seguro (Zero-Password):**
   - El operador realiza el login manual de forma segura en el navegador visible.
   - Las credenciales nunca se guardan en código fuente, archivos ni logs.
3. **Sistema de Checkpoints y Reanudación (SQLite ACID):**
   - Base de datos local en `storage/pod_checkpoints.db`.
   - Si un lote de 1,000 registros se interrumpe en el POD 500, la siguiente ejecución detecta el avance, solicita confirmación y reanuda en el registro 501 sin duplicar registros.
4. **Motor de Análisis de Calidad Fotográfica (Local, sin IA externa obligatoria):**
   - **Desenfoque:** Varianza Laplaciana de nitidez.
   - **Brillo extremo:** Detección de fotos subexpuestas (negras/cámara tapada) y sobreexpuestas (deslumbradas).
   - **Validación de integridad:** Detección de imágenes corruptas o vacías.
   - **Interfaz desacoplada:** Preparada para conectar modelos multimodales o proveedores de Computer Vision en la nube si se requiere en el futuro.
5. **Detección Avanzada de Duplicados y Fraude:**
   - **SHA-256:** Coincidencia exacta de ficheros bit a bit.
   - **Difference Hash (dHash / pHash):** Detección perceptual de fotos idénticas o ligeramente modificadas (recortes, recompresión) con umbral de Distancia de Hamming configurable.
   - Taxonomía estandarizada: `Exact Duplicate`, `Possible Visual Duplicate`, `Unique`.
   - Registro de auditoría con detalles de fotos comparadas.
6. **Motor de Reglas de Compliance:**
   - Clasificación determinista: `VALID / LIKELY VALID`, `REVIEW REQUIRED`, `POSSIBLE ISSUE`, `ERROR`.
   - Cero rechazos ciegos: siempre prioriza la revisión humana.
7. **Exportación a Excel Profesional (`pandas` + `openpyxl`):**
   - Hoja `POD Results` con 20 columnas normalizadas.
   - Formato condicional semaforizado (Verde: Aprobado/Válido, Amarillo: Requiere Revisión, Rojo: Posible Problema/Error).
   - Hoja `Summary` con métricas ejecutivas, conteo de duplicados y totales.
8. **Modo Inspección (`python main.py inspect`):**
   - Herramienta para analizar la estructura DOM de la plataforma real sin alterar datos.
   - Extrae `page_dump.html`, `screenshot_full.png`, `elements_catalog.json` y `inspection_summary.md`.
9. **Generador de Datos de Demostración Offline:**
   - Permite probar el 100% de la lógica, el motor de CV, los checkpoints y el reporte Excel sin necesidad de conectarse a la plataforma real.

---

## 🗂️ Arquitectura y Estructura del Proyecto

```
pod_automation/
├── config.py                   # Configuración centralizada, variables de entorno y umbrales
├── main.py                     # CLI interactivo, comandos inspect, demo, date y resume
├── generate_demo_dataset.py    # Generador de datos sintéticos para pruebas offline
├── requirements.txt            # Dependencias del proyecto
├── .env.example                # Plantilla de variables de entorno
├── README.md                   # Manual técnico de usuario (este archivo)
│
├── automation/                 # Módulo RPA y Playwright
│   ├── browser.py              # Gestión del navegador Chromium (visible / slow_mo)
│   ├── login.py                # Asistente de inicio de sesión manual seguro
│   ├── dashboard.py            # Navegación del dashboard DSP
│   ├── pod_scraper.py          # Extracción de lista, apertura de modal, capturas y reintentos
│   ├── selectors.py            # Capa centralizada de selectores con contingencia (fallbacks)
│   ├── inspector.py            # Herramienta de inspección DOM no destructiva
│   └── audit_logger.py         # Logger estructurado con sanitización de contraseñas
│
├── models/                     # Modelos de Datos Tipados (Pydantic / Dataclasses)
│   └── pod.py                  # PODRecord, ImageQualityMetrics, Enums, serialización
│
├── processing/                 # Motores de Auditoría y Computer Vision
│   ├── image_analysis.py       # Algoritmos de brillo, nitidez, resolución y hashes
│   ├── duplicate_detection.py  # Detección de duplicados exactos y perceptuales
│   ├── rules.py                # Reglas de negocio configurables
│   └── validator.py            # Evaluador maestro que asigna el veredicto final
│
├── storage/                    # Persistencia y Almacenamiento Local
│   ├── checkpoint_manager.py   # Gestor de checkpoints transaccionales en SQLite
│   ├── pod_checkpoints.db      # Base de datos SQLite de checkpoints
│   ├── logs/                   # Archivos de auditoría cronológica (audit_*.log)
│   ├── screenshots/            # Capturas de pantalla automáticas ante incidencias
│   ├── inspection/             # Volcados del modo inspect (HTML, JSON, PNG, MD)
│   └── pod_images/             # Fotografías descargadas organizadas por tracking
│
├── export/                     # Capa de Reportes y Salidas
│   └── excel_exporter.py       # Generador de Excel con formato condicional y Summary
│
├── output/                     # Destino de reportes generados (.xlsx)
│   └── POD_Audit_Report_*.xlsx # Hojas de cálculo con formato condicional
│
└── tests/                      # Suite de Pruebas Automatizadas (37 tests)
    ├── test_phase6_to_13.py    # Pruebas integrales de fases 6 a 13
    ├── test_phase5_image_analysis.py
    ├── test_duplicate_detection.py
    ├── test_rule_engine_phase4.py
    ├── test_pod_model_and_storage.py
    ├── test_excel_export.py
    ├── test_image_analysis.py
    ├── test_validator.py
    └── test_pipeline_mock.py
```

---

## 💻 Instalación en Windows (Paso a Paso)

### 1. Requisitos del Sistema
- **Windows 10** o **Windows 11** (64 bits).
- **Python 3.10 o superior** (recomendado Python 3.11, 3.12 o 3.13) instalado y añadido al `PATH`.
- Acceso a Internet para la descarga inicial de paquetes.

### 2. Abrir Terminal de PowerShell
Abra PowerShell en la raíz del proyecto:
```powershell
cd C:\Users\luisv\.gemini\antigravity-ide\scratch\pod_automation
```

### 3. Crear y Activar el Entorno Virtual
```powershell
# Crear el entorno virtual
python -m venv venv

# Activar el entorno virtual
.\venv\Scripts\Activate.ps1
```
*(Si PowerShell muestra un error de directiva de ejecución, ejecute: `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` y vuelva a activar).*

### 4. Instalar Dependencias
```powershell
pip install --upgrade pip
pip install -r requirements.txt
```

### 5. Instalar los Navegadores de Playwright
```powershell
playwright install chromium
```

### 6. Configurar Variables de Entorno (Opcional)
Copie la plantilla `.env.example` a `.env`:
```powershell
Copy-Item .env.example .env
```

---

## ⚡ Comandos Exactos para Ejecutar

### 1. Menú Interactivo Principal
Inicia la consola interactiva con las 4 opciones estándar:
```powershell
python main.py
```
```
================================================================================
  SISTEMA DE VERIFICACIÓN Y AUDITORÍA DE POD (DSP) — MODO READ-ONLY
================================================================================
  1. Procesar fecha
  2. Reanudar proceso anterior
  3. Ver configuración
  4. Salir
================================================================================
Selecciona una opción [1-4]:
```

### 2. Modo Demostración Offline (Sin requerir acceso a la plataforma)
Ejecuta una simulación completa con 10 casos reales de prueba (entregas válidas, fotos borrosas, sobreexpuestas, subexpuestas, fotos idénticas SHA-256, fotos perceptual hash similares e incidencias de plataforma):
```powershell
python main.py demo
```
O directamente:
```powershell
python generate_demo_dataset.py
```
*Genera el reporte Excel completo en `output/POD_Audit_Report_Demo_*.xlsx` y registra la sesión en SQLite y logs.*

### 3. Modo Inspección de Plataforma (`inspect`)
Abre el navegador en modo visible para que inicies sesión manualmente y captura el estado de la plataforma para extraer los selectores reales:
```powershell
python main.py inspect
```
*Guarda los artefactos en `storage/inspection/` (`page_dump.html`, `screenshot_full.png`, `elements_catalog.json`, `inspection_summary.md`).*

### 4. Procesar una Fecha Directamente por Línea de Comandos
```powershell
python main.py --date 09/12/2026
```

### 5. Reanudar un Proceso Interrumpido
Si el procesamiento se canceló a la mitad, reanuda automáticamente desde el último POD auditado sin duplicar registros:
```powershell
python main.py --resume
```

### 6. Ejecutar la Suite de Pruebas Automatizadas
Verifica que los 37 tests unitarios y de integración pasen satisfactoriamente:
```powershell
pytest tests/ -v
```

---

## ⚙️ Configuración del Sistema (`config.py` / `.env`)

El archivo [config.py](file:///C:/Users/luisv/.gemini/antigravity-ide/scratch/pod_automation/config.py) centraliza todos los parámetros operativos y de seguridad:

| Parámetro | Valor por Defecto | Descripción |
|---|---|---|
| `HEADLESS` | `False` | Navegador visible para supervisión humana continua |
| `SLOW_MO` | `100` (ms) | Pausa entre acciones del bot para naturalidad y visibilidad |
| `DEFAULT_TIMEOUT` | `30000` (ms) | Tiempo de espera máximo para elementos web |
| `MAX_RETRIES` | `3` | Intentos por POD antes de marcar error y continuar |
| `OUTPUT_DIRECTORY` | `./output` | Carpeta de exportación de hojas Excel |
| `SCREENSHOT_ON_ERROR`| `True` | Captura automática de pantalla en `storage/screenshots/` |
| `DATE_FORMAT` | `MM/DD/YYYY` | Formato estándar de fecha de la plataforma |
| `DUPLICATE_THRESHOLD`| `5` | Umbral de Distancia de Hamming para dHash (64 bits) |
| `READ_ONLY_MODE` | `True` | **Garantía de solo lectura**. Impide mutaciones |
| `MAX_BRIGHTNESS` | `240.0` | Umbral superior de brillo medio (sobreexposición) |
| `MIN_BRIGHTNESS` | `25.0` | Umbral inferior de brillo medio (subexposición / negro) |
| `BLUR_THRESHOLD` | `100.0` | Varianza Laplaciana mínima de nitidez |

---

## 📊 Formato de Exportación a Excel (`POD Results` y `Summary`)

El exportador genera un archivo Excel profesional con dos hojas:

### Hoja 1: `POD Results` (20 Columnas Normalizadas)
1. **Tracking**: Número de guía / seguimiento.
2. **Stop**: Número de parada en ruta.
3. **Driver**: Identificador del conductor.
4. **Station**: Estación o almacén de origen.
5. **Address**: Dirección de entrega.
6. **Delivery Status**: Estado reportado por la plataforma (`Delivered`, etc.).
7. **Delivery Date**: Fecha de entrega (`MM/DD/YYYY`).
8. **Delivery Type**: Tipo de entrega (`Front Door`, `Customer`, `Porch`, etc.).
9. **Photos Count**: Cantidad de fotos adjuntas.
10. **Package Visible**: Indicador de paquete visible.
11. **Property/Door Visible**: Indicador de puerta/propiedad visible.
12. **Address Visible**: Indicador de número visible.
13. **Image Quality**: Diagnóstico de calidad (`EXCELLENT`, `ACCEPTABLE`, `BLURRY`, `TOO_DARK`, `TOO_BRIGHT`).
14. **Duplicate Photo**: Detección de duplicados (`Exact Duplicate`, `Possible Visual Duplicate`, `Unique`).
15. **Validation Result**: Veredicto ejecutivo con **formato condicional tricolor**:
    - 🟢 **VERDE (`#D4EDDA`)**: `APPROVED / VALID`
    - 🟡 **AMARILLO (`#FFF3CD`)**: `REVIEW REQUIRED`
    - 🔴 **ROJO (`#F8D7DA`)**: `POSSIBLE INVALID POD / ERROR`
16. **Confidence Score**: Puntuación de confianza (0.0 a 100.0%).
17. **Requires Manual Review**: Indicador booleano para triaje humano.
18. **Non Compliance Reason**: Motivo exacto de la advertencia o fallo.
19. **Processing Status**: Estado del pipeline (`COMPLETED`, `FAILED`).
20. **Error**: Detalle técnico del error si ocurrió alguno.

### Hoja 2: `Summary`
Métricas consolidadas de la ejecución:
- Total de POD procesados.
- Total de POD válidos.
- Total que requieren revisión manual.
- Total con errores de procesamiento.
- Total de fotografías analizadas.
- Total de posibles duplicados detectados.

---

## 🔍 Modo Inspect y Conexión con la Plataforma Real

### ¿Por qué existe una capa de selectores centralizada?
La plataforma DSP de Gofo Express es privada y sus selectores HTML deben ser mapeados a partir de una sesión real. Por diseño de ingeniería y seguridad, **no se deben inventar selectores aleatorios**.

Todos los selectores se gestionan de forma centralizada en el archivo [automation/selectors.py](file:///C:/Users/luisv/.gemini/antigravity-ide/scratch/pod_automation/automation/selectors.py):

```python
SELECTORS = {
    "date_input": None,
    "search_button": None,
    "pod_list": None,
    "pod_card": None,
    "tracking_number": None,
    "pod_modal": None,
    "pod_images": None,
    "close_modal": None,
}
```

### ¿Cómo utilizar la herramienta de inspección?
1. Ejecute:
   ```powershell
   python main.py inspect
   ```
2. El navegador Chromium se abrirá de forma visible.
3. Inicie sesión manualmente en la plataforma con sus credenciales habituales.
4. Navegue a la página de consulta de PODs donde se visualiza la tabla o lista de entregas.
5. Regrese a la consola y presione **[ENTER]** para confirmar.
6. El inspector extraerá automáticamente:
   - `storage/inspection/page_dump.html`: El código HTML completo y rendered de la vista.
   - `storage/inspection/screenshot_full.png`: Captura de pantalla de la página actual.
   - `storage/inspection/elements_catalog.json`: Inventario de botones, inputs, modales e imágenes con sus atributos (`data-testid`, `id`, `name`, `aria-label`, `class`).
   - `storage/inspection/inspection_summary.md`: Resumen legible con recomendaciones.

### 📋 ¿Qué información específica necesitas proporcionarme para completar la conexión?

Para configurar los selectores reales y dejar el scraper 100% operativo en producción, compárteme los siguientes datos (o el archivo `inspection_summary.md` generado):

| Elemento Requerido | Función en la Plataforma | Tipo de Selector Preferido |
|---|---|---|
| **1. Selector del campo de fecha** (`date_input`) | Campo donde se escribe o selecciona la fecha a consultar (ej: `input[name="date"]`, `[data-testid="date-picker"]`, `#deliveryDate`). | `data-testid` > `name` > `id` |
| **2. Selector del botón de búsqueda** (`search_button`) | Botón que ejecuta la consulta de entregas tras fijar la fecha (ej: `button:has-text("Search")`, `button:has-text("Consultar")`). | `data-testid` > Texto/ARIA > Clases CSS |
| **3. Selector del contenedor de la lista** (`pod_list`) | Tabla (`<tbody>`), cuadrícula (`div.grid`) o lista donde aparecen todos los registros. | `data-testid` > `id` > Clase contenedora |
| **4. Selector de la tarjeta/fila individual** (`pod_card`) | Selector correspondiente a una fila individual (`<tr>`) o tarjeta de entrega. | `table tbody tr` > `div.pod-card` |
| **5. Selector del número de tracking** (`tracking_number`) | Elemento dentro de la fila o modal que contiene el código de seguimiento (ej: `span.tracking-id`, `td[data-col="tracking"]`). | `data-testid` > Clase semántica |
| **6. Selector del modal de detalle** (`pod_modal`) | Ventana emergente o panel lateral que se abre al hacer clic sobre una entrega para ver sus fotos. | `div.modal-dialog`, `[role="dialog"]`, `div.drawer` |
| **7. Selector de las fotografías** (`pod_images`) | Etiquetas `<img>` dentro del modal o tarjeta que contienen las fotos del POD. | `img.pod-photo`, `div.modal img` |
| **8. Selector del botón para cerrar el modal** (`close_modal`) | Botón o cruz para cerrar el detalle y pasar a la siguiente entrega (ej: `button.close`, `button[aria-label="Close"]`). | `aria-label` > `data-testid` > Clases CSS |

#### Regla de Oro para los Selectores:
Se priorizan en este orden:
1. `data-testid` o atributos personalizados para testing (`data-cy`, `data-qa`).
2. Roles accesibles ARIA (`role="button"`, `role="dialog"`).
3. Atributos semánticos (`name`, `aria-label`, `title`).
4. Clases CSS estables e IDs únicos.
5. **Se evitan selectores XPath absolutos o frágiles** (ej: `/html/body/div[3]/div[2]/table...`).

---

## 🛡️ Registro de Auditoría y Gestión de Errores

- **Archivos de Log:** Se almacenan en `storage/logs/audit_YYYYMMDD_HHMMSS.log`.
- **Sanitización de Datos:** Cualquier contraseña, token de autenticación o dato sensible es automáticamente anonimizado antes de ser escrito en los logs.
- **Resiliencia ante Fallos:** Si un POD falla tras `MAX_RETRIES` (3 intentos):
  1. Se toma una captura de pantalla del error en `storage/screenshots/error_<tracking>_<timestamp>.png`.
  2. Se registra el error detallado en el log y en la base de datos de checkpoints.
  3. El bot **continúa con el siguiente POD** sin abortar la ejecución del lote completo.
- **Auditoría Humana Garantizada:** Cualquier entrega dudosa es clasificada como `REVIEW REQUIRED` o `POSSIBLE ISSUE`, permitiendo al equipo del DSP revisar directamente la fotografía local enlazada.

---

## 📄 Licencia

Uso exclusivo interno para operaciones de DSP con Gofo Express. Prohibida su distribución no autorizada.
